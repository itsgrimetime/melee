from pathlib import Path
import subprocess,json
p=Path('src/melee/mn/mnsnap.c');base=p.read_text();out=Path('/tmp/c016-snap-source-probes');out.mkdir(exist_ok=True)
variants={}
for field in ['main_joint','main_shapeanim','warn_animjoint']:
 old='    return &snap->'+field+';'
 assert base.count(old)==1
 for kind,new in [('embedded','    void** result;\n    struct { void** ptr; } ref;\n    return result = (ref.ptr = &snap->'+field+');'),('context','    struct { void** ptr; } ref;\n    ref.ptr = &snap->'+field+';\n    return ref.ptr;')]:variants[field+'-'+kind]=base.replace(old,new)
start=base.index('mnSnap_CreateThumbnails(');end=base.index('/// Entry point:',start)
for mode in ['embedded','sequential']:
 for axes in ['x','xyz']:
  block=base[start:end]
  for axis in axes:
   old=f'    step_{axis} = end_pos.{axis} - start_pos.{axis};'
   new=f'    step_{axis} = (end_pos.{axis} = end_pos.{axis} - start_pos.{axis});' if mode=='embedded' else f'    end_pos.{axis} = end_pos.{axis} - start_pos.{axis};\n    step_{axis} = end_pos.{axis};'
   assert old in block;block=block.replace(old,new)
  variants['delta-'+mode+'-'+axes]=base[:start]+block+base[end:]
rows=[]
try:
 for name,source in variants.items():
  p.write_text(source);(out/(name+'.c')).write_text(source)
  r=subprocess.run(['python','tools/checkdiff.py','mnSnap_80257F24','--format','json'],capture_output=True,text=True)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d.get('structural')}
  except Exception:row={'name':name,'error':r.stdout[-300:]+r.stderr[-300:]}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base)
(out/'summary.json').write_text(json.dumps(rows,indent=2))

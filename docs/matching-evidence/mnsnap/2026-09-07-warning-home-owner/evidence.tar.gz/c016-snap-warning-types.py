from pathlib import Path
import subprocess,json
p=Path('src/melee/mn/mnsnap.c');base=p.read_text();out=Path('/tmp/c016-snap-warning-types');out.mkdir(exist_ok=True)
variants={}
start=base.index('void mnSnap_80257F24(void)')
for name,typ in [('descriptor','HSD_AnimJoint**'),('const-field','void* const*'),('const-pointee','const void**')]:
 part=base[start:].replace('    void** warn_animjoint;','    '+typ+' warn_animjoint;',1)
 part=part.replace('warn_animjoint = &snap->warn_animjoint;','warn_animjoint = ('+typ+') &snap->warn_animjoint;',1)
 for direct in [False,True]:
  pp=part.replace('mnSnap_GetWarnAnimJoint(snap)','warn_animjoint',1) if direct else part
  variants[name+('-direct' if direct else '-getter')]=base[:start]+pp
rows=[]
try:
 for name,source in variants.items():
  p.write_text(source);(out/(name+'.c')).write_text(source)
  r=subprocess.run(['python','tools/checkdiff.py','mnSnap_80257F24','--format','json'],capture_output=True,text=True)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d.get('structural')}
  except Exception:row={'name':name,'error':r.stdout[-300:]+r.stderr[-300:]}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base)
(out/'summary.json').write_text(json.dumps(rows,indent=2))

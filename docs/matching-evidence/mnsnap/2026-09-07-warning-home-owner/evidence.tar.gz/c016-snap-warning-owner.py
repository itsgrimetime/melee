from pathlib import Path
import subprocess,json
p=Path('src/melee/mn/mnsnap.c');base=p.read_text();out=Path('/tmp/c016-snap-warning-owner');out.mkdir(exist_ok=True)
variants={}
start=base.index('void mnSnap_80257F24(void)')
for value in ['mnSnap_GetWarnAnimJoint(snap)','&snap->warn_animjoint']:
 part=base[start:].replace('    warn_animjoint = &snap->warn_animjoint;\n','',1)
 part=part.replace('mnSnap_GetWarnAnimJoint(snap)','(warn_animjoint = '+value+')',1)
 variants['embedded-'+('getter' if value.startswith('mnSnap') else 'field')]=base[:start]+part
old='static inline void** mnSnap_GetWarnAnimJoint(mnSnap_State* snap)\n{\n    return &snap->warn_animjoint;\n}'
for name,body in [('return-assignment','    return *out = &snap->warn_animjoint;'),('separate','    *out = &snap->warn_animjoint;\n    return *out;'),('nested-result','    void** result;\n    return result = (*out = &snap->warn_animjoint);')]:
 new='static inline void** mnSnap_GetWarnAnimJoint(mnSnap_State* snap, void*** out)\n{\n'+body+'\n}'
 text=base.replace(old,new).replace('mnSnap_GetWarnAnimJoint(snap)','mnSnap_GetWarnAnimJoint(snap, &warn_animjoint)')
 text=text.replace('    warn_animjoint = &snap->warn_animjoint;\n','',1)
 variants['output-'+name]=text
rows=[]
try:
 for name,source in variants.items():
  p.write_text(source);(out/(name+'.c')).write_text(source)
  r=subprocess.run(['python','tools/checkdiff.py','mnSnap_80257F24','--format','json'],capture_output=True,text=True)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d.get('structural')}
  except Exception:row={'name':name,'error':r.stdout[-300:]+r.stderr[-300:]}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base)
(out/'summary.json').write_text(json.dumps(rows,indent=2))

from pathlib import Path
import subprocess,json
p=Path('src/melee/mn/mnsnap.c');base=p.read_text();out=Path('/tmp/c016-snap-warning-update');out.mkdir(exist_ok=True)
variants={}
old='    warn_animjoint = &snap->warn_animjoint;'
forms={'previous-field':'    warn_animjoint = &snap->warn_joint;\n    warn_animjoint++;','next-field':'    warn_animjoint = &snap->warn_matanim;\n    warn_animjoint--;','add-assign':'    warn_animjoint = &snap->warn_joint;\n    warn_animjoint += 1;','embedded-update':'    warn_animjoint = &snap->warn_joint;\n    ++warn_animjoint;'}
for name,new in forms.items():
 text=base.replace(old,new)
 for getter in [True,False]:
  t=text if getter else text.replace('mnSnap_GetWarnAnimJoint(snap)','warn_animjoint',1)
  variants[name+('-getter' if getter else '-direct')]=t
rows=[]
try:
 for name,source in variants.items():
  p.write_text(source);(out/(name+'.c')).write_text(source)
  r=subprocess.run(['python','tools/checkdiff.py','mnSnap_80257F24','--format','json'],capture_output=True,text=True)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d.get('structural')}
  except Exception:row={'name':name,'error':r.stdout[-300:]+r.stderr[-300:]}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base)
(out/'summary.json').write_text(json.dumps(rows,indent=2))

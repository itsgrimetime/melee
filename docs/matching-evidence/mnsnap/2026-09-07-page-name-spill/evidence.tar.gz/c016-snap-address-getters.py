from pathlib import Path
import subprocess,json
p=Path('src/melee/mn/mnsnap.c');base=p.read_text();out=Path('/tmp/c016-snap-address-getters');out.mkdir(exist_ok=True)
variants={}
getters=[('mnSnap_GetWarnAnimJoint','warn_animjoint'),('mnSnap_GetMainJoint','main_joint'),('mnSnap_GetMainShapeAnim','main_shapeanim')]
for mask in range(1,8):
 text=base;names=[]
 for i,(fn,var) in enumerate(getters):
  if mask&(1<<i):
   old='static inline void** '+fn+'(mnSnap_State* snap)\n{\n    return &snap->'+var+';\n}'
   new='static inline void** '+fn+'(void*** resource)\n{\n    return *resource;\n}'
   assert old in text;text=text.replace(old,new);text=text.replace(fn+'(snap)',fn+'(&'+var+')');names.append(var)
 variants['address-'+'-'.join(names)]=text
rows=[]
try:
 for name,source in variants.items():
  p.write_text(source);(out/(name+'.c')).write_text(source)
  r=subprocess.run(['python','tools/checkdiff.py','mnSnap_80257F24','--format','json'],capture_output=True,text=True)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d.get('structural')}
  except Exception:row={'name':name,'error':r.stdout[-300:]+r.stderr[-300:]}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base)
(out/'summary.json').write_text(json.dumps(rows,indent=2))

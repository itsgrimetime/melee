from pathlib import Path
import sys,json,re
sys.path.insert(0,'/Users/mike/.codex/worktrees/d82d549a-e85c-4cac-95c7-4578ab792d23/melee/tools/melee-agent')
from src.mwcc_debug.parser import parse_pcdump
from src.mwcc_debug.colorgraph_parser import parse_hook_events
rows=[]
for tag in ['retained-equality']:
 text=Path('/tmp/c016-snap-'+tag+'-fresh.txt').read_text();p=next(p for p in parse_pcdump(text,function='mnSnap_80257F24')[0].passes if p.name=='AFTER PEEPHOLE FORWARD')
 defs={};ins=[]
 for bi,ii,x in p.all_instructions():
  if x.opcode=='bl' and 'lbArchive_LoadSections' in x.operands:break
  ins.append((x.opcode,x.operands))
  if x.regs:defs.setdefault(x.regs[0][1],[]).append(x.opcode+' '+x.operands)
 e=next(f for f in parse_hook_events(text) if f.name=='mnSnap_80257F24')
 rounds=[]
 for c in e.colorgraph_sections:
  if c.class_id!=0:continue
  spilled=[{'ig':d.ig_idx,'defs':defs.get(d.ig_idx,[])} for d in c.decisions if d.flags&1]
  rounds.append({'result':c.result,'spills':spilled})
 row={'tag':tag,'rounds':rounds,'early_instructions':ins};rows.append(row)
 print(tag,json.dumps(rounds,indent=2))
Path('/tmp/c016-snap-retained-spills.json').write_text(json.dumps(rows,indent=2))

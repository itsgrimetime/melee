from pathlib import Path
import subprocess,json
p=Path('src/melee/mn/mnsnap.c');base=p.read_text();out=Path('/tmp/c016-snap-page-lifetime');out.mkdir(exist_ok=True)
variants={}
start=base.index('void mnSnap_80257F24(void)')
part=base[start:]
part=part.replace('    void** main_load;','    const char* page_name;\n    void** main_load;',1)
part=part.replace('    main_joint = &snap->main_joint;','    main_joint = &snap->main_joint;\n    page_name = "MenMainPhotoSn_Top_joint";',1)
part=part.replace('"MenMainPhotoSn_Top_joint", arrows_joint','page_name, arrows_joint',1)
for where,needle in [('before','    /* Main GObj */'),('aftercreate','    snap->main_gobj = gobj;')]:
 for op in ['!=','==']:
  comparison='    (void) ((const void*) page_name '+op+' (const void*) snap);\n'
  variants[where+('neq' if op=='!=' else 'eq')]=base[:start]+part.replace(needle,comparison+needle,1)
variants['named-control']=base[:start]+part
rows=[]
try:
 for name,source in variants.items():
  p.write_text(source);(out/(name+'.c')).write_text(source)
  r=subprocess.run(['python','tools/checkdiff.py','mnSnap_80257F24','--format','json'],capture_output=True,text=True)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d.get('structural')}
  except Exception:row={'name':name,'error':r.stdout[-300:]+r.stderr[-300:]}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base)
(out/'summary.json').write_text(json.dumps(rows,indent=2))

from pathlib import Path
import subprocess,json
p=Path('src/melee/mn/mnsnap.c');base=p.read_text();out=Path('/tmp/c016-snap-getter-reuse');out.mkdir(exist_ok=True)
variants={}
start=base.index('void mnSnap_80257F24(void)')
pairs=[('mnSnap_GetWarnAnimJoint(snap)','warn_animjoint'),('mnSnap_GetMainJoint(snap)','main_joint'),('mnSnap_GetMainShapeAnim(snap)','main_shapeanim')]
for mask in range(1,8):
 part=base[start:];names=[]
 for i,(call,var) in enumerate(pairs):
  if mask&(1<<i):part=part.replace(call,var,1);names.append(var)
 variants['direct-'+'-'.join(names)]=base[:start]+part
rows=[]
try:
 for name,source in variants.items():
  p.write_text(source);(out/(name+'.c')).write_text(source)
  r=subprocess.run(['python','tools/checkdiff.py','mnSnap_80257F24','--format','json'],capture_output=True,text=True)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.stderr')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d.get('structural')}
  except Exception:row={'name':name,'error':r.stdout[-300:]+r.stderr[-300:]}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base)
(out/'summary.json').write_text(json.dumps(rows,indent=2))

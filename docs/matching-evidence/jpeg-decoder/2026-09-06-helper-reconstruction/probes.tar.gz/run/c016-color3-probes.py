from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B5C.c'); baseline=p.read_text(); root=Path('/tmp/c016-color3-probes');root.mkdir(exist_ok=True)
(root/'baseline.c').write_text(baseline)
start=baseline.index('static inline void jpeg_store_rgb565('); fnstart=baseline.index('static void fn_803B6820('); end=baseline.index('static inline s32 hsd_803B6BE4_inline',fnstart)
helper=baseline[start:fnstart];body=baseline[fnstart:end]; variants={}
def add(name,h=helper,b=body,extra=''):
 variants[name]=baseline[:start]+h+extra+b+baseline[end:]
for typ in ['u16','u32','s32']:
 h=helper.replace('static inline void jpeg_store_rgb565(u16* out,','static inline '+typ+' jpeg_make_rgb565(').replace('*out =','return')
 b=body.replace('jpeg_store_rgb565(out + out_offset, luminance, cb, cr);','out[out_offset] = jpeg_make_rgb565(luminance, cb, cr);')
 add('return-packed-'+typ,h,b)
call='jpeg_store_rgb565(out + out_offset, luminance, cb, cr);'
expr='(((x / 4) * 0x10) +\n                            ((aligned_width << 2) * ((y / 4) + group_y)))'
assert expr in body
for kind in ['offset','pointer']:
 if kind=='offset':
  extra='static inline s32 jpeg_group_offset(s32 x, s32 y, s32 width, s32 group)\n{\n return ((x / 4) * 16) + ((width << 2) * ((y / 4) + group));\n}\n'
  b=body.replace(expr,'jpeg_group_offset(x, y, aligned_width, group_y)')
 else:
  extra='static inline u16* jpeg_group_pointer(u8* dst, s32 x, s32 y, s32 width, s32 group)\n{\n return (u16*) dst + ((x / 4) * 16) + ((width << 2) * ((y / 4) + group));\n}\n'
  b=body.replace('(u16*) dst + '+expr,'jpeg_group_pointer(dst, x, y, aligned_width, group_y)')
 add('group-'+kind,b=b,extra=extra)
# Extract actual bias operation into helper, preserving complete loop body.
bias_start=body.index('    luma_block =');bias_end=body.index('    block_columns =')
bias=body[bias_start:bias_end]
extra='static inline void jpeg_bias_luma(u8* base)\n{\n s32 bias_block, luma_groups, channel;\n s32* luma;\n u8* luma_block;\n'+bias+'}\n'
add('bias-helper',b=body[:bias_start]+'    jpeg_bias_luma(base);\n'+body[bias_end:],extra=extra)
# Move a complete pixel's sample fetching and destination computation together.
pix_start=body.index('                        luminance =');pix_end=body.index(call,pix_start)+len(call)
pix=body[pix_start:pix_end]
extra='static inline void jpeg_store_block_pixel(u16* out, s32* luma_base, u8* base, s32 chroma_row, s32 block, s32 aligned_width)\n{\n s32 luminance, chroma_column, cb, cr, out_offset;\n u8* chroma;\n'+pix+'\n}\n'
add('block-pixel-helper',b=body[:pix_start]+'                        jpeg_store_block_pixel(out, luma_base, base, chroma_row, block, aligned_width);'+body[pix_end:],extra=extra)
# Separate each color's expression and clamp into a helper.
red='(f32) ((1.402 * (f64) cr) + (f64) luminance)'
green='((f32) luminance - (0.3441f * (f32) cb)) - (0.7139f * (f32) cr)'
blue='(f32) ((f64) ((1.7718f * (f32) cb) + (f32) luminance) -\n                        (0.0012 * (f64) cr))'
for which in ['red','green','blue','all']:
 h=helper;extra=''
 for color,ex in [('red',red),('green',green),('blue',blue)]:
  if which not in [color,'all']:continue
  extra+='static inline u8 jpeg_'+color+'(s32 luminance, s32 cb, s32 cr)\n{\n f32 value = '+ex+';\n return jpeg_clamp(value);\n}\n'
  assign=re.compile(r'    '+color+r'_value =\s*'+re.escape(ex)+r';\n    '+('green' if color=='green' else 'pixel.'+color)+r' = jpeg_clamp\('+color+r'_value\);')
  h,n=assign.subn('    '+('green' if color=='green' else 'pixel.'+color)+' = jpeg_'+color+'(luminance, cb, cr);',h);assert n==1,(which,color)
 add('channel-helper-'+which,h=extra+h)
results=[]
try:
 for name,source in variants.items():
  (root/(name+'.c')).write_text(source);p.write_text(source)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:d=json.loads(r.stdout);score=d['fuzzy_match_percent'];c=d.get('classification',{});frame=c.get('stack_frame_sizes',{});reg=c.get('register_allocation_guidance',{}).get('register_only_count')
  except Exception:score=None;frame={};reg=None
  row=dict(name=name,score=score,frame=frame,register_diffs=reg,exit=r.returncode);results.append(row);print(json.dumps(row),flush=True)
finally:
 p.write_text(baseline);(root/'results.json').write_text(json.dumps(results,indent=2)+'\n')

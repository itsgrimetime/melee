from pathlib import Path
import json,subprocess
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();root=Path('/tmp/c016-color3-bias');root.mkdir(exist_ok=True)
a=base.index('    luma_block =',base.index('static void fn_803B6820'));b=base.index('    block_columns =',a);variants={}
for typ in ['int','s32','u32']:
 for pointer in [False,True]:
  chunk='''    luma_block = (u8*) ((JpegState*) base)->work.luma;
    for (bias_block = 0; bias_block < 4; bias_block++) {
        TYPE i;
        luma = (s32*) luma_block;
        for (i = 0; i < 64; i++) {
            OP
        }
        luma_block += 0x100;
    }
'''.replace('TYPE',typ).replace('OP','*luma++ += 0x80;' if pointer else 'luma[i] += 0x80;')
  variants['bias-natural-'+typ+('-pointer' if pointer else '-indexed')]=base[:a]+chunk+base[b:]
for typ in ['int','s32']:
 chunk='''    {
        TYPE i;
        luma = ((JpegState*) base)->work.luma;
        for (i = 0; i < 256; i++) {
            luma[i] += 0x80;
        }
    }
'''.replace('TYPE',typ)
 variants['bias-flat-'+typ]=base[:a]+chunk+base[b:]
rows=[]
try:
 for tag,s in variants.items():
  p.write_text(s);(root/(tag+'.c')).write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(tag+'.json')).write_text(r.stdout);(root/(tag+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':tag,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'classification':d['classification']['primary']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

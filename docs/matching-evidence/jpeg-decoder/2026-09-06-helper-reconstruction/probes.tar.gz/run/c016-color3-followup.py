from pathlib import Path
import json,subprocess,re
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();root=Path('/tmp/c016-color3-followup');root.mkdir(exist_ok=True);old=Path('/tmp/c016-color3-probes');variants={}
for name in ['return-packed-u16','return-packed-u32','channel-helper-all','channel-helper-red','block-pixel-helper']:
 s=(old/(name+'.c')).read_text();start=s.index('static inline s32 jpeg_clamp');end=s.index('static inline s32 hsd_803B6BE4_inline',start)
 variants[name+'-depth8']=s[:start]+'#pragma inline_depth(8)\n'+s[start:end]+'#pragma inline_depth(2)\n'+s[end:]
for name in ['channel-helper-red','channel-helper-green','channel-helper-blue','channel-helper-all']:
 s=(old/(name+'.c')).read_text()
 s,n=re.subn(r' return jpeg_clamp\(value\);', ' if (value < 0.0f) return 0;\n if (255.0f < value) return 255;\n return (u8)(s32)value;',s)
 assert n in [1,3],(name,n)
 variants[name+'-flat-clamp']=s
# Diagnostic explicit instruction intrinsics with the same RGB565 masks.
s=base.replace('static inline void jpeg_store_rgb565','int __rlwimi(int, int, int, int, int);\n\nstatic inline void jpeg_store_rgb565',1)
oldpack='*out = ((pixel.red << 8) & 0xF800) | ((pixel.green << 3) & 0x7E0) |\n           (pixel.blue >> 3U);'
assert oldpack in s
variants['pack-rlwimi-diagnostic']=s.replace(oldpack,'*out = __rlwimi(__rlwimi((pixel.green << 3) & 0x7E0, pixel.red, 8, 16, 20), pixel.blue, 29, 27, 31);')
# New lifetime boundary: process complete tile groups via a helper, keeping bias in parent.
a=base.index('static void fn_803B6820('); b=base.index('static inline s32 hsd_803B6BE4_inline',a);body=base[a:b]
loopstart=body.index('    block_columns =');loopend=body.rfind('}')
decls=body[body.index('{')+1:body.index('    base =')];loops=body[loopstart:loopend]
extra='static inline void jpeg_store_groups(u8* dst, s32 x, s32 y, s32 width, u8* base)\n{'+decls.replace('    u8* base;\n','')+loops+'}\n\n'
newbody=body[:loopstart]+'    jpeg_store_groups(dst, x, y, width, base);\n'+body[loopend:]
variants['tile-groups-helper']=base[:a]+extra+newbody+base[b:]
results=[]
try:
 for name,s in variants.items():
  (root/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:d=json.loads(r.stdout);score=d['fuzzy_match_percent'];c=d['classification'];frame=c.get('stack_frame_sizes');reg=c.get('register_allocation_guidance',{}).get('register_only_count')
  except Exception:score=None;frame={};reg=None
  row=dict(name=name,score=score,frame=frame,register_diffs=reg,exit=r.returncode);results.append(row);print(json.dumps(row),flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(results,indent=2)+'\n')

from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-clamp-out');out.mkdir(exist_ok=True)
try:
 for shape in ['return-wrapper','direct-branches']:
  helper='static inline void jpeg_clamp_out(u8* out, f32 value)\n{\n'
  if shape=='return-wrapper':helper+='    *out = jpeg_clamp(value);\n}\n\n'
  else:helper+='    if (value < 0.0f) { *out = 0; return; }\n    if (255.0f < value) { *out = 255; return; }\n    *out = (u8) (s32) value;\n}\n\n'
  for channels in [('red',),('green',),('blue',),('red','green'),('red','green','blue')]:
   s=base.replace('static inline void jpeg_store_rgb565',helper+'static inline void jpeg_store_rgb565')
   for ch in channels:
    dst='green' if ch=='green' else 'pixel.'+ch;s=s.replace(dst+' = jpeg_clamp('+ch+'_value);','jpeg_clamp_out(&'+dst+', '+ch+'_value);')
   name=shape+'-'+'-'.join(channels);(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

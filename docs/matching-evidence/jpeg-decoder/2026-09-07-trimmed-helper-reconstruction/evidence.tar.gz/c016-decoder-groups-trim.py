from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-groups-trim');out.mkdir(exist_ok=True)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);fn=base[a:b];decls=fn[fn.index('{')+1:fn.index('    base =')];start=fn.index('    block_columns =');end=fn.rfind('}');loops=fn[start:end];prefix=fn[fn.index('    base ='):start]
def needed(ds,body,exclude=()):
 lines=[]
 for l in ds.splitlines(True):
  m=re.search(r'(\w+);',l)
  if m and (m[1] in exclude or not re.search(r'\b'+m[1]+r'\b',body)):continue
  lines.append(l)
 return ''.join(lines)
variants=[]
for name in ['plain','start-param','width-param']:
 params='u8* dst, s32 x, s32 y, s32 width, u8* base';args='dst, x, y, width, base';loop=loops;pref=prefix;exclude=['base']
 if name=='start-param':params+=', s32 group_y';args+=', 0';exclude+=['group_y'];loop=loop.replace('group_y = 0;',';')
 if name=='width-param':
  params=params.replace('s32 width','s32 aligned_width');args=args.replace('width','aligned_width');exclude+=['aligned_width']
  k=loop.index('    for (group_y');pref+=loop[:k];loop=loop[k:]
 helper='static inline void jpeg_store_groups('+params+')\n{'+needed(decls,loop,exclude)+loop+'}\n\n'
 call='    jpeg_store_groups('+args+');\n';newfn=fn[:fn.index('{')+1]+needed(decls,pref+call)+pref+call+'}\n'
 variants.append((name,base[:a]+helper+newfn+base[b:]))
try:
 for name,s in variants:
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-loop-params');out.mkdir(exist_ok=True)
a=base.index('    luma_block = (u8*) ((JpegState*) base)->work.luma;',base.index('static void fn_803B6820'))
b=base.index('    block_columns =',a);body=base[a:b]
variants=[]
for name,params,args in [('start','s32 bias_block','0'),('count','s32 group_count','16'),('start-count','s32 bias_block, s32 group_count','0, 16'),('start-limit','s32 bias_block, s32 block_limit','0, 4')]:
 decl='    s32* luma;\n    u8* luma_block;\n    s32 channel;\n    s32 luma_groups;\n'
 if 'bias_block' not in params:decl+='    s32 bias_block;\n'
 hbody=body
 if 'bias_block' in params:hbody=hbody.replace('bias_block = 0;',';')
 if 'group_count' in params:hbody=hbody.replace('luma_groups = 16;','luma_groups = group_count;')
 if 'block_limit' in params:hbody=hbody.replace('bias_block < 4;','bias_block < block_limit;')
 helper='static inline void jpeg_bias_luma(u8* base, '+params+')\n{\n'+decl+hbody+'}\n\n'
 s=base[:a]+'    jpeg_bias_luma(base, '+args+');\n'+base[b:]
 s=s.replace('static void fn_803B6820(',helper+'static void fn_803B6820(')
 variants.append((name,s))
try:
 for name,s in variants:
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

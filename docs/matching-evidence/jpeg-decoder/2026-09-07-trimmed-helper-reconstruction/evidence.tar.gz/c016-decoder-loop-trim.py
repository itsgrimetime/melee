from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-loop-trim');out.mkdir(exist_ok=True)
try:
 for name in ['start','count','start-count','start-limit']:
  s=Path('/tmp/c016-decoder-loop-params/'+name+'.c').read_text();a=s.index('static void fn_803B6820(');b=s.index('static inline s32 hsd_803B6BE4_inline',a)
  fn=s[a:b]
  for decl in ['    s32* luma;\n','    u8* luma_block;\n','    s32 channel;\n','    s32 bias_block;\n','    s32 luma_groups;\n']:fn=fn.replace(decl,'')
  s=s[:a]+fn+s[b:];(out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

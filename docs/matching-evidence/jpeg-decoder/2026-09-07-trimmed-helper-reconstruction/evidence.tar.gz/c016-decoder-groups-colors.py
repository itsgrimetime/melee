from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-groups-colors');out.mkdir(exist_ok=True)
a=base.index('static inline void jpeg_store_rgb565(');b=base.index('static void fn_803B6820(',a);helper=base[a:b];body=helper[helper.index('{')+1:helper.rfind('}')]
call='jpeg_store_rgb565(out + out_offset, luminance, cb, cr);'
try:
 for parent in ['plain','start-param','width-param']:
  for mode in ['pointer','index']:
   s=Path('/tmp/c016-decoder-groups-trim/'+parent+'.c').read_text()
   if mode=='pointer':replacement='{\n    u16* rgb_out = out + out_offset;'+body.replace('*out =','*rgb_out =')+'}'
   else:replacement='{'+body.replace('*out =','out[out_offset] =')+'}'
   assert s.count(call)==1;s=s.replace(call,replacement);name=parent+'-'+mode;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

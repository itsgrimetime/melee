from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-x-helper-width-reuse');out.mkdir(exist_ok=True)
try:
 for mode in ['baseline','raw','quotient','int','local']:
  s=base if mode=='baseline' else Path('/tmp/c016-decoder-x-scalar-helper/'+mode+'.c').read_text()
  a=s.index('static void fn_803B6820(');b=s.index('static inline s32 hsd_803B6BE4_inline',a);fn=s[a:b].replace('    s32 block_columns;\n','');fn=re.sub(r'\bblock_columns\b','width',fn);s=s[:a]+fn+s[b:]
  (out/(mode+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(mode+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(mode,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

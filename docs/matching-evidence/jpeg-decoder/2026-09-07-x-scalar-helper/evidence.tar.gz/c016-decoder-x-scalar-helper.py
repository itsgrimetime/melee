from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-x-scalar-helper');out.mkdir(exist_ok=True)
variants=[]
for red in [False,True]:
 b=base if not red else base.replace('(1.402 * (f64) cr) + (f64) luminance','(f64) luminance + (1.402 * (f64) cr)')
 for mode in ['raw','quotient','int','local']:
  typ='int' if mode=='int' else 's32';expr='x * 16' if mode=='quotient' else '(x / 4) * 16';arg='x / 4' if mode=='quotient' else 'x'
  body=('    s32 offset = '+expr+';\n    return offset;') if mode=='local' else '    return '+expr+';'
  h='static inline '+typ+' jpeg_x_offset('+typ+' x)\n{\n'+body+'\n}\n\n'
  s=b.replace('static void fn_803B6820(',h+'static void fn_803B6820(').replace('(x / 4) * 0x10','jpeg_x_offset('+arg+')')
  variants.append((('red-first-' if red else '')+mode,s))
try:
 for name,s in variants:
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import sys,json,itertools
sys.path.insert(0,str(Path('tools/melee-agent').resolve()))
from src.mwcc_debug.tiebreak import load_gpr_ig,predict_assignments,validate_g1
old=load_gpr_ig(Path('/tmp/c016-decoder-flags-fixed.txt').read_text(),'fn_803B6820');ig=load_gpr_ig(Path('/tmp/c016-decoder-pointer-inequality-scp.txt').read_text(),'fn_803B6820');assert validate_g1(ig).correct==113
cv=lambda n:n+3 if n>=107 else n
target={cv(n):v for n,v in predict_assignments(old).items()}
for x in Path('/tmp/c016-decoder-inequality-mapped-target.txt').read_text().strip().split(','):
 _,n,v=map(int,x.split(':'));target[n]=v
moves=[(65,'after',125),(63,'before',64),(78,'after',125),(37,'after',117),(77,'after',131),(79,'after',76)]
rows=[]
for mask in range(64):
 order=list(ig.select_order);chosen=[]
 for i,(n,side,anchor) in enumerate(moves):
  if mask&(1<<i):order.remove(n);order.insert(order.index(anchor)+(side=='after'),n);chosen.append(i)
 pred=predict_assignments(ig,order=order);diff=[n for n,v in target.items() if pred.get(n)!=v]
 rows.append({'move_indices':chosen,'target_difference_count':len(diff),'target_difference_nodes':diff,'X':pred[65],'chroma':pred[37]})
winners=[r for r in rows if not r['target_difference_count']];print('winners',winners);print('best',sorted(rows,key=lambda r:(r['target_difference_count'],len(r['move_indices'])))[:6])
Path('/tmp/c016-decoder-current-order-model.json').write_text(json.dumps({'scope':'64 subsets of six previously tested abstract SELECT-order moves, remapped to current graph. Not a new simplify reconstruction, source realization, minimality proof or complete physical target proof. Same inherited target extension as node-ablation report; added dead nodes unconstrained.','moves':moves,'rows':rows},indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-block-offset-order');out.mkdir(exist_ok=True)
stmt='''                        out_offset = ((block & 1) << 5) +
                                     (aligned_width * ((block & 2) << 2));
'''
variants=[]
for name,anchor in [('before-luma','                        luminance = luma_base[block * 64];'),('before-cr','                        cr = ((JpegState*) chroma)->work.cr[0];')]:
 variants.append((name,base.replace(stmt,'').replace(anchor,stmt+anchor)))
variants.append(('split-low-first',base.replace(stmt,'                        out_offset = (block & 1) << 5;\n                        out_offset += aligned_width * ((block & 2) << 2);\n')))
variants.append(('split-high-first',base.replace(stmt,'                        out_offset = aligned_width * ((block & 2) << 2);\n                        out_offset += (block & 1) << 5;\n')))
helper='static inline s32 jpeg_block_offset(s32 block, s32 width)\n{\n    return ((block & 1) << 5) + (width * ((block & 2) << 2));\n}\n\n'
for name,call in [('helper','jpeg_block_offset(block, aligned_width)'),('helper-reverse-params','jpeg_block_offset(aligned_width, block)')]:
 h=helper if name=='helper' else helper.replace('(s32 block, s32 width)','(s32 width, s32 block)')
 s=base.replace('static void fn_803B6820(',h+'static void fn_803B6820(').replace(stmt,'                        out_offset = '+call+';\n');variants.append((name,s))
try:
 for name,s in variants:
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import sys,json,itertools
from dataclasses import asdict
sys.path.insert(0,str(Path('tools/melee-agent').resolve()))
from src.mwcc_debug.tiebreak import load_gpr_ig,validate_g1,predict_assignments
old=load_gpr_ig(Path('/tmp/c016-decoder-flags-fixed.txt').read_text(),'fn_803B6820')
ig=load_gpr_ig(Path('/tmp/c016-decoder-pointer-inequality-scp.txt').read_text(),'fn_803B6820')
assert validate_g1(old).correct==validate_g1(old).total==110
assert validate_g1(ig).correct==validate_g1(ig).total==113
cv=lambda n:n+3 if n>=107 else n
oldorder=[cv(n) for n in old.select_order];oldcolors={cv(n):v for n,v in predict_assignments(old).items()};target=dict(oldcolors)
for x in Path('/tmp/c016-decoder-inequality-mapped-target.txt').read_text().strip().split(','):
 _,n,v=map(int,x.split(':'));target[n]=v
rows=[]
for retain_count in range(4):
 for keep in itertools.combinations([107,108,109],retain_count):
  order=[n for n in ig.select_order if n not in {107,108,109} or n in keep]
  for mode in ['current-old-node-order','original-old-node-order']:
   if mode=='original-old-node-order':
    it=iter(oldorder);order=[n if n in {107,108,109} else next(it) for n in order]
   pred=predict_assignments(ig,order=order)
   diffs=[{'ig':n,'pred':pred[n],'target':v} for n,v in target.items() if pred.get(n)!=v]
   row={'keep_new_nodes':list(keep),'mode':mode,'target_differences':diffs,'changed_from_original_colors':[n for n,v in oldcolors.items() if pred.get(n)!=v],'focus':{n:pred[n] for n in [65,37,63,64,78,77,79]},'order':order}
   rows.append(row);print(keep,mode,'target differences',len(diffs),'vs old colors',len(row['changed_from_original_colors']),'X/chroma',pred[65],pred[37])
Path('/tmp/c016-decoder-added-node-ablation.json').write_text(json.dumps({'scope':'Existing SELECT surrogate with supplied order. Node omission and old-node-order restoration are abstract interventions, not recomputed simplify/allocator passes or source proof. Target extends inherited partial map by assuming other old baseline colors are correct. New dead nodes unconstrained.','validation':asdict(validate_g1(ig)),'rows':rows},indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-dec8-frame');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline s32 jpeg_clamp');b=base.index('static void fn_803B6820(',a);end=base.index('static inline s32 hsd_803B6BE4_inline',b)
variants={}
for typ in ['s32','u8']:
 for pad in [True,False]:
  s=base[a:b];old='    return (u8) (s32) value;';assert s.count(old)==1
  s=s.replace(old,'    {\n        '+typ+' result = (u8) (s32) value;\n        return result;\n    }')
  body=base[b:end] if pad else base[b:end].replace('    PAD_STACK(8);\n','')
  variants[f'clamp-{typ}-pad{int(pad)}']=base[:a]+s+body+base[end:]
s=base[a:b];s=s.replace('    f32 red_value, green_value, blue_value;','    f64 red_value, blue_value;\n    f32 green_value;')
s=s.replace('red_value = (f32) ((1.402 * (f64) cr) + (f64) luminance);','red_value = (1.402 * (f64) cr) + (f64) luminance;')
s=s.replace('blue_value = (f32) ((f64) ((1.7718f * (f32) cb) + (f32) luminance) -\n                        (0.0012 * (f64) cr));','blue_value = (f64) ((1.7718f * (f32) cb) + (f32) luminance) -\n                 (0.0012 * (f64) cr);')
assert 'red_value = (f32)' not in s and 'blue_value = (f32)' not in s
variants['call-rounding-no-pad']=base[:a]+s+base[b:end].replace('    PAD_STACK(8);\n','')+base[end:]
rows=[]
try:
 for name,full in variants.items():
  p.write_text(full);(out/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']}
  except Exception:row={'name':name,'exit':r.returncode}
  rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

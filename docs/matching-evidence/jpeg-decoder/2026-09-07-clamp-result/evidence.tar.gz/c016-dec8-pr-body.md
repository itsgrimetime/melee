Fix the operand order of the chroma-address addition in `fn_803B6820`, improving its match from **98.81743% to 98.83817%**. The subtract-negative expression preserves the division/remainder instruction sequence while emitting the addition operands in the original order.

Replace `PAD_STACK(8)` with a result local in the inlined `jpeg_clamp` helper. This preserves the generated instructions and 176-byte stack frame without explicit padding. The function remains 964 bytes; the other five functions in `hsd_3B5C.c` remain 100%. The TU stays Linkable while register differences remain.

Validation: `python configure.py && ninja` passes, including the original DOL checksum. The padding replacement preserves the TU's code/data bytes and relocation targets after accounting for renamed compiler-generated constants.

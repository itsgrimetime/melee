from elftools.elf.elffile import ELFFile
import json,hashlib
from pathlib import Path

def read(path):
 with open(path,'rb') as f:
  e=ELFFile(f);sy=e.get_section_by_name('.symtab');sections={};relocs={}
  for sec in e.iter_sections():
   if sec.name.startswith(('.debug','.line','.rela.debug','.rela.line')) or sec.name in ['', '.shstrtab','.strtab','.symtab','.comment']:continue
   if sec.header.sh_type in ('SHT_RELA','SHT_REL'):
    rows=[]
    for r in sec.iter_relocations():
     sym=sy.get_symbol(r['r_info_sym']);index=sym['st_shndx'];name=sym.name
     target={'name':name,'section':index,'value':sym['st_value'],'size':sym['st_size']}
     if name.startswith('@') and isinstance(index,int):
      target['name']='<anonymous>';target['section']=e.get_section(index).name
      target['bytes']=e.get_section(index).data()[sym['st_value']:sym['st_value']+sym['st_size']].hex()
     rows.append({'offset':r['r_offset'],'type':r['r_info_type'],'addend':r.entry.get('r_addend',0),'target':target})
    relocs[sec.name]=rows
   else:sections[sec.name]={'size':sec.header.sh_size,'flags':sec.header.sh_flags,'alignment':sec.header.sh_addralign,'sha256':hashlib.sha256(sec.data()).hexdigest()}
  return {'sections':sections,'relocations':relocs}
a=read('/tmp/c016-dec8-before.o');b=read('/tmp/c016-dec8-retained.o')
out={'sections_identical':a['sections']==b['sections'],'relocations_identical_after_anonymous_name_normalization':a['relocations']==b['relocations'],'before':a,'after':b}
Path('/tmp/c016-dec8-object-verification.json').write_text(json.dumps(out,indent=2)+'\n')
assert out['sections_identical'];assert out['relocations_identical_after_anonymous_name_normalization']
print('All non-debug section bytes/layout and relocation targets identical; anonymous constant names normalized by actual section/value/size/bytes.')

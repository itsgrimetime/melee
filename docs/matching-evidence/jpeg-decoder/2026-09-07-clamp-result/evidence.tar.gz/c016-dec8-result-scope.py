from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-dec8-result-scope');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline s32 jpeg_clamp');b=base.index('static void fn_803B6820(',a);end=base.index('static inline s32 hsd_803B6BE4_inline',b)
variants={}
for typ in ['s32','u8']:
 s=base[a:b].replace('static inline s32 jpeg_clamp(f32 value)\n{','static inline s32 jpeg_clamp(f32 value)\n{\n    '+typ+' result;')
 s=s.replace('    return (u8) (s32) value;','    result = (u8) (s32) value;\n    return result;')
 variants['top-'+typ]=base[:a]+s+base[b:end].replace('    PAD_STACK(8);\n','')+base[end:]
s=Path('/tmp/c016-dec8-frame/clamp-u8-pad0.c').read_text().replace('u8 result = (u8) (s32) value;', 'u8 result = (s32) value;')
variants['branch-u8-implicit']=s
rows=[]
try:
 for name,full in variants.items():
  p.write_text(full);(out/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']}
  except Exception:row={'name':name,'exit':r.returncode}
  rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

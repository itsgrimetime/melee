from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-direct-address');out.mkdir(exist_ok=True)
a=base.index('                            chroma = base +');b=base.index(';',a)+1
expr='(chroma_row + chroma_column) - (-((block / 2) << 5))'
try:
 for unsigned in ['none','cr','cb','both']:
  s=base[:a]+base[b:];s=s.replace('    u8* chroma;\n','')
  for ch in ['cr','cb']:
   idx='(u32) ('+expr+')' if unsigned in [ch,'both'] else expr
   s=s.replace('((JpegState*) chroma)->work.'+ch+'[0]','((JpegState*) base)->work.'+ch+'['+idx+']')
  (out/(unsigned+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(unsigned+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(unsigned,x['fuzzy_match_percent'],flush=True)
finally:p.write_text(base)

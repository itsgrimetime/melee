from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-x-dependencies');out.mkdir(exist_ok=True)
variants=[]
anchors=[('outer','        group_chroma = group_y * 16;', 'group_y'),('inner','                    for (block = 0; block < 4; block++) {','tile_x'),('store','                        jpeg_store_rgb565(out + out_offset, luminance, cb, cr);','out_offset'),('end','                    out += 1;','tile_x')]
for tag,anchor,other in anchors:
 for op in ['!=','==']:
  stmt='(void) (((x / 4) * 16) '+op+' '+other+');'
  indent=anchor[:len(anchor)-len(anchor.lstrip())]
  variants.append((tag+('-ne' if op=='!=' else '-eq'),base.replace(anchor,indent+stmt+'\n'+anchor)))
variants.append(('width-ne',base.replace('    for (group_y = 0; group_y < 2; group_y++) {','    (void) (((x / 4) * 16) != aligned_width);\n    for (group_y = 0; group_y < 2; group_y++) {')))
variants.append(('dst-ne',base.replace('    for (group_y = 0; group_y < 2; group_y++) {','    (void) ((u32) ((x / 4) * 16) != (u32) dst);\n    for (group_y = 0; group_y < 2; group_y++) {')))
try:
 for name,s in variants:
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

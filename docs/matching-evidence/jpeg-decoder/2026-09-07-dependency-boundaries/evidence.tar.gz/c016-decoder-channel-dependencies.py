from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-channel-dependencies');out.mkdir(exist_ok=True)
variants=[('red-green','    pixel.green = green;','    (void) (pixel.red != green);'),('red-blue','    pixel.blue = jpeg_clamp(blue_value);','    (void) (pixel.red != pixel.blue);'),('green-blue','    pixel.blue = jpeg_clamp(blue_value);','    (void) (green != pixel.blue);'),('pixel-green-blue','    pixel.blue = jpeg_clamp(blue_value);','    (void) (pixel.green != pixel.blue);'),('red-cr','    pixel.red = jpeg_clamp(red_value);','    (void) (pixel.red != cr);'),('green-cb','    pixel.green = green;','    (void) (green != cb);')]
try:
 for name,anchor,stmt in variants:
  s=base.replace(anchor,anchor+'\n'+stmt);(out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

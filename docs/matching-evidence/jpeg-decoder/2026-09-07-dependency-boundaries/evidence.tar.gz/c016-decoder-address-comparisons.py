from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-address-comparisons');out.mkdir(exist_ok=True)
old='(void) ((u8*) out != chroma);'
variants={'cr-address':'(void) ((u8*) out != (u8*) &((JpegState*) chroma)->work.cr[0]);','cb-address':'(void) ((u8*) out != (u8*) &((JpegState*) chroma)->work.cb[0]);','luma-address':'(void) ((u8*) out != (u8*) &((JpegState*) chroma)->work.luma[0]);','unsigned-less':'(void) ((u32) out < (u32) chroma);','unsigned-greater':'(void) ((u32) out > (u32) chroma);','unsigned-subtract':'(void) (((u32) out - (u32) chroma) != 0);','unsigned-xor':'(void) (((u32) out ^ (u32) chroma) != 0);'}
try:
 for name,expr in variants.items():
  s=base.replace(old,expr);(out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

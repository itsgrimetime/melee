from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-address-out');out.mkdir(exist_ok=True)
old='''        out = (u16*) dst + (((x / 4) * 0x10) +
                            ((aligned_width << 2) * ((y / 4) + group_y)));'''
variants=[
('all', 'u16** out, u8* dst, s32 x, s32 y, s32 width, s32 group', '*out = (u16*) dst + (x / 4) * 16 + (width << 2) * ((y / 4) + group);', '&out, dst, x, y, aligned_width, group_y'),
('offsets', 'u16** out, u8* dst, s32 xo, s32 yo', '*out = (u16*) dst + (xo + yo);', '&out, dst, (x / 4) * 16, (aligned_width << 2) * ((y / 4) + group_y)'),
('row', 'u16** out, u8* dst, s32 x, s32 row, s32 stride', '*out = (u16*) dst + ((x / 4) * 16 + stride * row);', '&out, dst, x, (y / 4) + group_y, aligned_width << 2'),
('xout', 's32* out, s32 x', '*out = (x / 4) * 16;', '')]
try:
 for name,args,body,call in variants:
  helper='static inline void jpeg_output_address('+args+')\n{\n    '+body+'\n}\n\n'
  s=base.replace('static void fn_803B6820(',helper+'static void fn_803B6820(')
  if name=='xout':
   s=s.replace('    s32* luma_base;','    s32* luma_base;\n    s32 x_offset;').replace(old,'        jpeg_output_address(&x_offset, x);\n'+old.replace('(x / 4) * 0x10','x_offset'))
  else:s=s.replace(old,'        jpeg_output_address('+call+');')
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout)
  try:
   x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
  except Exception:print(name,r.stdout[-2000:],r.stderr[-1000:],flush=True)
finally:p.write_text(base)

import sys,re,json
from pathlib import Path
from collections import Counter
sys.path.insert(0,str(Path('tools/melee-agent').resolve()))
from src.mwcc_debug.parser import parse_pcdump
paths=['/tmp/c016-decoder-flags-fixed.txt','/tmp/c016-decoder-pointer-inequality-scp.txt']
f=[parse_pcdump(Path(p).read_text(),function='fn_803B6820')[0] for p in paths]
report={'scope':'Per-block instruction multiset correspondence; allows scheduling changes. Anonymous symbol normalization does not prove data equivalence. Tests a proposed +3 GPR renaming for IDs >=107 and removes only the three observed comparison instructions. Not a graph-isomorphism or full target proof.','passes':[]}
for a,b in zip(f[0].passes,f[1].passes):
 if a.name=='AFTER REGISTER COLORING':break
 def rows(p,old):
  result=Counter(); removed=[]
  for block,i,x in p.all_instructions():
   if not old and x.opcode in ['subf','addic','subfe'] and re.match(r'r(?:107|108|109),',x.operands):
    removed.append([block,i,x.opcode,x.operands]);continue
   operands=x.operands
   if old:operands=re.sub(r'\br(\d+)\b',lambda m:'r'+str(int(m[1])+3 if int(m[1])>=107 else int(m[1])),operands)
   operands=re.sub(r'@\d+','@CONST',operands)
   result[(block,x.opcode,operands)]+=1
  return result,removed
 ca,_=rows(a,True);cb,rm=rows(b,False)
 r={'pass':a.name,'equal':ca==cb,'removed':rm,'baseline_only':[list(k)+[v] for k,v in (ca-cb).items()],'candidate_only':[list(k)+[v] for k,v in (cb-ca).items()]}
 report['passes'].append(r);print(a.name,r['equal'],'removed',len(rm),'missing',sum((ca-cb).values()),'extra',sum((cb-ca).values()))
Path('/tmp/c016-decoder-inequality-role-audit.json').write_text(json.dumps(report,indent=2)+'\n')

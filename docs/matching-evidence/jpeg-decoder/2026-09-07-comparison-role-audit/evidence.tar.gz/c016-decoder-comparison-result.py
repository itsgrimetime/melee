from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-comparison-result');out.mkdir(exist_ok=True)
old='(void) ((u8*) out != chroma);'
variants={'local-int':'{ int different = ((u8*) out != chroma); }','local-u8':'{ u8 different = ((u8*) out != chroma); }','out-offset':'out_offset = ((u8*) out != chroma);','column':'chroma_column = ((u8*) out != chroma);','channel':'channel = ((u8*) out != chroma);','add-one':'(void) (((u8*) out != chroma) + 1);','shift':'(void) (((u8*) out != chroma) << 1);','empty-if':'if ((u8*) out != chroma) {}'}
try:
 for name,expr in variants.items():
  s=base.replace(old,expr);(out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-clamp-dependencies');out.mkdir(exist_ok=True)
try:
 for name,expr in [('ne0','result != 0'),('ne255','result != 255'),('ne1','result != 1'),('eq0','result == 0'),('lt128','result < 128'),('byte-ne0','(u8) result != 0')]:
  s=base.replace('    return result;','    (void) ('+expr+');\n    return result;',1);(out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

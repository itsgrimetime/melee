from pathlib import Path
import sys,json
sys.path.insert(0,str(Path('tools/melee-agent').resolve()))
from src.mwcc_debug.tiebreak import load_gpr_ig,predict_assignments,validate_g1
old=load_gpr_ig(Path('/tmp/c016-decoder-flags-fixed.txt').read_text(),'fn_803B6820');ig=load_gpr_ig(Path('/tmp/c016-decoder-red-current-pcdump.txt').read_text(),'fn_803B6820');g=validate_g1(ig);assert g.correct==g.total==113
cv=lambda n:n+3 if n>=107 else n
swap=lambda n:127-n if n in [63,64] else n
target={swap(cv(n)):v for n,v in predict_assignments(old).items()}
for x in Path('/tmp/c016-decoder-inequality-mapped-target.txt').read_text().strip().split(','):
 _,n,v=map(int,x.split(':'));target[swap(n)]=v
moves=[(65,125),(78,125),(77,131),(79,76)];rows=[]
for mask in range(16):
 order=list(ig.select_order);used=[]
 for i,(n,anchor) in enumerate(moves):
  if mask&(1<<i):order.remove(n);order.insert(order.index(anchor)+1,n);used.append(i)
 pred=predict_assignments(ig,order=order);diff=[n for n,v in target.items() if pred.get(n)!=v]
 rows.append({'move_indices':used,'different_target_nodes':diff})
print('winning subsets',[r for r in rows if not r['different_target_nodes']])
Path('/tmp/c016-decoder-red-four-moves.json').write_text(json.dumps({'scope':'Supplied SELECT orders on observed red-first graph, not source/simplify proof. Target inherited from mapped partial baseline with unchanged-other-color assumption; dead comparison nodes unconstrained.','moves_after':moves,'rows':rows},indent=2)+'\n')

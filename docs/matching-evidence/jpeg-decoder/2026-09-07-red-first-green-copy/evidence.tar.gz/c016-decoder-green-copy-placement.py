from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-green-copy-placement');out.mkdir(exist_ok=True)
variants=[]
for red in [False,True]:
 b=base if not red else Path('build/verification/decoder/red-luminance-first.c').read_text()
 for mode in ['before-blue-clamp','after-blue-clamp','reverse','reverse-deferred']:
  s=b
  if mode.startswith('reverse'):
   s=s.replace('    green = jpeg_clamp(green_value);\n    pixel.green = green;','    pixel.green = jpeg_clamp(green_value);\n    green = pixel.green;').replace('(pixel.green << 3)','(green << 3)')
   if mode=='reverse-deferred':s=s.replace('    green = pixel.green;\n','').replace('    pixel.blue = jpeg_clamp(blue_value);','    green = pixel.green;\n    pixel.blue = jpeg_clamp(blue_value);')
  else:
   s=s.replace('    pixel.green = green;\n','');anchor='    pixel.blue = jpeg_clamp(blue_value);';line='    pixel.green = green;'
   s=s.replace(anchor,(line+'\n'+anchor) if mode=='before-blue-clamp' else (anchor+'\n'+line))
  variants.append((('red-first-' if red else '')+mode,s))
try:
 for name,s in variants:
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

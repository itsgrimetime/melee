from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');b=p.read_bytes()
try:
 p.write_bytes(Path('/tmp/c016-decoder-padding-reconstruction/record-group_row-no-pad.c').read_bytes())
 r=subprocess.run(['melee-agent','debug','dump','local',str(p),'--function','fn_803B6820','--output','/tmp/c016-decoder-group-pcdump.txt','--no-cache-sync'],capture_output=True,text=True,timeout=120)
 Path('/tmp/c016-decoder-group-dump.log').write_text(r.stdout+r.stderr);print(r.stdout+r.stderr);assert r.returncode==0
finally:p.write_bytes(b)

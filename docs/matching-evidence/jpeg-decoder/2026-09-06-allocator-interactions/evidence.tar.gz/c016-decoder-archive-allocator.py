from pathlib import Path
import json, hashlib, tarfile, subprocess
root=Path('docs/matching-evidence/jpeg-decoder/2026-09-06-allocator-interactions')
root.mkdir(parents=True,exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
vp=Path('/tmp/c016-decoder-allocator-verification.json')
v=json.loads(vp.read_text());v['source_head']=head
for p,h in v['sha1'].items(): assert hashlib.sha1(Path(p).read_bytes()).hexdigest()==h
vp.write_text(json.dumps(v,indent=2)+'\n')
files=[];candidates=[]
for family in ['global-access','parameter-order','pixel-layout','discard-dependency','channel-locals','clamp-return']:
 p=Path('/tmp/c016-decoder-'+family)
 files.extend((f,str(f.relative_to('/tmp'))) for f in p.rglob('*') if f.is_file())
 files.append((Path(str(p)+'.py'),p.name+'.py'))
 candidates.extend({'family':family,**r} for r in json.loads((p/'results.json').read_text()))
assert len(candidates)==58
for name in ['current-pcdump.txt','current-pressure.json','current-divergence.json','group-dump.py','group-pcdump.txt','group-dump.log','group-diff.txt','alpha-map.py','alpha-map.json','discard-pattern.json','allocator-doctor.log','post3383-build.log','allocator-restored.json','allocator-restored.log','allocator-verification.json','archive-allocator.py']:
 p=Path('/tmp/c016-decoder-'+name);files.append((p,p.name))
for name in ['c016-pr3383.diff','c016-pr3383-status.json','c016-upstream-3382-build.log']:
 p=Path('/tmp')/name;files.append((p,p.name))
for name in ['parser.py','colorgraph_parser.py']:
 p=Path('tools/melee-agent/src/mwcc_debug')/name;files.append((p,'parser-reference/'+name))
files.append((Path('src/sysdolphin/baselib/hsd_3B5C.c'),'restored-hsd_3B5C.c'))
m={'function':'fn_803B6820','scratch':None,'source_head':head,'retained_percent':98.81743,'retained_frame':176,'retained_source_change':False,'validation':v,'candidates':candidates,'caveats':['Forced allocator targets are diagnostic only.','Register correspondence normalizes anonymous constants and does not prove whole-graph isomorphism or candidate data equality.','All candidate source changes were reverted.'],'members':[]}
assert len({n for p,n in files})==len(files)
with tarfile.open(root/'evidence.tar.gz','w:gz') as t:
 for p,n in sorted(files,key=lambda x:x[1]):
  d=p.read_bytes();m['members'].append({'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()});t.add(p,arcname=n)
with tarfile.open(root/'evidence.tar.gz') as t:
 for f in m['members']: assert hashlib.sha256(t.extractfile(f['path']).read()).hexdigest()==f['sha256']
m['archive_sha256']=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest()
(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('Verified',len(files),'archive members;',len(candidates),'probes;', (root/'evidence.tar.gz').stat().st_size,'archive bytes')

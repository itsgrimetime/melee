from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-pixel-layout');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline void jpeg_store_rgb565(');b=base.index('static void fn_803B6820(',a);part=base[a:b]
old='''    struct {
        u8 red, green, blue;
    } pixel;'''
assert part.count(old)==1
variants={}
for typ in ['u8','u16','u32','s32']:
 s=part.replace(old,'    struct { '+typ+' red, green, blue, alpha; } pixel;')
 variants[typ+'-rgba']=base[:a]+s+base[b:]
for n in [3,4]:
 s=part.replace(old,'    u8 pixel['+str(n)+'];')
 for i,field in enumerate(['red','green','blue']):s=s.replace('pixel.'+field,'pixel['+str(i)+']')
 variants['byte-array'+str(n)]=base[:a]+s+base[b:]
s=part.replace(old,'    GXColor pixel;')
for field,short in [('red','r'),('green','g'),('blue','b')]:s=s.replace('pixel.'+field,'pixel.'+short)
variants['GXColor']=('#include <dolphin/gx/GXStruct.h>\n'+base[:a]+s+base[b:])
rows=[]
try:
 for name,full in variants.items():
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

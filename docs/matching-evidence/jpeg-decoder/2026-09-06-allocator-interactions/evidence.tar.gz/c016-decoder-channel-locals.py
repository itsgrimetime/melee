from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-channel-locals');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline void jpeg_store_rgb565(');b=base.index('static void fn_803B6820(',a);part=base[a:b]
part=part.replace('    u8 green;\n','').replace('    green = jpeg_clamp(green_value);\n    pixel.green = green;','    pixel.green = jpeg_clamp(green_value);')
variants={}
for mask in range(8):
 if mask==2:continue
 fields=[field for i,field in enumerate(['red','green','blue']) if mask&(1<<i)]
 s=part
 for field in fields:s=s.replace('    pixel.'+field+' = jpeg_clamp('+field+'_value);','    '+field+' = jpeg_clamp('+field+'_value);\n    pixel.'+field+' = '+field+';')
 if fields:s=s.replace('    f32 red_value, green_value, blue_value;','    f32 red_value, green_value, blue_value;\n    u8 '+', '.join(fields)+';')
 variants['-'.join(fields) if fields else 'none']=base[:a]+s+base[b:]
# Change the existing green owner's storage class with a real aggregate, testing
# both retained frame padding and replacement of that padding by the aggregate.
for kind in ['struct','array']:
 for pad in ['keep','remove']:
  s=base
  if kind=='struct':s=s.replace('    u8 green;','    struct { u8 value; } green;');access='green.value'
  else:s=s.replace('    u8 green;','    u8 green[1];');access='green[0]'
  s=s.replace('    green = jpeg_clamp(green_value);','    '+access+' = jpeg_clamp(green_value);').replace('    pixel.green = green;','    pixel.green = '+access+';')
  if pad=='remove':s=s[:s.index('static void fn_803B6820(')]+s[s.index('static void fn_803B6820('):].replace('    PAD_STACK(8);\n','',1)
  variants['green-'+kind+'-'+pad]=s
rows=[]
try:
 for name,full in variants.items():
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

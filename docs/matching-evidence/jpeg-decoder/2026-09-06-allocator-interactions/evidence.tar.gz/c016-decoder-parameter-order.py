from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-parameter-order');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
old='static inline void jpeg_store_rgb565(u16* out, s32 luminance, s32 cb, s32 cr)'
call='jpeg_store_rgb565(out + out_offset, luminance, cb, cr);'
assert base.count(old)==base.count(call)==1
params={'out':'u16* out','luminance':'s32 luminance','cb':'s32 cb','cr':'s32 cr'};args={'out':'out + out_offset','luminance':'luminance','cb':'cb','cr':'cr'}
variants={}
for order in itertools.permutations(['luminance','cb','cr']):
 for at in ['first','last']:
  names=('out',)+order if at=='first' else order+('out',)
  if names==('out','luminance','cb','cr'):continue
  s=base.replace(old,'static inline void jpeg_store_rgb565('+', '.join(params[n] for n in names)+')').replace(call,'jpeg_store_rgb565('+', '.join(args[n] for n in names)+');')
  variants['-'.join(names)]=s
rows=[]
try:
 for name,full in variants.items():
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-global-access');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b]
free=Path('/tmp/c016-decoder-padding-reconstruction/record-group_row-no-pad.c').read_text();fa=free.index('static void fn_803B6820(');fb=free.index('static inline s32 hsd_803B6BE4_inline',fa)
variants={}
for label,body in [('scalar',part),('group',free[fa:fb])]:
 for sites in [('all',(1,2,3)),('pixel',(2,3)),('chroma',(3,)),('luma',(2,))]:
  n,ids=sites;t=body
  if 1 in ids:t=t.replace('((JpegState*) base)->work.luma','((JpegState*) hsd_804D2E70)->work.luma')
  if 2 in ids:t=t.replace('&base[0x118]','&hsd_804D2E70[0x118]')
  if 3 in ids:t=t.replace('chroma = base +','chroma = hsd_804D2E70 +')
  if len(ids)==3:t=t.replace('    u8* base;\n','').replace('    base = hsd_804D2E70;\n','')
  variants[label+'-'+n]=t
rows=[]
try:
 for name,s in variants.items():
  full=base[:a]+s+base[b:];(out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-clamp-return');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline s32 jpeg_clamp(');b=base.index('static inline void jpeg_store_rgb565(',a);part=base[a:b]
variants={}
for typ in ['u8','int','u32','u16']:
 for ret in ['keep-narrow','direct']:
  s=part.replace('static inline s32 jpeg_clamp(','static inline '+typ+' jpeg_clamp(')
  if ret=='direct':s=s.replace('return (u8) (s32) value;','return (s32) value;')
  variants[typ+'-'+ret]=base[:a]+s+base[b:]
# Same u8 result, express range narrowing at the function return conversion.
variants['s32-implicit-narrow']=base[:a]+part.replace('return (u8) (s32) value;','return (s32) value;')+base[b:]
rows=[]
try:
 for name,full in variants.items():
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

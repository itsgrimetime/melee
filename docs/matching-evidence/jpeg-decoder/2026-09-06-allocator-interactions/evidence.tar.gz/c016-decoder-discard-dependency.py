from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-discard-dependency');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b]
variants={}
exprs={'base-equality':'chroma == base','base-difference':'chroma - base','luma-end-equality':'chroma == luma_block','output-equality':'chroma == (u8*) out'}
for name,expr in exprs.items():
 for site in ['before-load','before-conversion','after-conversion']:
  line='                        (void) ('+expr+');\n'
  if site=='before-load':anchor='                        cr = ((JpegState*) chroma)->work.cr[0];';s=part.replace(anchor,line+anchor)
  elif site=='before-conversion':anchor='                        jpeg_store_rgb565(out + out_offset, luminance, cb, cr);';s=part.replace(anchor,line+anchor)
  else:anchor='                        jpeg_store_rgb565(out + out_offset, luminance, cb, cr);\n';s=part.replace(anchor,anchor+line)
  assert s!=part;variants[name+'-'+site]=s
rows=[]
try:
 for name,s in variants.items():
  full=base[:a]+s+base[b:];(out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

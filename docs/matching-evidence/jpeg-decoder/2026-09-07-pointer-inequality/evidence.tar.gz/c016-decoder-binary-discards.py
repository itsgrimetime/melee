from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-binary-discards');out.mkdir(exist_ok=True)
anchor='                        cr = ((JpegState*) chroma)->work.cr[0];'
store='                        jpeg_store_rgb565(out + out_offset, luminance, cb, cr);'
try:
 for name,statement in [('pointer-equality','(void) ((u8*) out == chroma);'),('pointer-inequality','(void) ((u8*) out != chroma);'),('base-equality','(void) (base == chroma);'),('x-luma','(void) (x == luminance);'),('offset-luma','(void) (out_offset == luminance);'),('channel-pair','(void) (cb == cr);')]:
  at=store if name in ['offset-luma','channel-pair'] else anchor
  s=base.replace(at,'                        '+statement+'\n'+at)
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

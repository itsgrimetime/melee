from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-x-types');out.mkdir(exist_ok=True)
variants={
'int-division':'((int) x / 4) * 0x10',
'int-quotient':'((int) (x / 4)) * 0x10',
'unsigned-quotient':'((u32) (x / 4)) * 0x10',
'unsigned-scale':'(x / 4) * 0x10U',
'int-scale':'(int) ((x / 4) * 0x10)',
'unsigned-scale-result':'(u32) ((x / 4) * 0x10)',
'shift':'(x / 4) << 4',
'unsigned-shift':'((u32) (x / 4)) << 4',
}
try:
 for name,expr in variants.items():
  s=base.replace('(x / 4) * 0x10','('+expr+')');(out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout)
  d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

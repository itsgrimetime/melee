from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-clamp-clones');out.mkdir(exist_ok=True)
start=base.index('static inline s32 jpeg_clamp(');end=base.index('static inline void jpeg_store_rgb565',start);helper=base[start:end]
try:
 for label,channels in [('red',['red']),('green',['green']),('blue',['blue']),('all',['red','green','blue']),('reverse',['blue','green','red'])]:
  s=base
  clones=''.join(helper.replace('jpeg_clamp(', 'jpeg_clamp_'+ch+'(') for ch in channels)
  s=s[:end]+clones+s[end:]
  for ch in channels:s=s.replace('jpeg_clamp('+ch+'_value)', 'jpeg_clamp_'+ch+'('+ch+'_value)')
  (out/(label+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(label+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(label,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

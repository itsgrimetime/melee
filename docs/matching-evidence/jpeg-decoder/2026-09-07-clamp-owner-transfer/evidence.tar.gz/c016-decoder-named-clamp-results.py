from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-named-clamp-results');out.mkdir(exist_ok=True)
try:
 for first in [False,True]:
  for chans in [('red',),('green',),('red','green')]:
   s=base if not first else base.replace('(1.402 * (f64) cr) + (f64) luminance','(f64) luminance + (1.402 * (f64) cr)')
   decl=''.join('    s32 '+c+'_result;\n' for c in chans);s=s.replace('    u8 green;','    u8 green;\n'+decl)
   for c in chans:
    dst='pixel.red' if c=='red' else 'green'
    s=s.replace(dst+' = jpeg_clamp('+c+'_value);',c+'_result = jpeg_clamp('+c+'_value);\n    '+dst+' = '+c+'_result;')
   name=('red-first-' if first else '')+'-'.join(chans);(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

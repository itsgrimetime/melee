from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-clamp-owner-transfer');out.mkdir(exist_ok=True)
try:
 for src in sorted(Path('/tmp/c016-decoder-named-clamp-results').glob('*.c')):
  s=src.read_text();a=s.index('static inline s32 jpeg_clamp(');b=s.index('static inline void jpeg_store_rgb565',a);h=s[a:b].replace('    s32 result;\n','').replace('    result = (u8) (s32) value;\n    return result;','    return (u8) (s32) value;');s=s[:a]+h+s[b:]
  (out/src.name).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(src.stem+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(src.stem,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

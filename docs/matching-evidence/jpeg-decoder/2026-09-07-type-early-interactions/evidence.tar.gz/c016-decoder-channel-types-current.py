from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-channel-types-current');out.mkdir(exist_ok=True);variants=[]
for typ in ['int','s32','u32','u16']:variants.append(('green-'+typ,base.replace('    u8 green;','    '+typ+' green;')))
for field in ['red','green','blue']:
 for typ in ['u16','u32']:
  fields='\n'.join('        '+(typ if c==field else 'u8')+' '+c+';' for c in ['red','green','blue'])
  variants.append(('field-'+field+'-'+typ,base.replace('        u8 red, green, blue;',fields)))
try:
 for name,s in variants:
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-early-dependencies');out.mkdir(exist_ok=True)
variants=[]
for place,anchor in [('before-bias','    luma_block = (u8*) ((JpegState*) base)->work.luma;'),('after-bias','    block_columns = (width + 0xF) / 16;')]:
 for pair,expr in [('pointers','dst != base'),('dimensions','width != y'),('coords','x != y')]:variants.append((place+'-'+pair,base.replace(anchor,'    (void) ('+expr+');\n'+anchor)))
for pair,expr in [('stride-y','aligned_width != y'),('stride-width','aligned_width != width')]:variants.append((pair,base.replace('    for (group_y = 0; group_y < 2; group_y++) {','    (void) ('+expr+');\n    for (group_y = 0; group_y < 2; group_y++) {')))
try:
 for name,s in variants:
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

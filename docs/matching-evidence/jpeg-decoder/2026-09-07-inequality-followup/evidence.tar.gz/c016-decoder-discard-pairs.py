from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-discard-pairs');out.mkdir(exist_ok=True)
anchor='                        cr = ((JpegState*) chroma)->work.cr[0];'
variants=[('out-luma','(u8*) out != (u8*) luma_base'),('chroma-luma','chroma != (u8*) luma_base'),('out-base','(u8*) out != base'),('x-scaled-luma','((x / 4) * 16) != luminance'),('x-scaled-chroma','((x / 4) * 16) != chroma_row'),('row-luma','chroma_row != luminance'),('block-luma','block != luminance'),('x-y-scaled','((x / 4) * 16) != ((y / 4) * 16)')]
try:
 for name,expr in variants:
  s=base.replace(anchor,'                        (void) ('+expr+');\n'+anchor)
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

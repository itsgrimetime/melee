from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-discard-refine');out.mkdir(exist_ok=True)
line='                        (void) ((u8*) out != chroma);\n'
clean=base.replace(line,'')
cr='                        cr = ((JpegState*) chroma)->work.cr[0];'
cb='                        cb = ((JpegState*) chroma)->work.cb[0];'
store='                        jpeg_store_rgb565(out + out_offset, luminance, cb, cr);'
variants=[]
for name,expr in [('reverse','chroma != (u8*) out'),('void-pointers','(void*) out != (void*) chroma'),('u16-pointers','out != (u16*) chroma'),('negated-eq','!((u8*) out == chroma)'),('bare','(u8*) out != chroma')]:
 stmt=('                        '+expr+';\n') if name=='bare' else '                        (void) ('+expr+');\n'
 variants.append((name,clean.replace(cr,stmt+cr)))
for name,at in [('after-cr',cb),('after-cb',store)]:variants.append((name,clean.replace(at,line+at)))
variants.append(('final-output',clean.replace(store,'                        (void) ((u8*) (out + out_offset) != chroma);\n'+store)))
variants.append(('red-luminance-first',base.replace('(1.402 * (f64) cr) + (f64) luminance','(f64) luminance + (1.402 * (f64) cr)')))
try:
 for name,s in variants:
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

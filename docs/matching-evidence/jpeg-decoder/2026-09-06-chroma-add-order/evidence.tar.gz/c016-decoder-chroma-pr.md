Fix the operand order of the chroma-address addition in `fn_803B6820`, improving its match from **98.81743% to 98.83817%**. The subtract-negative expression preserves the existing division/remainder instruction sequence while emitting the addition operands in the original order.

The function remains 964 bytes with a 176-byte stack frame. The other five functions in `hsd_3B5C.c` remain 100%; the TU stays Linkable while register differences remain.

Validation: `python configure.py && ninja` passes, including the original DOL checksum.

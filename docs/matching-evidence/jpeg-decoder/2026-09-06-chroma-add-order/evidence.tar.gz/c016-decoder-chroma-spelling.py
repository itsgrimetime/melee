from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-chroma-spelling');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b];old='''chroma_row + ((block / 2) << 5) +
                                              chroma_column'''
exprs={'negative-product':'(chroma_row + chroma_column) - ((block / 2) * -32)','negative-quotient':'(chroma_row + chroma_column) - (-(block / 2) * 32)','parenthesized-negation':'(chroma_row + chroma_column) - (-((block / 2) << 5))','negative-shift':'(chroma_row + chroma_column) - (-(block / 2) << 5)'}
rows=[]
try:
 for name,expr in exprs.items():
  full=base[:a]+part.replace(old,expr)+base[b:];(out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1],(name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json,hashlib,tarfile
root=Path('docs/matching-evidence/jpeg-decoder/2026-09-06-chroma-add-order');root.mkdir(parents=True,exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();pr=Path('/Users/mike/.codex/worktrees/c016/melee-pr-jpeg-decoder')
source=Path('src/sysdolphin/baselib/hsd_3B5C.c');assert source.read_bytes()==(pr/source).read_bytes()
validation={'source_head':head,'pr_head':subprocess.check_output(['git','-C',str(pr),'rev-parse','HEAD'],text=True).strip(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'before':98.81743,'after':98.83817,'frame':176,'instructions':241,'units':{},'checksums':{},'model':json.loads(Path('/tmp/c016-decoder-chroma-model-check.json').read_text())}
for label,tree in [('working',Path('.')),('clean_pr',pr)]:
 report=json.loads((tree/'build/GALE01/report.json').read_text());unit=next(u for u in report['units'] if u['name'].endswith('sysdolphin/baselib/hsd_3B5C'))
 fs=[{'name':f['name'],'percent':f['fuzzy_match_percent']} for f in unit['functions']];assert len(fs)==6 and all(f['percent']==(98.83817 if f['name']=='fn_803B6820' else 100) for f in fs)
 validation['units'][label]=fs;sha={n:hashlib.sha1((tree/n).read_bytes()).hexdigest() for n in ['build/GALE01/main.dol','orig/GALE01/sys/main.dol']};assert len(set(sha.values()))==1;validation['checksums'][label]=sha
Path('/tmp/c016-decoder-chroma-verification.json').write_text(json.dumps(validation,indent=2)+'\n')
files=[];candidates=[]
for family in ['pair','barriers','spelling']:
 p=Path('/tmp/c016-decoder-chroma-'+family)
 files.extend((f,str(f.relative_to('/tmp'))) for f in p.rglob('*') if f.is_file());files.append((Path(str(p)+'.py'),p.name+'.py'))
 for r in json.loads((p/'results.json').read_text()):
  row={'family':family,**r,'valid_source_evidence':r['name']!='negative-shift'}
  if r['name']=='negative-shift':row['rejected_reason']='Left shift of a negative signed value; never retained.'
  if r['name']=='pointer-roundtrip-pair':row['caveat']='Diagnostic pointer round trip only, not proposed PR source.'
  candidates.append(row)
assert len(candidates)==26 and sum(x['valid_source_evidence'] for x in candidates)==25
for suffix in ['iro-baseline','iro-reassociated']:
 p=Path('/tmp/c016-decoder-chroma-'+suffix);files.extend((f,str(f.relative_to('/tmp'))) for f in p.rglob('*') if f.is_file());assert json.loads((p/'provenance.json').read_text())['exit_code']==0
for suffix in ['doctor.log','capture.py','iro-baseline.log','iro-reassociated.log','inspect.log','inspect-cleanup.log','retained.json','retained.log','build.log','retained-pcdump.txt','retained-dump.log','model-check.py','model-check.json','pr.md','pr-doctor.log','pr-build.log','pr-status.json','final.json','final.log','final-build.log','mismatch-pattern.json','verification.json','archive.py']:
 p=Path('/tmp/c016-decoder-chroma-'+suffix);files.append((p,p.name))
for suffix in ['current-pcdump.txt','order-interactions.json','float-baseline.json']:
 p=Path('/tmp/c016-decoder-'+suffix);files.append((p,p.name))
p=Path('/tmp/c016-decoder-gprsum/row-low-high.c');files.append((p,'iro-reassociated-source.c'))
files.append((source,'retained-hsd_3B5C.c'))
for name in ['tiebreak.py','colorgraph_parser.py']:
 p=Path('tools/melee-agent/src/mwcc_debug')/name;files.append((p,'model-reference/'+name))
m={'function':'fn_803B6820','scratch':None,'pr':'https://github.com/doldecomp/melee/pull/3384','retained_source_change':True,'validation':validation,'candidates':candidates,'remote_inspector':{'invocation':'inspect-24ade80b72d832b1894b2449','result':'exact-ref fetch failure, wrapper timeout125, cleanup retry124 lacks terminal proof','issue':1497,'dump_produced':False},'members':[]}
assert len({n for p,n in files})==len(files)
with tarfile.open(root/'evidence.tar.gz','w:gz') as t:
 for p,n in sorted(files,key=lambda x:x[1]):
  d=p.read_bytes();m['members'].append({'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()});t.add(p,arcname=n)
with tarfile.open(root/'evidence.tar.gz') as t:
 for f in m['members']:assert hashlib.sha256(t.extractfile(f['path']).read()).hexdigest()==f['sha256']
m['archive_sha256']=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest();(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified',len(files),'members;',len(candidates),'runs, 25 valid;', (root/'evidence.tar.gz').stat().st_size,'bytes')

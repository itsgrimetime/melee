from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-chroma-pair');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b]
old='''                            chroma_column = (block % 2) * 4;
                            chroma = base + ((chroma_row + ((block / 2) << 5) +
                                              chroma_column) *
                                             4);'''
assert old in part
variants={}
for layout in ['xy-record','yx-record','array']:
 for scaled in [False,True]:
  for pad in ['keep','remove']:
   if layout=='array':decl='s32 block_position[2];';low='block_position[0]';high='block_position[1]'
   else:decl='struct { s32 '+('x, y' if layout=='xy-record' else 'y, x')+'; } block_position;';low='block_position.x';high='block_position.y'
   lo='(block % 2)'+(' * 4' if scaled else '');hi='(block / 2)'+(' << 5' if scaled else '')
   expr='chroma_row + '+(low if scaled else low+' * 4')+' + '+(high if scaled else '('+high+' << 5)')
   repl='                            '+decl+'\n                            '+low+' = '+lo+';\n                            '+high+' = '+hi+';\n                            chroma = base + (('+expr+') * 4);'
   s=part.replace(old,repl).replace('    s32 chroma_column;\n','')
   if pad=='remove':s=s.replace('    PAD_STACK(8);\n','')
   variants[layout+('-scaled-' if scaled else '-raw-')+pad]=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in variants.items():
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1],(name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

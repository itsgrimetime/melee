from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_bytes();candidate=Path('/tmp/c016-decoder-gprsum/row-low-high.c').read_bytes()
try:
 p.write_bytes(candidate)
 r=subprocess.run(['melee-agent','debug','retro','dump',str(p),'-f','fn_803B6820','--phases','frontend','--output','/tmp/c016-decoder-chroma-iro-reassociated','--timeout','120'],capture_output=True,text=True)
 Path('/tmp/c016-decoder-chroma-iro-reassociated.log').write_text(r.stdout+r.stderr);print('retail frontend exit',r.returncode,flush=True)
finally:p.write_bytes(base)

from pathlib import Path
import sys,json,re
sys.path.insert(0,str(Path('tools/melee-agent').resolve()))
from src.mwcc_debug.tiebreak import load_gpr_ig,validate_g1,predict_assignments
old=load_gpr_ig(Path('/tmp/c016-decoder-current-pcdump.txt').read_text(),'fn_803B6820');new=load_gpr_ig(Path('/tmp/c016-decoder-chroma-retained-pcdump.txt').read_text(),'fn_803B6820')
def shape(g):return {'order':g.select_order,'nodes':{n:{'neighbors':sorted(v.neighbors),'precolored':v.precolored,'observed':v.observed_reg,'incomplete':v.incomplete} for n,v in g.nodes.items()}}
assert shape(old)==shape(new)
g=validate_g1(new);assert g.correct==g.total==110 and g.spill_abstained==0
model=json.loads(Path('/tmp/c016-decoder-order-interactions.json').read_text());win=next(r for r in model['rows'] if not r['differences'])
pred=predict_assignments(new,order=win['select_order']);assert {str(k):v for k,v in pred.items()}==win['predicted_assignments']
a=json.loads(Path('/tmp/c016-decoder-float-baseline.json').read_text());b=json.loads(Path('/tmp/c016-decoder-chroma-retained.json').read_text())
def code(d):return {x[:4]:x.split('\t')[0].strip() for x in d['current_asm'] if re.match(r'^\+[0-9a-f]+: (?:[0-9a-f]{2} ){3}[0-9a-f]{2}',x)}
aa=code(a);bb=code(b);assert aa.keys()==bb.keys() and len(aa)==241
changes=[{'offset':k,'before':aa[k],'after':bb[k]} for k in aa if aa[k]!=bb[k]];assert len(changes)==1 and changes[0]['offset']=='+1cc'
result={'ordinary_before':a['fuzzy_match_percent'],'ordinary_after':b['fuzzy_match_percent'],'instruction_changes':changes,'gpr_graph_and_select_order_equal':True,'g1_correct':110,'g1_total':110,'existing_abstract_order_replays':True,'moves':win['moves'],'scope':'No source realization of the abstract order. Equality covers recorded select-order graph, precolored neighbors, observed colors, and completeness; not uncaptured retail optimizer internals.'}
Path('/tmp/c016-decoder-chroma-model-check.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-offset-lifetimes');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b];variants={}
for var in ['tile_offset','out_offset','group_row']:
 for embedded in [False,True]:
  s=part
  if var=='tile_offset':s=s.replace('    PAD_STACK(8);','    s32 tile_offset;\n    PAD_STACK(8);')
  if embedded:s=s.replace('((x / 4) * 0x10)','('+var+' = (x / 4) * 0x10)')
  else:
   s=s.replace('((x / 4) * 0x10)',var)
   s=s.replace('        out = (u16*) dst','        '+var+' = (x / 4) * 0x10;\n        out = (u16*) dst')
  variants[var+('-embedded' if embedded else '-inner-assignment')]=base[:a]+s+base[b:]
for scope in ['last','block','sample','first']:
 s=part.replace('    u8* chroma;\n','')
 marker={'last':'    PAD_STACK(8);','first':'    s32 tile_y;','block':'                    for (block = 0; block < 4; block++) {\n','sample':'                        luminance = luma_base[block * 64];'}[scope]
 if scope=='block':s=s.replace(marker,marker+'                        u8* chroma;\n')
 else:s=s.replace(marker,'    u8* chroma;\n'+marker)
 variants['chroma-'+scope]=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in variants.items():
  assert full!=base
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1], (name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

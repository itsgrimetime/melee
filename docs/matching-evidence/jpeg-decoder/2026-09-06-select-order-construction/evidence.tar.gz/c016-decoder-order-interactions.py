from pathlib import Path
import sys,json
sys.path.insert(0,str(Path('tools/melee-agent').resolve()))
from src.mwcc_debug.tiebreak import load_gpr_ig,validate_g1,predict_assignments
ig=load_gpr_ig(Path('/tmp/c016-decoder-current-pcdump.txt').read_text(),'fn_803B6820')
g=validate_g1(ig);assert g.correct==g.total==110 and not g.spill_abstained
base=predict_assignments(ig)
forced='65:15,100:16,101:16,102:11,103:11,104:11,105:11,106:11,37:16,114:11,112:11,110:11,108:16,63:20,44:18,78:16,116:16,75:28,120:17,122:28,118:17,77:17,124:16,79:17,128:16,130:18,126:16,140:17'
target=dict(base);target.update({int(a):int(b) for a,b in (x.split(':') for x in forced.split(','))})
rows=[]
scenarios = [[], [(65,'after',122)], [(65,'after',122),(63,'before',64)]]
for marker in [140,130,124,116,114,112,110,108,101,100]:
 scenarios.append([(65,'after',122),(63,'before',64),(37,'after',marker)])
 scenarios.append([(65,'after',122),(63,'before',64),(78,'after',122),(37,'after',marker)])
for marker in [128,79,76,37,146,140,132]:
 scenarios.append([(65,'after',122),(63,'before',64),(78,'after',122),(37,'after',114),(77,'after',marker)])
for green_marker in [128,76,132,126]:
 for result_marker in [76,132,126]:
  scenarios.append([(65,'after',122),(63,'before',64),(78,'after',122),(37,'after',114),(77,'after',green_marker),(79,'after',result_marker)])
winning = [(65,'after',122),(63,'before',64),(78,'after',122),(37,'after',114),(77,'after',128),(79,'after',76)]
for i in range(len(winning)):
 scenarios.append(winning[:i]+winning[i+1:])
for moves in scenarios:
 order=list(ig.select_order)
 for node,where,marker in moves:
  order.remove(node);order.insert(order.index(marker)+(where=='after'),node)
 pred=predict_assignments(ig,order=order)
 row={'moves':moves,'focus':{str(n):pred[n] for n in [65,63,64,44,37,118,78,122,66]},'differences':[{'ig':n,'predicted':v,'target':target[n]} for n,v in pred.items() if target[n]!=v]}
 row['select_order']=order;row['predicted_assignments']=pred;rows.append(row);print({k:v for k,v in row.items() if k not in ['select_order','predicted_assignments']})
Path('/tmp/c016-decoder-order-interactions.json').write_text(json.dumps({'scope':'Abstract select-order perturbations using existing validated G1 model, baseline graph unchanged; no source realizability or full target proof. Target extension assumes other baseline physical assignments should remain unchanged.','rows':rows},indent=2)+'\n')

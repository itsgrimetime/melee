from pathlib import Path
import json,hashlib,tarfile,re,subprocess
root=Path('docs/matching-evidence/jpeg-decoder/2026-09-06-select-order-construction');root.mkdir(parents=True,exist_ok=True)
head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()
assert subprocess.check_output(['git','diff','--','src/sysdolphin/baselib/hsd_3B5C.c'],text=True)==''
a=json.loads(Path('/tmp/c016-decoder-float-baseline.json').read_text());b=json.loads(Path('/tmp/c016-decoder-coordinate-owner/wide-channels-no-pad.json').read_text());restored=json.loads(Path('/tmp/c016-decoder-order-restored.json').read_text())
def code(d):return [x.split('\t')[0].strip() for x in d['current_asm'] if re.match(r'^\+[0-9a-f]+: (?:[0-9a-f]{2} ){3}[0-9a-f]{2}',x)]
assert len(code(a))==len(code(b))==241 and code(a)==code(b)
assert restored['fuzzy_match_percent']==98.81743
report=json.loads(Path('build/GALE01/report.json').read_text());unit=next(u for u in report['units'] if u['name'].endswith('sysdolphin/baselib/hsd_3B5C'))
functions=[{'name':f['name'],'percent':f['fuzzy_match_percent']} for f in unit['functions']]
assert len(functions)==6 and all(f['percent']==(98.81743 if f['name']=='fn_803B6820' else 100) for f in functions)
sha1={str(p):hashlib.sha1(p.read_bytes()).hexdigest() for p in [Path('build/GALE01/main.dol'),Path('orig/GALE01/sys/main.dol')]};assert len(set(sha1.values()))==1
v={'source_head':head,'source_sha256':hashlib.sha256(Path('src/sysdolphin/baselib/hsd_3B5C.c').read_bytes()).hexdigest(),'ordinary_match':98.81743,'other_tu_functions':functions,'full_build_exit':0,'sha1':sha1,'wide_channels_no_padding':{'instruction_bytes_equal':True,'instructions':241,'scope':'Only instruction bytes, not anonymous relocation identity or linked candidate data proof'}}
Path('/tmp/c016-decoder-order-verification.json').write_text(json.dumps(v,indent=2)+'\n')
files=[];candidates=[];normalized=set()
for family in ['float-boundary','coordinate-owner','sample-parameters','offset-lifetimes','clamp-shape','clamp-result-owner']:
 p=Path('/tmp/c016-decoder-'+family);files.extend((f,str(f.relative_to('/tmp'))) for f in p.rglob('*') if f.is_file());files.append((Path(str(p)+'.py'),p.name+'.py'))
 for r in json.loads((p/'results.json').read_text()):
  candidates.append({'family':family,**r});normalized.add(re.sub(r'\s+','',(p/(r['name']+'.c')).read_text()))
assert len(candidates)==56 and len(normalized)==55
for name in ['float-doctor.log','float-baseline.json','current-pcdump.txt','order-interactions.py','order-interactions.json','order-interactions.log','tiebreak-baseline.json','donor-hashed.txt','donor-local.txt','donor-windows.txt','order-restored.json','order-restored.log','order-build.log','order-verification.json','archive-order.py']:
 p=Path('/tmp/c016-decoder-'+name);files.append((p,p.name))
for p in Path('/tmp').glob('c016-decoder-tiebreak-after-*.json'):files.append((p,p.name))
for name in ['tiebreak.py','colorgraph_parser.py']:
 p=Path('tools/melee-agent/src/mwcc_debug')/name;files.append((p,'model-reference/'+name))
files.append((Path('src/sysdolphin/baselib/hsd_3B5C.c'),'restored-hsd_3B5C.c'))
m={'function':'fn_803B6820','scratch':None,'source_head':head,'retained_percent':98.81743,'retained_source_change':False,'validation':v,'candidates':candidates,'unique_whitespace_normalized_sources':len(normalized),'model_scope':'Abstract select-order perturbations only; not simplify-order or source realizability proof. Explicit target map supplemented by observed colors of other nodes.','members':[]}
assert len({n for p,n in files})==len(files)
with tarfile.open(root/'evidence.tar.gz','w:gz') as t:
 for p,n in sorted(files,key=lambda x:x[1]):
  d=p.read_bytes();m['members'].append({'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()});t.add(p,arcname=n)
with tarfile.open(root/'evidence.tar.gz') as t:
 for f in m['members']:assert hashlib.sha256(t.extractfile(f['path']).read()).hexdigest()==f['sha256']
m['archive_sha256']=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest();(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('Verified',len(files),'members;',len(candidates),'source runs;',len(normalized),'whitespace-normalized sources;', (root/'evidence.tar.gz').stat().st_size,'bytes');print(json.dumps(v,indent=2))

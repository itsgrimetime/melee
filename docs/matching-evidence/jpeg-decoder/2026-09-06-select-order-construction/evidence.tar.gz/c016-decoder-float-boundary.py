from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-float-boundary');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline s32 jpeg_clamp('); b=base.index('static inline void jpeg_store_rgb565(',a); c=base.index('static void fn_803B6820(',b)
clamp=base[a:b];helper=base[b:c]; variants={}
variants['double-clamp-input']=base[:a]+clamp.replace('f32 value','f64 value')+base[b:]
variants['double-clamp-float-comparisons']=base[:a]+clamp.replace('f32 value','f64 value').replace('value < 0.0f','(f32) value < 0.0f').replace('255.0f < value','255.0f < (f32) value')+base[b:]
variants['double-clamp-local-float']=base[:a]+clamp.replace('f32 value','f64 input').replace('{\n','{\n    f32 value = input;\n',1)+base[b:]
for ch in ['red','green','blue','all']:
 h=helper
 if ch=='all':h=h.replace('f32 red_value, green_value, blue_value;','f64 red_value, green_value, blue_value;')
 else:
  others=[x+'_value' for x in ['red','green','blue'] if x!=ch]
  h=h.replace('f32 red_value, green_value, blue_value;','f32 '+', '.join(others)+';\n    f64 '+ch+'_value;')
 variants[ch+'-wide-local']=base[:b]+h+base[c:]
# Move the same float rounding boundary from a named local to helper parameter conversion.
for ch in ['red','blue','both']:
 h=helper
 if ch in ['red','both']:
  h=h.replace('red_value = (f32) ((1.402 * (f64) cr) + (f64) luminance);','red_value = ((1.402 * (f64) cr) + (f64) luminance);')
 if ch in ['blue','both']:
  h=h.replace('blue_value = (f32) ((f64)', 'blue_value = ((f64)')
 types=['f64' if x in ([ch] if ch!='both' else ['red','blue']) else 'f32' for x in ['red','green','blue']]
 h=h.replace('f32 red_value, green_value, blue_value;','\n    '.join(t+' '+x+'_value;' for t,x in zip(types,['red','green','blue'])))
 variants[ch+'-round-at-call']=base[:b]+h+base[c:]
rows=[]
try:
 for name,full in variants.items():
  assert full!=base
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1], (name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

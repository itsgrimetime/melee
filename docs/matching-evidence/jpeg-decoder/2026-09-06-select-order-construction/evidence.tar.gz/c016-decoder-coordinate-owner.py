from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-coordinate-owner');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b];variants={}
for xmode in ['quotient','scaled']:
 for owner in ['parameter','local','record']:
  for place in ['pre-bias','pre-groups']:
   s=part
   value='x / 4' if xmode=='quotient' else '(x / 4) * 0x10'
   var={'parameter':'x','local':'tile_offset','record':'position.x'}[owner]
   expr='('+var+' * 0x10)' if xmode=='quotient' else var
   s=s.replace('((x / 4) * 0x10)',expr)
   if owner=='local':s=s.replace('    PAD_STACK(8);','    s32 tile_offset;\n    PAD_STACK(8);')
   if owner=='record':s=s.replace('    PAD_STACK(8);','    struct { s32 x; } position;\n    PAD_STACK(8);')
   marker='    base = hsd_804D2E70;' if place=='pre-bias' else '    for (group_y = 0; group_y < 2; group_y++) {'
   assert marker in s;s=s.replace(marker,'    '+var+' = '+value+';\n'+marker)
   variants[xmode+'-'+owner+'-'+place]=base[:a]+s+base[b:]
for owner in ['parameter','record']:
 s=part
 if owner=='parameter':
  init='    x = (x / 4) * 0x10;\n    y /= 4;\n'
  s=s.replace('((x / 4) * 0x10)','x').replace('(y / 4)','y')
 else:
  s=s.replace('    PAD_STACK(8);','    struct { s32 x, y; } position;')
  init='    position.x = (x / 4) * 0x10;\n    position.y = y / 4;\n'
  s=s.replace('((x / 4) * 0x10)','position.x').replace('(y / 4)','position.y')
 marker='    for (group_y = 0; group_y < 2; group_y++) {';s=s.replace(marker,init+marker)
 variants['both-scaled-'+owner]=base[:a]+s+base[b:]
v=Path('/tmp/c016-decoder-float-boundary/both-round-at-call.c').read_text();va=v.index('static void fn_803B6820(');vb=v.index('static inline s32 hsd_803B6BE4_inline',va)
variants['wide-channels-no-pad']=v[:va]+v[va:vb].replace('    PAD_STACK(8);\n','')+v[vb:]
rows=[]
try:
 for name,full in variants.items():
  assert full!=base
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1], (name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-clamp-result-owner');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline void jpeg_store_rgb565(');b=base.index('static void fn_803B6820(',a);part=base[a:b];variants={}
for channel in ['red','green','blue','all']:
 s=part
 for ch in (['red','green','blue'] if channel=='all' else [channel]):
  v=ch+'_value';dest='green' if ch=='green' else 'pixel.'+ch;temp=ch+'_clamped'
  s=s.replace('    u8 green;','    s32 '+temp+';\n    u8 green;')
  marker=dest+' = jpeg_clamp('+v+');';assert marker in s
  expr='if ('+v+' < 0.0f) {\n        '+temp+' = 0;\n    } else if (255.0f < '+v+') {\n        '+temp+' = 255;\n    } else {\n        '+temp+' = (u8) (s32) '+v+';\n    }\n    '+dest+' = '+temp+';'
  s=s.replace(marker,expr)
 variants[channel+'-wide-result']=base[:a]+s+base[b:]
# A measured +8-byte natural local layout compensates the flat blue clamp's -8 bytes.
s=Path('/tmp/c016-decoder-float-boundary/both-round-at-call.c').read_text()
cs=Path('/tmp/c016-decoder-clamp-shape/branches-blue.c').read_text();ca=cs.index('    if (blue_value <');cb=cs.index('\n\n    *out',ca)
s=s.replace('    pixel.blue = jpeg_clamp(blue_value);',cs[ca:cb])
variants['wide-values-flat-blue']=s
rows=[]
try:
 for name,full in variants.items():
  assert full!=base
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1], (name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-sample-parameters');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline void jpeg_store_rgb565(');b=base.index('static void fn_803B6820(',a);part=base[a:b];variants={}
for flags in itertools.product([False,True],repeat=3):
 if not any(flags):continue
 s=part;name=[]
 for flag,ch,typ in zip(flags,['luminance','cb','cr'],['f64','f32','f64']):
  if flag:s=s.replace('s32 '+ch,typ+' '+ch,1);name.append(ch)
 variants['-'.join(name)]=base[:a]+s+base[b:]
# Cb only participates in float arithmetic; double parameter plus its existing casts is also exact.
variants['all-double']=base[:a]+part.replace('s32 luminance','f64 luminance',1).replace('s32 cb','f64 cb',1).replace('s32 cr','f64 cr',1)+base[b:]
rows=[]
try:
 for name,full in variants.items():
  assert full!=base
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1], (name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-clamp-shape');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline void jpeg_store_rgb565(');b=base.index('static void fn_803B6820(',a);part=base[a:b];variants={}
for form in ['conditional','branches']:
 for channel in ['red','green','blue','all']:
  s=part
  for ch in (['red','green','blue'] if channel=='all' else [channel]):
   v=ch+'_value';dest='green' if ch=='green' else 'pixel.'+ch
   marker=dest+' = jpeg_clamp('+v+');';assert marker in s
   if form=='conditional':expr=dest+' = '+v+' < 0.0f ? 0 : (255.0f < '+v+' ? 255 : (u8) (s32) '+v+');'
   else:expr='if ('+v+' < 0.0f) {\n        '+dest+' = 0;\n    } else if (255.0f < '+v+') {\n        '+dest+' = 255;\n    } else {\n        '+dest+' = (u8) (s32) '+v+';\n    }'
   s=s.replace(marker,expr)
  variants[form+'-'+channel]=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in variants.items():
  assert full!=base
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1], (name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-gprsum');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b]
old='''chroma_row + ((block / 2) << 5) +
                                              chroma_column'''
assert part.count(old)==1
variants={
 'row-low-high':'(chroma_row + chroma_column) + ((block / 2) << 5)',
 'low-high-row':'(chroma_column + ((block / 2) << 5)) + chroma_row',
 'high-row-low':'((block / 2) << 5) + (chroma_row + chroma_column)',
 'row-low-high-right':'chroma_row + (chroma_column + ((block / 2) << 5))',
}
rows=[]
try:
 for name,expr in variants.items():
  s=part.replace(old,expr);full=base[:a]+s+base[b:];(out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

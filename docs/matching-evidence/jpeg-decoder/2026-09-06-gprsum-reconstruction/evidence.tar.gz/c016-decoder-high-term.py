from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-high-term');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b]
old='''                            chroma_column = (block % 2) * 4;
                            chroma = base + ((chroma_row + ((block / 2) << 5) +
                                              chroma_column) *
                                             4);'''
assert part.count(old)==1
variants={}
for typ in ['s32','int','u32']:
 for order in ['low-high','high-low']:
  for pad in ['keep','remove']:
   low='                            chroma_column = (block % 2) * 4;\n'; high='                            chroma_high = (block / 2) << 5;\n'
   repl='                            '+typ+' chroma_high;\n'+(low+high if order=='low-high' else high+low)+'                            chroma = base + ((chroma_row + chroma_column + chroma_high) * 4);'
   s=part.replace(old,repl)
   if pad=='remove':s=s.replace('    PAD_STACK(8);\n','')
   variants[typ+'-'+order+'-'+pad]=s
rows=[]
try:
 for name,s in variants.items():
  full=base[:a]+s+base[b:];(out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-padding-reconstruction');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b]
import re
variants={}
prior=Path.home()/'.config/decomp-me/matching-evidence/jpeg-color-2026-09-06/allocator-followup'
for name in ['chroma-aggregate','chroma-aggregate-reverse','samples-aggregate','samples-aggregate-ycbcr']:
 c=(prior/('c016-color2-'+name+'.c')).read_text();x=c.index('static void fn_803B6820(');y=c.index('static inline s32 hsd_803B6BE4_inline',x);s=c[x:y].replace('    PAD_STACK(8);\n','');variants[name+'-no-pad']=s
for names in [('chroma_row','chroma_column'),('group_row','group_chroma'),('luma_x','luma_row_offset')]:
 s=part
 for name in names:
  s=s.replace('    s32 '+name+';\n','');s=re.sub(r'\b'+name+r'\b','offsets.'+name,s)
 decl='    struct { s32 '+names[0]+'; s32 '+names[1]+'; } offsets;\n'
 s=s.replace('    PAD_STACK(8);\n',decl)
 variants['record-'+names[0]+'-no-pad']=s
rows=[]
try:
 for name,s in variants.items():
  full=base[:a]+s+base[b:];(out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

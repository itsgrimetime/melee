from pathlib import Path
import json,hashlib,tarfile,re,subprocess
root=Path('docs/matching-evidence/jpeg-decoder/2026-09-06-gprsum-reconstruction');root.mkdir(parents=True,exist_ok=True)
a=json.loads(Path('/tmp/c016-decoder-baseline-current.json').read_text());b=json.loads(Path('/tmp/c016-decoder-padding-reconstruction/record-group_row-no-pad.json').read_text())
def code(d):return [x.split('\t')[0].strip() for x in d['current_asm'] if re.match(r'^\+[0-9a-f]+: (?:[0-9a-f]{2} ){3}[0-9a-f]{2}',x)]
assert len(code(a))==len(code(b))==241 and code(a)==code(b)
validation={'instruction_byte_comparison':{'baseline_count':241,'candidate_count':241,'identical':True,'scope':'Instruction bytes only; anonymous relocation symbol names differ; not linked candidate proof.'},'restored_percent':json.loads(Path('/tmp/c016-decoder-restored-current.json').read_text())['fuzzy_match_percent'],'full_build_exit':0,'checksums':[]}
r=json.loads(Path('build/GALE01/report.json').read_text());u=next(u for u in r['units'] if u['name'].endswith('sysdolphin/baselib/hsd_3B5C'));validation['restored_tu_functions']=[{'name':f['name'],'percent':f.get('fuzzy_match_percent')} for f in u['functions']]
for f in ['build/GALE01/main.dol','orig/GALE01/sys/main.dol']:validation['checksums'].append({'path':f,'sha1':hashlib.sha1(Path(f).read_bytes()).hexdigest()})
assert validation['checksums'][0]['sha1']==validation['checksums'][1]['sha1'];Path('/tmp/c016-decoder-verification-current.json').write_text(json.dumps(validation,indent=2)+'\n')
files=[];candidates=[]
for family in ['gprsum','high-term','padding-reconstruction']:
 p=Path('/tmp/c016-decoder-'+family);files.extend((f,str(f.relative_to('/tmp'))) for f in p.rglob('*') if f.is_file());files.append((Path(str(p)+'.py'),p.name+'.py'));candidates.extend({'family':family,**r} for r in json.loads((p/'results.json').read_text()))
for name in ['baseline-current.json','baseline-current.log','restored-current.json','restored-current.log','build-current.log','verification-current.json','archive-current.py']:
 f=Path('/tmp/c016-decoder-'+name);files.append((f,f.name))
m={'function':'fn_803B6820','scratch':None,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'retained_percent':98.81743,'retained_frame':176,'retained_source_change':False,'useful_candidate':'c016-decoder-padding-reconstruction/record-group_row-no-pad.c','candidate_caveat':'Removes PAD_STACK with group-row aggregate, same instruction bytes and score; not a 100% source match.','validation':validation,'candidates':candidates,'members':[]}
with tarfile.open(root/'evidence.tar.gz','w:gz') as t:
 for p,n in sorted(files,key=lambda x:x[1]):
  d=p.read_bytes();m['members'].append({'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()});t.add(p,arcname=n)
with tarfile.open(root/'evidence.tar.gz') as t:
 for f in m['members']:assert hashlib.sha256(t.extractfile(f['path']).read()).hexdigest()==f['sha256']
m['archive_sha256']=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest();(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified',len(files),'archive members;',len(candidates),'probes');print(json.dumps(validation,indent=2))

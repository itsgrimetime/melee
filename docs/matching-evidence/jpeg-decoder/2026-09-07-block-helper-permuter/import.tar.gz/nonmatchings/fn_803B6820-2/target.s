# General Purpose Registers (GPRs)
.set r0, 0
.set r1, 1
.set r2, 2
.set r3, 3
.set r4, 4
.set r5, 5
.set r6, 6
.set r7, 7
.set r8, 8
.set r9, 9
.set r10, 10
.set r11, 11
.set r12, 12
.set r13, 13
.set r14, 14
.set r15, 15
.set r16, 16
.set r17, 17
.set r18, 18
.set r19, 19
.set r20, 20
.set r21, 21
.set r22, 22
.set r23, 23
.set r24, 24
.set r25, 25
.set r26, 26
.set r27, 27
.set r28, 28
.set r29, 29
.set r30, 30
.set r31, 31

# Floating Point Registers (FPRs)
.set f0, 0
.set f1, 1
.set f2, 2
.set f3, 3
.set f4, 4
.set f5, 5
.set f6, 6
.set f7, 7
.set f8, 8
.set f9, 9
.set f10, 10
.set f11, 11
.set f12, 12
.set f13, 13
.set f14, 14
.set f15, 15
.set f16, 16
.set f17, 17
.set f18, 18
.set f19, 19
.set f20, 20
.set f21, 21
.set f22, 22
.set f23, 23
.set f24, 24
.set f25, 25
.set f26, 26
.set f27, 27
.set f28, 28
.set f29, 29
.set f30, 30
.set f31, 31

# Graphics Quantization Registers (GQRs)
.set qr0, 0
.set qr1, 1
.set qr2, 2
.set qr3, 3
.set qr4, 4
.set qr5, 5
.set qr6, 6
.set qr7, 7

# Special Purpose Registers (SPRs)
.set XER, 1
.set LR, 8
.set CTR, 9
.set DSISR, 18
.set DAR, 19
.set DEC, 22
.set SDR1, 25
.set SRR0, 26
.set SRR1, 27
.set SPRG0, 272
.set SPRG1, 273
.set SPRG2, 274
.set SPRG3, 275
.set EAR, 282
.set PVR, 287
.set IBAT0U, 528
.set IBAT0L, 529
.set IBAT1U, 530
.set IBAT1L, 531
.set IBAT2U, 532
.set IBAT2L, 533
.set IBAT3U, 534
.set IBAT3L, 535
.set DBAT0U, 536
.set DBAT0L, 537
.set DBAT1U, 538
.set DBAT1L, 539
.set DBAT2U, 540
.set DBAT2L, 541
.set DBAT3U, 542
.set DBAT3L, 543
.set GQR0, 912
.set GQR1, 913
.set GQR2, 914
.set GQR3, 915
.set GQR4, 916
.set GQR5, 917
.set GQR6, 918
.set GQR7, 919
.set HID2, 920
.set WPAR, 921
.set DMA_U, 922
.set DMA_L, 923
.set UMMCR0, 936
.set UPMC1, 937
.set UPMC2, 938
.set USIA, 939
.set UMMCR1, 940
.set UPMC3, 941
.set UPMC4, 942
.set USDA, 943
.set MMCR0, 952
.set PMC1, 953
.set PMC2, 954
.set SIA, 955
.set MMCR1, 956
.set PMC3, 957
.set PMC4, 958
.set SDA, 959
.set HID0, 1008
.set HID1, 1009
.set IABR, 1010
.set DABR, 1013
.set L2CR, 1017
.set ICTC, 1019
.set THRM1, 1020
.set THRM2, 1021
.set THRM3, 1022

# Condition Register (CR) bits
.set cr0lt, 0
.set cr0gt, 1
.set cr0eq, 2
.set cr0un, 3
.set cr1lt, 4
.set cr1gt, 5
.set cr1eq, 6
.set cr1un, 7
.set cr2lt, 8
.set cr2gt, 9
.set cr2eq, 10
.set cr2un, 11
.set cr3lt, 12
.set cr3gt, 13
.set cr3eq, 14
.set cr3un, 15
.set cr4lt, 16
.set cr4gt, 17
.set cr4eq, 18
.set cr4un, 19
.set cr5lt, 20
.set cr5gt, 21
.set cr5eq, 22
.set cr5un, 23
.set cr6lt, 24
.set cr6gt, 25
.set cr6eq, 26
.set cr6un, 27
.set cr7lt, 28
.set cr7gt, 29
.set cr7eq, 30
.set cr7un, 31

# Defines a sized symbol with function type.
# Usage:
# .fn my_function, local
# /* asm here */
# .endfn my_function
.macro .fn name, visibility=global
.\visibility "\name"
.type "\name", @function
"\name":
.endm

.macro .endfn name
.size "\name", . - "\name"
.endm

# Defines a sized symbol with object type.
# Usage:
# .obj my_object, local
# /* data here */
# .endobj my_object
.macro .obj name, visibility=global
.\visibility "\name"
.type "\name", @object
"\name":
.endm

.macro .endobj name
.size "\name", . - "\name"
.endm

# Defines a sized symbol without a type.
# Usage:
# .sym my_sym, local
# /* anything here */
# .endsym my_sym
.macro .sym name, visibility=global
.\visibility "\name"
"\name":
.endm

.macro .endsym name
.size "\name", . - "\name"
.endm

# Generates a relative relocation against a symbol.
# Usage:
# .rel my_function, .L_label
.macro .rel name, label
.4byte "\name" + ("\label" - "\name")
.endm
.fn fn_803B6820, global
/* 803B6820 003B3400  94 21 FF 50 */	stwu r1, -0xb0(r1)
/* 803B6824 003B3404  3C E0 80 4D */	lis r7, hsd_804D2E70@ha
/* 803B6828 003B3408  39 40 00 00 */	li r10, 0x0
/* 803B682C 003B340C  BD C1 00 68 */	stmw r14, 0x68(r1)
/* 803B6830 003B3410  3B A7 2E 70 */	addi r29, r7, hsd_804D2E70@l
/* 803B6834 003B3414  39 3D 01 18 */	addi r9, r29, 0x118
.L_803B6838:
/* 803B6838 003B3418  38 00 00 04 */	li r0, 0x4
/* 803B683C 003B341C  7C 09 03 A6 */	mtctr r0
/* 803B6840 003B3420  39 09 00 00 */	addi r8, r9, 0x0
.L_803B6844:
/* 803B6844 003B3424  80 E8 00 00 */	lwz r7, 0x0(r8)
/* 803B6848 003B3428  38 07 00 80 */	addi r0, r7, 0x80
/* 803B684C 003B342C  90 08 00 00 */	stw r0, 0x0(r8)
/* 803B6850 003B3430  80 E8 00 04 */	lwz r7, 0x4(r8)
/* 803B6854 003B3434  38 07 00 80 */	addi r0, r7, 0x80
/* 803B6858 003B3438  90 08 00 04 */	stw r0, 0x4(r8)
/* 803B685C 003B343C  80 E8 00 08 */	lwz r7, 0x8(r8)
/* 803B6860 003B3440  38 07 00 80 */	addi r0, r7, 0x80
/* 803B6864 003B3444  90 08 00 08 */	stw r0, 0x8(r8)
/* 803B6868 003B3448  80 E8 00 0C */	lwz r7, 0xc(r8)
/* 803B686C 003B344C  38 07 00 80 */	addi r0, r7, 0x80
/* 803B6870 003B3450  90 08 00 0C */	stw r0, 0xc(r8)
/* 803B6874 003B3454  80 E8 00 10 */	lwz r7, 0x10(r8)
/* 803B6878 003B3458  38 07 00 80 */	addi r0, r7, 0x80
/* 803B687C 003B345C  90 08 00 10 */	stw r0, 0x10(r8)
/* 803B6880 003B3460  80 E8 00 14 */	lwz r7, 0x14(r8)
/* 803B6884 003B3464  38 07 00 80 */	addi r0, r7, 0x80
/* 803B6888 003B3468  90 08 00 14 */	stw r0, 0x14(r8)
/* 803B688C 003B346C  80 E8 00 18 */	lwz r7, 0x18(r8)
/* 803B6890 003B3470  38 07 00 80 */	addi r0, r7, 0x80
/* 803B6894 003B3474  90 08 00 18 */	stw r0, 0x18(r8)
/* 803B6898 003B3478  80 E8 00 1C */	lwz r7, 0x1c(r8)
/* 803B689C 003B347C  38 07 00 80 */	addi r0, r7, 0x80
/* 803B68A0 003B3480  90 08 00 1C */	stw r0, 0x1c(r8)
/* 803B68A4 003B3484  80 E8 00 20 */	lwz r7, 0x20(r8)
/* 803B68A8 003B3488  38 07 00 80 */	addi r0, r7, 0x80
/* 803B68AC 003B348C  90 08 00 20 */	stw r0, 0x20(r8)
/* 803B68B0 003B3490  80 E8 00 24 */	lwz r7, 0x24(r8)
/* 803B68B4 003B3494  38 07 00 80 */	addi r0, r7, 0x80
/* 803B68B8 003B3498  90 08 00 24 */	stw r0, 0x24(r8)
/* 803B68BC 003B349C  80 E8 00 28 */	lwz r7, 0x28(r8)
/* 803B68C0 003B34A0  38 07 00 80 */	addi r0, r7, 0x80
/* 803B68C4 003B34A4  90 08 00 28 */	stw r0, 0x28(r8)
/* 803B68C8 003B34A8  80 E8 00 2C */	lwz r7, 0x2c(r8)
/* 803B68CC 003B34AC  38 07 00 80 */	addi r0, r7, 0x80
/* 803B68D0 003B34B0  90 08 00 2C */	stw r0, 0x2c(r8)
/* 803B68D4 003B34B4  80 E8 00 30 */	lwz r7, 0x30(r8)
/* 803B68D8 003B34B8  38 07 00 80 */	addi r0, r7, 0x80
/* 803B68DC 003B34BC  90 08 00 30 */	stw r0, 0x30(r8)
/* 803B68E0 003B34C0  80 E8 00 34 */	lwz r7, 0x34(r8)
/* 803B68E4 003B34C4  38 07 00 80 */	addi r0, r7, 0x80
/* 803B68E8 003B34C8  90 08 00 34 */	stw r0, 0x34(r8)
/* 803B68EC 003B34CC  80 E8 00 38 */	lwz r7, 0x38(r8)
/* 803B68F0 003B34D0  38 07 00 80 */	addi r0, r7, 0x80
/* 803B68F4 003B34D4  90 08 00 38 */	stw r0, 0x38(r8)
/* 803B68F8 003B34D8  80 E8 00 3C */	lwz r7, 0x3c(r8)
/* 803B68FC 003B34DC  38 07 00 80 */	addi r0, r7, 0x80
/* 803B6900 003B34E0  90 08 00 3C */	stw r0, 0x3c(r8)
/* 803B6904 003B34E4  39 08 00 40 */	addi r8, r8, 0x40
/* 803B6908 003B34E8  42 00 FF 3C */	bdnz .L_803B6844
/* 803B690C 003B34EC  39 4A 00 01 */	addi r10, r10, 0x1
/* 803B6910 003B34F0  2C 0A 00 04 */	cmpwi r10, 0x4
/* 803B6914 003B34F4  39 29 01 00 */	addi r9, r9, 0x100
/* 803B6918 003B34F8  41 80 FF 20 */	blt .L_803B6838
/* 803B691C 003B34FC  38 06 00 0F */	addi r0, r6, 0xf
/* 803B6920 003B3500  C0 22 F2 04 */	lfs f1, lbl_804DEBE4@sda21(r0)
/* 803B6924 003B3504  7C 06 26 70 */	srawi r6, r0, 4
/* 803B6928 003B3508  C9 42 F1 F8 */	lfd f10, lbl_804DEBD8@sda21(r0)
/* 803B692C 003B350C  7C C6 01 94 */	addze r6, r6
/* 803B6930 003B3510  C9 22 F1 F0 */	lfd f9, lbl_804DEBD0@sda21(r0)
/* 803B6934 003B3514  7C B7 16 70 */	srawi r23, r5, 2
/* 803B6938 003B3518  C1 02 F2 00 */	lfs f8, lbl_804DEBE0@sda21(r0)
/* 803B693C 003B351C  7E F7 01 94 */	addze r23, r23
/* 803B6940 003B3520  C0 E2 F2 0C */	lfs f7, lbl_804DEBEC@sda21(r0)
/* 803B6944 003B3524  7C 84 16 70 */	srawi r4, r4, 2
/* 803B6948 003B3528  C0 C2 F2 08 */	lfs f6, lbl_804DEBE8@sda21(r0)
/* 803B694C 003B352C  54 C0 20 36 */	slwi r0, r6, 4
/* 803B6950 003B3530  C8 A2 F2 18 */	lfd f5, lbl_804DEBF8@sda21(r0)
/* 803B6954 003B3534  7C 84 01 94 */	addze r4, r4
/* 803B6958 003B3538  C0 62 F2 10 */	lfs f3, lbl_804DEBF0@sda21(r0)
/* 803B695C 003B353C  3A C0 00 00 */	li r22, 0x0
/* 803B6960 003B3540  3A B6 00 00 */	addi r21, r22, 0x0
/* 803B6964 003B3544  54 CE 30 32 */	slwi r14, r6, 6
/* 803B6968 003B3548  54 8F 20 36 */	slwi r15, r4, 4
/* 803B696C 003B354C  38 C0 00 00 */	li r6, 0x0
/* 803B6970 003B3550  3F C0 43 30 */	lis r30, 0x4330
.L_803B6974:
/* 803B6974 003B3554  7C 8E B9 D6 */	mullw r4, r14, r23
/* 803B6978 003B3558  7C 8F 22 14 */	add r4, r15, r4
/* 803B697C 003B355C  54 84 08 3C */	slwi r4, r4, 1
/* 803B6980 003B3560  3B 36 00 00 */	addi r25, r22, 0x0
/* 803B6984 003B3564  7D 23 22 14 */	add r9, r3, r4
/* 803B6988 003B3568  38 E0 00 00 */	li r7, 0x0
/* 803B698C 003B356C  3B 00 00 00 */	li r24, 0x0
.L_803B6990:
/* 803B6990 003B3570  38 80 00 00 */	li r4, 0x0
/* 803B6994 003B3574  56 AC 18 38 */	slwi r12, r21, 3
.L_803B6998:
/* 803B6998 003B3578  7D 18 62 14 */	add r8, r24, r12
/* 803B699C 003B357C  54 85 17 38 */	rlwinm r5, r4, 2, 28, 28
/* 803B69A0 003B3580  7F 59 2A 14 */	add r26, r25, r5
/* 803B69A4 003B3584  55 1F 10 3A */	slwi r31, r8, 2
/* 803B69A8 003B3588  38 A0 00 00 */	li r5, 0x0
.L_803B69AC:
/* 803B69AC 003B358C  39 00 00 04 */	li r8, 0x4
/* 803B69B0 003B3590  7C AA 0E 70 */	srawi r10, r5, 1
/* 803B69B4 003B3594  7D 09 03 A6 */	mtctr r8
/* 803B69B8 003B3598  7F 7D FA 14 */	add r27, r29, r31
/* 803B69BC 003B359C  7D 4A D2 14 */	add r10, r10, r26
/* 803B69C0 003B35A0  39 00 00 00 */	li r8, 0x0
/* 803B69C4 003B35A4  3B 7B 01 18 */	addi r27, r27, 0x118
.L_803B69C8:
/* 803B69C8 003B35A8  7D 10 0E 70 */	srawi r16, r8, 1
/* 803B69CC 003B35AC  82 7B 00 00 */	lwz r19, 0x0(r27)
/* 803B69D0 003B35B0  7E 10 01 94 */	addze r16, r16
/* 803B69D4 003B35B4  56 10 08 3C */	slwi r16, r16, 1
/* 803B69D8 003B35B8  7E 10 40 10 */	subfc r16, r16, r8
/* 803B69DC 003B35BC  7D 0B 0E 70 */	srawi r11, r8, 1
/* 803B69E0 003B35C0  7D 6B 01 94 */	addze r11, r11
/* 803B69E4 003B35C4  56 10 10 3A */	slwi r16, r16, 2
/* 803B69E8 003B35C8  55 6B 28 34 */	slwi r11, r11, 5
/* 803B69EC 003B35CC  7D 70 5A 14 */	add r11, r16, r11
/* 803B69F0 003B35D0  7D 6A 5A 14 */	add r11, r10, r11
/* 803B69F4 003B35D4  55 6B 10 3A */	slwi r11, r11, 2
/* 803B69F8 003B35D8  7E 1D 5A 14 */	add r16, r29, r11
/* 803B69FC 003B35DC  6E 6B 80 00 */	xoris r11, r19, 0x8000
/* 803B6A00 003B35E0  82 90 06 18 */	lwz r20, 0x618(r16)
/* 803B6A04 003B35E4  91 61 00 5C */	stw r11, 0x5c(r1)
/* 803B6A08 003B35E8  6E 8B 80 00 */	xoris r11, r20, 0x8000
/* 803B6A0C 003B35EC  82 50 05 18 */	lwz r18, 0x518(r16)
/* 803B6A10 003B35F0  91 61 00 64 */	stw r11, 0x64(r1)
/* 803B6A14 003B35F4  55 0B 17 38 */	rlwinm r11, r8, 2, 28, 28
/* 803B6A18 003B35F8  7D 60 59 D6 */	mullw r11, r0, r11
/* 803B6A1C 003B35FC  93 C1 00 60 */	stw r30, 0x60(r1)
/* 803B6A20 003B3600  93 C1 00 58 */	stw r30, 0x58(r1)
/* 803B6A24 003B3604  C8 41 00 60 */	lfd f2, 0x60(r1)
/* 803B6A28 003B3608  C8 01 00 58 */	lfd f0, 0x58(r1)
/* 803B6A2C 003B360C  FC 42 48 28 */	fsub f2, f2, f9
/* 803B6A30 003B3610  55 10 2E B4 */	clrlslwi r16, r8, 31, 5
/* 803B6A34 003B3614  FC 00 48 28 */	fsub f0, f0, f9
/* 803B6A38 003B3618  7D 70 5A 14 */	add r11, r16, r11
/* 803B6A3C 003B361C  FC 0A 00 BA */	fmadd f0, f10, f2, f0
/* 803B6A40 003B3620  FC 00 00 18 */	frsp f0, f0
/* 803B6A44 003B3624  FC 00 40 40 */	fcmpo cr0, f0, f8
/* 803B6A48 003B3628  40 80 00 0C */	bge .L_803B6A54
/* 803B6A4C 003B362C  3A 00 00 00 */	li r16, 0x0
/* 803B6A50 003B3630  48 00 00 24 */	b .L_803B6A74
.L_803B6A54:
/* 803B6A54 003B3634  FC 01 00 40 */	fcmpo cr0, f1, f0
/* 803B6A58 003B3638  40 80 00 0C */	bge .L_803B6A64
/* 803B6A5C 003B363C  3A 00 00 FF */	li r16, 0xff
/* 803B6A60 003B3640  48 00 00 14 */	b .L_803B6A74
.L_803B6A64:
/* 803B6A64 003B3644  FC 00 00 1E */	fctiwz f0, f0
/* 803B6A68 003B3648  D8 01 00 58 */	stfd f0, 0x58(r1)
/* 803B6A6C 003B364C  82 01 00 5C */	lwz r16, 0x5c(r1)
/* 803B6A70 003B3650  56 10 06 3E */	clrlwi r16, r16, 24
.L_803B6A74:
/* 803B6A74 003B3654  6E 51 80 00 */	xoris r17, r18, 0x8000
/* 803B6A78 003B3658  6E 7C 80 00 */	xoris r28, r19, 0x8000
/* 803B6A7C 003B365C  92 21 00 64 */	stw r17, 0x64(r1)
/* 803B6A80 003B3660  6E 91 80 00 */	xoris r17, r20, 0x8000
/* 803B6A84 003B3664  93 81 00 54 */	stw r28, 0x54(r1)
/* 803B6A88 003B3668  56 1C 06 3E */	clrlwi r28, r16, 24
/* 803B6A8C 003B366C  93 C1 00 60 */	stw r30, 0x60(r1)
/* 803B6A90 003B3670  93 C1 00 50 */	stw r30, 0x50(r1)
/* 803B6A94 003B3674  C8 41 00 60 */	lfd f2, 0x60(r1)
/* 803B6A98 003B3678  92 21 00 5C */	stw r17, 0x5c(r1)
/* 803B6A9C 003B367C  C8 01 00 50 */	lfd f0, 0x50(r1)
/* 803B6AA0 003B3680  EC 42 48 28 */	fsubs f2, f2, f9
/* 803B6AA4 003B3684  93 C1 00 58 */	stw r30, 0x58(r1)
/* 803B6AA8 003B3688  EC 00 48 28 */	fsubs f0, f0, f9
/* 803B6AAC 003B368C  C8 81 00 58 */	lfd f4, 0x58(r1)
/* 803B6AB0 003B3690  EC 84 48 28 */	fsubs f4, f4, f9
/* 803B6AB4 003B3694  EC 06 00 BC */	fnmsubs f0, f6, f2, f0
/* 803B6AB8 003B3698  EC 07 01 3C */	fnmsubs f0, f7, f4, f0
/* 803B6ABC 003B369C  FC 00 40 40 */	fcmpo cr0, f0, f8
/* 803B6AC0 003B36A0  40 80 00 0C */	bge .L_803B6ACC
/* 803B6AC4 003B36A4  3A 20 00 00 */	li r17, 0x0
/* 803B6AC8 003B36A8  48 00 00 24 */	b .L_803B6AEC
.L_803B6ACC:
/* 803B6ACC 003B36AC  FC 01 00 40 */	fcmpo cr0, f1, f0
/* 803B6AD0 003B36B0  40 80 00 0C */	bge .L_803B6ADC
/* 803B6AD4 003B36B4  3A 20 00 FF */	li r17, 0xff
/* 803B6AD8 003B36B8  48 00 00 14 */	b .L_803B6AEC
.L_803B6ADC:
/* 803B6ADC 003B36BC  FC 00 00 1E */	fctiwz f0, f0
/* 803B6AE0 003B36C0  D8 01 00 50 */	stfd f0, 0x50(r1)
/* 803B6AE4 003B36C4  82 01 00 54 */	lwz r16, 0x54(r1)
/* 803B6AE8 003B36C8  56 11 06 3E */	clrlwi r17, r16, 24
.L_803B6AEC:
/* 803B6AEC 003B36CC  6E 50 80 00 */	xoris r16, r18, 0x8000
/* 803B6AF0 003B36D0  6E 72 80 00 */	xoris r18, r19, 0x8000
/* 803B6AF4 003B36D4  92 01 00 5C */	stw r16, 0x5c(r1)
/* 803B6AF8 003B36D8  6E 90 80 00 */	xoris r16, r20, 0x8000
/* 803B6AFC 003B36DC  92 41 00 64 */	stw r18, 0x64(r1)
/* 803B6B00 003B36E0  56 31 06 3E */	clrlwi r17, r17, 24
/* 803B6B04 003B36E4  93 C1 00 58 */	stw r30, 0x58(r1)
/* 803B6B08 003B36E8  93 C1 00 60 */	stw r30, 0x60(r1)
/* 803B6B0C 003B36EC  C8 41 00 58 */	lfd f2, 0x58(r1)
/* 803B6B10 003B36F0  92 01 00 54 */	stw r16, 0x54(r1)
/* 803B6B14 003B36F4  C8 01 00 60 */	lfd f0, 0x60(r1)
/* 803B6B18 003B36F8  EC 42 48 28 */	fsubs f2, f2, f9
/* 803B6B1C 003B36FC  93 C1 00 50 */	stw r30, 0x50(r1)
/* 803B6B20 003B3700  EC 00 48 28 */	fsubs f0, f0, f9
/* 803B6B24 003B3704  C8 81 00 50 */	lfd f4, 0x50(r1)
/* 803B6B28 003B3708  FC 84 48 28 */	fsub f4, f4, f9
/* 803B6B2C 003B370C  EC 03 00 BA */	fmadds f0, f3, f2, f0
/* 803B6B30 003B3710  FC 05 01 3C */	fnmsub f0, f5, f4, f0
/* 803B6B34 003B3714  FC 00 00 18 */	frsp f0, f0
/* 803B6B38 003B3718  FC 00 40 40 */	fcmpo cr0, f0, f8
/* 803B6B3C 003B371C  40 80 00 0C */	bge .L_803B6B48
/* 803B6B40 003B3720  3A 00 00 00 */	li r16, 0x0
/* 803B6B44 003B3724  48 00 00 24 */	b .L_803B6B68
.L_803B6B48:
/* 803B6B48 003B3728  FC 01 00 40 */	fcmpo cr0, f1, f0
/* 803B6B4C 003B372C  40 80 00 0C */	bge .L_803B6B58
/* 803B6B50 003B3730  3A 00 00 FF */	li r16, 0xff
/* 803B6B54 003B3734  48 00 00 14 */	b .L_803B6B68
.L_803B6B58:
/* 803B6B58 003B3738  FC 00 00 1E */	fctiwz f0, f0
/* 803B6B5C 003B373C  D8 01 00 50 */	stfd f0, 0x50(r1)
/* 803B6B60 003B3740  82 01 00 54 */	lwz r16, 0x54(r1)
/* 803B6B64 003B3744  56 10 06 3E */	clrlwi r16, r16, 24
.L_803B6B68:
/* 803B6B68 003B3748  56 31 1D 74 */	rlwinm r17, r17, 3, 21, 26
/* 803B6B6C 003B374C  53 91 44 28 */	rlwimi r17, r28, 8, 16, 20
/* 803B6B70 003B3750  52 11 EE FE */	rlwimi r17, r16, 29, 27, 31
/* 803B6B74 003B3754  55 6B 08 3C */	slwi r11, r11, 1
/* 803B6B78 003B3758  7E 29 5B 2E */	sthx r17, r9, r11
/* 803B6B7C 003B375C  3B 7B 01 00 */	addi r27, r27, 0x100
/* 803B6B80 003B3760  39 08 00 01 */	addi r8, r8, 0x1
/* 803B6B84 003B3764  42 00 FE 44 */	bdnz .L_803B69C8
/* 803B6B88 003B3768  38 A5 00 01 */	addi r5, r5, 0x1
/* 803B6B8C 003B376C  2C 05 00 04 */	cmpwi r5, 0x4
/* 803B6B90 003B3770  39 29 00 02 */	addi r9, r9, 0x2
/* 803B6B94 003B3774  3B FF 00 04 */	addi r31, r31, 0x4
/* 803B6B98 003B3778  41 80 FE 14 */	blt .L_803B69AC
/* 803B6B9C 003B377C  38 84 00 01 */	addi r4, r4, 0x1
/* 803B6BA0 003B3780  2C 04 00 04 */	cmpwi r4, 0x4
/* 803B6BA4 003B3784  39 8C 00 08 */	addi r12, r12, 0x8
/* 803B6BA8 003B3788  41 80 FD F0 */	blt .L_803B6998
/* 803B6BAC 003B378C  38 E7 00 01 */	addi r7, r7, 0x1
/* 803B6BB0 003B3790  2C 07 00 02 */	cmpwi r7, 0x2
/* 803B6BB4 003B3794  3B 39 00 02 */	addi r25, r25, 0x2
/* 803B6BB8 003B3798  3B 18 00 04 */	addi r24, r24, 0x4
/* 803B6BBC 003B379C  41 80 FD D4 */	blt .L_803B6990
/* 803B6BC0 003B37A0  38 C6 00 01 */	addi r6, r6, 0x1
/* 803B6BC4 003B37A4  2C 06 00 02 */	cmpwi r6, 0x2
/* 803B6BC8 003B37A8  3A F7 00 01 */	addi r23, r23, 0x1
/* 803B6BCC 003B37AC  3A D6 00 10 */	addi r22, r22, 0x10
/* 803B6BD0 003B37B0  3A B5 00 04 */	addi r21, r21, 0x4
/* 803B6BD4 003B37B4  41 80 FD A0 */	blt .L_803B6974
/* 803B6BD8 003B37B8  B9 C1 00 68 */	lmw r14, 0x68(r1)
/* 803B6BDC 003B37BC  38 21 00 B0 */	addi r1, r1, 0xb0
/* 803B6BE0 003B37C0  4E 80 00 20 */	blr
.endfn fn_803B6820

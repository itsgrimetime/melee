#!/usr/bin/env bash
# Patched by melee-agent debug permute fix-compile
set -e
INPUT_ABS="$(realpath "$1")"
OUTPUT_ABS="$(realpath "$3")"
cd /Users/mike/.codex/worktrees/c016/melee
STAGE="nonmatchings/.permuter_stage_$$.c"
mkdir -p nonmatchings
cp "$INPUT_ABS" "$STAGE"
trap 'rm -f "$STAGE"' EXIT
INPUT="$STAGE"
OUTPUT="$OUTPUT_ABS"
WIBO=""
if [[ -n "${MWCC_DEBUG_WIBO:-}" && -f "$MWCC_DEBUG_WIBO" && -x "$MWCC_DEBUG_WIBO" ]]; then
  WIBO="$MWCC_DEBUG_WIBO"
elif [[ -n "${MELEE_ROOT:-}" && -f "$MELEE_ROOT/tools/mwcc_debug/bin/wibo" && -x "$MELEE_ROOT/tools/mwcc_debug/bin/wibo" ]]; then
  WIBO="$MELEE_ROOT/tools/mwcc_debug/bin/wibo"
elif [[ -f "tools/mwcc_debug/bin/wibo" && -x "tools/mwcc_debug/bin/wibo" ]]; then
  WIBO="tools/mwcc_debug/bin/wibo"
elif [[ -f "/Users/mike/code/melee/tools/mwcc_debug/bin/wibo" && -x "/Users/mike/code/melee/tools/mwcc_debug/bin/wibo" ]]; then
  WIBO="/Users/mike/code/melee/tools/mwcc_debug/bin/wibo"
else
  echo "error: patched wibo executable not found; set MWCC_DEBUG_WIBO or build tools/mwcc_debug/bin/wibo" >&2
  exit 2
fi
build/tools/wibo build/tools/sjiswrap.exe build/compilers/GC/1.2.5n/mwcceppc.exe -nowraplines -cwd source -Cpp_exceptions off -proc gekko -fp hardware -align powerpc -nosyspath -fp_contract on -O4,p -multibyte -enum int -nodefaults -inline auto -pragma 'cats off' -pragma 'warn_notinlined off' -RTTI off -str reuse -DBUILD_VERSION=0 -DVERSION_GALE01 -DMUST_MATCH -maxerrors 1 -msgstyle std -warn off -requireprotos -i src -i src/MSL -i extern/dolphin/include -i build/GALE01/include -lang=c -Cpp_exceptions on -sym on -c "$INPUT" -o "$OUTPUT"

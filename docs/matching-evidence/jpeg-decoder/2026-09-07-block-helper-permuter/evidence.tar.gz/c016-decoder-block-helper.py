from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-block-helper');out.mkdir(exist_ok=True)
fs=base.index('static void fn_803B6820(');fe=base.index('static inline s32 hsd_803B6BE4_inline',fs)
a=base.index('                    for (block = 0;',fs);b=base.index('                    out += 1;',a);loop=base[a:b]
ha=base.index('static inline void jpeg_store_rgb565(');hb=fs;rgb=base[ha:hb];rgb=rgb[rgb.index('{')+1:rgb.rfind('}')]
locals=['    s32 chroma_column;\n','    s32 cr;\n','    s32 block;\n','    s32 luminance;\n','    s32 cb;\n','    s32 out_offset;\n','    u8* chroma;\n']
try:
 for start in [False,True]:
  for mode in ['index','pointer']:
   params='u16* out, s32* luma_base, u8* base, s32 chroma_row, s32 aligned_width';args='out, luma_base, base, chroma_row, aligned_width';l=loop;decl=''.join(locals)
   if start:params+=', s32 block';args+=', 0';l=l.replace('block = 0;',';');decl=decl.replace('    s32 block;\n','')
   color='{'+rgb.replace('*out =','out[out_offset] =')+'}' if mode=='index' else '{\n    u16* rgb_out = out + out_offset;'+rgb.replace('*out =','*rgb_out =')+'}'
   l=l.replace('jpeg_store_rgb565(out + out_offset, luminance, cb, cr);',color)
   helper='static inline void jpeg_store_blocks('+params+')\n{\n'+decl+l+'}\n\n'
   fn=base[fs:a]+'                    jpeg_store_blocks('+args+');\n'+base[b:fe]
   for dec in locals:fn=fn.replace(dec,'')
   s=base[:fs]+helper+fn+base[fe:];name=('start-' if start else '')+mode;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);d=json.loads(r.stdout);print(name,d['fuzzy_match_percent'],d['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

import json,sys
from pathlib import Path
sys.path.insert(0,'/Users/mike/code/mwcc-decomp/tools')
from coloring_model import replay_simplify
p=json.load(open('/tmp/c016-decoder-current-standard-retail/backend-trace.v1.json'))
c=p['functions'][0]['regalloc']['classes'][0]
neighbors={n['ig_id']:set() for n in c['nodes']}
for e in c['edges']:
 neighbors[e['a']].add(e['b']);neighbors[e['b']].add(e['a'])
roots={m['alias']:m['root'] for m in c['coalesce']['mappings']}
nodes=[dict(virtual_register=n['ig_id'],physical_register=roots.get(n['ig_id'],n['ig_id'] if n['ig_id']<32 else -1),flags=4 if n['ig_id'] in roots else 0,neighbors=sorted(neighbors[n['ig_id']]),spill_cost=0) for n in c['nodes']]
s={'register_class':'gpr','nodes':nodes,'simplify_order':c['select_order']}
r=replay_simplify(s)
actual={d['ig_id']:d['assigned_phys'] for d in c['color_decisions']}
result={'scope':'Adapter to existing coloring_model. Coalesced roots from observed retail mappings; spill costs assumed zero, valid only if no jams. Graph from observed retail edges.', 'order_equal':r['simplify_order']==c['select_order'],'color_equal':sum(r['colors'].get(n)==v for n,v in actual.items()),'color_count':len(actual),'spill_choices':r['spill_choices'],'observed_order':c['select_order'],'predicted_order':r['simplify_order']}
print(json.dumps({k:v for k,v in result.items() if 'order' not in k or isinstance(v,bool)},indent=2))
Path('/tmp/c016-decoder-retail-replay.json').write_text(json.dumps(result,indent=2))
Path('/tmp/c016-decoder-retail-model-input.json').write_text(json.dumps(s,indent=2))

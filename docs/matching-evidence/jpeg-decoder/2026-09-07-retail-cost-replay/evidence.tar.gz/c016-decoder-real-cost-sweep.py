import json,sys
from pathlib import Path
sys.path.insert(0,'/Users/mike/code/mwcc-decomp/tools')
from coloring_model import replay_simplify
s=json.load(open('/tmp/c016-decoder-real-cost-model-input.json'))
b=replay_simplify(s);target=dict(b['colors'])
for x in Path('/tmp/c016-decoder-inequality-mapped-target.txt').read_text().strip().split(','):
 _,n,v=map(int,x.split(':'));target[n]=v
for dead in [107,108,109]:target.pop(dead,None)
rows=[]
for node in [65,63,78,77,79,66]:
 for kind,values in [('rank',[i+.5 for i in range(32,150)]),('degree',range(-10,11))]:
  for val in values:
   r=replay_simplify(s,**({'ranks':{node:val}} if kind=='rank' else {'extra_permanent_degree':{node:val}}))
   misses=[n for n,v in target.items() if r['colors'].get(n)!=v]
   rows.append({'node':node,'kind':kind,'value':val,'misses':len(misses),'missing_nodes':misses,'jam_nodes':[x['register'] for x in r['spill_choices']]})
base=sum(b['colors'].get(n)!=v for n,v in target.items())
print('baseline',base)
for node in [65,63,78,77,79,66]:
 for kind in ['rank','degree']:
  best=sorted([r for r in rows if r['node']==node and r['kind']==kind],key=lambda r:r['misses'])[0];print(best)
Path('/tmp/c016-decoder-real-cost-sweep.json').write_text(json.dumps({'scope':'Single abstract rank or permanent-degree changes with full simplify/select replay. Target extends partial mapped target using current baseline colors. Not source evidence or full target proof.','baseline_misses':base,'rows':rows},indent=2))

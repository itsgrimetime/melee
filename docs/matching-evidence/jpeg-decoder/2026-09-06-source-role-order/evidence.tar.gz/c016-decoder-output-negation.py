from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-output-negation');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b]
old='''(((x / 4) * 0x10) +
                            ((aligned_width << 2) * ((y / 4) + group_y)))''';assert old in part
xx='((x / 4) * 0x10)';yy='((aligned_width << 2) * ((y / 4) + group_y))'
exprs={'subtract-negative-row':'('+xx+' - (-'+yy+'))','subtract-negative-column':'('+yy+' - (-'+xx+'))','row-first':'('+yy+' + '+xx+')','nested-negative-row':'('+xx+' - ((aligned_width << 2) * (-((y / 4) + group_y))))'}
red0='(f32) ((1.402 * (f64) cr) + (f64) luminance)';red1='(f32) ((f64) luminance + (1.402 * (f64) cr))'
rows=[]
try:
 for name,expr in exprs.items():
  for red in ['baseline','luma-first']:
   full=base[:a]+part.replace(old,expr)+base[b:]
   if red=='luma-first':full=full.replace(red0,red1)
   label=name+'-'+red;(out/(label+'.c')).write_text(full);p.write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   assert r.returncode in [0,1],(label,r.returncode,r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import json,sys
sys.path.insert(0,str(Path('tools/melee-agent').resolve()))
from src.mwcc_debug.tiebreak import load_gpr_ig,validate_g1,predict_assignments
old=load_gpr_ig(Path('/tmp/c016-decoder-chroma-retained-pcdump.txt').read_text(),'fn_803B6820')
new=load_gpr_ig(Path('/tmp/c016-decoder-red-owner-pcdump.txt').read_text(),'fn_803B6820')
mapping=json.loads(Path('/tmp/c016-decoder-red-owner-map.json').read_text())
assert all(p['consistent_bijection'] for p in mapping['passes'])
m=next(p['map'] for p in mapping['passes'] if p['pass']=='AFTER PEEPHOLE FORWARD')
def remap(n):return int(m.get('r'+str(n),'r'+str(n))[1:])
assert set(map(remap,old.nodes))==set(new.nodes)
errors=[]
for n,v in old.nodes.items():
 w=new.nodes[remap(n)]
 if set(map(remap,v.neighbors))!=w.neighbors or v.precolored!=w.precolored or v.incomplete!=w.incomplete: errors.append(n)
assert not errors,errors
g=validate_g1(new);assert g.correct==g.total==110 and not g.spill_abstained
winner=next(r for r in json.loads(Path('/tmp/c016-decoder-order-interactions.json').read_text())['rows'] if not r['differences'])
target={remap(int(k)):v for k,v in winner['predicted_assignments'].items()}
moves=[(remap(n),where,remap(marker)) for n,where,marker in winner['moves'] if (n,where,marker)!=(63,'before',64)]
rows=[]
for count in range(len(moves)+1):
 order=list(new.select_order)
 for n,where,marker in moves[:count]:
  order.remove(n);order.insert(order.index(marker)+(where=='after'),n)
 pred=predict_assignments(new,order=order)
 rows.append({'moves':moves[:count],'differences':[{'ig':n,'predicted':v,'target':target[n]} for n,v in pred.items() if v!=target[n]],'order':order,'assignments':pred})
assert not rows[-1]['differences'],rows[-1]['differences']
result={'scope':'Candidate realizes Cr/luma role order in ordinary source; five remaining moves only abstract SELECT perturbations. Extended target assumes unmapped baseline colors unchanged. This is not a source100 result.','graph_isomorphic_under_precolor_mapping':True,'unmapped_nodes_identity_extension_validated_by_graph':True,'baseline_replay_correct':g.correct,'ordinary_candidate_percent':98.75519,'rows':rows}
Path('/tmp/c016-decoder-red-owner-replay.json').write_text(json.dumps(result,indent=2)+'\n')
print('Graph isomorphic; replay 110/110; remaining abstract moves:',moves)
print('Wrong assignments by prefix:',[len(r['differences']) for r in rows])

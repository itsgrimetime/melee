from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-color-expression-order');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline void jpeg_store_rgb565(');b=base.index('static void fn_803B6820(',a);part=base[a:b]
red='(f32) ((1.402 * (f64) cr) + (f64) luminance)';blue='((1.7718f * (f32) cb) + (f32) luminance)'
variants={
 'red-luma-first':part.replace(red,'(f32) ((f64) luminance + (1.402 * (f64) cr))'),
 'red-cr-first-product':part.replace(red,'(f32) (((f64) cr * 1.402) + (f64) luminance)'),
 'red-both':part.replace(red,'(f32) ((f64) luminance + ((f64) cr * 1.402))'),
 'blue-luma-first':part.replace(blue,'((f32) luminance + (1.7718f * (f32) cb))'),
 'blue-cb-first-product':part.replace(blue,'(((f32) cb * 1.7718f) + (f32) luminance)'),
 'blue-both':part.replace(blue,'((f32) luminance + ((f32) cb * 1.7718f))'),
 'green-products-swapped':part.replace('(0.3441f * (f32) cb)','((f32) cb * 0.3441f)').replace('(0.7139f * (f32) cr)','((f32) cr * 0.7139f)'),
}
variants['red-blue-luma-first']=variants['red-luma-first'].replace(blue,'((f32) luminance + (1.7718f * (f32) cb))')
rows=[]
try:
 for name,s in variants.items():
  assert s!=part;full=base[:a]+s+base[b:];(out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1],(name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

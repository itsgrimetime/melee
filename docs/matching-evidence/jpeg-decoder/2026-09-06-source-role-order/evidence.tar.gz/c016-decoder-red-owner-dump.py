from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_bytes()
try:
 p.write_bytes(Path('/tmp/c016-decoder-color-expression-order/red-luma-first.c').read_bytes())
 r=subprocess.run(['melee-agent','debug','dump','local',str(p),'--function','fn_803B6820','--output','/tmp/c016-decoder-red-owner-pcdump.txt','--no-cache-sync'],capture_output=True,text=True)
 Path('/tmp/c016-decoder-red-owner-dump.log').write_text(r.stdout+r.stderr);assert r.returncode==0;print('captured')
finally:p.write_bytes(base)

from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-channel-reuse');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static inline void jpeg_store_rgb565(');b=base.index('static void fn_803B6820(',a);part=base[a:b];variants={}
for red,blue in itertools.product(['none','separate','embedded'],repeat=2):
 if red==blue=='none':continue
 s=part
 for ch,form in [('red',red),('blue',blue)]:
  if form=='none':continue
  expr='jpeg_clamp('+ch+'_value)';old='pixel.'+ch+' = '+expr+';'
  new=('green = '+expr+';\n    pixel.'+ch+' = green;') if form=='separate' else 'pixel.'+ch+' = green = '+expr+';'
  assert old in s;s=s.replace(old,new)
 variants[red+'-red-'+blue+'-blue']=base[:a]+s+base[b:]
# Preserve the two single-precision subtractions with explicit accumulator assignments.
g='''    green_value =
        ((f32) luminance - (0.3441f * (f32) cb)) - (0.7139f * (f32) cr);'''
for form,repl in {'compound':'    green_value = (f32) luminance;\n    green_value -= 0.3441f * (f32) cb;\n    green_value -= 0.7139f * (f32) cr;', 'split':'    green_value = (f32) luminance - 0.3441f * (f32) cb;\n    green_value = green_value - 0.7139f * (f32) cr;'}.items():
 assert g in part;variants['green-'+form]=base[:a]+part.replace(g,repl)+base[b:]
rows=[]
try:
 for name,full in variants.items():
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1],(name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-sample-load-order');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('static void fn_803B6820(');b=base.index('static inline s32 hsd_803B6BE4_inline',a);part=base[a:b]
loads={'luminance':'luminance = luma_base[block * 64];','cr':'cr = ((JpegState*) chroma)->work.cr[0];','cb':'cb = ((JpegState*) chroma)->work.cb[0];'}
args={'luminance':'luma_base[block * 64]','cr':'((JpegState*) chroma)->work.cr[0]','cb':'((JpegState*) chroma)->work.cb[0]'}
variants={}
for order in itertools.permutations(loads):
 s=part
 for v in loads.values():assert s.count(v)==1;s=s.replace('                        '+v+'\n','')
 marker='                        out_offset =';s=s.replace(marker,''.join('                        '+loads[n]+'\n' for n in order)+marker)
 variants['-'.join(order)]=base[:a]+s+base[b:]
for names in [('luminance',),('cr',),('cb',),('luminance','cb','cr')]:
 s=part;call='jpeg_store_rgb565(out + out_offset, luminance, cb, cr);';rep=call
 for n in names:
  s=s.replace('                        '+loads[n]+'\n','');rep=rep.replace(n,args[n])
 s=s.replace(call,rep);variants['argument-'+'-'.join(names)]=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in variants.items():
  (out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1],(name,r.returncode,r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

import sys,json,re
from pathlib import Path
sys.path.insert(0,str(Path('tools/melee-agent').resolve()))
from src.mwcc_debug.parser import parse_pcdump
from src.mwcc_debug.colorgraph_parser import parse_hook_events,find_function
paths=[Path('/tmp/c016-decoder-chroma-retained-pcdump.txt'),Path('/tmp/c016-decoder-red-owner-pcdump.txt')]
texts=[p.read_text() for p in paths];f=[parse_pcdump(t,function='fn_803B6820')[0] for t in texts]
result={'scope':'Aligned precolor PCode bijection followed by mapped final colorgraph decisions. Anonymous names normalized for alignment, not data equivalence proof.','passes':[]}
for pa,pb in zip(f[0].passes,f[1].passes):
 if pa.name=='AFTER REGISTER COLORING':break
 aa=list(pa.all_instructions());bb=list(pb.all_instructions());mapping={};inverse={};errors=[]
 if len(aa)!=len(bb):errors.append('instruction count differs')
 for (bi,ii,x),(bj,ij,y) in zip(aa,bb):
  if (bi,ii,x.opcode)!=(bj,ij,y.opcode):errors.append([bi,ii,'instruction identity mismatch']);continue
  def norm(s):return re.sub(r'\b[rf][0-9]+\b','REG',re.sub(r'@[0-9]+','@CONST',s))
  if norm(x.operands)!=norm(y.operands):errors.append([bi,ii,'operand shape mismatch']);continue
  if len(x.regs)!=len(y.regs):errors.append([bi,ii,'register count mismatch']);continue
  for ar,br in zip(x.regs,y.regs):
   if ar[0]!=br[0] or (ar[1]<32 and ar!=br):errors.append([bi,ii,'physical/class mismatch',ar,br]);continue
   if ar in mapping and mapping[ar]!=br:errors.append([bi,ii,'inconsistent mapping',ar,br,mapping[ar]])
   if br in inverse and inverse[br]!=ar:errors.append([bi,ii,'non-bijective',ar,br,inverse[br]])
   mapping[ar]=br;inverse[br]=ar
 row={'pass':pa.name,'a_instructions':len(aa),'b_instructions':len(bb),'consistent_bijection':not errors,'errors':errors[:12],'map':{k+str(n):v[0]+str(v[1]) for (k,n),v in mapping.items()}};result['passes'].append(row)
 if pa.name=='AFTER PEEPHOLE FORWARD' and not errors:
  ea,eb=[find_function(parse_hook_events(t),'fn_803B6820') for t in texts]
  cls=[]
  for ca,cb in zip(ea.colorgraph_sections,eb.colorgraph_sections):
   bdec={v.ig_idx:v for v in cb.decisions};count=0;diff=[];kind='r' if ca.class_id==0 else 'f'
   for da in ca.decisions:
    key=(kind,da.ig_idx)
    if key not in mapping:continue
    bn=mapping[key][1]
    if bn not in bdec:continue
    db=bdec[bn];count+=1
    if (da.assigned_reg,da.iter_idx)!=(db.assigned_reg,db.iter_idx):diff.append({'a':da.ig_idx,'b':bn,'a_color':da.assigned_reg,'b_color':db.assigned_reg,'a_select':da.iter_idx,'b_select':db.iter_idx})
   cls.append({'class':ca.class_id,'mapped_decisions':count,'color_or_select_differences':diff})
  result['mapped_colorgraph']=cls
Path('/tmp/c016-decoder-red-owner-map.json').write_text(json.dumps(result,indent=2)+'\n')
for r in result['passes']:print(r['pass'],r['consistent_bijection'],r['a_instructions'],r['b_instructions'],r['errors'][:2])
print('colorgraph',result.get('mapped_colorgraph'))

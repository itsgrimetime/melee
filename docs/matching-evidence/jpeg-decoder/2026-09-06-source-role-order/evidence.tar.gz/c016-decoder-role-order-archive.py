from pathlib import Path
import subprocess,json,hashlib,tarfile
root=Path('docs/matching-evidence/jpeg-decoder/2026-09-06-source-role-order');root.mkdir(parents=True,exist_ok=True)
source=Path('src/sysdolphin/baselib/hsd_3B5C.c')
assert source.read_bytes()==subprocess.check_output(['git','show','HEAD:'+str(source)])
d=json.loads(Path('/tmp/c016-decoder-role-order-final.json').read_text());assert d['fuzzy_match_percent']==98.83817
report=json.loads(Path('build/GALE01/report.json').read_text());u=next(u for u in report['units'] if u['name'].endswith('sysdolphin/baselib/hsd_3B5C'))
fs=[{'name':f['name'],'percent':f['fuzzy_match_percent']} for f in u['functions']];assert len(fs)==6 and all(f['percent']==(98.83817 if f['name']=='fn_803B6820' else 100) for f in fs)
sha={str(p):hashlib.sha1(p.read_bytes()).hexdigest() for p in [Path('build/GALE01/main.dol'),Path('orig/GALE01/sys/main.dol')]};assert set(sha.values())=={'08e0bf20134dfcb260699671004527b2d6bb1a45'}
files=[];rows=[]
for family in ['sample-load-order','color-expression-order','output-negation','channel-reuse','green-subtraction']:
 p=Path('/tmp/c016-decoder-'+family);files.extend((f,str(f.relative_to('/tmp'))) for f in p.rglob('*') if f.is_file());files.append((Path(str(p)+'.py'),p.name+'.py'))
 rows.extend({'family':family,**r} for r in json.loads((p/'results.json').read_text()))
assert len(rows)==46
for suffix in ['role-order-doctor.log','role-order-final.json','role-order-final.log','role-order-build.log','role-order-attempt.log','role-order-archive.py','red-owner-pcdump.txt','red-owner-dump.py','red-owner-dump.log','red-owner-map.py','red-owner-map.json','red-owner-replay.py','red-owner-replay.json','order-target.json','order-target.log','order-source-proposals.json','order-source-proposals.log','chroma-retained-pcdump.txt','order-interactions.json']:
 p=Path('/tmp/c016-decoder-'+suffix);files.append((p,p.name))
files.append((source,'retained-hsd_3B5C.c'))
for name in ['tiebreak.py','parser.py','colorgraph_parser.py']:
 p=Path('tools/melee-agent/src/mwcc_debug')/name;files.append((p,'model-reference/'+name))
m={'function':'fn_803B6820','scratch':None,'pr':'https://github.com/doldecomp/melee/pull/3384','head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'retained_source_change':False,'ordinary_retained_percent':98.83817,'experimental_percent':98.75519,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'unit_functions':fs,'dol_sha1':sha,'runs':rows,'caveat':'Candidate realizes one role-order change. Five remaining selection-order changes are abstract model perturbations only, not source100.','members':[]}
assert len(set(n for _,n in files))==len(files)
with tarfile.open(root/'evidence.tar.gz','w:gz') as t:
 for p,n in sorted(files,key=lambda x:x[1]):
  data=p.read_bytes();m['members'].append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});t.add(p,arcname=n)
with tarfile.open(root/'evidence.tar.gz') as t:
 for f in m['members']:assert hashlib.sha256(t.extractfile(f['path']).read()).hexdigest()==f['sha256']
m['archive_sha256']=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest();(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified',len(files),'members,',len(rows),'compile runs,',(root/'evidence.tar.gz').stat().st_size,'bytes')

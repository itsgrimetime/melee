from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B5C.c');base=p.read_text();out=Path('/tmp/c016-decoder-green-subtraction');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
old='((f32) luminance - (0.3441f * (f32) cb)) - (0.7139f * (f32) cr)';assert base.count(old)==1
lum='(f32) luminance';cb='(0.3441f * (f32) cb)';cr='(0.7139f * (f32) cr)'
exprs={'inner-negative-add':'('+lum+' + -'+cb+') - '+cr,'outer-negative-add':'('+lum+' - '+cb+') + -'+cr,'inner-reverse-subtract':'-('+cb+' - '+lum+') - '+cr,'outer-reverse-subtract':'-('+cr+' - ('+lum+' - '+cb+'))','negative-cr-first':'-'+cr+' + ('+lum+' - '+cb+')'}
red0='(f32) ((1.402 * (f64) cr) + (f64) luminance)';red1='(f32) ((f64) luminance + (1.402 * (f64) cr))'
rows=[]
try:
 for name,expr in exprs.items():
  for red in ['baseline','luma-first']:
   full=base.replace(old,expr)
   if red=='luma-first':full=full.replace(red0,red1)
   label=name+'-'+red;(out/(label+'.c')).write_text(full);p.write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','fn_803B6820','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   assert r.returncode in [0,1],(label,r.returncode,r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

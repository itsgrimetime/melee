#include "gmtoulib.h"

#include <melee/ft/forward.h>
#include <melee/pl/forward.h>
#include <sysdolphin/baselib/forward.h>

#include <m2c_macros.h>
#include <placeholder.h>
#include <stdio.h>
#include <string.h>

#include "forward.h"
#include "gm_1601.h"
#include "gm_unsplit.h"
#include "gmmain_lib.h"
#include "gmtoulib.static.h"
#include "types.h"
#include <melee/lb/lblanguage.h>
#include <melee/lb/lbspdisplay.h>
#include <melee/mn/mnmain.h>
#include <melee/mn/mnname.h>
#include <melee/mn/mnstagesel.h>
#include <melee/pl/player.h>
#include <melee/sc/types.h>
#include <sysdolphin/baselib/cobj.h>
#include <sysdolphin/baselib/controller.h>
#include <sysdolphin/baselib/debug.h>
#include <sysdolphin/baselib/dobj.h>
#include <sysdolphin/baselib/fog.h>
#include <sysdolphin/baselib/gobj.h>
#include <sysdolphin/baselib/gobjgxlink.h>
#include <sysdolphin/baselib/gobjobject.h>
#include <sysdolphin/baselib/gobjplink.h>
#include <sysdolphin/baselib/gobjproc.h>
#include <sysdolphin/baselib/hsd_3915.h>
#include <sysdolphin/baselib/jobj.h>
#include <sysdolphin/baselib/mobj.h>
#include <sysdolphin/baselib/random.h>
#include <sysdolphin/baselib/sislib.h>
#include <sysdolphin/baselib/wobj.h>

int lbl_804D663C;
u8 lbl_804D6638[0x4];

extern SceneDesc* lbl_804D666C;
extern SceneDesc* lbl_804D6674;
extern u8 lbl_804D6680[8];
extern char* const lbl_804DA6B4;
extern char* const lbl_804DA6B8;
extern char* const lbl_804DA6BC;
extern char* const lbl_804DA6C0;
extern char* const lbl_804DA6C4;
extern char* const lbl_804DA6C8;
extern char* const lbl_804DA6CC;
extern char* const lbl_804DA6D0;
static s32 lbl_804D6630;
static s32 lbl_804D6634;

const struct lbl_803B7C80_t {
    s32 v[10];
} lbl_803B7C80 = {
    30, -20, 15, -12, 10, -8, 6, -4, 2, 1,
};

/* 3B7CA8 */ static const HSD_CameraDescPerspective lbl_803B7CA8 = {
    NULL,
    0,
    PROJ_PERSPECTIVE,
    { 0, 640, 0, 480 },
    { 0, 640, 0, 480 },
    &lbl_803D9DF4,
    &lbl_803D9E08,
    0.0f,
    NULL,
    0.1f,
    30000.0f,
    60.0f,
    1.3333333f,
};

typedef struct BracketData {
    /* 0x0000 */ BracketEntry entries[64];
    /* 0x3700 */ BracketSrcEntry* srcs[3];
} BracketData;

typedef struct BracketSrcPtr {
    BracketSrcEntry* ptr;
} BracketSrcPtr;

typedef union lbl_803D9D20_u {
    struct lbl_803D9D20_t fields;
    u8 bytes[sizeof(struct lbl_803D9D20_t)];
} lbl_803D9D20_u;

static inline void gmTournament_SetBracketByes(BracketEntry* entries,
                                               s32 entrant_count)
{
    if (entrant_count == 1) {
        entries[5].slots[1].x32 = 1;
    } else if (entrant_count == 3) {
        entries[10].slots[0].x32 = 1;
        entries[11].slots[1].x32 = 1;
    } else if (entrant_count == 5) {
        entries[23].slots[1].x32 = 1;
    } else if (entrant_count == 7) {
        entries[46].slots[1].x32 = 1;
        entries[47].slots[1].x32 = 1;
    }
}

void fn_8018A514(int count, float val)
{
    s32 region;
    BracketEntry* entries;
    BracketSrcEntry* src;
    BracketSrcEntry** srcs;
    int i;
    s32 n;

    entries = lbl_80473AB8;
    /// @todo Dead read; a third early lbl_80473AB8-rooted expression is needed
    /// so the compiler binds the .bss anchor to a register before
    /// lbl_803D9D20.
    (void) lbl_80473AB8;
    region = count < 9 ? 0 : count >= 14 ? 2 : 1;

    srcs = (BracketSrcEntry**) &lbl_804771B8;
    src = srcs[region];

    if (count < 9) {
        for (i = 0; i < count; i++) {
            src += lbl_803D9D20.x20[i];
        }
    } else if (count < 14) {
        for (i = 9; i < count; i++) {
            src += lbl_803D9D20.x20[i];
        }
    } else {
        for (i = 14; i < count; i++) {
            src += lbl_803D9D20.x20[i];
        }
    }

    n = ((lbl_803D9D20_u*) &lbl_803D9D20)->bytes[i = count + 0x20];

    for (i = 0; i < n; i++) {
        lbl_80473AB8[i].x0 = src->x0;
        lbl_80473AB8[i].x1 = src->x1;
        lbl_80473AB8[i].x2 = src->x2;
        lbl_80473AB8[i].x3 = src->x3;
        lbl_80473AB8[i].x4 = src->x4;
        lbl_80473AB8[i].x5 = src->x5;
        lbl_80473AB8[i].x6 = src->x6;
        lbl_80473AB8[i].x1C = val;
        lbl_80473AB8[i].xC = src->x8;
        lbl_80473AB8[i].x14 = src->xC;
        lbl_80473AB8[i].x10 = src->x10;
        lbl_80473AB8[i].x18 = src->x14;
        lbl_80473AB8[i].x20.r = src->x18;
        lbl_80473AB8[i].x20.g = src->x1A;
        lbl_80473AB8[i].x20.b = src->x1C;
        lbl_80473AB8[i].x20.a = src->x1E;
        lbl_80473AB8[i].x24 = src->x19;
        lbl_80473AB8[i].x25 = src->x1B;
        lbl_80473AB8[i].x26 = src->x1D;
        lbl_80473AB8[i].x27 = src->x1F;
        lbl_80473AB8[i].x28 = src->x20;
        lbl_80473AB8[i].slots[0].x52 = 9;
        lbl_80473AB8[i].slots[0].x32 = 0;
        lbl_80473AB8[i].slots[1].x52 = 9;
        lbl_80473AB8[i].slots[1].x32 = 0;
        lbl_80473AB8[i].slots[2].x52 = 9;
        lbl_80473AB8[i].slots[2].x32 = 0;
        lbl_80473AB8[i].slots[3].x52 = 9;
        lbl_80473AB8[i].slots[3].x32 = 0;
        lbl_80473AB8[i].slots[0].x30 = src->x21;
        lbl_80473AB8[i].slots[1].x30 = src->x22;
        lbl_80473AB8[i].slots[2].x30 = src->x23;
        lbl_80473AB8[i].slots[3].x30 = src->x24;
        src++;
    }

    if (region == 0) {
        gmTournament_SetBracketByes(entries, count);
    }
    PAD_STACK(24);
}

void fn_8018A970(int arg0)
{
    int i;
    for (i = 0; i < 0x40; i++) {
        if (lbl_80473AB8[i].x0 != 0) {
            HSD_GObj* gobj = GObj_Create(0xE, 0x1B, 0);
            gobj->user_data = &lbl_80473AB8[i];
            if (i == 0) {
                HSD_GObj_SetupProc(gobj, fn_8018B090, 0);
            }
            GObj_SetupGXLink(gobj, fn_8018E46C, 4, 1);
        }
    }

    if (arg0 < 9) {
        gmTournament_SetBracketByes(lbl_80473AB8, arg0);
    }
}

static inline void gmTournament_SetTripleRightCoords(BracketEntry* entry,
                                                     s32* p3C, s32* p44,
                                                     s32* p34, s32* p40,
                                                     s32* p48, s32* p38)
{
    s32 val1;
    s32 val;
    s32* pX10;
    s32* pX18;

    val1 = entry->xC + entry->x14;
    pX10 = &entry->x10;
    pX18 = &entry->x18;
    *p3C = val1;
    *p44 = val1;
    *p34 = val1;
    val = *pX10 + *pX18;
    *p40 = val;
    *p48 = val;
    *p38 = val;
    *p40 = *pX10 + *pX18 - *pX18 / 3;
}

static inline void gmTournament_SetRegularCoords(s32 entry_idx, s32 slot_idx,
                                                 u8 x3, BracketData* bracket,
                                                 s32* p3C, s32* p44, s32* p34,
                                                 s32* p40, s32* p48, s32* p38)
{
    s32 val1;
    s32 val2;

    val1 = lbl_80473AB8[entry_idx].xC +
           slot_idx * (lbl_80473AB8[entry_idx].x14 / (s32) x3);
    *p3C = val1;
    *p44 = val1;
    *p34 = val1;
    val2 = lbl_80473AB8[entry_idx].x10 + lbl_80473AB8[entry_idx].x18 -
           lbl_80473AB8[entry_idx].x18 * bracket->entries[entry_idx].x2;
    *p40 = val2;
    *p48 = val2;
    *p38 = val2;
    *p40 = lbl_80473AB8[entry_idx].x10 +
           lbl_80473AB8[entry_idx].x18 * bracket->entries[entry_idx].x2;
}

void fn_8018AA74(HSD_JObj* jobj, s32 entry_idx, s32 slot_idx)
{
    u8* px3;
    s32 val1;
    s32* p48;
    s32* p34;
    s32* p3C;
    BracketEntry* entry;
    s32* p44;
    s32* pX18;
    s32* p38;
    s32 xC;
    s32* p40;
    s32 x10;
    s32 x18;
    s32 val;
    s32* pX10;
    s32 val2;
    s32 tmp;
    u8 x3;
    u8 tm_x2E;

    TmData* tm = gm_GetTournamentData();
    BracketData* bracket = (BracketData*) lbl_80473AB8;

    p34 = &bracket->entries[entry_idx].slots[slot_idx].x34;
    p3C = &bracket->entries[entry_idx].slots[slot_idx].x3C;
    p44 = &bracket->entries[entry_idx].slots[slot_idx].x44;
    p38 = &bracket->entries[entry_idx].slots[slot_idx].x38;
    p40 = &bracket->entries[entry_idx].slots[slot_idx].x40;
    {
        s32* slot_x48 = &bracket->entries[entry_idx].slots[slot_idx].x48;
        p48 = slot_x48;
    }
    entry = &lbl_80473AB8[entry_idx];

    if (entry->x1 != 0) {
        px3 = &entry->x3;
        x3 = *px3;
        (void) px3;
        if (x3 == 0 && entry->x4 != 0) {
            switch (entry->x4) {
            case 1: {
                xC = entry->xC;
                pX18 = &entry->x18;
                pX10 = &entry->x10;
                (void) pX18;
                *p3C = xC;
                *p44 = xC;
                *p34 = xC;
                {
                    x18 = *pX18;
                    x10 = *pX10;
                    val = x10 + x18 - slot_idx * x18;
                    *p40 = val;
                    *p48 = val;
                    *p38 = val;
                }
                *p40 = *pX10 + *pX18 / 2;
                break;
            }
            case 2:
                switch (slot_idx) {
                case 0: {
                    xC = entry->xC;
                    val1 = xC + 0x2B;
                    pX10 = &entry->x10;
                    pX18 = &entry->x18;
                    *p3C = val1;
                    *p44 = val1;
                    *p34 = val1;
                    {
                        x10 = *pX10;
                        x18 = *pX18;
                        val2 = x10 + x18;
                        *p40 = val2;
                        *p48 = val2;
                        *p38 = val2;
                    }
                    *p40 = *pX10 + *pX18 / 2;
                    break;
                }
                case 1: {
                    xC = entry->xC;
                    val1 = xC + entry->x14;
                    pX10 = &entry->x10;
                    pX18 = &entry->x18;
                    *p3C = val1;
                    *p44 = val1;
                    *p34 = val1;
                    {
                        x10 = *pX10;
                        x18 = *pX18;
                        val2 = x10 + x18;
                        *p40 = val2;
                        *p48 = val2;
                        *p38 = val2;
                    }
                    *p40 = *pX10 + *pX18 / 2;
                    break;
                }
                default: {
                    xC = lbl_80473AB8[entry_idx].xC;
                    val1 = xC + lbl_80473AB8[entry_idx].x14 / 2;
                    *p3C = val1;
                    *p44 = val1;
                    *p34 = val1;
                    {
                        x10 = lbl_80473AB8[entry_idx].x10;
                        *p40 = x10;
                        *p48 = x10;
                        *p38 = x10;
                    }
                    *p40 = lbl_80473AB8[entry_idx].x10 +
                           lbl_80473AB8[entry_idx].x18 / 2;
                    break;
                }
                }
                break;
            case 3:
                switch (slot_idx) {
                case 0: {
                    xC = entry->xC;
                    pX10 = &entry->x10;
                    pX18 = &entry->x18;
                    *p3C = xC;
                    *p44 = xC;
                    *p34 = xC;
                    {
                        x10 = *pX10;
                        x18 = *pX18;
                        val = x10 + x18;
                        *p40 = val;
                        *p48 = val;
                        *p38 = val;
                    }
                    *p40 = *pX10 + *pX18 - *pX18 / 3;
                    break;
                }
                case 1: {
                    gmTournament_SetTripleRightCoords(entry, p3C, p44, p34,
                                                      p40, p48, p38);
                    break;
                }
                case 2: {
                    xC = entry->xC;
                    *p3C = xC;
                    *p44 = xC;
                    *p34 = xC;
                    {
                        x10 = entry->x10;
                        *p40 = x10;
                        *p48 = x10;
                        *p38 = x10;
                    }
                    *p40 = entry->x10 + entry->x18 / 3;
                    break;
                }
                default: {
                    xC = lbl_80473AB8[entry_idx].xC;
                    val1 = xC + lbl_80473AB8[entry_idx].x14;
                    *p3C = val1;
                    *p44 = val1;
                    *p34 = val1;
                    {
                        x10 = lbl_80473AB8[entry_idx].x10;
                        *p40 = x10;
                        *p48 = x10;
                        *p38 = x10;
                    }
                    *p40 = lbl_80473AB8[entry_idx].x10 +
                           lbl_80473AB8[entry_idx].x18 / 3;
                    break;
                }
                }
                break;
            }
        } else {
            gmTournament_SetRegularCoords(entry_idx, slot_idx, x3, bracket,
                                          p3C, p44, p34, p40, p48, p38);
            if (*px3 == 1) {
                tm_x2E = tm->x2E;
                if (tm_x2E == 6) {
                    if (entry_idx == 5 && slot_idx == 1) {
                        tmp = *p48 + 0x46;
                        *p48 = tmp;
                        *p38 = tmp;
                    }
                } else if (tm_x2E == 0xC) {
                    if ((entry_idx == 0xA && slot_idx == 0) ||
                        (entry_idx == 0xB && slot_idx == 1))
                    {
                        tmp = *p48 + 0x3C;
                        *p48 = tmp;
                        *p38 = tmp;
                    }
                } else if (tm_x2E == 0x18) {
                    if (entry_idx == 0x17 && slot_idx == 1) {
                        tmp = *p48 + 0x28;
                        *p48 = tmp;
                        *p38 = tmp;
                    }
                } else if (tm_x2E == 0x30) {
                    if (entry_idx == 0x2E && slot_idx == 1) {
                        tmp = *p48 + 0x1E;
                        *p48 = tmp;
                        *p38 = tmp;
                    } else if (entry_idx == 0x2F && slot_idx == 1) {
                        tmp = *p48 - 0x1E;
                        *p48 = tmp;
                        *p38 = tmp;
                    }
                }
            }
        }
    }

    HSD_JObjSetTranslateX(jobj,
                          (f32) lbl_80473AB8[entry_idx].slots[slot_idx].x44);
    HSD_JObjSetTranslateY(jobj,
                          -(f32) lbl_80473AB8[entry_idx].slots[slot_idx].x48);
}

static inline f32 gmTournament_GetBracketSlideYForward(BracketEntrySlot* slot)
{
    return -(0.3f * (f32) lbl_804D6630 + (f32) slot->x48);
}

static inline f32 gmTournament_GetBracketSlideYReverse(BracketEntrySlot* slot)
{
    return -((f32) slot->x48 - 0.3f * (f32) lbl_804D6630);
}

static inline HSD_JObj* fn_8018B090_inline0(BracketEntry* bracket_entries,
                                            s32 bracket_slot_index,
                                            s32 bracket_entry_index)
{
    return bracket_entries[bracket_entry_index]
        .slots[bracket_slot_index]
        .x2C->hsd_obj;
}

static inline BracketEntry* fn_8018B090_inline2(BracketEntry* bracket_entries,
                                                s32 bracket_entry_index)
{
    return &bracket_entries[bracket_entry_index];
}

static inline void fn_8018B090_inline3(BracketEntry* entry)
{
    fn_80190520((f32) (entry->xC + (entry->x14 / 2)),
                -(f32) (entry->x10 + (entry->x18 / 2)), -150.0f);
}

static inline s32 fn_8018B090_inline4(BracketEntry* entry)
{
    s32 i;
    for (i = 0; i < 4; i++) {
        if (entry->slots[i].x4C == 0) {
            break;
        }
    }
    return i;
}

static inline void fn_8018B090_inline5(BracketEntry* entries,
                                       BracketEntry* src, s32 slot_idx)
{
    u8* next_entry;
    u8* next_slot;
    src->x1 = 0;
    next_entry = &src->x5;
    next_slot = &src->x6;
    entries[*next_entry].slots[*next_slot].x30 = 1;
    entries[*next_entry].slots[*next_slot].x50 = src->slots[slot_idx].x50;
    entries[*next_entry].slots[*next_slot].x51 = src->slots[slot_idx].x51;
    entries[*next_entry].slots[*next_slot].x52 = src->slots[slot_idx].x52;
    entries[*next_entry].slots[*next_slot].x4D = src->slots[slot_idx].x4D;
    entries[*next_entry].slots[*next_slot].x4E = src->slots[slot_idx].x4E;
    entries[*next_entry].slots[*next_slot].x4F = src->slots[slot_idx].x4F;
    src->slots[slot_idx].x30 = 0;
    src->slots[slot_idx].x4E = 3;
}

static inline void fn_8018B090_inline6(BracketEntry* entry, s32 slot_idx)
{
    HSD_JObj* jobj = entry->slots[slot_idx].x2C->hsd_obj;
    HSD_JObjSetTranslateX(jobj, (f32) entry->slots[slot_idx].x44);
}

static inline void fn_8018B090_inline7(BracketEntry* entry, s32 slot_idx)
{
    HSD_JObj* jobj = entry->slots[slot_idx].x2C->hsd_obj;
    HSD_JObjSetTranslateY(jobj, -(f32) entry->slots[slot_idx].x48);
}

static inline void fn_8018B090_inline8(struct lbl_803D9DAC_t* camera)
{
    f32* y;
    f32* z;
    mn_8022F410(&camera->current.x, &camera->target.x, camera->step.x);
    y = &camera->current.y;
    mn_8022F410(y, &camera->target.y, camera->step.y);
    z = &camera->current.z;
    mn_8022F410(z, &camera->target.z, camera->step.z);
    fn_80190520(camera->current.x, *y, *z);
}

void fn_8018B090(HSD_GObj* arg0)
{
    BracketEntry* entries = lbl_80473AB8;
    TmData* tm = gm_GetTournamentData();
    HSD_JObj* jobj2;
    s32 k;
    s32 i;
    s32 idx;
    s32 var_r24;
    var_r24 = 0;
    idx = fn_8018F74C();

    switch (tm->cur_option) {
    case 20:
        lbl_804D6630 = 0;
        return;
    case 21:
        if (entries[idx].x18 != 0) {
            for (i = 0; i < 4; i++) {
                if (entries[idx].slots[i].x30 != 0) {
                    HSD_JObj* jobj;
                    jobj = fn_8018B090_inline0(entries, i, idx);
                    jobj2 = jobj;
                    if (entries[idx].x2 != 0) {
                        HSD_JObjSetTranslateY(
                            jobj2, gmTournament_GetBracketSlideYReverse(
                                       &entries[idx].slots[i]));
                    } else {
                        switch (entries[idx].x4) {
                        case 1:
                            if (i == 0) {
                                HSD_JObjSetTranslateY(
                                    jobj2,
                                    gmTournament_GetBracketSlideYForward(
                                        &entries[idx].slots[i]));
                            } else {
                                HSD_JObjSetTranslateY(
                                    jobj2,
                                    gmTournament_GetBracketSlideYReverse(
                                        &entries[idx].slots[i]));
                            }
                            break;
                        case 2:
                        case 3:
                            if (i <= 1) {
                                HSD_JObjSetTranslateY(
                                    jobj2,
                                    gmTournament_GetBracketSlideYForward(
                                        &entries[idx].slots[i]));
                            } else {
                                HSD_JObjSetTranslateY(
                                    jobj2,
                                    gmTournament_GetBracketSlideYReverse(
                                        &entries[idx].slots[i]));
                            }
                            break;
                        default:
                            HSD_JObjSetTranslateY(
                                jobj2, gmTournament_GetBracketSlideYForward(
                                           &entries[idx].slots[i]));
                            break;
                        }
                    }
                }
            }
        }
        lbl_804D6630 += 1;
        return;
    case 22: {
        BracketEntry* entry = &entries[idx];
        s32 h = entry->x18;
        if (h) {
            f32 d;
            lbl_803D9DAC.current.x = 320.0f;
            lbl_803D9DAC.current.y = -240.0f;
            lbl_803D9DAC.current.z = 0.0f;
            lbl_803D9DAC.target.x = (f32) (entry->xC + (entry->x14 / 2));
            lbl_803D9DAC.target.y = -(f32) (entry->x10 + (h / 2));
            lbl_803D9DAC.target.z = -150.0f;
            d = ABS((lbl_803D9DAC.target.x - lbl_803D9DAC.current.x) *
                    0.033333f);
            lbl_803D9DAC.step.x = 1.0f + d;
            d = 0.033333f * (lbl_803D9DAC.target.y - lbl_803D9DAC.current.y);
            if (d < 0.0f) {
                d = -d;
            }
            lbl_803D9DAC.step.y = 1.0f + d;
            d = 0.033333f * (lbl_803D9DAC.target.z - lbl_803D9DAC.current.z);
            if (d < 0.0f) {
                d = -d;
            }
            lbl_803D9DAC.step.z = 1.0f + d;
        }
    }
        lbl_804D6630 = 0;
        /* fallthrough */
    case 23:
        if (entries[idx].x18 != 0) {
            s32 amount = lbl_804D6630 / 6;
            lbl_804D6630 += 1;
            if (mn_8022F410(&lbl_803D9DAC.current.x, &lbl_803D9DAC.target.x,
                            lbl_803D9DAC.step.x) < 0)
            {
                mn_8022F410(&lbl_803D9DAC.current.x, &lbl_803D9DAC.target.x,
                            lbl_803D9DAC.step.x);
            } else {
                mn_8022F410(&lbl_803D9DAC.current.x, &lbl_803D9DAC.target.x,
                            lbl_803D9DAC.step.x);
            }
            if (mn_8022F410(&lbl_803D9DAC.current.y, &lbl_803D9DAC.target.y,
                            lbl_803D9DAC.step.y) < 0)
            {
                mn_8022F410(&lbl_803D9DAC.current.y, &lbl_803D9DAC.target.y,
                            lbl_803D9DAC.step.y);
            } else {
                mn_8022F410(&lbl_803D9DAC.current.y, &lbl_803D9DAC.target.y,
                            lbl_803D9DAC.step.y);
            }
            if (mn_8022F410(&lbl_803D9DAC.current.z, &lbl_803D9DAC.target.z,
                            lbl_803D9DAC.step.z) < 0)
            {
                mn_8022F410(&lbl_803D9DAC.current.z, &lbl_803D9DAC.target.z,
                            lbl_803D9DAC.step.z);
            } else {
                mn_8022F410(&lbl_803D9DAC.current.z, &lbl_803D9DAC.target.z,
                            lbl_803D9DAC.step.z);
            }
            fn_80190520(lbl_803D9DAC.current.x, lbl_803D9DAC.current.y,
                        lbl_803D9DAC.current.z);
            if (entries[idx].x4 != 1) {
                s32 slot_no;
                for (slot_no = 0; slot_no < 4; slot_no++) {
                    if (entries[idx].slots[slot_no].x30 != 0) {
                        mn_8022F470((int*) &entries[idx].slots[slot_no].x48,
                                    (int*) &entries[idx].slots[slot_no].x40, amount);
                        {
                            f32 y = -(f32) entries[idx].slots[slot_no].x48;
                            HSD_JObjSetTranslateY(
                                entries[idx].slots[slot_no].x2C->hsd_obj, y);
                        }
                    }
                }
                return;
            }
            for (i = 0; i < 4; i++) {
                if (entries[idx].slots[i].x30 != 0) {
                    entries[idx].slots[i].x40 = entries[idx].slots[i].x48;
                }
            }
        }
        return;
    case 24:
        if (entries[idx].x18 != 0) {
            struct lbl_803B7C80_t sp;
            s32* arr;
            sp = lbl_803B7C80;
            arr = sp.v;
            lbl_804D6630 += 1;
            for (k = 0; k < 4; k++) {
                if (entries[idx].slots[k].x30 != 0) {
                    HSD_JObj* jobj = entries[idx].slots[k].x2C->hsd_obj;
                    if (entries[idx].x2 != 0) {
                        HSD_JObjSetTranslateY(
                            jobj, -((f32) entries[idx].slots[k].x40 -
                                    (0.1f * (f32) arr[lbl_804D6630 % 10])));
                    } else {
                        switch (entries[idx].x4) {
                        case 1:
                            if (k == 0) {
                                HSD_JObjSetTranslateY(
                                    jobj,
                                    -((0.1f * (f32) arr[lbl_804D6630 % 10]) +
                                      (f32) entries[idx].slots[k].x40));
                            } else {
                                HSD_JObjSetTranslateY(
                                    jobj,
                                    -((f32) entries[idx].slots[k].x40 -
                                      (0.1f * (f32) arr[lbl_804D6630 % 10])));
                            }
                            break;
                        case 2:
                        case 3:
                            if (k <= 1) {
                                HSD_JObjSetTranslateY(
                                    jobj,
                                    -((0.1f * (f32) arr[lbl_804D6630 % 10]) +
                                      (f32) entries[idx].slots[k].x40));
                            } else {
                                HSD_JObjSetTranslateY(
                                    jobj,
                                    -((f32) entries[idx].slots[k].x40 -
                                      (0.1f * (f32) arr[lbl_804D6630 % 10])));
                            }
                            break;
                        default:
                            HSD_JObjSetTranslateY(
                                jobj, -((0.1f * (f32) arr[lbl_804D6630 % 10]) +
                                        (f32) entries[idx].slots[k].x40));
                            break;
                        }
                    }
                }
            }
        }
        return;
    case 25:
        for (i = 0; i < 4; i++) {
            if (entries[idx].slots[i].x30 != 0) {
                entries[idx].slots[i].x48 = entries[idx].slots[i].x40;
            }
        }
        return;
    case 32: {
        s32 h = entries[idx].x18;
        if (h != 0) {
            fn_8018B090_inline3(&entries[idx]);
            for (i = 0; i < 4; i++) {
                if (entries[idx].slots[i].x4C == 0) {
                    entries[idx].slots[i].x3C =
                        entries[idx].xC + (entries[idx].x14 / 2);
                } else {
                    s32 t = entries[idx].slots[i].x40;
                    entries[idx].slots[i].x40 = entries[idx].slots[i].x38;
                    entries[idx].slots[i].x38 = t;
                }
            }
        } else {
            fn_801904D0();
        }
    }
        tm->cur_option = 0x21;
        return;
    case 33:
        if (entries[idx].x18 != 0) {
            for (i = 0; i < 4; i++) {
                if (entries[idx].slots[i].x30 == 0) {
                    var_r24 += 1;
                } else {
                    u8 t5 = entries[idx].slots[i].x4C;
                    if (t5 == 0) {
                        lbl_804D6634 = i;
                        if (entries[idx].x4 != 1) {
                            mn_8022F470((int*) &entries[idx].slots[i].x44,
                                        (int*) &entries[idx].slots[i].x3C, 2);
                            if (entries[idx].slots[i].x44 ==
                                entries[idx].slots[i].x3C)
                            {
                                var_r24 += 1;
                            }
                            HSD_JObjSetTranslateX(
                                entries[idx].slots[i].x2C->hsd_obj,
                                (f32) entries[idx].slots[i].x44);
                        } else {
                            var_r24 += 1;
                        }
                    } else {
                        mn_8022F470((int*) &entries[idx].slots[i].x48,
                                    (int*) &entries[idx].slots[i].x40,
                                    t5 + ((t5 + 1) / 2));
                        if (entries[idx].slots[i].x48 ==
                            entries[idx].slots[i].x40)
                        {
                            var_r24 += 1;
                        }
                        HSD_JObjSetTranslateY(
                            entries[idx].slots[i].x2C->hsd_obj,
                            -(f32) entries[idx].slots[i].x48);
                    }
                }
            }
            if (var_r24 == 4) {
                s32 slot_idx;
                s32 ent;
                entries[idx].slots[slot_idx = lbl_804D6634].x3C =
                    lbl_803D9E1C[ent = tm->entrants][0];
                entries[idx].slots[slot_idx].x40 =
                    lbl_803D9E1C[tm->entrants][1];
                tm->cur_option = 0x22;
            }
        } else {
            tm->cur_option = 0x22;
        }
        return;
    case 34:
        if (entries[idx].x18 != 0) {
            if (tm->x33 == 5) {
                mn_8022F470((int*) &entries[idx].slots[lbl_804D6634].x44,
                            (int*) &entries[idx].slots[lbl_804D6634].x3C, 2);
                fn_8018B090_inline6(&entries[idx], lbl_804D6634);
                if (entries[idx].slots[lbl_804D6634].x44 ==
                    entries[idx].slots[lbl_804D6634].x3C)
                {
                    tm->cur_option = 0x23;
                }
            } else {
                lbl_804D6630 = 0;
                tm->cur_option = 0x24;
            }
        } else {
            lbl_804D6630 = 0;
            tm->cur_option = 0x24;
        }
        return;
    case 35:
        if (entries[idx].x18 != 0) {
            if (tm->x33 == 5) {
                mn_8022F470((int*) &entries[idx].slots[lbl_804D6634].x48,
                            (int*) &entries[idx].slots[lbl_804D6634].x40, 2);
                fn_8018B090_inline7(&entries[idx], lbl_804D6634);
                if (entries[idx].slots[lbl_804D6634].x48 ==
                    entries[idx].slots[lbl_804D6634].x40)
                {
                    tm->x33 = 6;
                }
            } else {
                lbl_804D6630 = 0;
                tm->cur_option = 0x24;
            }
        } else {
            lbl_804D6630 = 0;
            tm->cur_option = 0x24;
        }
        return;
    case 36: {
        BracketEntry* entry = &entries[idx];
        s32 h = entry->x18;
        if (h != 0) {
            f32 d;
            lbl_803D9DAC.current.x = (f32) (entry->xC + (entry->x14 / 2));
            lbl_803D9DAC.current.y = -(f32) (entry->x10 + (h / 2));
            lbl_803D9DAC.current.z = -150.0f;
            lbl_803D9DAC.target.x = 320.0f;
            lbl_803D9DAC.target.y = -240.0f;
            lbl_803D9DAC.target.z = 0.0f;
            d = 0.04f * (lbl_803D9DAC.target.x - lbl_803D9DAC.current.x);
            if (d < 0.0f) {
                d = -d;
            }
            lbl_803D9DAC.step.x = d;
            d = 0.04f * (lbl_803D9DAC.target.y - lbl_803D9DAC.current.y);
            if (d < 0.0f) {
                d = -d;
            }
            lbl_803D9DAC.step.y = d;
            d = 0.04f * (lbl_803D9DAC.target.z - lbl_803D9DAC.current.z);
            if (d < 0.0f) {
                d = -d;
            }
            lbl_803D9DAC.step.z = d;
        }
    }
        tm->cur_option = 0x25;
        return;
    case 37:
        if (entries[idx].x18 == 0) {
            lbl_804D6630 = 0x78;
        }
        if (lbl_804D6630 < 0x78) {
            lbl_804D6630 += 1;
            fn_8018B090_inline8(&lbl_803D9DAC);
            return;
        }
        lbl_804D6630 = 0;
        fn_801904D0();
        tm->cur_option = 0x26;
        return;
    case 38:
        if (entries[idx].x18 == 0) {
            lbl_804D6630 = 0x78;
        }
        if (lbl_804D6630 < 0x78) {
            lbl_804D6630 += 1;
            return;
        }
        {
            s32 slot_idx = fn_8018B090_inline4(&entries[idx]);
            BracketEntry* src;
            src = fn_8018B090_inline2(entries, fn_8018F74C());
            fn_8018B090_inline5(entries, src, slot_idx);
            tm->cur_option = 0x27;
        }
        break;
    }
    PAD_STACK(0x18);
}

/* 3D9EE8 */ static char lbl_803D9EE8[] = {
    131, 81, 131, 88, 131, 103, 32, 48, 48,
};
/* 3D9EF4 */ static char lbl_803D9EF4[] = {
    130, 103, 130, 108, 130, 109, 32, 48, 48,
};
/* 3D9EF4 */ static char lbl_803D9F00[] = {
    130, 98, 130, 111, 130, 116, 32, 48, 48,
};

static GXColor const lbl_804DA67C = { 0xFF, 0xFF, 0, 0xFF };

/// Draws tournament bracket lines for different bracket types (0-3).
void fn_8018C8D4(BracketEntry* arg0, s32 arg1, s32 arg2, s32 arg3, s32 arg4,
                 s32 arg5)
{
    /// @todo Redundant cast and assignment improves match
#ifdef MUST_MATCH
    BracketEntry* data = (BracketEntry*) arg0;
#else
    BracketEntry* data = arg0;
#endif
    f32 thickness;
    f32 neg_thickness;
    GXColor c0, c1, c2, c3, c4, c5, c6, c7, c8, c9;
    s32 half_h, third_h;
    s32 mid_y, bot_y, two_third_y;
    s32 half, center, right;
    GXColor c10, c11, c12, c13, c14, c15, c16, c17, c18, c19;
    GXColor c20, c21, c22, c23, c24, c25, c26, c27, c28, c29;
    GXColor c30, c31, c32, c33;

    c0 = lbl_804DA67C;
    thickness = data->x1C;

    switch ((s32) data->x4) {
    case 0:
        c1 = c0;
        {
            GXColor* color = &c1;
            DrawRectangle((f32) arg1, (f32) arg2, thickness, (f32) arg4,
                          color);
        }
        if (data->x20.g == 0) {
            c2 = data->x20;
            {
                GXColor* color = &c2;
                DrawRectangle((f32) arg1, (f32) arg2, thickness, (f32) arg4,
                              color);
            }
        }
        return;

    case 1:
        c3 = c0;
        {
            GXColor* color = &c3;
            DrawRectangle((f32) arg1, (f32) arg2, thickness, (f32) arg4,
                          color);
        }
        if (data->x20.g == 0) {
            if (data->slots[0].x4C == 0) {
                half_h = arg4 / 2;
                c4 = data->x20;
                {
                    GXColor* color = &c4;
                    DrawRectangle((f32) arg1, (f32) (arg2 + half_h), thickness,
                                  (f32) half_h, color);
                }
                return;
            }
            c5 = data->x20;
            {
                GXColor* color = &c5;
                DrawRectangle((f32) arg1, (f32) arg2, thickness,
                              (f32) (arg4 / 2), color);
            }
        }
        break;

    case 2:
        half = arg3 / 2;
        center = arg1 + half;
        half_h = arg4 / 2;
        c6 = c0;
        {
            GXColor* color = &c6;
            DrawRectangle((f32) center, (f32) arg2, thickness, (f32) half_h,
                          color);
        }

        neg_thickness = -thickness;
        c7 = c0;
        {
            GXColor* color = &c7;
            DrawRectangle((f32) (arg1 + 0x2B), (f32) (mid_y = arg2 + half_h),
                          ((f32) arg3 + thickness) - 43.0f, neg_thickness,
                          color);
        }

        c8 = c0;
        {
            GXColor* color = &c8;
            DrawRectangle((f32) (arg1 + 0x2B), (f32) mid_y, thickness,
                          (f32) half_h, color);
        }

        right = arg1 + arg3;
        c9 = c0;
        {
            GXColor* color = &c9;
            DrawRectangle((f32) right, (f32) mid_y, thickness, (f32) half_h,
                          color);
        }

        if (data->x20.g == 0) {
            if (data->slots[0].x4C == 0) {
                c10 = data->x20;
                {
                    GXColor* color = &c10;
                    DrawRectangle((f32) (arg1 + 0x2B), (f32) mid_y, thickness,
                                  (f32) half_h, color);
                }
                c11 = data->x20;
                {
                    GXColor* color = &c11;
                    DrawRectangle((f32) (arg1 + 0x2B), (f32) mid_y,
                                  (f32) (half - 0x2B), neg_thickness, color);
                }
                return;
            }
            if (data->slots[1].x4C == 0) {
                c12 = data->x20;
                {
                    GXColor* color = &c12;
                    DrawRectangle((f32) right, (f32) mid_y, thickness,
                                  (f32) half_h, color);
                }
                c13 = data->x20;
                {
                    GXColor* color = &c13;
                    DrawRectangle((f32) center, (f32) mid_y,
                                  (f32) half + thickness, neg_thickness,
                                  color);
                }
                return;
            }
            c14 = data->x20;
            {
                GXColor* color = &c14;
                DrawRectangle((f32) center, (f32) arg2, thickness,
                              (f32) half_h, color);
            }
        }
        break;

    case 3:
        half = arg3 / 2;
        third_h = arg4 / 3;

        c15 = c0;
        {
            GXColor* color = &c15;
            DrawRectangle((f32) (arg1 + half), (f32) (arg2 + third_h),
                          thickness, (f32) (third_h - 2), color);
        }

        c16 = c0;
        {
            GXColor* color = &c16;
            DrawRectangle((f32) arg1, (f32) arg2, thickness, (f32) third_h,
                          color);
        }

        right = arg1 + arg3;
        c17 = c0;
        {
            GXColor* color = &c17;
            DrawRectangle((f32) right, (f32) arg2, thickness, (f32) third_h,
                          color);
        }

        bot_y = (arg2 + arg4) - third_h;
        c18 = c0;
        {
            GXColor* color = &c18;
            DrawRectangle((f32) arg1, (f32) bot_y, thickness, (f32) third_h,
                          color);
        }

        c19 = c0;
        {
            GXColor* color = &c19;
            DrawRectangle((f32) right, (f32) bot_y, thickness, (f32) third_h,
                          color);
        }

        neg_thickness = -thickness;
        c20 = c0;
        {
            GXColor* color = &c20;
            DrawRectangle((f32) arg1, (f32) (arg2 + third_h),
                          (f32) arg3 + thickness, neg_thickness, color);
        }

        c21 = c0;
        {
            GXColor* color = &c21;
            DrawRectangle((f32) arg1, (f32) bot_y, (f32) arg3 + thickness,
                          neg_thickness, color);
        }

        if (data->x20.g == 0) {
            if (data->slots[0].x4C == 0) {
                c22 = data->x20;
                two_third_y = arg2 + ((arg4 * 2) / 3);
                {
                    GXColor* color = &c22;
                    DrawRectangle((f32) arg1, (f32) two_third_y, thickness,
                                  (f32) third_h, color);
                }
                c23 = data->x20;
                {
                    GXColor* color = &c23;
                    DrawRectangle((f32) arg1, (f32) two_third_y, (f32) half,
                                  neg_thickness, color);
                }
                c24 = data->x20;
                {
                    GXColor* color = &c24;
                    DrawRectangle((f32) (arg1 + half),
                                  (f32) (arg2 + (arg4 / 2)), thickness,
                                  (f32) ((arg4 / 6) - 1), color);
                }
                return;
            }
            if (data->slots[1].x4C == 0) {
                c25 = data->x20;
                two_third_y = arg2 + ((arg4 * 2) / 3);
                {
                    GXColor* color = &c25;
                    DrawRectangle((f32) right, (f32) two_third_y, thickness,
                                  (f32) third_h, color);
                }
                c26 = data->x20;
                {
                    GXColor* color = &c26;
                    DrawRectangle((f32) (arg1 + half), (f32) two_third_y,
                                  (f32) half, neg_thickness, color);
                }
                c27 = data->x20;
                {
                    GXColor* color = &c27;
                    DrawRectangle((f32) (arg1 + half),
                                  (f32) (arg2 + (arg4 / 2)), thickness,
                                  (f32) ((arg4 / 6) - 1), color);
                }
                return;
            }
            if (data->slots[2].x4C == 0) {
                c28 = data->x20;
                {
                    GXColor* color = &c28;
                    DrawRectangle((f32) arg1, (f32) arg2, thickness,
                                  (f32) third_h, color);
                }
                c29 = data->x20;
                {
                    GXColor* color = &c29;
                    DrawRectangle((f32) arg1, (f32) (arg2 + third_h),
                                  (f32) half, neg_thickness, color);
                }
                c30 = data->x20;
                {
                    GXColor* color = &c30;
                    DrawRectangle((f32) (arg1 + half), (f32) (arg2 + third_h),
                                  thickness, (f32) ((arg4 / 6) - 1), color);
                }
                return;
            }
            c31 = data->x20;
            {
                GXColor* color = &c31;
                DrawRectangle((f32) right, (f32) arg2, thickness,
                              (f32) third_h, color);
            }
            c32 = data->x20;
            {
                GXColor* color = &c32;
                DrawRectangle((f32) (arg1 + half), (f32) (arg2 + third_h),
                              (f32) half, neg_thickness, color);
            }
            c33 = data->x20;
            {
                GXColor* color = &c33;
                DrawRectangle((f32) (arg1 + half), (f32) (arg2 + third_h),
                              thickness, (f32) ((arg4 / 6) - 1), color);
            }
        }
        break;
    }
}

static GXColor const lbl_804DA684 = { 255, 255, 0, 255 };

/// Draws tournament bracket connector lines with optional tail segments.
void fn_8018D50C(BracketEntry* data, s32 arg1, s32 arg2, s32 arg3, s32 arg4,
                 s32 arg5)
{
    TmData* tm;
    f32 thickness;
    f32 neg_thickness;
    s32 right;
    s32 bottom;
    GXColor c0, c1, c2, c3, c4, c5, c6, c7, c8, c9;
    GXColor c10, c11, c12, c13, c14, c15, c16, c17, c18, c19;

    tm = gm_GetTournamentData();
    c0 = lbl_804DA684;
    thickness = data->x1C;
    c1 = c0;
    {
        GXColor* color = &c1;
        DrawRectangle((f32) arg1, (f32) arg2, thickness, (f32) arg4, color);
    }

    right = arg1 + arg3;
    c2 = c0;
    {
        GXColor* color = &c2;
        DrawRectangle((f32) right, (f32) arg2, thickness, (f32) arg4, color);
    }

    neg_thickness = -thickness;
    c3 = c0;
    {
        GXColor* color = &c3;
        DrawRectangle((f32) arg1, (f32) arg5, (f32) arg3 + thickness,
                      neg_thickness, color);
    }

    if (data->x20.g == 0) {
        if (data->slots[0].x4C == 0) {
            c4 = data->x20;
            {
                GXColor* color = &c4;
                DrawRectangle((f32) arg1, (f32) arg2, thickness, (f32) arg4,
                              color);
            }
            c5 = data->x20;
            {
                GXColor* color = &c5;
                DrawRectangle((f32) arg1, (f32) arg5,
                              (f32) (arg3 / 2) + thickness, neg_thickness,
                              color);
            }
        } else {
            c6 = data->x20;
            {
                GXColor* color = &c6;
                DrawRectangle((f32) right, (f32) arg2, thickness, (f32) arg4,
                              color);
            }
            {
                s32 half2 = arg3 / 2;
                c7 = data->x20;
                {
                    GXColor* color = &c7;
                    DrawRectangle((f32) (arg1 + half2), (f32) arg5,
                                  (f32) half2 + thickness, neg_thickness,
                                  color);
                }
            }
        }
    }

    if (tm->entrants == 1) {
        if (data->slots[1].x32 != 0) {
            bottom = arg2 + arg4;
            c8 = c0;
            {
                GXColor* color = &c8;
                DrawRectangle((f32) right, (f32) bottom, thickness, -70.0f,
                              color);
            }
            if (data->x20.g == 0 && data->slots[0].x4C != 0) {
                c9 = data->x20;
                DrawRectangle((f32) right, (f32) bottom, thickness, -70.0f,
                              &c9);
            }
        }
        return;
    } else if (tm->entrants == 3) {
        if (data->slots[0].x32 != 0) {
            bottom = arg2 + arg4;
            c10 = c0;
            {
                GXColor* color = &c10;
                DrawRectangle((f32) arg1, (f32) bottom, thickness, -60.0f,
                              color);
            }
            if (data->x20.g == 0 && data->slots[0].x4C == 0) {
                c11 = data->x20;
                DrawRectangle((f32) arg1, (f32) bottom, thickness, -60.0f,
                              &c11);
            }
        } else if (data->slots[1].x32 != 0) {
            bottom = arg2 + arg4;
            c12 = c0;
            {
                GXColor* color = &c12;
                DrawRectangle((f32) right, (f32) bottom, thickness, -60.0f,
                              color);
            }
            if (data->x20.g == 0 && data->slots[0].x4C != 0) {
                c13 = data->x20;
                DrawRectangle((f32) right, (f32) bottom, thickness, -60.0f,
                              &c13);
            }
        }
    } else if (tm->entrants == 5) {
        if (data->slots[1].x32 != 0) {
            bottom = arg2 + arg4;
            c14 = c0;
            {
                GXColor* color = &c14;
                DrawRectangle((f32) right, (f32) bottom, thickness, -40.0f,
                              color);
            }
            if (data->x20.g == 0 && data->slots[0].x4C != 0) {
                c15 = data->x20;
                DrawRectangle((f32) right, (f32) bottom, thickness, -40.0f,
                              &c15);
            }
        }
    } else if (tm->entrants == 7) {
        if (data->slots[1].x32 != 0) {
            if (data->x2 == 0) {
                bottom = arg2 + arg4;
                c16 = c0;
                {
                    GXColor* color = &c16;
                    DrawRectangle((f32) right, (f32) bottom, thickness, -30.0f,
                                  color);
                }
                if (data->x20.g == 0 && data->slots[0].x4C != 0) {
                    c17 = data->x20;
                    {
                        GXColor* color = &c17;
                        DrawRectangle((f32) right, (f32) bottom, thickness,
                                      -30.0f, color);
                    }
                }
            } else {
                c18 = c0;
                {
                    GXColor* color = &c18;
                    DrawRectangle((f32) right, (f32) (arg2 + 0x1E), thickness,
                                  -30.0f, color);
                }
                if (data->x20.g == 0 && data->slots[0].x4C != 0) {
                    c19 = data->x20;
                    DrawRectangle((f32) right, (f32) (arg2 + 0x1E), thickness,
                                  -30.0f, &c19);
                }
            }
        }
    }
}

static GXColor const col = { 0xFF, 0xFF, 0x00, 0xFF };

void fn_8018DC18(BracketEntry* data, s32 arg1, s32 arg2, s32 arg3, s32 arg4,
                 s32 arg5)
{
    f32 thickness;
    f32 neg_thickness;
    s32 right;
    s32 half;
    s32 center;
    GXColor c0, c1, c2, c3, c4, c5, c6, c7, c8, c9;

    c0 = col;
    thickness = data->x1C;
    c1 = c0;
    {
        GXColor* color = &c1;
        DrawRectangle((f32) arg1, (f32) arg2, thickness, (f32) arg4, color);
    }

    right = arg1 + arg3;
    c2 = c0;
    {
        GXColor* color = &c2;
        DrawRectangle((f32) right, (f32) arg2, thickness, (f32) arg4, color);
    }

    half = arg3 / 2;
    center = arg1 + half;
    c3 = c0;
    {
        GXColor* color = &c3;
        DrawRectangle((f32) center, (f32) arg2, thickness, (f32) arg4, color);
    }

    neg_thickness = -thickness;
    c4 = c0;
    {
        GXColor* color = &c4;
        DrawRectangle((f32) arg1, (f32) arg5, (f32) arg3 + thickness,
                      neg_thickness, color);
    }

    if (data->x20.g == 0) {
        if (data->slots[0].x4C == 0) {
            c5 = data->x20;
            {
                GXColor* color = &c5;
                DrawRectangle((f32) arg1, (f32) arg2, thickness, (f32) arg4,
                              color);
            }
            c6 = data->x20;
            {
                GXColor* color = &c6;
                DrawRectangle((f32) arg1, (f32) arg5, (f32) half + thickness,
                              neg_thickness, color);
            }
            return;
        }
        if (data->slots[1].x4C == 0) {
            c7 = data->x20;
            {
                GXColor* color = &c7;
                DrawRectangle(center, arg2, thickness, arg4, color);
            }
            return;
        }
        c8 = data->x20;
        {
            GXColor* color = &c8;
            DrawRectangle((f32) right, (f32) arg2, thickness, (f32) arg4,
                          color);
        }
        c9 = data->x20;
        {
            GXColor* color = &c9;
            DrawRectangle((f32) center, (f32) arg5, (f32) half + thickness,
                          neg_thickness, color);
        }
    }
}

static const GXColor lbl_804DA69C = { 255, 255, 0, 255 };

void fn_8018DF68(BracketEntry* arg0, s32 arg1, s32 arg2, s32 arg3, s32 arg4,
                 s32 arg5)
{
    GXColor line_color;
    GXColor first_color;
    GXColor right_color;
    GXColor left_third_color;
    GXColor right_third_color;
    GXColor horizontal_color;
    GXColor slot0_vertical_color;
    GXColor slot0_horizontal_color;
    GXColor slot1_vertical_color;
    GXColor slot1_horizontal_color;
    GXColor slot2_vertical_color;
    GXColor slot2_horizontal_color;
    GXColor slot3_vertical_color;
    GXColor slot3_horizontal_color;
    f32 neg_thickness;
    f32 thickness;
    s32 right;
    s32 third;
    s32 right_third;
    s32 half;

    line_color = lbl_804DA69C;
    thickness = arg0->x1C;
    first_color = line_color;
    {
        GXColor* color = &first_color;
        DrawRectangle((f32) arg1, (f32) arg2, thickness, (f32) arg4, color);
    }

    right = arg1 + arg3;
    right_color = line_color;
    {
        GXColor* color = &right_color;
        DrawRectangle((f32) right, (f32) arg2, thickness, (f32) arg4, color);
    }

    left_third_color = line_color;
    third = arg3 / 3;
    {
        f32 x = (f32) (arg1 + third);
        GXColor* color = &left_third_color;
        DrawRectangle(x, (f32) arg2, thickness, (f32) arg4, color);
    }

    right_third = right - third;
    right_third_color = line_color;
    {
        GXColor* color = &right_third_color;
        DrawRectangle((f32) right_third, (f32) arg2, thickness, (f32) arg4,
                      color);
    }

    neg_thickness = -thickness;
    horizontal_color = line_color;
    {
        GXColor* color = &horizontal_color;
        DrawRectangle((f32) arg1, (f32) arg5, (f32) arg3 + thickness,
                      neg_thickness, color);
    }

    if (arg0->x20.g == 0) {
        if (arg0->slots[0].x4C == 0) {
            slot0_vertical_color = arg0->x20;
            {
                GXColor* color = &slot0_vertical_color;
                DrawRectangle((f32) arg1, (f32) arg2, thickness, (f32) arg4,
                              color);
            }
            slot0_horizontal_color = arg0->x20;
            {
                GXColor* color = &slot0_horizontal_color;
                DrawRectangle((f32) arg1, (f32) arg5,
                              (f32) (arg3 / 2) + thickness, neg_thickness,
                              color);
            }
            return;
        }
        if (arg0->slots[1].x4C == 0) {
            slot1_vertical_color = arg0->x20;
            {
                GXColor* color = &slot1_vertical_color;
                DrawRectangle((f32) (arg1 + third), (f32) arg2, thickness,
                              (f32) arg4, color);
            }
            slot1_horizontal_color = arg0->x20;
            {
                GXColor* color = &slot1_horizontal_color;
                DrawRectangle((f32) (arg1 + third), (f32) arg5,
                              ((f32) (arg3 / 2) + thickness) - third,
                              neg_thickness, color);
            }
            return;
        }
        if (arg0->slots[2].x4C == 0) {
            slot2_vertical_color = arg0->x20;
            {
                GXColor* color = &slot2_vertical_color;
                DrawRectangle((f32) right_third, (f32) arg2, thickness,
                              (f32) arg4, color);
            }
            half = arg3 / 2;
            slot2_horizontal_color = arg0->x20;
            {
                GXColor* color = &slot2_horizontal_color;
                DrawRectangle((f32) (arg1 + half), (f32) arg5,
                              ((f32) half + thickness) - third, neg_thickness,
                              color);
            }
            return;
        }
        slot3_vertical_color = arg0->x20;
        {
            GXColor* color = &slot3_vertical_color;
            DrawRectangle((f32) right, (f32) arg2, thickness, (f32) arg4,
                          color);
        }
        half = arg3 / 2;
        slot3_horizontal_color = arg0->x20;
        {
            GXColor* color = &slot3_horizontal_color;
            DrawRectangle((f32) (arg1 + half), (f32) arg5,
                          (f32) half + thickness, neg_thickness, color);
        }
    }
}

/// @todo Currently 98.8% match - permuter couldn't improve beyond score 140

void fn_8018E46C(HSD_GObj* gobj, int unused)
{
    BracketEntry* data;
    s32 temp;
    s32 r30;

    data = gobj->user_data;
    data->x3 = data->x3;

    if (data->x2 != 0) {
        temp = -(data->x10 + data->x18);
    } else {
        temp = -data->x10;
    }
    r30 = temp;
    HSD_FogSet(NULL);
    hsd_80391A04(1.0F, 1.0F, 1);
    switch (data->x3) {
    case 0:
        fn_8018C8D4(data, data->xC - (s32) (0.5f * data->x1C), -data->x10,
                    data->x14, -data->x18, r30);
        break;
    case 1:
        fn_8018D50C(data, data->xC - (s32) (0.5f * data->x1C), -data->x10,
                    data->x14, -data->x18, r30);
        break;
    case 2:
        fn_8018DC18(data, data->xC - (s32) (0.5f * data->x1C), -data->x10,
                    data->x14, -data->x18, r30);
        break;
    case 3:
        fn_8018DF68(data, data->xC - (s32) (0.5f * data->x1C), -data->x10,
                    data->x14, -data->x18, r30);
        break;
    }
}

static inline void gmTournament_InitBracket(s32 entrant_count, f32 anim_frame,
                                            bool reset)
{
    if (reset) {
        fn_8018A514(entrant_count, anim_frame);
    }
    fn_8018A970(entrant_count);
}

/// Initializes the tournament bracket camera and optionally resets bracket
/// data. Removes all existing GObjs from two entity lists, inits lbl_80473AB8
/// entries, creates camera GObj with CObjDesc loaded from lbl_803B7CA8 rodata.
#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
void fn_8018E618(int arg0, f32 farg0, int arg1)
{
    HSD_CameraDescPerspective cam;
    HSD_GObj* gobj;
    HSD_GObj* tmp;
    s32 i;
    PAD_STACK(16);

    cam = lbl_803B7CA8;

    while ((tmp = M2C_FIELD(HSD_GObj_Entities, HSD_GObj**, 0x6C)) != NULL) {
        HSD_GObjPLink_80390228(tmp);
    }
    while ((tmp = M2C_FIELD(HSD_GObj_Entities, HSD_GObj**, 0x50)) != NULL) {
        HSD_GObjPLink_80390228(tmp);
    }

    for (i = 0; i < 0x40; i++) {
        if (arg1 != 0) {
            lbl_80473AB8[i].x0 = 0;
            lbl_80473AB8[i].slots[0].x4E = 3;
            lbl_80473AB8[i].slots[1].x4E = 3;
            lbl_80473AB8[i].slots[2].x4E = 3;
            lbl_80473AB8[i].slots[3].x4E = 3;
        }
    }

    gobj = GObj_Create(9, 0x14, 1);
    {
        typedef struct CObjData {
            f32 pos[9];
            struct lbl_803D9DD0_t cobj_data;
        } CObjData;
        HSD_CObj* cobj = HSD_CObjLoadDesc((HSD_CObjDesc*) &cam);
        CObjData* cobj_data = (CObjData*) &lbl_803D9DAC;
        cobj_data->cobj_data.cobj = cobj;
        {
            HSD_CObj** cobj_ptr = &cobj_data->cobj_data.cobj;
            u8* kind_ptr = &HSD_GObj_CameraKind;
            HSD_GObjObject_80390A70(gobj, *kind_ptr, *cobj_ptr);
        }
    }
    GObj_SetupGXLinkMax(gobj, HSD_GObj_803910D8, 1);
    ((u32*) &gobj->gxlink_prios)[1] = 0x10;
    ((u32*) &gobj->gxlink_prios)[0] = 0;

    gmTournament_InitBracket(arg0, farg0, arg1);
}
#ifdef MUST_MATCH
#pragma pop
#endif

void fn_8018E85C(DynamicModelDesc* model, s32 flag)
{
    u8* sub;
    TmData* td;
    HSD_JObj* jobj;
    s32 outer_idx;
    s32 inner_idx;
    s32 bracket_idx;
    s32 j;
    u8* ptr;
    HSD_GObj* gobj;
    s32 anim_frame;
    f32 final_pos;
    f32 pos;
    f32 pos_multiplier;

    td = gm_GetTournamentData();
    bracket_idx = 0;

    for (outer_idx = 0; outer_idx < 0x40; outer_idx++) {
        if (lbl_80473AB8[outer_idx].x0 == 0) {
            goto next_entry;
        }
        inner_idx = 0;
        for (; inner_idx < 4; inner_idx++) {
            sub = &lbl_80473AB8[outer_idx].x0 + inner_idx * 0x2C;
            if (sub[0x30] == 0) {
                goto next_sub;
            }

            if (flag != 0) {
                ptr = (u8*) td;
                for (j = 0; j < 64; j++) {
                    if (ptr[0x44 + j * 0x12] == bracket_idx) {
                        break;
                    }
                }
                sub[0x50] = (u8) j;
                ptr = (u8*) td + j * 0x12;
                sub[0x4D] = ptr[0x3A];
                sub[0x4E] = ptr[0x37];
                sub[0x4F] = ptr[0x3E];
                sub[0x51] = ptr[0x38];
                sub[0x52] = ptr[0x39];
                *(u16*) (sub + 0x54) = *(u16*) (ptr + 0x40);
                bracket_idx++;
            }

            gobj = GObj_Create(0xE, 0x1B, 0);
            *(HSD_GObj**) (sub + 0x2C) = gobj;
            gobj = *(HSD_GObj**) (sub + 0x2C);
            jobj = HSD_JObjLoadJoint(model->joint);
            HSD_GObjObject_80390A70(gobj, HSD_GObj_JObjKind, jobj);
            GObj_SetupGXLink(gobj, HSD_GObj_JObjCallback, 4, 2);
            gm_8016895C(jobj, model, 0);

            anim_frame = sub[0x4D] + sub[0x4F] * 0x1E;
            HSD_JObjReqAnimAll(jobj, (f32) anim_frame);
            HSD_JObjAnimAll(jobj);

            if (outer_idx == fn_8018F74C()) {
                pos_multiplier = 10.0f;
            } else {
                pos_multiplier = 7.0f;
            }

            pos = 0.0083f * (f32) (0x40 - (s32) td->x2E) + 1.0f;
            final_pos = pos_multiplier * pos;
            HSD_JObjSetScaleX(jobj, final_pos);

            pos = 0.0083f * (f32) (0x40 - (s32) td->x2E) + 1.0f;
            final_pos = pos_multiplier * pos;
            HSD_JObjSetScaleY(jobj, final_pos);

            if (td->cur_option < 0x1F) {
                fn_8018AA74(jobj, outer_idx, inner_idx);
            } else {
                fn_8018FDC4(jobj, (f32) * (s32*) (sub + 0x44),
                            -(f32) * (s32*) (sub + 0x48), 666.0f);
            }

        next_sub:;
        }
    next_entry:;
    }
}

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
void fn_8018EC48(void)
{
    mn_8022F138(0x19, 0x1C);
    mn_8022F138(0x12, 0x15);
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
void fn_8018EC7C(void)
{
    mn_8022F0F0(0x1B);
    mn_8022F0F0(0x14);
}
#ifdef MUST_MATCH
#pragma pop
#endif

void fn_8018ECA8(s32 char_id, s32 name_type, s32 jobj_idx1, f32 pos_x,
                 f32 pos_y, s32 jobj_idx2)
{
    char* hmn_texts[2];
    char* cpu_texts[2];
    TmData* tm;
    s32 num;

    tm = gm_GetTournamentData();

    hmn_texts[0] = lbl_804DA6B4;
    cpu_texts[0] = lbl_804DA6BC;
    hmn_texts[1] = lbl_804DA6B8;
    cpu_texts[1] = lbl_804DA6C0;

    if (name_type == 0xFF) {
        HSD_SisLib_803A6B98(tm->x518[jobj_idx1], pos_x, pos_y,
                            GetNameText((u8) char_id));
        return;
    }

    if (char_id >= 0x320) {
        if (char_id < 0x384) {
            num = char_id - 0x320;
            if (num >= 10) {
                hmn_texts[!!lbLang_IsSavedLanguageUS()][7] =
                    (s8) (num / 10 + 0x30);
                hmn_texts[!!lbLang_IsSavedLanguageUS()][8] =
                    (s8) (num % 10 + 0x30);
                hmn_texts[!!lbLang_IsSavedLanguageUS()][9] = 0;
            } else {
                hmn_texts[!!lbLang_IsSavedLanguageUS()][7] =
                    (s8) (char_id - 0x2F0);
                hmn_texts[!!lbLang_IsSavedLanguageUS()][8] = 0;
            }
            HSD_SisLib_803A6B98(tm->x518[jobj_idx1], pos_x, pos_y,
                                hmn_texts[!!lbLang_IsSavedLanguageUS()]);
            return;
        }
        if (char_id >= 0x3E7) {
            return;
        }
        num = char_id - 0x384;
        if (num >= 10) {
            cpu_texts[!!lbLang_IsSavedLanguageUS()][7] =
                (s8) (num / 10 + 0x30);
            cpu_texts[!!lbLang_IsSavedLanguageUS()][8] =
                (s8) (num % 10 + 0x30);
            cpu_texts[!!lbLang_IsSavedLanguageUS()][9] = 0;
        } else {
            cpu_texts[!!lbLang_IsSavedLanguageUS()][7] =
                (s8) (char_id - 0x354);
            cpu_texts[!!lbLang_IsSavedLanguageUS()][8] = 0;
        }
        HSD_SisLib_803A6B98(tm->x518[jobj_idx2], pos_x, pos_y,
                            cpu_texts[!!lbLang_IsSavedLanguageUS()]);
        return;
    }

    if (name_type == 0) {
        HSD_SisLib_803A6B98(tm->x518[jobj_idx1], pos_x, pos_y,
                            GetNameText((u8) char_id));
    } else if (name_type == 1) {
        HSD_SisLib_803A6B98(tm->x518[jobj_idx2], pos_x, pos_y,
                            GetNameText((u8) char_id));
    }
}

char* const lbl_804DA6B4 = lbl_803D9EE8;
char* const lbl_804DA6B8 = lbl_803D9EF4;
char* const lbl_804DA6BC = lbl_803D9F00;
char* const lbl_804DA6C0 = lbl_803D9F00;
char* const lbl_804DA6C4 = lbl_803D9EE8;
char* const lbl_804DA6C8 = lbl_803D9EF4;
char* const lbl_804DA6CC = lbl_803D9F00;
char* const lbl_804DA6D0 = lbl_803D9F00;

/// Formats a tournament slot display name into a destination buffer.
void fn_8018F00C(char* dest, s32 slot_id)
{
    char* templates_800[2];
    char* templates_900[2];
    char* tmpl_800;
    char* tmpl_900;

    templates_800[0] = lbl_804DA6C4;
    templates_900[0] = lbl_804DA6CC;
    templates_800[1] = lbl_804DA6C8;
    templates_900[1] = lbl_804DA6D0;

    tmpl_800 = templates_800[!!lbLang_IsSavedLanguageUS()];
    tmpl_900 = templates_900[!!lbLang_IsSavedLanguageUS()];

    if (slot_id >= 0x320) {
        if (slot_id < 0x384) {
            /* Slot IDs 800-899: format as 2-digit number (00-99) */
            s32 diff = slot_id - 0x320;
            if (diff < 10) {
                /* Single digit: write digit + null terminator */
                tmpl_800[7] = (s8) (slot_id - 0x2F0);
                tmpl_800[8] = 0;
            } else {
                /* Double digit: write tens, ones, null terminator */
                tmpl_800[7] = (s8) (diff / 10 + 0x30);
                tmpl_800[8] = (s8) (diff % 10 + 0x30);
                tmpl_800[9] = 0;
            }
            strcpy(dest, tmpl_800);
        } else if (slot_id != 0x3E7) {
            /* Slot IDs 900-998: format as 2-digit number (00-98) */
            s32 diff = slot_id - 0x384;
            if (diff < 10) {
                /* Single digit: write digit + null terminator */
                tmpl_900[7] = (s8) (slot_id - 0x354);
                tmpl_900[8] = 0;
            } else {
                /* Double digit: write tens, ones, null terminator */
                tmpl_900[7] = (s8) (diff / 10 + 0x30);
                tmpl_900[8] = (s8) (diff % 10 + 0x30);
                tmpl_900[9] = 0;
            }
            strcpy(dest, tmpl_900);
        }
    } else {
        /* Slot IDs below 800: use player nametag text */
        strcpy(dest, GetNameText((u8) slot_id));
    }
}

s32 gm_8018F1B0(MatchEnd* me)
{
    TmData* tm;

    tm = gm_GetTournamentData();

    switch (gm_804771C4.match_type) {
    case 0:
        return 1;

    case 1:
        switch (tm->hmn_cpu_count) {
        case 1:
            return 1;

        case 2:
            if (tm->x30 == 3) {
                if (me->n_winners == 3) {
                    return 1;
                }
            } else if (tm->x30 == 4) {
                if (me->n_winners >= 3) {
                    return 1;
                }
            }
            break;

        case 3:
            if (me->n_winners == 4) {
                return 1;
            }
            break;
        }
        break;

    case 2:
        switch (tm->hmn_cpu_count) {
        case 1:
            if (tm->x30 == me->n_winners) {
                return 1;
            }
            break;

        case 2:
            if (tm->x30 == 3) {
                return 1;
            } else if (tm->x30 == 4) {
                if (me->n_winners >= 3) {
                    return 1;
                }
            }
            break;

        case 3:
            return 1;
        }
        break;
    }

    return 0;
}

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
int fn_8018F310(int arg0)
{
    int i;
    for (i = 0; i < ARRAY_SIZE(lbl_803D9D20.x59); i++) {
        if (lbl_803D9D20.x59[i] == arg0) {
            return i;
        }
    }
    return -1;
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
int fn_8018F3BC(s32 arg0)
{
    return lbl_803D9D20.x59[arg0];
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
int fn_8018F3D0(int arg0)
{
    if (arg0 == 0xE || (arg0 >= 0x10 && arg0 <= 0x13) || arg0 == 0xA) {
        return 1;
    }
    if (arg0 <= 0xD) {
        return 0;
    }
    return 2;
}
#ifdef MUST_MATCH
#pragma pop
#endif

/* 3D9F0C */ struct lbl_803D9F0C_t lbl_803D9F0C = { -1, -1, -1 };

int fn_8018F410(void)
{
    int char_id;

    do {
        char_id = HSD_Randi(0x19);
    } while (lbl_803D9D20.x72[char_id] == 0 || lbl_803D9F0C.x0 == char_id ||
             lbl_803D9F0C.x4 == char_id || lbl_803D9F0C.x8 == char_id);
    lbl_803D9F0C.x8 = lbl_803D9F0C.x4;
    lbl_803D9F0C.x4 = lbl_803D9F0C.x0;
    lbl_803D9F0C.x0 = char_id;
    return char_id;
}

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
int fn_8018F4A0(void)
{
    int temp_r3 = mnStageSel_8025BBD4();
    if (!gm_80164430(temp_r3)) {
        printf("This is impossible stage num from mnSelStageRandom() -> stage "
               "%d \n",
               temp_r3);
        HSD_ASSERT(0x53D, 0);
    }
    return temp_r3;
}
#ifdef MUST_MATCH
#pragma pop
#endif

/// Counts available tournament slots and returns the last found index.
#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
s32 fn_8018F508(s32* out_index)
{
    s32 count;
    u8* base_ptr;
    u8* slot_ptr;
    s32 i;

    count = 0;
    base_ptr = (u8*) &lbl_80473AB8[fn_8018F74C()];
    slot_ptr = base_ptr;

    if (slot_ptr[0x0] == 0) {
        return -1;
    }

    for (i = 0; i < 4; i++) {
        if (slot_ptr[0x4E] != 3) {
            if (out_index != NULL) {
                *out_index = i;
            }
            count++;
        }
        slot_ptr += 0x2C;
    }

    return count;
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma dont_inline on
#endif
char* fn_8018F5F0(void)
{
    if (lbLang_IsSavedLanguageUS()) {
        return "SdTou.usd";
    } else {
        return "SdTou.dat";
    }
}
#ifdef MUST_MATCH
#pragma pop
#endif

/// ???
/// tournament uses the user data as just an int
/// it controls various menu jobj states ie animation state, visibility, etc
#ifdef MUST_MATCH
#pragma dont_inline on
#endif
u32 fn_8018F62C(HSD_GObj* gobj)
{
    return (u32) gobj->user_data;
}
#ifdef MUST_MATCH
#pragma dont_inline off
#endif

#ifdef MUST_MATCH
#pragma push
#pragma dont_inline on
#endif
TmData* gm_GetTournamentData(void)
{
    return &gm_804771C4;
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma dont_inline on
#endif
u32 fn_8018F640(int arg0)
{
    if (arg0 >= 4) {
        arg0 = 4;
    }
    return gm_GetButtonsTriggered(arg0);
}

u32 fn_8018F674(int arg0)
{
    if (arg0 >= 4) {
        arg0 = 4;
    }
    return gm_801A36C0(arg0);
}
#ifdef MUST_MATCH
#pragma dont_inline off
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
u32 fn_8018F6A8(int arg0)
{
    if (arg0 >= 4) {
        arg0 = 4;
    }
    return gm_GetButtonsPressed((u8) arg0);
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
int fn_8018F6DC(int arg0)
{
    if (arg0 >= 0x13) {
        if (arg0 == 0x1D) {
            return 5;
        }
        return arg0 - 1;
    }
    return arg0;
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
CharacterKind fn_8018F6FC(CSSIconHud arg0)
{
    if (arg0 >= 0x13) {
        if (arg0 == 0x1D) {
            return 5;
        }
        return arg0 + 1;
    }
    return (CharacterKind) arg0;
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
float fn_8018F71C(int arg0, int arg1)
{
    return arg0 + arg1 * 0x1E;
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
int fn_8018F74C(void)
{
    int i;

    for (i = 0; i < 0x40; i++) {
        if (lbl_80473AB8[i].x1 != 0) {
            break;
        }
    }

    return i;
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
int fn_8018F808(void)
{
    int i;
    int noerrcount = 0;
    for (i = 0; i < 4; i++) {
        if (HSD_PadMasterStatus[(u8) i].err == 0) {
            noerrcount += 1;
        }
    }
    return noerrcount;
}
#ifdef MUST_MATCH
#pragma pop
#endif

static inline s32 fn_8018F888_inline0(void)
{
    s32 i;

    for (i = 0; i < 0x40; i++) {
        if (lbl_80473AB8[i].x1 != 0) {
            break;
        }
    }

    return i;
}

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
void fn_8018F888(void)
{
    s32 i = fn_8018F888_inline0();

    lbl_80473AB8[i].x20.g = 0;

    if (gm_804771C4.x33 != 5) {
        return;
    }

    i = fn_8018F888_inline0();

    lbl_80473AB8[i + 1].x20.g = 0;
}
#ifdef MUST_MATCH
#pragma pop
#endif

static inline int fn_8018FA24_inline0(int char_kind)
{
    if (char_kind < CKIND_SEAK) {
        return char_kind;
    }
    if (char_kind == CKIND_GKOOPS) {
        return 5;
    }
    return char_kind + 1;
}

void fn_8018FA24(void)
{
    u8* ptr;
    u8* dst;
    u8* tmdata;
    s32 player_idx;
    s32 player_count;
    s32 i;
    BracketEntry* entry;

    PAD_STACK(8);

    tmdata = (u8*) &gm_804771C4;

    entry = lbl_80473AB8;
    for (i = 0; i < 64; entry++, i++) {
        if (entry->x1 != 0) {
            break;
        }
    }

    dst = tmdata;
    ptr = (u8*) lbl_80473AB8 + i * (s32) 0xDC;
    player_count = 0;

    for (player_idx = 0; player_idx < 4; player_idx++) {
        dst[0x4B6] = ptr[0x30];
        dst[0x4B7] = ptr[0x50];
        *(u16*) (dst + 0x4BE) = *(u16*) (tmdata + 0x40 + ptr[0x50] * 0x12);
        dst[0x4BC] = ptr[0x51];
        dst[0x4BD] = ptr[0x52];
        dst[0x4B9] = ptr[0x4D];
        Player_SetPlayerCharacter(player_idx, fn_8018FA24_inline0(dst[0x4B9]));
        dst[0x4B8] = ptr[0x4E];
        if (dst[0x4B8] != 3) {
            player_count += 1;
        }
        Player_SetSlottype(player_idx, dst[0x4B8]);
        dst[0x4BB] = ptr[0x4F];
        Player_SetCostumeId(player_idx, dst[0x4BB]);
        dst[0x4BC] = ptr[0x51];
        ptr += 0x2C;
        dst += 0xA;
    }

    tmdata[0x30] = player_count;
}

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
void fn_8018FBD8(void* arg0, s32 arg1)
{
    ((HSD_GObj*) arg0)->user_data = (void*) arg1;
}
#ifdef MUST_MATCH
#pragma pop
#endif

void fn_8018FBE0(s32 arg0, s32 arg1, s32 arg2, s32 arg3, s32 arg4, s32 arg5,
                 s32 arg6)
{
    s32 i;

    ((TmData*) &((BracketData*) lbl_80473AB8)->srcs[3])->cur_option = arg0;
    ((TmData*) &((BracketData*) lbl_80473AB8)->srcs[3])->x1C = arg1;
    ((TmData*) &((BracketData*) lbl_80473AB8)->srcs[3])->x20 = arg2;

    for (i = 0; 64 > i; i++) {
        ((TmData*) &((BracketData*) lbl_80473AB8)->srcs[3])->x37[i].x2 =
            (u8) arg3;
        ((TmData*) &((BracketData*) lbl_80473AB8)->srcs[3])->x37[i].x1 =
            (u8) arg4;
        ((TmData*) &((BracketData*) lbl_80473AB8)->srcs[3])->x37[i].xD =
            (u8) i;
        ((TmData*) &((BracketData*) lbl_80473AB8)->srcs[3])->x37[i].x9 =
            (u16) arg5;
        ((TmData*) &((BracketData*) lbl_80473AB8)->srcs[3])->x37[i].x0 =
            (u8) arg6;
    }
}

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
void fn_8018FDC4(HSD_JObj* jobj, float x, float y, float z)
{
    if ((int) x != 666) {
        HSD_JObjSetTranslateX(jobj, x);
    }
    if ((int) y != 666) {
        HSD_JObjSetTranslateY(jobj, y);
    }
    if ((int) z != 666) {
        HSD_JObjSetTranslateZ(jobj, z);
    }
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
void fn_8018FF9C(HSD_JObj* jobj, float x, float y, float z)
{
    if ((int) x != 666) {
        HSD_JObjSetScaleX(jobj, x);
    }
    if ((int) y != 666) {
        HSD_JObjSetScaleY(jobj, y);
    }
    if ((int) z != 666) {
        HSD_JObjSetScaleZ(jobj, z);
    }
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
HSD_GObj* fn_80190174(HSD_CObjDesc* cobjdesc)
{
    HSD_GObj* gobj = GObj_Create(0x13, 0x12, 0);
    HSD_CObj* cobj = HSD_CObjLoadDesc(cobjdesc);
    HSD_GObjObject_80390A70(gobj, HSD_GObj_CameraKind, cobj);
    GObj_SetupGXLinkMax(gobj, HSD_GObj_803910D8, 0);
    gobj->gxlink_prios = 7;
    return gobj;
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
HSD_GObj* fn_801901F8(HSD_CObjDesc* cobjdesc)
{
    HSD_GObj* gobj = GObj_Create(0x13, 0x15, 2);
    HSD_CObj* cobj = HSD_CObjLoadDesc(cobjdesc);
    HSD_GObjObject_80390A70(gobj, HSD_GObj_CameraKind, cobj);
    GObj_SetupGXLinkMax(gobj, HSD_GObj_803910D8, 2);
    gobj->gxlink_prios = 0xA;
    return gobj;
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
void fn_8019027C(UNK_T lights)
{
    HSD_GObj* gobj = GObj_Create(0xB, 0x1A, 0);
    HSD_LObj* lobj = lb_80011AC4(lights);
    HSD_GObjObject_80390A70(gobj, HSD_GObj_LightKind, lobj);
    GObj_SetupGXLink(gobj, HSD_GObj_LObjCallback, 1, 0);
}
#ifdef MUST_MATCH
#pragma pop
#endif

/// Initializes SIS library text rendering for tournament mode.
#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
void fn_801902F0(int sis_param)
{
    s32 value;
    PAD_STACK(8);

    value = sis_param;
    HSD_SisLib_803A5E70();
    if (gm_804771C4.x1C == 0) {
        value = 0;
    }
    lbl_804D663C =
        HSD_SisLib_803A611C(0, (HSD_GObj*) value, 9, 0x12, 0, 3, 0, 0x13);
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
HSD_GObj* fn_8019035C(bool arg0, DynamicModelDesc* model, int arg2, int arg3,
                      int arg4, bool arg5, void (*arg6)(HSD_GObj*), f32 arg8)
{
    HSD_GObj* gobj = GObj_Create(0xE, arg3, 0);
    HSD_JObj* jobj = HSD_JObjLoadJoint(model->joint);
    HSD_GObjObject_80390A70(gobj, HSD_GObj_JObjKind, jobj);
    GObj_SetupGXLink(gobj, HSD_GObj_JObjCallback, arg4, 0);
    if (arg6 != NULL) {
        HSD_GObj_SetupProc(gobj, arg6, 0);
    }
    if (arg5) {
        gm_8016895C(jobj, model, arg2);
        HSD_JObjReqAnimAll(jobj, arg8);
        HSD_JObjAnimAll(jobj);
        if (arg0) {
            HSD_JObjSetFlagsAll(jobj, JOBJ_HIDDEN);
        }
    }
    return gobj;
}
#ifdef MUST_MATCH
#pragma pop
#endif

#ifdef MUST_MATCH
#pragma dont_inline on
#endif
void fn_8019044C(HSD_JObj* jobj, float arg1)
{
    HSD_JObjReqAnimAll(jobj, arg1);
    HSD_JObjAnimAll(jobj);
}
#ifdef MUST_MATCH
#pragma dont_inline off
#endif

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif
void fn_80190480(float arg8)
{
    if ((int) arg8 == 0) {
        HSD_CObjSetFov(lbl_803D9DD0.cobj, lbl_803D9DD0.xD0);
        return;
    }
    HSD_CObjSetFov(lbl_803D9DD0.cobj, arg8);
}
#ifdef MUST_MATCH
#pragma pop
#endif

void fn_801904D0(void)
{
    struct lbl_803D9DD0_t* tmp = &lbl_803D9DD0;
    HSD_CObjSetInterest(tmp->cobj, &lbl_803D9E08.pos);
    HSD_CObjSetEyePosition(tmp->cobj, &lbl_803D9DF4.pos);
}

#ifdef MUST_MATCH
#pragma push
#pragma auto_inline off
#endif

void fn_80190520(f32 x, f32 y, f32 z)
{
    Vec3 sp14;

    if (((s32) x == 0) && ((s32) y == 0) && ((s32) z == 0)) {
        struct lbl_803D9DD0_t* tmp = &lbl_803D9DD0;
        HSD_CObjSetInterest(tmp->cobj, &lbl_803D9E08.pos);
        HSD_CObjSetEyePosition(tmp->cobj, &lbl_803D9DF4.pos);
        return;
    } else {
        struct lbl_803D9DD0_t* tmp = &lbl_803D9DD0;
        sp14.x = x;
        sp14.y = y;
        sp14.z = z;
        HSD_CObjSetInterest(tmp->cobj, &sp14);
        sp14.z = 415.6922f + z;
        HSD_CObjSetEyePosition(tmp->cobj, &sp14);
    }
}
#ifdef MUST_MATCH
#pragma pop
#endif

static inline int gm_801905F0_inline0(int c_kind)
{
    if (c_kind < CKIND_SEAK) {
        return c_kind;
    }
    if (c_kind == CKIND_GKOOPS) {
        return CKIND_KOOPA;
    }
    return c_kind + 1;
}

void gm_801905F0(StartMeleeData* arg0)
{
    u8 _padA[8];
    int i;
    TmData* tm = &gm_804771C4;
    GameRules* rules = gmMainLib_GetGameRules();
    TmVsData sp18;

    gm_LoadAnnouncer();
    gm_SetupRulesDefaults(&arg0->rules);
    arg0->rules.is_teams = false;
    arg0->rules.stkind = tm->x28;
    fn_801640B0(&arg0->rules.x20);
    arg0->rules.match_kind = rules->mode;
    if (rules->mode != 1) {
        arg0->rules.timer_enabled = true;
    } else if (rules->stock_time_limit != 0) {
        arg0->rules.timer_enabled = true;
    } else {
        arg0->rules.timer_enabled = false;
    }
    if (arg0->rules.timer_enabled) {
        if (rules->mode != 1) {
            if (rules->time_limit == 0) {
                arg0->rules.time_limit = 99 * 60;
            } else {
                arg0->rules.time_limit = rules->time_limit * 60;
            }
        } else {
            if (rules->stock_time_limit == 0) {
                arg0->rules.time_limit = 99 * 60;
            } else {
                arg0->rules.time_limit = rules->stock_time_limit * 60;
            }
        }
    }
    if (arg0->rules.match_kind == MatchKind_Stock) {
        arg0->rules.is_stock = true;
    }
    arg0->rules.timer_counts_up = false;
    arg0->rules.x4_2 = false;
    arg0->rules.x4_4 = false;
    arg0->rules.xB = gmMainLib_8015CC58()->item_freq;
    arg0->rules.x2_2 = false;
    arg0->rules.x18 = 0;
    arg0->rules.game_speed = 1.0f;
    arg0->rules.x30 = fn_801653E8(rules->damage_ratio);
    arg0->rules.x3_4 = false;
    arg0->rules.x3_5 = false;
    arg0->rules.x3_2 = false;
    arg0->rules.x3_3 = false;
    switch (gmMainLib_8015ED30()) {
    case 1:
        arg0->rules.xC = 0;
        break;
    case 0:
        arg0->rules.xC = -1;
        break;
    case 2:
        arg0->rules.xC = -2;
        break;
    }
    if (rules->pause != 0) {
        arg0->rules.disable_pausing = false;
    } else {
        arg0->rules.disable_pausing = true;
    }
    if (rules->score_display != 0 && !arg0->rules.match_kind) {
        arg0->rules.x3_0 = true;
    } else {
        arg0->rules.x3_0 = false;
    }
    gm_SetupAllPlayerDefaults(arg0->players);

    for (i = 0; i < 4; i++) {
        if (i < tm->x30) {
            arg0->players[i].model_scale = 1.0f;
            arg0->players[i].nametag = (u8) MIN(tm->x4B8[i].x6, 0x78);
            if (tm->x4B8[i].x2 != 0) {
                arg0->players[i].ckind = gm_801905F0_inline0(fn_8018F410());
                arg0->players[i].color =
                    HSD_Randi(gm_80169238(arg0->players[i].ckind));
            } else {
                arg0->players[i].ckind = gm_801905F0_inline0(tm->x4B8[i].x1);
                arg0->players[i].color = tm->x4B8[i].x3;
            }
            arg0->players[i].slot_type = tm->x4B8[i].x0;
            arg0->players[i].stocks = rules->stock_count;
            arg0->players[i].sub_color = 0;
            arg0->players[i].team = 0xFF;
            arg0->players[i].rumble_enabled =
                gm_RumbleEnabledForPlayer(i, arg0->players[i].nametag);
            if (tm->x4B8[i].x0 == 1) {
                arg0->players[i].rumble_enabled = false;
            }
            arg0->players[i].cpu_kind = 4;
            arg0->players[i].cpu_level = tm->x4B8[i].x4;
            arg0->players[i].x12 = 0;
            if (gmMainLib_GetGameRules()->handicap != 0) {
                arg0->players[i].attack_ratio = fn_8016419C(tm->x4B8[i].x5);
                arg0->players[i].defense_ratio = fn_801641B4(tm->x4B8[i].x5);
            } else {
                arg0->players[i].attack_ratio =
                    arg0->players[i].defense_ratio = 1.0F;
            }
        } else {
            arg0->players[i].slot_type = Gm_PKind_NA;
        }
    }

    sp18.stkind = arg0->rules.stkind;
    for (i = 0; i < 4; i++) {
        sp18.slot_type[i] = arg0->players[i].slot_type;
        sp18.char_id[i] = arg0->players[i].ckind;
        sp18.color[i] = arg0->players[i].color;
    }

    fn_8019EF08(&sp18);
}

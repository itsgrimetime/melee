from pathlib import Path
import subprocess,json
p=Path('src/melee/gm/gmtoulib.c');base=p.read_text();out=Path('/tmp/c016-bracket-loop-counter');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('    case 23:',base.index('void fn_8018B090('));b=base.index('    case 24:',a);part=base[a:b]
start=part.index('                for (i = 0; i < 4; i++) {')
end=part.index('                return;',start)
loop=part[start:end]
import re
variants={}
for counter in ('k','slot_no'):
 for shape in ('for','while','do'):
  t=re.sub(r'\bi\b',counter,loop)
  if shape=='while':t=t.replace('for ('+counter+' = 0; '+counter+' < 4; '+counter+'++) {',counter+' = 0;\n                while ('+counter+' < 4) {'); pos=t.rfind('                }');t=t[:pos]+'                    '+counter+'++;\n'+t[pos:]
  if shape=='do':
   t=t.replace('for ('+counter+' = 0; '+counter+' < 4; '+counter+'++) {',counter+' = 0;\n                do {');pos=t.rfind('                }');t=t[:pos]+'                    '+counter+'++;\n                } while ('+counter+' < 4);'+t[pos+17:]
  if counter=='slot_no':t='                s32 slot_no;\n'+t
  variants[counter+'-'+shape]=part[:start]+t+part[end:]
rows=[]
try:
 for name,s in variants.items():
  full=base[:a]+s+base[b:];(out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_8018B090','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

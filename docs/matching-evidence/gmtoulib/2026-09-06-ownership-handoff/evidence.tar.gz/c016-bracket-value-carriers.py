from pathlib import Path
import subprocess,json
p=Path('src/melee/gm/gmtoulib.c');base=p.read_text();out=Path('/tmp/c016-bracket-value-carriers');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('    case 33:',base.index('void fn_8018B090('));b=base.index('    case 34:',a);part=base[a:b]
old='''                s32 slot_idx;
                s32 ent;
                entries[idx].slots[slot_idx = lbl_804D6634].x3C =
                    lbl_803D9E1C[ent = tm->entrants][0];'''
assert part.count(old)==1
variants={}
for carrier in ('ent','i','k','var_r24'):
 for placement in ('embedded','before'):
  decl='                s32 slot_idx;\n'+('                s32 ent;\n' if carrier=='ent' else '')
  expr='lbl_803D9E1C[tm->entrants][0]'
  if placement=='embedded':repl=decl+'                entries[idx].slots[slot_idx = lbl_804D6634].x3C =\n                    ('+carrier+' = '+expr+');'
  else:repl=decl+'                '+carrier+' = '+expr+';\n                entries[idx].slots[slot_idx = lbl_804D6634].x3C = '+carrier+';'
  variants[carrier+'-'+placement]=part.replace(old,repl)
# Preserve a scalar coordinate by reusing the incoming, now-dead index only after LHS index is consumed.
# Not used: changing idx inside RHS would have unspecified interaction with LHS evaluation.
rows=[]
try:
 for name,s in variants.items():
  full=base[:a]+s+base[b:];(out/(name+'.c')).write_text(full);p.write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','fn_8018B090','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

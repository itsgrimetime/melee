import json,sys,copy
from pathlib import Path
sys.path.insert(0,'/Users/mike/code/mwcc-decomp/tools')
from coloring_model import replay_simplify
r=Path('/tmp/c016-rgb-direct-call-stages/creation');b=json.loads((r/'coloring-0001-gpr-01-before.json').read_text());a=json.loads((r/'coloring-0001-gpr-01-after.json').read_text());t={int(k):v for k,v in json.load(open('/tmp/c016-rgb-direct-call-correspondence.json'))['target_assignments'].items()}
base=replay_simplify(b);actual={n['virtual_register']:n['physical_register'] for n in a['nodes']};assert base['simplify_order']==b['simplify_order'];assert all(actual[v]==c for v,c in base['colors'].items())
rows=[]
for root,alias in [(40,74),(74,40)]:
 q=copy.deepcopy(b);ns={n['virtual_register']:n for n in q['nodes']};assert root not in ns[alias]['neighbors'];neighbors=set(ns[root]['neighbors'])|set(ns[alias]['neighbors']);neighbors.discard(alias);neighbors.discard(root);ns[root]['neighbors']=sorted(neighbors)
 for v in neighbors:
  if root not in ns[v]['neighbors']:ns[v]['neighbors'].append(root)
 ns[alias]['flags']|=4;ns[alias]['physical_register']=root;q['simplify_order']=[v for v in q['simplify_order'] if v!=alias]
 q['coalesced_registers'][alias]=root
 out=replay_simplify(q);colors=out['colors'];miss={v:{'actual':colors.get(root if v==alias else v),'target':c} for v,c in t.items() if colors.get(root if v==alias else v)!=c}
 rows.append({'root':root,'alias':alias,'row_color':colors[root],'target_mismatches':miss,'mismatch_count':len(miss),'select_order':out['simplify_order']})
print([(x['root'],x['row_color'],x['mismatch_count']) for x in rows])
Path('/tmp/c016-rgb-merge-model.json').write_text(json.dumps({'baseline_replay_rows':len(base['colors']),'hypothesis_only':True,'scope':'Offline coalesced alias with unioned root neighbors, retained permanent alias edges. No compiler intervention; not a source-realizability proof. Target subset only, not final code/scheduling proof.','variants':rows},indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();s=Path('/tmp/c016-rgb-row-lifetime-call/combined.c').read_text();s=s.replace('                            s32 column_offset = (pixel_index & 1) * 0x20;','').replace('src[column_offset + (pixel_index & 2) * stride]','src[(pixel_index & 1) * 0x20 + (pixel_index & 2) * stride]');Path('/tmp/c016-rgb-shared-row.c').write_text(s)
try:
 p.write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);Path('/tmp/c016-rgb-shared-row.json').write_text(r.stdout);x=json.loads(r.stdout);print(x['fuzzy_match_percent'],x['classification']['stack_frame_sizes'])
 r=subprocess.run(['melee-agent','debug','retro','dump',str(p),'-f','hsd_803B3408','--phases','frontend','--gdb-py','/tmp/c016-rgb-stages-hook.py','--timeout','180','-O','/tmp/c016-rgb-shared-row-stages'],capture_output=True,text=True,timeout=210);print('capture',r.returncode)
finally:p.write_text(base)

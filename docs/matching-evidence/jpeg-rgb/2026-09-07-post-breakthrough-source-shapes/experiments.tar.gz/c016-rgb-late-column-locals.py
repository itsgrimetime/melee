from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-late-column-locals');out.mkdir(exist_ok=True)
try:
 for which in ['low','high','both']:
  for order in ['row-first','column-first']:
   for rowhome in [True,False]:
    s=base;decl='';lo='(chroma_x & 1)';ulo='(chroma_x & 1U)';hi='(chroma_x & 2) * 4'
    if which in ['low','both']:decl+='                    s32 chroma_low = (chroma_x & 1);\n';lo='chroma_low';ulo='(u32) chroma_low'
    if which in ['high','both']:decl+='                    s32 chroma_high = (chroma_x & 2) * 4;\n';hi='chroma_high'
    for oldlow,newlow in [('(chroma_x & 1U)',ulo),('(chroma_x & 1)',lo)]:
     old='dst_row + '+oldlow+' + (chroma_x & 2) * 4';new=('dst_row + '+newlow+' + '+hi) if order=='row-first' else '('+newlow+' + '+hi+') + dst_row';s=s.replace(old,new)
    marker='                for (chroma_x = 0; chroma_x < 4; chroma_x++) {\n';s=s.replace(marker,marker+decl)
    if not rowhome:s=s.replace('s32 row_offset = (pixel_index & 2) * stride;','').replace('column_offset + row_offset','column_offset + ((pixel_index & 2) * stride)')
    name=which+'-'+order+('-row-home' if rowhome else '-no-row');(out/(name+'.c')).write_text(s);p.write_text(s)
    r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],flush=True)
finally:p.write_text(base)

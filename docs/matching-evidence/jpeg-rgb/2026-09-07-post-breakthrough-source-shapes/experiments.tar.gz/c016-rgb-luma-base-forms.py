from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-luma-base-forms');out.mkdir(exist_ok=True)
a=base.index('luma_base =',base.index('void hsd_803B3408'));b=base.index(',\n                        pixel_index',a);old=base[a:b]
idx='tile_x * 4 + ((tile_y * 4 + luma_y) * 8 + luma_x)'
forms={'typed-array':'&((JpegWork*) HSD_804D2648_BUF)->data.x118['+idx+']','element-offset':'(s32*) HSD_804D2648_BUF + ('+idx+') + 0x46','element-offset-grouped':'(s32*) HSD_804D2648_BUF + (('+idx+') + 0x46)','element-base-offset':'((s32*) HSD_804D2648_BUF + 0x46) + ('+idx+')','index-first':'('+idx+') + ((s32*) HSD_804D2648_BUF + 0x46)','byte-base-offset':'(s32*) ((HSD_804D2648_BUF + 0x118) + ('+idx+') * 4)'}
try:
 for name,expr in forms.items():
  s=base.replace(old,'luma_base = '+expr);(out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

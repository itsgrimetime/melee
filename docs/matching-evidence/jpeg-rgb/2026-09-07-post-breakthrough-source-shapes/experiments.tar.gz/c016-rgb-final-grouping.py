from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-final-grouping');out.mkdir(exist_ok=True)
old=['dst_row + (chroma_x & 1U) + (chroma_x & 2) * 4','dst_row + (chroma_x & 1) + (chroma_x & 2) * 4']
def forms(u):
 l='(chroma_x & 1'+u+')';h='(chroma_x & 2) * 4';r='dst_row'
 return [r+' + '+l+' + '+h,r+' + ('+l+' + '+h+')','('+l+' + '+h+') + '+r,r+' + ('+h+' + '+l+')']
try:
 for i,j in itertools.product(range(4),repeat=2):
  if i==j==0:continue
  s=base.replace(old[0],forms('U')[i]).replace(old[1],forms('')[j]);name=f'{i}-{j}';(out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],flush=True)
finally:p.write_text(base)

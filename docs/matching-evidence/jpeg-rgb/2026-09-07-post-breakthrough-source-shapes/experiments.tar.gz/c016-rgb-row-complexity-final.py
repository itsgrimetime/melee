from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-row-complexity-final');out.mkdir(exist_ok=True)
try:
 for which in ['cb','cr','both']:
  for grouping in ['row-first','column-first']:
   s=base
   for ch,low in [('cb','(chroma_x & 1U)'),('cr','(chroma_x & 1)')]:
    row='(tile_offset + row_part + (chroma_y & 2) * 16)' if which in [ch,'both'] else 'dst_row';old='dst_row + '+low+' + (chroma_x & 2) * 4';new=row+' + '+low+' + (chroma_x & 2) * 4' if grouping=='row-first' else '('+low+' + (chroma_x & 2) * 4) + '+row;s=s.replace(old,new)
   name=which+'-'+grouping;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],flush=True)
finally:p.write_text(base)

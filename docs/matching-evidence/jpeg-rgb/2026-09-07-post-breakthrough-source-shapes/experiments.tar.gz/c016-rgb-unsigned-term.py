from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-unsigned-term');out.mkdir(exist_ok=True)
oldcb='dst_row + (chroma_x & 1U) + (chroma_x & 2) * 4';oldcr='dst_row + (chroma_x & 1) + (chroma_x & 2) * 4';terms={'row':'dst_row','low':'(chroma_x & 1)','high':'(chroma_x & 2) * 4'}
try:
 for unsigned in ['row','high']:
  for order in itertools.permutations(terms):
   ut=dict(terms);ut[unsigned]='(u32) ('+ut[unsigned]+')';s=base.replace(oldcb,' + '.join(ut[n] for n in order)).replace(oldcr,' + '.join(terms[n] for n in order));name=unsigned+'-'+'-'.join(order);(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],flush=True)
finally:p.write_text(base)

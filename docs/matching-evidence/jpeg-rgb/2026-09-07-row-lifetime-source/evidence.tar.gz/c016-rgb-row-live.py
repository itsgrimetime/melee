from pathlib import Path
import json,subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();src=Path('/tmp/c016-rgb-row-frame/corrected-no-row.c').read_text();root=Path('/tmp/c016-rgb-row-live');root.mkdir(exist_ok=True);rows=[]
old='''                dst_row = rgb_row((chroma_y & 1) * 4, (chroma_y & 2) * 16, tile_y * 16 + tile_x * 2);
                src_row = (chroma_y & 1) * 32 + (chroma_y & 2) * stride;'''
try:
 for before in [False,True]:
  for typ in ['s32','int','u32']:
   for direction in ['low4','low32']:
    n=('src-first-' if before else 'dst-first-')+typ+'-'+direction;decl=typ+' low = (chroma_y & 1) * '+('4' if direction=='low4' else '32')+';';dst='dst_row = rgb_row('+('low' if direction=='low4' else 'low / 8')+', (chroma_y & 2) * 16, tile_y * 16 + tile_x * 2);';sr='src_row = '+('low * 8' if direction=='low4' else 'low')+' + (chroma_y & 2) * stride;';new='                '+decl+'\n                '+('\n                '.join([sr,dst] if before else [dst,sr]));s=src.replace(old,new);assert s!=src;p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

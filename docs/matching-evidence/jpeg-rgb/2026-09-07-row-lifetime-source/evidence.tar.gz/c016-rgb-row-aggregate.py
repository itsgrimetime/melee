from pathlib import Path
import re,json,subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-row-aggregate');root.mkdir(exist_ok=True);a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);rows=[]
try:
 for corrected in [False,True]:
  for kind in ['array','struct','pair-dst-first','pair-src-first']:
   n=('corrected-' if corrected else 'baseline-')+kind;part=base[a:b];part=part.replace('                s32 dst_row;', '')
   if kind=='array':decl='                s32 row[1];';dst='row[0]'
   elif kind=='struct':decl='                struct { s32 value; } row;';dst='row.value'
   else:
    part=part.replace('                s32 src_row;','');decl='                struct { '+('s32 dst; s32 src;' if kind=='pair-dst-first' else 's32 src; s32 dst;')+' } row;';dst='row.dst';part=re.sub(r'\bsrc_row\b','row.src',part)
   part=re.sub(r'\bdst_row\b',dst,part);part=part.replace('            for (chroma_y = 0; chroma_y < 4; chroma_y++) {','            for (chroma_y = 0; chroma_y < 4; chroma_y++) {\n'+decl)
   if corrected:part=part.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + '+('row.src' if kind.startswith('pair') else 'src_row')+')','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + '+('row.src' if kind.startswith('pair') else 'src_row'))
   s=base[:a]+part+base[b:];p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

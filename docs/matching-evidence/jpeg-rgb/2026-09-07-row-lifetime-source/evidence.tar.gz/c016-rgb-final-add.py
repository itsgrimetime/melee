from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-final-add');root.mkdir(exist_ok=True);rows=[]
variants={'direct':('s32 tile, s32 row','return tile + row;','tile_y * 16 + tile_x * 2, dst_row'),'result':('s32 tile, s32 row','s32 result = tile + row; return result;','tile_y * 16 + tile_x * 2, dst_row'),'row-first':('s32 row, s32 tile','return tile + row;','dst_row, tile_y * 16 + tile_x * 2'),'tile-update':('s32 tile, s32 row','tile += row; return tile;','tile_y * 16 + tile_x * 2, dst_row'),'row-update':('s32 tile, s32 row','row = tile + row; return row;','tile_y * 16 + tile_x * 2, dst_row')}
try:
 for frame in ['full','no-row']:
  for n,(params,body,args) in variants.items():
   name=frame+'-'+n;s=base.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row');s=s.replace('dst_row = (tile_y * 16 + tile_x * 2) + dst_row;','dst_row = rgb_add('+args+');');s=s.replace('void hsd_803B3408(', 'static inline s32 rgb_add('+params+') { '+body+' }\n\nvoid hsd_803B3408(',1)
   if frame=='no-row':s=s.replace('                        s32 row_offset = (pixel_index & 2) * stride;','').replace('src[column_offset + row_offset]','src[column_offset + (pixel_index & 2) * stride]')
   p.write_text(s);(root/(name+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':name,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

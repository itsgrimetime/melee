from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('/tmp/c016-rgb-donor-add/low-local-False.c').read_text();out=Path('/tmp/c016-rgb-donor-add-followup');out.mkdir(exist_ok=True)
old='dst_row = tile_offset + (chroma_y & 2) * 16 + row_part;'
variants={
 'swap':'dst_row = tile_offset + row_part + (chroma_y & 2) * 16;',
 'right-group':'dst_row = tile_offset + (row_part + (chroma_y & 2) * 16);',
 'reverse-right-group':'dst_row = tile_offset + ((chroma_y & 2) * 16 + row_part);',
 'sum-first':'dst_row = (row_part + (chroma_y & 2) * 16) + tile_offset;',
}
for order in itertools.permutations(['tile_offset','row_part','row_high']):variants['locals-'+'-'.join(x.replace('row_','') for x in order)]='row_high = (chroma_y & 2) * 16;\n                dst_row = '+' + '.join(order)+';'
try:
 for name,expr in variants.items():
  s=seed.replace(old,expr)
  if 'row_high' in expr:s=s.replace('                s32 row_part;','                s32 row_part;\n                s32 row_high;')
  assert s!=seed
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

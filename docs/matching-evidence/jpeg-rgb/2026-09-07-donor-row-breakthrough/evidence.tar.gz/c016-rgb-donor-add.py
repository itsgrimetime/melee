from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-donor-add');out.mkdir(exist_ok=True)
old='dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;\n                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;'
try:
 for part in ['high','low']:
  for tile in ['expression','local']:
   for cast in [False,True]:
    s=base;term='(chroma_y & 2) * 16' if part=='high' else '(chroma_y & 1) * 4';other='(chroma_y & 1) * 4' if part=='high' else '(chroma_y & 2) * 16'
    if cast:other='(s32) ((u32) (chroma_y & '+('1' if part=='high' else '2')+') * '+('4U' if part=='high' else '16U')+')'
    t='tile_offset' if tile=='local' else '(tile_y * 16 + tile_x * 2)'
    if tile=='local':s=s.replace('            s32 chroma_y;','            s32 chroma_y;\n            s32 tile_offset = tile_y * 16 + tile_x * 2;')
    s=s.replace('                s32 src_row;','                s32 src_row;\n                s32 row_part;')
    s=s.replace(old,'row_part = '+term+';\n                dst_row = '+t+' + '+other+' + row_part;')
    s=s.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
    name=part+'-'+tile+'-'+str(cast);(out/(name+'.c')).write_text(s);p.write_text(s)
    r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-direct-index');out.mkdir(exist_ok=True)
index='                    chroma_index = (chroma_x & 2) * 4;\n                    chroma_index = (chroma_x & 1) + chroma_index;\n                    chroma_index += dst_row;'
assign='                    chroma_dest =\n                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);'
terms={'low':'(chroma_x & 1)','high':'(chroma_x & 2) * 4','row':'dst_row'}
try:
 for order in itertools.permutations(terms):
  for mode in ['pointer','expression']:
   expr='('+' + '.join(terms[n] for n in order)+')';s=seed.replace('                    s32 chroma_index;','').replace(index,'')
   if mode=='pointer':s=s.replace('chroma_index * 4',expr+' * 4')
   else:s=s.replace('                    JpegWork* chroma_dest;','').replace(assign,'').replace('chroma_dest->','((JpegWork*) (HSD_804D2648_BUF + '+expr+' * 4))->')
   name='-'.join(order)+'-'+mode;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-dest-offset');out.mkdir(exist_ok=True)
assign='                    chroma_dest =\n                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);'
try:
 for mode in ['scaled','unscaled','reuse-index']:
  for access in ['member','scalar']:
   s=seed.replace('                    JpegWork* chroma_dest;','                    s32 chroma_offset;' if mode!='reuse-index' else '')
   if mode=='scaled':s=s.replace(assign,'                    chroma_offset = chroma_index * 4;');offset='chroma_offset'
   elif mode=='unscaled':s=s.replace(assign,'                    chroma_offset = chroma_index;');offset='chroma_offset * 4'
   else:s=s.replace(assign,'                    chroma_index *= 4;');offset='chroma_index'
   if access=='member':s=s.replace('chroma_dest->','((JpegWork*) (HSD_804D2648_BUF + '+offset+'))->')
   else:
    for field in ['518','618']:s=s.replace('chroma_dest->data.x'+field+'[0]','*(s32*) (HSD_804D2648_BUF + '+offset+' + 0x'+field+')')
   name=mode+'-'+access;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

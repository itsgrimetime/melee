from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text()
try:
 p.write_text(Path('/tmp/c016-rgb-chroma-ownership/dest-expression.c').read_text())
 r=subprocess.run(['melee-agent','debug','retro','dump',str(p),'-f','hsd_803B3408','--phases','frontend','--gdb-py','/tmp/c016-rgb-stages-hook.py','--timeout','180','-O','/tmp/c016-rgb-dest-expr-stages'],capture_output=True,text=True,timeout=210);Path('/tmp/c016-rgb-dest-expr-capture.log').write_text(r.stdout+r.stderr);print(r.returncode,r.stdout[-1000:],r.stderr[-500:])
finally:p.write_text(base)

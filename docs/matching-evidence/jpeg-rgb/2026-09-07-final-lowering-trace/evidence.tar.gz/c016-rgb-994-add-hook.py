"""Selected-function read-only stage/creation/coloring capture; no full compile."""
def intervene(ctx):
    import runpy,json
    from pathlib import Path
    m=runpy.run_path('/Users/mike/code/mwcc-decomp/tools/gdb/allocator_snapshot.py')
    out=Path(ctx.out_dir)/'creation';out.mkdir(parents=True,exist_ok=True)
    ctx.cad.NODE_NAMES[:] = json.loads(Path('/tmp/c016-rgb-node-names.json').read_text())
    original_stop=m['PCodeWrapperBreakpoint'].stop
    def capture_add_expression(bp):
        result=original_stop(bp)
        if bp.session.capture_current and bp.session.pending_creations:
            event=bp.session.pending_creations[-1]
            fields=event.get('codegen_item_fields')
            if event.get('opcode_argument')==60 and fields and fields.get('kind_04')==4:
                ptr=int(fields['pointer_0a'],16)
                with (out/'add-expression-lowering.txt').open('a') as f:
                    f.write(json.dumps(event)+'\n')
                    ctx.cad.print_expression(f,ctx.cad.MwccENode.load(ptr),0)
        return result
    m['PCodeWrapperBreakpoint'].stop=capture_add_expression
    session=m['CaptureSession'](out,target_name=ctx.fn,target='ninji')
    keep=[session.codegen_breakpoint,session.pcode_builder_return_breakpoint,
          *session.pcode_wrapper_breakpoints,session.initial_pcode_breakpoint,
          session.optimized_pcode_breakpoint,session.post_scheduler_pcode_breakpoint,
          session.forward_peephole_pcode_breakpoint,*session.post_allocation_pcode_breakpoints,
          session.allocate_breakpoint,session.coloring_breakpoint]
    for bp in ctx.gdb.breakpoints():bp.enabled=bp in keep
    original=session.begin_function
    def begin(ptr):
        original(ptr)
        obj=ctx.cad.MwccObject.load(ptr,load_linkname=False)
        session.function_identity['name']=obj.name
        session.function_identity['name_decoder']='cadmic exact-1.2.5n descriptor'
        session.capture_current=obj.name==ctx.fn
        with (out/'functions.jsonl').open('a') as f:f.write(json.dumps(session.function_identity)+'\n')
    session.begin_function=begin
    class Final(ctx.gdb.Breakpoint):
        def stop(self):
            if not session.capture_current:return False
            (out/'capture-complete.json').write_text(json.dumps({'function':session.function_identity,'scope':'selected function through final scheduling; no full compiler run','target_sha256':session.target_sha256},indent=2)+'\n')
            return True
    Final('*'+hex(m['FINAL_PCODE_ADDRESS']),internal=True)
    ctx.cont()

def intervene(ctx):
    from pathlib import Path
    import json
    for bp in ctx.gdb.breakpoints():bp.enabled=False
    def rd(a):return ctx.cad.read_u32(a)
    class Entry(ctx.gdb.Breakpoint):
        def stop(self):
            objptr=rd(0x588238)
            if not objptr:return False
            obj=ctx.cad.MwccObject.load(objptr,load_linkname=False)
            if obj.name!=ctx.fn:return False
            sp=int(ctx.gdb.parse_and_eval('$esp'));ptr=rd(sp+4)
            data=bytes(ctx.gdb.selected_inferior().read_memory(ptr,26));words=[int.from_bytes(data[i:i+2],'little') for i in range(0,26,2)]
            if data[0]!=2:return False
            result={'function':obj.name,'descriptor':hex(ptr),'raw':data.hex(),'shorts':words,'caller_return':hex(rd(sp)),'requested_result':rd(sp+12)}
            with (Path(ctx.out_dir)/'descriptors.jsonl').open('a') as f:f.write(json.dumps(result)+'\n')
            if 38 in words and 100 in words:
                (Path(ctx.out_dir)/'target-descriptor.json').write_text(json.dumps(result,indent=2)+'\n')
                return True
            return False
    Entry('*0x4a0ba0',internal=True);ctx.cont()

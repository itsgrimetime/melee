
void __cdecl FUN_004a0fc0(char *param_1)

{
  int iVar1;
  bool bVar2;
  short sVar3;
  undefined4 uVar4;
  undefined4 uVar5;
  undefined2 uVar6;
  undefined4 unaff_EDI;
  
  sVar3 = DAT_0058846e;
  bVar2 = false;
  iVar1 = *(int *)(param_1 + 0x12);
  switch(*param_1) {
  case '\0':
  case '\x01':
  case '\x02':
  case '\x03':
  case '\x04':
  case '\x06':
  case '\a':
  case '\t':
  case '\n':
    goto switchD_004a0fe4_caseD_0;
  default:
    goto LAB_004a111c;
  case '\b':
    goto switchD_004a0fe4_caseD_8;
  case '\v':
    break;
  }
  bVar2 = true;
switchD_004a0fe4_caseD_8:
  if (*(char *)(iVar1 + 2) == '\x01') {
    *param_1 = '\x01';
    *(undefined2 *)(param_1 + 2) = DAT_0058842a;
    *(int *)(param_1 + 0x12) = iVar1;
  }
  else if (*(char *)(iVar1 + 2) == '\x02') {
    if (*(int *)(iVar1 + 0x26) == (int)(short)*(int *)(iVar1 + 0x26)) {
      param_1[2] = '\0';
      param_1[3] = '\0';
    }
    else {
      DAT_0058846e = DAT_0058846e + 1;
      *(short *)(param_1 + 2) = sVar3;
      FUN_004a25d0(0x8a);
    }
    *(undefined2 *)(param_1 + 8) = *(undefined2 *)(iVar1 + 0x26);
    *(int *)(param_1 + 0x12) = iVar1;
    *param_1 = '\x01';
  }
  else {
    uVar4 = FUN_00489c20(iVar1);
    uVar5 = FUN_0048ad10(iVar1);
    sVar3 = DAT_0058846e;
    uVar6 = (undefined2)((uint)uVar4 >> 0x10);
    if ((char)uVar5 == '\0') {
      uVar5 = CONCAT22((short)((uint)unaff_EDI >> 0x10),DAT_0058846e);
      DAT_0058846e = DAT_0058846e + 1;
      uVar4 = CONCAT22(uVar6,DAT_0058846e);
      DAT_0058846e = sVar3 + 2;
      FUN_004a1f60(uVar5,0,iVar1,0,'\x01');
      FUN_004a2000(uVar4,uVar5,iVar1,0,'\x01');
LAB_004a10eb:
      param_1[0x12] = '\0';
      param_1[0x13] = '\0';
      param_1[0x14] = '\0';
      param_1[0x15] = '\0';
    }
    else if ((short)uVar4 == 0) {
      uVar4 = CONCAT22(uVar6,DAT_0058846e);
      DAT_0058846e = DAT_0058846e + 1;
      FUN_004a2060(uVar4,0,iVar1,0);
      goto LAB_004a10eb;
    }
    *param_1 = '\x01';
    *(short *)(param_1 + 2) = (short)uVar4;
  }
  if (bVar2) {
    if (*param_1 == '\x01') {
      *param_1 = '\t';
    }
    else {
LAB_004a111c:
      FUN_00445780();
    }
  }
switchD_004a0fe4_caseD_0:
  return;
}


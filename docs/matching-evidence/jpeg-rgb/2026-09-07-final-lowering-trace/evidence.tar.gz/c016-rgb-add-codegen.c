
void __cdecl FUN_004a0ba0(char *param_1,char *param_2,uint param_3)

{
  bool bVar1;
  bool bVar2;
  char cVar3;
  short sVar4;
  uint local_14;
  
  cVar3 = *param_2;
  if ((((cVar3 != '\x01') && (cVar3 != '\x03')) || (*(int *)(param_2 + 2) != 8)) &&
     (((DAT_00584244 == '\0' || (cVar3 != '\x02')) || (*(int *)(param_2 + 2) == 4)))) {
    FUN_004a0fc0(param_1);
    sVar4 = (short)param_3;
    switch(*param_1) {
    case '\0':
      return;
    case '\x01':
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      FUN_004a2060(param_3,*(short *)(param_1 + 2),*(int *)(param_1 + 0x12),*(short *)(param_1 + 8))
      ;
      local_14 = param_3;
      break;
    case '\x02':
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      FUN_004a25d0(0x3c);
      local_14 = param_3;
      break;
    case '\x03':
      return;
    case '\x04':
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      sVar4 = (short)*(int *)(param_1 + 0xe);
      local_14 = param_3;
      if (*(int *)(param_1 + 0xe) == (int)sVar4) {
        FUN_004a25d0(0x89);
      }
      else {
        if (('\x01' < DAT_005842e1) && (sVar4 != 0)) {
          DAT_0058846e = DAT_0058846e + 1;
        }
        FUN_004a25d0(0x8a);
        if (sVar4 != 0) {
          FUN_004a25d0(0x3f);
        }
      }
      break;
    default:
      FUN_00445780();
      break;
    case '\a':
      bVar2 = false;
      bVar1 = false;
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      FUN_004a25d0(0x82);
      switch(*(undefined2 *)(param_1 + 6)) {
      case 0x15:
        bVar2 = true;
      case 0x14:
        bVar1 = bVar2;
        break;
      case 0x16:
        bVar2 = true;
      case 0x13:
        bVar1 = bVar2;
        break;
      case 0x18:
        bVar2 = true;
      case 0x17:
        bVar1 = bVar2;
        break;
      default:
        FUN_00445780();
      }
      FUN_004a25d0(0x67);
      local_14 = param_3;
      if (bVar1) {
        FUN_004a25d0(0x5a);
      }
      break;
    case '\t':
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      cVar3 = *param_2;
      sVar4 = 0x22;
      if ((cVar3 == '\x01') || (cVar3 == '\x03')) {
        if (*(int *)(param_2 + 2) == 1) {
          sVar4 = 0x15;
        }
        else if (*(int *)(param_2 + 2) == 2) {
          cVar3 = FUN_0048f180(param_2);
          if (cVar3 == '\0') {
            sVar4 = 0x1d;
          }
          else {
            sVar4 = 0x19;
          }
        }
      }
      else if (((cVar3 != '\v') && ((cVar3 != '\n' || (*(int *)(param_2 + 2) != 4)))) &&
              ((DAT_00584244 == '\0' || ((cVar3 != '\x02' || (*(int *)(param_2 + 2) != 4)))))) {
        FUN_00445780();
      }
      FUN_004a1dd0(sVar4,(short)param_3,
                   CONCAT22(*(short *)(param_1 + 8) >> 0xf,*(undefined2 *)(param_1 + 2)),
                   *(int *)(param_1 + 0x12),(int)*(short *)(param_1 + 8));
      FUN_0049cf70(*(uint *)(param_1 + 10));
      local_14 = param_3;
      break;
    case '\n':
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      cVar3 = *param_2;
      sVar4 = 0x24;
      if ((cVar3 == '\x01') || (cVar3 == '\x03')) {
        if (*(int *)(param_2 + 2) == 1) {
          sVar4 = 0x17;
        }
        else if (*(int *)(param_2 + 2) == 2) {
          cVar3 = FUN_0048f180(param_2);
          if (cVar3 == '\0') {
            sVar4 = 0x1f;
          }
          else {
            sVar4 = 0x1b;
          }
        }
      }
      else if (((cVar3 != '\v') && ((cVar3 != '\n' || (*(int *)(param_2 + 2) != 4)))) &&
              ((DAT_00584244 == '\0' || ((cVar3 != '\x02' || (*(int *)(param_2 + 2) != 4)))))) {
        FUN_00445780();
      }
      FUN_004a25d0(sVar4);
      FUN_0049cf70(*(uint *)(param_1 + 10));
      local_14 = param_3;
    }
    *param_1 = '\0';
    *(short *)(param_1 + 2) = (short)local_14;
    return;
  }
  FUN_004a0680(param_1,param_2,param_3,0);
  return;
}


from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();src=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-direct-row-call/structural-candidate.c.txt').read_text();root=Path('/tmp/c016-rgb-row-output');root.mkdir(exist_ok=True);rows=[]
old='static inline s32 jpeg_row_sum(s32 y) { s32 sum = (y & 1) * 4 + (y & 2) * 16; return sum; }'
try:
 for local in [False,True]:
  for order in ['first','last']:
   n=('local' if local else 'direct')+'-'+order
   params='s32* out, s32 y' if order=='first' else 's32 y, s32* out';args='&dst_row, chroma_y' if order=='first' else 'chroma_y, &dst_row'
   body='s32 sum = (y & 1) * 4 + (y & 2) * 16; *out = sum;' if local else '*out = (y & 1) * 4 + (y & 2) * 16;'
   s=src.replace(old,'static inline void jpeg_row_sum('+params+') { '+body+' }').replace('dst_row = tile_offset + jpeg_row_sum(chroma_y);','jpeg_row_sum('+args+');\n                dst_row = tile_offset + dst_row;')
   assert s!=src;p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

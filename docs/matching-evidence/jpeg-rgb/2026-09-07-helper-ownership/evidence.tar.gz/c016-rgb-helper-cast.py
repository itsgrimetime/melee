from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();src=Path('/tmp/c016-rgb-tile-param-call/local-update-no-row.c').read_text();root=Path('/tmp/c016-rgb-helper-cast');root.mkdir(exist_ok=True);rows=[]
try:
 for typ in ['u32','int','unsigned int']:
  for reverse in [False,True]:
   n=typ.replace(' ','-')+('-reverse' if reverse else '');s=src.replace('sum = tile + sum;','sum = tile + ('+typ+') sum;')
   if reverse:s=s.replace('jpeg_row_sum(s32 tile, s32 y)','jpeg_row_sum(s32 y, s32 tile)').replace('jpeg_row_sum(tile_offset, chroma_y)','jpeg_row_sum(chroma_y, tile_offset)')
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();src=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-direct-row-call/structural-candidate.c.txt').read_text();root=Path('/tmp/c016-rgb-result-owner');root.mkdir(exist_ok=True);rows=[]
try:
 for mode in ['cast-u32','cast-int','cast-uint','plain','identity','pointer']:
  n=mode;s=src;expr={'cast-u32':'(u32) dst_row','cast-int':'(int) dst_row','cast-uint':'(unsigned int) dst_row','plain':'dst_row','identity':'jpeg_row_value(dst_row)','pointer':'jpeg_row_value(&dst_row)'}[mode]
  if mode in ['identity','pointer']:
   h='static inline s32 jpeg_row_value('+('s32* row' if mode=='pointer' else 's32 row')+') { return '+('*row' if mode=='pointer' else 'row')+'; }\n'
   s=s.replace('void hsd_803B3408(',h+'void hsd_803B3408(',1)
  s=s.replace('dst_row = tile_offset + jpeg_row_sum(chroma_y);','dst_row = jpeg_row_sum(chroma_y);\n                dst_row = tile_offset + '+expr+';')
  p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

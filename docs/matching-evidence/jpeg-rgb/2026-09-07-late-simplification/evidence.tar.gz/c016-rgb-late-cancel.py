from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-late-cancel');out.mkdir(exist_ok=True)
exprs={
 'y-add-sub':'(dst_row + chroma_y - chroma_y)',
 'tile-add-sub':'(dst_row + (tile_y * 16 + tile_x * 2) - (tile_y * 16 + tile_x * 2))',
 'tile-xor-xor':'(dst_row ^ (tile_y * 16 + tile_x * 2) ^ (tile_y * 16 + tile_x * 2))',
 'tile-sub-add':'(dst_row - (tile_y * 16 + tile_x * 2) + (tile_y * 16 + tile_x * 2))',
 'sum-expand':'((dst_row + (chroma_y & 1) * 4) - (chroma_y & 1) * 4)',
 'nested-cancel':'(dst_row + ((chroma_y & 1) * 4 + (chroma_y & 2) * 16) - ((chroma_y & 1) * 4 + (chroma_y & 2) * 16))'
}
try:
 for name,expr in exprs.items():
  s=base.replace('(tile_y * 16 + tile_x * 2) + dst_row','(tile_y * 16 + tile_x * 2) + '+expr)
  s=s.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification']['stack_frame_sizes'],flush=True)
finally:p.write_text(base)

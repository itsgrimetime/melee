from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text()
out=Path('/tmp/c016-rgb-row-condition');out.mkdir(exist_ok=True)
try:
 for family,s in [('baseline',base),('structural',Path('docs/matching-evidence/jpeg-rgb/2026-09-07-direct-row-call/structural-candidate.c.txt').read_text())]:
  for which in ['dst','src','both']:
   start=s.index('            for (chroma_y = 0;');end=s.index('                for (chroma_x',start)
   block=s[start:end]; decls='';expr=[];remain=[]
   for line in block.splitlines()[1:]:
    st=line.strip()
    if st in ['s32 dst_row;','s32 src_row;']:decls+='            '+st+'\n'
    elif '=' in st:
     if (st.startswith('dst_row') and which in ['dst','both']) or (st.startswith('src_row') and which in ['src','both']):expr.append(st.rstrip(';'))
     else:remain.append(line)
   t=s[:start]+decls+'            for (chroma_y = 0; '+', '.join(expr)+', chroma_y < 4; chroma_y++) {\n'+'\n'.join(remain)+'\n\n'+s[end:]
   name=family+'-'+which;(out/(name+'.c')).write_text(t);p.write_text(t)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
   (out/(name+'.json')).write_text(r.stdout)
   try:
    x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification']['stack_frame_sizes'],flush=True)
   except Exception: print(name,r.stderr[-500:],r.stdout[:500],flush=True)
finally:p.write_text(base)

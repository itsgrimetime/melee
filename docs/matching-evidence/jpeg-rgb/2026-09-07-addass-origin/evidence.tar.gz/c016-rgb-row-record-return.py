from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-row-record-return');root.mkdir(exist_ok=True);rows=[]
old='''                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;
                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;'''
try:
 for mode in ['sum-return','sum-out','sum-return-update','sum-out-update']:
  helper='typedef struct { s32 value; } RgbRow;\n'
  if 'return' in mode:helper+='static inline RgbRow rgb_sum(s32 low, s32 high) { RgbRow result; result.value = low + high; return result; }\n';stmt='row = rgb_sum((chroma_y & 1) * 4, (chroma_y & 2) * 16);'
  else:helper+='static inline void rgb_sum(RgbRow* result, s32 low, s32 high) { result->value = low + high; }\n';stmt='rgb_sum(&row, (chroma_y & 1) * 4, (chroma_y & 2) * 16);'
  if mode.endswith('update'):stmt+=' row.value = (tile_y * 16 + tile_x * 2) + row.value; dst_row = row.value;'
  else:stmt+=' dst_row = (tile_y * 16 + tile_x * 2) + row.value;'
  s=base.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row');s=s.replace(old,'                RgbRow row; '+stmt);s=s.replace('void hsd_803B3408(',helper+'\nvoid hsd_803B3408(',1);p.write_text(s);(root/(mode+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(mode+'.json')).write_text(r.stdout);(root/(mode+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':mode,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

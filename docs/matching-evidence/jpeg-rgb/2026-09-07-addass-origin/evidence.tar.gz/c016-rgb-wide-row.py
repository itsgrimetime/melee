from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-wide-row');root.mkdir(exist_ok=True);rows=[]
old='''                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;
                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;'''
try:
 for corrected in [False,True]:
  for typ in ['s64','u64']:
   for shape in ['cast-sum','cast-tile','wide-local','wide-sum-local']:
    n=('corrected-' if corrected else 'baseline-')+typ+'-'+shape;s=base
    if corrected:s=s.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
    if shape=='cast-sum':new='                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;\n                dst_row = (s32) ((tile_y * 16 + tile_x * 2) + ('+typ+') dst_row);'
    elif shape=='cast-tile':new='                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;\n                dst_row = (s32) (('+typ+') (tile_y * 16 + tile_x * 2) + dst_row);'
    elif shape=='wide-local':new='                '+typ+' row_sum = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;\n                dst_row = (s32) ((tile_y * 16 + tile_x * 2) + row_sum);'
    else:new='                '+typ+' row_sum = ('+typ+') ((chroma_y & 1) * 4) + (chroma_y & 2) * 16;\n                dst_row = (s32) ((tile_y * 16 + tile_x * 2) + row_sum);'
    s=s.replace(old,new);assert s!=base;p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr)
    try:x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')}
    except Exception:row={'name':n,'score':None,'exit':r.returncode}
    rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

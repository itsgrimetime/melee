from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-channel-inline');out.mkdir(exist_ok=True)
channels={'r':'((pixel >> 8U) & 0xF8)','g':'((pixel >> 3U) & 0xFC)','b':'((pixel * 8) & 0xF8)'}
try:
 for argtype in ['u16','s32']:
  for rettype in ['s32','f32']:
   for scope in ['chroma','all']:
    start=seed.index('void hsd_803B3408(');end=seed.index('            luma_y = 0;',start) if scope=='chroma' else seed.index('static void fn_803B376C',start);body=seed[start:end];helpers=[]
    for ch,expr in channels.items():
     helpers.append('static inline '+rettype+' jpeg_'+ch+'('+argtype+' pixel) { return '+('(f32) ' if rettype=='f32' else '')+expr+'; }')
     body=body.replace('(f32) '+expr,('(f32) ' if rettype=='s32' else '')+'jpeg_'+ch+'(pixel)')
    s=seed[:start]+'\n'.join(helpers)+'\n\n'+body+seed[end:];name=argtype+'-'+rettype+'-'+scope;(out/(name+'.c')).write_text(s);p.write_text(s)
    r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-final-pointer-return');root.mkdir(exist_ok=True);rows=[]
try:
 for mode in ['direct','local']:
  for frame in ['full','no-row']:
   n=mode+'-'+frame;body='return tile + *row;' if mode=='direct' else 's32 result = tile + *row; return result;'
   s=base.replace('void hsd_803B3408(','static inline s32 jpeg_row_add(s32 tile, const s32* row) { '+body+' }\n\nvoid hsd_803B3408(',1).replace('dst_row = (tile_y * 16 + tile_x * 2) + dst_row;','dst_row = jpeg_row_add(tile_y * 16 + tile_x * 2, &dst_row);')
   s=s.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
   if frame=='no-row':s=s.replace('                        s32 row_offset = (pixel_index & 2) * stride;','').replace('src[column_offset + row_offset]','src[column_offset + (pixel_index & 2) * stride]')
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-row-pointer-update');root.mkdir(exist_ok=True);rows=[]
old='''                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;
                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;'''
try:
 for typ in ['s32','u8']:
  for boundary in ['direct','sum-local']:
   n=typ+'-'+boundary;s=base.replace('                s32 dst_row;','                '+typ+'* dst_row;');row='((chroma_y & 1) * 4 + (chroma_y & 2) * 16)';tile='(tile_y * 16 + tile_x * 2)'
   if boundary=='sum-local':s=s.replace('                s32 src_row;','                s32 src_row;\n                s32 row_offset;');prefix='                row_offset = '+row+';\n';row='row_offset'
   else:prefix=''
   if typ=='u8':row+=' * 4';tile+=' * 4'
   s=s.replace(old,prefix+'                dst_row = ('+typ+'*) HSD_804D2648_BUF + '+row+';\n                dst_row = '+tile+' + dst_row;')
   s=s.replace('                    chroma_index += dst_row;\n','').replace('(JpegWork*) (HSD_804D2648_BUF + chroma_index * 4)','(JpegWork*) (dst_row + chroma_index'+(' * 4' if typ=='u8' else '')+')')
   s=s.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

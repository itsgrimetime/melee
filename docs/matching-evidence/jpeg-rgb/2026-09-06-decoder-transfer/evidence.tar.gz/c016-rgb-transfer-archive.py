from pathlib import Path
import json,hashlib,subprocess,tarfile
root=Path('docs/matching-evidence/jpeg-rgb/2026-09-06-decoder-transfer');root.mkdir(parents=True,exist_ok=True)
src=Path('src/sysdolphin/baselib/hsd_3B34.c');assert src.read_bytes()==subprocess.check_output(['git','show','HEAD:'+str(src)])
def body(p):
 s=p.read_text();a=s.index('void hsd_803B3408(');b=s.index('static void fn_803B376C',a);return ''.join(s[a:b].replace('(((chroma_x & 1) * 2) + ((chroma_x & 2) * 4)) + src_row', '((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row').split())
assert body(Path('/tmp/c016-rgb-corrected-source.c'))==body(Path('/tmp/c016-rgb-combine-rule/LHR-left.c'))
final=json.loads(Path('/tmp/c016-rgb-transfer-final.json').read_text());assert final['fuzzy_match_percent']==98.7788
u=next(u for u in json.loads(Path('build/GALE01/report.json').read_text())['units'] if u['name'].endswith('sysdolphin/baselib/hsd_3B34'))
fs=[{'name':f['name'],'percent':f['fuzzy_match_percent']} for f in u['functions']];assert len(fs)==8
assert all(f['percent']=={'hsd_803B3408':98.7788,'hsd_803B3CD8':99.70266}.get(f['name'],100) for f in fs)
sha={str(p):hashlib.sha1(p.read_bytes()).hexdigest() for p in [Path('build/GALE01/main.dol'),Path('orig/GALE01/sys/main.dol')]};assert set(sha.values())=={'08e0bf20134dfcb260699671004527b2d6bb1a45'}
files=[];rows=[]
for family in ['transfer','row-transfer','destination-lifetime']:
 p=Path('/tmp/c016-rgb-'+family);files.extend((f,str(f.relative_to('/tmp'))) for f in p.rglob('*') if f.is_file());files.append((Path(str(p)+'.py'),p.name+'.py'))
 rows.extend({'family':family,**r} for r in json.loads((p/'results.json').read_text()))
assert len(rows)==20
for suffix in ['transfer-doctor.log','transfer-final.json','transfer-final.log','transfer-build.log','transfer-attempt.log','transfer-issue-note.log','transfer-archive.py','corrected-dump.py','corrected-dump.log','corrected-source.c','retail-replay.py','retail-replay.json','retail-replay.log']:
 p=Path('/tmp/c016-rgb-'+suffix);files.append((p,p.name))
for name in ['coloring-0001-gpr-01-before.json','coloring-0001-gpr-01-after.json','validation.json','destination-explanation.json']:
 p=Path('/tmp/c016-rgb-corrected-stages/creation')/name;files.append((p,'retail-reference/'+name))
files.append((Path('/tmp/c016-rgb-combine-rule/LHR-left.c'),'retail-reference/captured-candidate-source.c'))
files.append((Path('/tmp/c016-rgb-combine-rule/LHR-left.json'),'retail-reference/captured-candidate-checkdiff.json'))
p=Path('tools/melee-agent/src/mwcc_debug/tiebreak.py');files.append((p,'model-reference/tiebreak.py'));files.append((src,'retained-hsd_3B34.c'))
m={'function':'hsd_803B3408','scratch':None,'retained_source_change':False,'ordinary_match_percent':98.7788,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'candidate_function_matches_prior_capture_source_after_explicit_redundant_parentheses_and_whitespace_normalization':True,'unit_functions':fs,'dol_sha1':sha,'runs':rows,'caveat':'Retail SELECT replay105/105. Pointer-color what-ifs have collateral assignments, no full target or source100 proof.','members':[]}
assert len(set(n for _,n in files))==len(files)
with tarfile.open(root/'evidence.tar.gz','w:gz') as t:
 for p,n in sorted(files,key=lambda x:x[1]):
  d=p.read_bytes();m['members'].append({'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()});t.add(p,arcname=n)
with tarfile.open(root/'evidence.tar.gz') as t:
 for f in m['members']:assert hashlib.sha256(t.extractfile(f['path']).read()).hexdigest()==f['sha256']
m['archive_sha256']=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest();(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified',len(files),'members,',len(rows),'runs,',(root/'evidence.tar.gz').stat().st_size,'bytes')

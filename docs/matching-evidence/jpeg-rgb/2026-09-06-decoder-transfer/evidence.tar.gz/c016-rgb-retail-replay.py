from pathlib import Path
import sys,json
sys.path.insert(0,str(Path('tools/melee-agent').resolve()))
from src.mwcc_debug.tiebreak import IG,IGNode,validate_g1,predict_assignments
root=Path('/tmp/c016-rgb-corrected-stages/creation')
before=json.loads((root/'coloring-0001-gpr-01-before.json').read_text());after=json.loads((root/'coloring-0001-gpr-01-after.json').read_text())
assert before['format']==after['format']=='mwcc-coloring-snapshot-v1'
ns={n['virtual_register']:n for n in after['nodes']};bn={n['virtual_register']:n for n in before['nodes']};order=before['simplify_order'];decision=set(order)
nodes={n:IGNode(n,set(bn[n]['neighbors']),{v:(v if v<32 else ns[before['coalesced_registers'][v]]['physical_register']) for v in bn[n]['neighbors'] if v not in decision and (v<32 or ns[v]['physical_register']>=0)},len(bn[n]['neighbors']),False,ns[n]['physical_register']) for n in order}
results=[]
for reverse in [False,True]:
 ig=IG(0,list(reversed(order)) if reverse else list(order),nodes,decision);g=validate_g1(ig)
 results.append({'reverse':reverse,'correct':g.correct,'total':g.total,'abstained':g.spill_abstained,'mismatches':g.mismatches});print(results[-1])
 if g.correct==g.total and not g.spill_abstained:
  rows=[]
  for marker in ig.select_order:
   if marker==37:continue
   oo=list(ig.select_order);oo.remove(37);oo.insert(oo.index(marker)+1,37);pred=predict_assignments(ig,order=oo)
   if pred[37]==22:rows.append({'move':[37,'after',marker],'changed':{n:[nodes[n].observed_reg,v] for n,v in pred.items() if v!=nodes[n].observed_reg},'order':oo})
  results[-1]['destination_r22_orders']=rows;print('r22 orders',len(rows),[(r['move'],r['changed']) for r in rows])
Path('/tmp/c016-rgb-retail-replay.json').write_text(json.dumps(results,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-destination-lifetime');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
start=base.index('void hsd_803B3408(');end=base.index('static void fn_803B376C',start);part=base[start:end]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
init='                    chroma_dest =\n                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);\n';assert part.count(init)==1
lhs='                    chroma_dest->data.x518[0] =';idx=part.index(lhs);stop=part.index(';',idx)+1;assignment=part[idx:stop];rhs=assignment.split('=',1)[1]
rows=[]
try:
 for shape in ['baseline','corrected-pixel']:
  s=part if shape=='baseline' else part.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
  vs={
   'embedded-pointer':s.replace(init,'').replace(lhs,'                    (chroma_dest = (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4))->data.x518[0] ='),
   'result-before-pointer':s.replace('                    JpegWork* chroma_dest;','                    JpegWork* chroma_dest;\n                    s32 cb_value;').replace(init,'').replace(assignment,'                    cb_value ='+rhs+'\n'+init+'                    chroma_dest->data.x518[0] = cb_value;'),
   'result-before-index':s.replace('                    JpegWork* chroma_dest;','                    JpegWork* chroma_dest;\n                    s32 cb_value;').replace(assignment,'                    chroma_dest->data.x518[0] = cb_value;').replace('                    chroma_index = (chroma_x & 2) * 4;','                    cb_value ='+rhs+'\n                    chroma_index = (chroma_x & 2) * 4;')
  }
  for name,v in vs.items():
   label=shape+'-'+name;full=base[:start]+v+base[end:];p.write_text(full);(out/(label+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

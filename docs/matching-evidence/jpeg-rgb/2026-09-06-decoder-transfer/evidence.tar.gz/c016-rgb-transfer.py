from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-transfer');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]';assert base.count(expr)==2
L='((chroma_x & 1) * 2)';H='((chroma_x & 2) * 4)';R='src_row'
vs={
 'outer-negative-high':f'({R} + {L}) - (-{H})',
 'outer-negative-row':f'({L} + {H}) - (-{R})',
 'outer-negative-low':f'({H} + {R}) - (-{L})',
 'row-sub-negative-pair':f'{R} - (-({L} + {H}))',
 'low-sub-negative-pair':f'{L} - (-({H} + {R}))',
 'high-sub-negative-pair':f'{H} - (-({L} + {R}))',
}
rows=[]
try:
 for name,v in vs.items():
  s=base.replace(expr,'src['+v+']');p.write_text(s);(out/(name+'.c')).write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120)
  (out/(name+'.json')).write_text(r.stdout);(out/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

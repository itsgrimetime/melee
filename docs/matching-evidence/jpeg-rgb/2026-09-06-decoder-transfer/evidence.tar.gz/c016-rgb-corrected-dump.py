from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]';assert base.count(expr)==2
candidate=base.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]');Path('/tmp/c016-rgb-corrected-source.c').write_text(candidate)
try:
 p.write_text(candidate)
 r=subprocess.run(['melee-agent','debug','dump','local',str(p),'--output','/tmp/c016-rgb-corrected-pcdump.txt','--no-cache-sync'],capture_output=True,text=True,timeout=120)
 Path('/tmp/c016-rgb-corrected-dump.log').write_text(r.stdout+r.stderr);print('dump',r.returncode,r.stdout[-1000:],r.stderr[-500:])
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-row-transfer');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
old='dst_row = (tile_y * 16 + tile_x * 2) + dst_row;';assert base.count(old)==1
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
vs={'base-minus-negative-row':'dst_row = (tile_y * 16 + tile_x * 2) - (-dst_row);','row-minus-negative-base':'dst_row = dst_row - (-(tile_y * 16 + tile_x * 2));','compound-minus-negative-base':'dst_row -= -(tile_y * 16 + tile_x * 2);','negate-base-minus-row':'dst_row = -(-(tile_y * 16 + tile_x * 2) - dst_row);'}
rows=[]
try:
 for name,v in vs.items():
  for shape in ['baseline','corrected-pixel']:
   s=base.replace(old,v)
   if shape=='corrected-pixel':s=s.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
   label=name+'-'+shape;p.write_text(s);(out/(label+'.c')).write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120)
   (out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

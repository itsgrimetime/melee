from pathlib import Path
import pyghidra
pyghidra.start()
from ghidra.app.decompiler import DecompInterface
from ghidra.util.task import ConsoleTaskMonitor
proj=pyghidra.open_project(str(Path('tools/mwcc_debug/ghidra_project').resolve()),'mwcceppc',create=False)
try:
 with pyghidra.program_context(proj,'/mwcceppc.exe') as p:
  funcs={}
  for addr in ['005550d8','005723a8']:
   for ref in p.getReferenceManager().getReferencesTo(p.getAddressFactory().getAddress(addr)):
    f=p.getFunctionManager().getFunctionContaining(ref.getFromAddress())
    if f:funcs[str(f.getEntryPoint())]=f
  out=Path('/tmp/c016-rgb-expr-audit');out.mkdir(exist_ok=True)
  d=DecompInterface();d.openProgram(p)
  for addr,f in funcs.items():
   r=d.decompileFunction(f,15,ConsoleTaskMonitor())
   if r.decompileCompleted():(out/(addr+'.c')).write_text(r.getDecompiledFunction().getC())
  d.dispose();print('functions',len(funcs))

finally:proj.close()

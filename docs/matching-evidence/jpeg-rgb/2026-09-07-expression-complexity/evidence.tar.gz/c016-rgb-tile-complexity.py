from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-tile-complexity');root.mkdir(exist_ok=True);rows=[]
try:
 for scope in ['row','tile']:
  for separate in [False,True]:
   n=scope+('-separate' if separate else '-update')
   s=base.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
   if scope=='row':s=s.replace('                s32 src_row;','                s32 src_row;\n                s32 tile_offset = tile_y * 16 + tile_x * 2;')
   else:s=s.replace('            s32 chroma_y;','            s32 chroma_y;\n            s32 tile_offset = tile_y * 16 + tile_x * 2;')
   s=s.replace('dst_row = (tile_y * 16 + tile_x * 2) + dst_row;','dst_row = tile_offset + dst_row;')
   if separate:s=s.replace('                s32 dst_row;','                s32 dst_row;\n                s32 row_sum;').replace('dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;','row_sum = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;').replace('dst_row = tile_offset + dst_row;','dst_row = tile_offset + row_sum;')
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],text=True,capture_output=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)


char * __cdecl FUN_004fa620(char *param_1,char *param_2)

{
  char cVar1;
  undefined1 uVar2;
  char *pcVar3;
  undefined3 extraout_var;
  undefined3 extraout_var_00;
  undefined4 uVar4;
  ulonglong uVar5;
  double dVar6;
  
  if ('\n' < **(char **)(param_1 + 6)) {
    pcVar3 = FUN_004fa990(param_1,param_2);
    return pcVar3;
  }
  if ('\n' < **(char **)(param_2 + 6)) {
    pcVar3 = FUN_004fa990(param_2,param_1);
    return pcVar3;
  }
  FUN_00473440((int *)&param_1,(int *)&param_2);
  uVar2 = FUN_00473cb0(param_2);
  if ((short)CONCAT31(extraout_var,uVar2) != 0) {
    return param_1;
  }
  uVar2 = FUN_00473cb0(param_1);
  if ((short)CONCAT31(extraout_var_00,uVar2) != 0) {
    return param_2;
  }
  cVar1 = *param_1;
  if ((cVar1 == '2') && (*param_2 == '2')) {
    uVar5 = FUN_004a9020(*(char **)(param_1 + 6),*(ulonglong *)(param_1 + 10),0x2b,
                         *(uint *)(param_2 + 10),*(uint *)(param_2 + 0xe));
    *(ulonglong *)(param_1 + 10) = uVar5;
    return param_1;
  }
  if ((cVar1 == '3') && (*param_2 == '3')) {
    dVar6 = FUN_004a8990(*(int *)(param_1 + 6),*(double *)(param_1 + 10),0x2b,
                         *(double *)(param_2 + 10));
    *(double *)(param_1 + 10) = dVar6;
    return param_1;
  }
  if (cVar1 == '2') {
    uVar4 = FUN_004fab90(param_2,*(uint *)(param_1 + 10),*(uint *)(param_1 + 0xe));
    if ((short)uVar4 != 0) {
      return param_2;
    }
  }
  if (*param_2 == '2') {
    uVar4 = FUN_004fab90(param_1,*(uint *)(param_2 + 10),*(uint *)(param_2 + 0xe));
    if ((short)uVar4 != 0) {
      return param_1;
    }
  }
  param_1 = (char *)FUN_00473e30((int)param_1,(int)param_2,0xf);
  FUN_004fb470((int)param_1);
  if (**(char **)(param_1 + 6) == '\x02') {
    param_1 = (char *)FUN_00473ff0(param_1);
  }
  return param_1;
}


def intervene(ctx):
    from pathlib import Path
    import json
    ctx.cad.NODE_NAMES[:]=json.loads(Path('/tmp/c016-rgb-node-names.json').read_text())
    for bp in ctx.gdb.breakpoints():bp.enabled=False
    def rd(a):return ctx.cad.read_u32(a)
    def snap(ptr,label):
        data=bytes(ctx.gdb.selected_inferior().read_memory(ptr,26));left=rd(ptr+10);right=rd(ptr+14)
        meta={'node':hex(ptr),'left':hex(left),'right':hex(right),'left_complexity':int.from_bytes(ctx.gdb.selected_inferior().read_memory(left+1,1),'little'),'right_complexity':int.from_bytes(ctx.gdb.selected_inferior().read_memory(right+1,1),'little')}
        (Path(ctx.out_dir)/(label+'.json')).write_text(json.dumps(meta))
        with (Path(ctx.out_dir)/(label+'.txt')).open('w') as f:ctx.cad.print_expression(f,ctx.cad.MwccENode.load(ptr),0)
    class Done(ctx.gdb.Breakpoint):
        def __init__(self,ret,ptr):self.ptr=ptr;super().__init__('*'+hex(ret),internal=True)
        def stop(self):snap(self.ptr,'after');return True
    class Entry(ctx.gdb.Breakpoint):
        def stop(self):
            objptr=rd(0x588238)
            if not objptr:return False
            obj=ctx.cad.MwccObject.load(objptr,load_linkname=False)
            if obj.name!=ctx.fn:return False
            sp=int(ctx.gdb.parse_and_eval('$esp'));ptr=rd(sp+4)
            node=ctx.cad.MwccENode.load(ptr)
            def names(n):return [n.name]+[name for c in n.children for name in names(c)]
            ns=names(node)
            if 'dst_row' not in ns or 'tile_x' not in ns:return False
            snap(ptr,'before');Done(rd(sp),ptr);self.enabled=False;return False
    Entry('*0x4fb470',internal=True);ctx.cont()

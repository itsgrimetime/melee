
char * __cdecl FUN_004f6b80(char *param_1)

{
  char *pcVar1;
  byte *pbVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  double dVar5;
  char *local_10;
  byte *local_c;
  
  if (**(char **)(param_1 + 6) == '\x0e') {
    pcVar1 = (char *)FUN_005179b0((char *)0x0,5,param_1);
    return pcVar1;
  }
  pcVar1 = FUN_004fa340(param_1);
  pbVar2 = (byte *)FUN_004fb4c0(pcVar1);
  if ((DAT_0058427a != '\0') &&
     (uVar3 = FUN_0046d220(0x2d,pbVar2,(byte *)0x0,(int *)&local_10), (char)uVar3 != '\0')) {
    if (local_10 != (char *)0x0) {
      return local_10;
    }
    pbVar2 = local_c;
    if (local_c == (byte *)0x0) {
      FUN_00445780();
    }
  }
  switch(**(undefined1 **)(pbVar2 + 6)) {
  case 1:
  case 3:
    break;
  case 2:
    if (*pbVar2 != 0x33) {
      uVar3 = FUN_00473ea0((int)pbVar2,5);
      pcVar1 = (char *)FUN_00474000(uVar3);
      return pcVar1;
    }
    dVar5 = FUN_004a88f0((int)*(undefined1 **)(pbVar2 + 6),0x2d,*(double *)(pbVar2 + 10));
    *(double *)(pbVar2 + 10) = dVar5;
    return (char *)pbVar2;
  default:
    FUN_004463d0(0x90);
    return (char *)pbVar2;
  }
  pcVar1 = FUN_004738d0((char *)pbVar2);
  if (*pcVar1 != '2') {
    pcVar1 = (char *)FUN_00473ea0((int)pcVar1,5);
    return pcVar1;
  }
  uVar4 = FUN_004a8db0(*(char **)(pcVar1 + 6),0x2d,*(undefined8 *)(pcVar1 + 10));
  *(undefined8 *)(pcVar1 + 10) = uVar4;
  return pcVar1;
}


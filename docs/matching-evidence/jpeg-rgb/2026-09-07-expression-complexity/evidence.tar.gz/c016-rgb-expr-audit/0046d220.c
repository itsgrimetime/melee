
uint __cdecl FUN_0046d220(short param_1,byte *param_2,byte *param_3,int *param_4)

{
  byte bVar1;
  char cVar2;
  uint in_EAX;
  undefined4 *puVar3;
  int iVar4;
  char *pcVar5;
  int *piVar6;
  undefined2 extraout_var;
  uint uVar7;
  undefined4 uVar8;
  undefined1 *puVar9;
  byte *pbVar10;
  char *local_70;
  int *local_68;
  int local_64 [4];
  char *local_54;
  int *local_50;
  int *local_4c;
  undefined1 local_47;
  char *local_40 [3];
  short local_32;
  undefined4 *local_26;
  int local_20;
  char *local_1c;
  int local_18;
  char *local_14;
  
  bVar1 = **(byte **)(param_2 + 6);
  if (bVar1 == 5) {
    FUN_00504850(*(byte **)(param_2 + 6));
  }
  else if (bVar1 != 3) {
    if (param_3 == (byte *)0x0) {
      return in_EAX & 0xffffff00;
    }
    cVar2 = **(char **)(param_3 + 6);
    if ((cVar2 != '\x05') && (cVar2 != '\x03')) {
      return (uint)*(char **)(param_3 + 6) & 0xffffff00;
    }
  }
  FUN_00441db0((undefined1 *)local_40,0x1e);
  puVar3 = FUN_004c37f0(param_1);
  if (param_1 == 0x28) {
    if (**(char **)(param_2 + 6) == '\x05') {
      puVar3 = (undefined4 *)FUN_00497fd0((int)*(char **)(param_2 + 6),local_64,puVar3);
      if ((char)puVar3 != '\0') {
        if ((local_50 != (int *)0x0) ||
           (((local_54 != (char *)0x0 && (*local_54 == '\x05')) &&
            (**(char **)(local_54 + 0xe) == '\x06')))) {
          puVar3 = (undefined4 *)FUN_00441fa0(0x14);
          FUN_00441db0((undefined1 *)puVar3,0x14);
          *puVar3 = local_4c;
          puVar3[1] = param_2;
          *(undefined1 *)(puVar3 + 4) = local_47;
          if (local_50 == (int *)0x0) {
            iVar4 = FUN_00441fe0(8);
            puVar3[2] = iVar4;
            *(undefined4 *)puVar3[2] = 0;
            *(char **)(puVar3[2] + 4) = local_54;
          }
          else {
            puVar3[2] = local_50;
          }
          pcVar5 = (char *)FUN_00441fa0(0x1a);
          FUN_00441db0(pcVar5,0x1a);
          *pcVar5 = 'D';
          *(undefined1 **)(pcVar5 + 6) = &DAT_0055d5d0;
          *(undefined4 **)(pcVar5 + 10) = puVar3;
          DAT_005882d8 = FUN_00492070();
          piVar6 = FUN_004f9dd0('\x01');
          puVar3 = FUN_0046e460(pcVar5,piVar6);
          iVar4 = FUN_004fa3e0((int)puVar3);
          *param_4 = iVar4;
          param_4[1] = 0;
          param_4[2] = 0;
          DAT_005882d8 = FUN_00492070();
          return CONCAT31((int3)(CONCAT22(extraout_var,DAT_005882d8) >> 8),1);
        }
        puVar3 = (undefined4 *)FUN_00445780();
      }
    }
    return (uint)puVar3 & 0xffffff00;
  }
  piVar6 = (int *)FUN_00441fa0(8);
  piVar6[1] = (int)param_2;
  if (param_3 == (byte *)0x0) {
    *piVar6 = 0;
  }
  else {
    iVar4 = FUN_00441fa0(8);
    *piVar6 = iVar4;
    *(byte **)(*piVar6 + 4) = param_3;
    *(undefined4 *)*piVar6 = 0;
  }
  local_70 = (char *)0x0;
  if (**(char **)(param_2 + 6) == '\x05') {
    uVar7 = FUN_00497fd0((int)*(char **)(param_2 + 6),local_64,puVar3);
    if ((char)uVar7 != '\0') {
      if (local_54 == (char *)0x0) {
        if (local_50 == (int *)0x0) {
          FUN_00445780();
        }
      }
      else {
        local_18 = 0;
        local_14 = local_54;
        local_50 = &local_18;
      }
      pcVar5 = local_40[0];
      if ((param_1 != 0x3d) || ((local_4c[1] == *(int *)(param_2 + 6) && (*local_4c == 0)))) {
        FUN_0046f760(local_50,0,(undefined4 *)*piVar6,(int *)local_40,(int)param_2,'\0');
        if (pcVar5 != local_40[0]) {
          local_70 = local_40[0];
          local_68 = local_4c;
        }
      }
    }
  }
  uVar7 = FUN_00498250(DAT_0058824c,local_64,(int)puVar3);
  if ((char)uVar7 == '\0') {
    local_50 = (int *)0x0;
  }
  else if (local_54 != (char *)0x0) {
    local_20 = 0;
    local_1c = local_54;
    local_50 = &local_20;
  }
  if (DAT_005842a9 != '\0') {
    local_50 = FUN_0049b0e0(local_50,(int)puVar3,piVar6,'\x01');
  }
  if (local_50 != (int *)0x0) {
    FUN_0046f760(local_50,0,piVar6,(int *)local_40,0,'\0');
  }
  if (local_40[0] == (char *)0x0) {
    pcVar5 = *(char **)(param_2 + 6);
    if ((*pcVar5 != '\x05') &&
       ((param_3 == (byte *)0x0 || (pcVar5 = *(char **)(param_3 + 6), *pcVar5 != '\x05')))) {
      return (uint)pcVar5 & 0xffffff00;
    }
    uVar8 = FUN_0046d690(param_1,param_2,param_3,piVar6,param_4);
    return uVar8;
  }
  if (((param_1 != 0x26) || (param_3 != (byte *)0x0)) && (param_1 != 0x2c)) {
    pcVar5 = *(char **)(param_2 + 6);
    if (((*pcVar5 != '\x05') &&
        ((param_3 == (byte *)0x0 || (pcVar5 = *(char **)(param_3 + 6), *pcVar5 != '\x05')))) &&
       (local_32 != 0)) {
      return (uint)pcVar5 & 0xffffff00;
    }
    if ((param_3 != (byte *)0x0) && (local_32 == 2)) {
      uVar8 = FUN_0046d690(param_1,param_2,param_3,piVar6,param_4);
      if ((char)uVar8 != '\0') {
        return CONCAT31((int3)((uint)uVar8 >> 8),1);
      }
    }
  }
  if (local_26 != (undefined4 *)0x0) {
    FUN_00445960((int)local_40[0],local_26);
  }
  if (local_40[0] == local_70) {
    pbVar10 = (byte *)piVar6[1];
    piVar6 = (int *)*piVar6;
  }
  else {
    pbVar10 = (byte *)0x0;
    local_68 = (int *)0x0;
  }
  puVar9 = FUN_0046eb90(local_68,pbVar10,'\0',local_40[0],(int *)0x0,0,piVar6,'\0','\0','\x01');
  *param_4 = (int)puVar9;
  iVar4 = FUN_004fa3e0(*param_4);
  *param_4 = iVar4;
  param_4[1] = 0;
  param_4[2] = 0;
  return CONCAT31((int3)((uint)iVar4 >> 8),1);
}



char * __cdecl FUN_004fb4c0(char *param_1)

{
  char *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined4 *puVar4;
  double dVar5;
  
  while( true ) {
    if (*param_1 != '\x04') {
      return param_1;
    }
    pcVar1 = *(char **)(param_1 + 10);
    if (*pcVar1 != '8') break;
    iVar2 = *(int *)(pcVar1 + 10);
    if (*(char *)(iVar2 + 2) != '\x06') {
      if (((*(uint *)(iVar2 + 0x12) & 0x10000) != 0) &&
         (*(undefined1 **)(param_1 + 6) == *(undefined1 **)(iVar2 + 0xe))) {
        switch(**(undefined1 **)(param_1 + 6)) {
        case 1:
        case 3:
          *param_1 = '2';
          uVar3 = *(undefined4 *)(iVar2 + 0x2a);
          *(undefined4 *)(param_1 + 10) = *(undefined4 *)(iVar2 + 0x26);
          *(undefined4 *)(param_1 + 0xe) = uVar3;
          break;
        case 2:
          *param_1 = '3';
          puVar4 = *(undefined4 **)(iVar2 + 0x26);
          if (puVar4 == (undefined4 *)0x0) {
            dVar5 = FUN_004a8650(&DAT_0055f5f0,DAT_00555420,DAT_00555424);
            *(double *)(param_1 + 10) = dVar5;
          }
          else {
            uVar3 = puVar4[1];
            *(undefined4 *)(param_1 + 10) = *puVar4;
            *(undefined4 *)(param_1 + 0xe) = uVar3;
          }
          break;
        default:
          FUN_00445780();
          break;
        case 0xb:
          *param_1 = '2';
          uVar3 = *(undefined4 *)(iVar2 + 0x2a);
          *(undefined4 *)(param_1 + 10) = *(undefined4 *)(iVar2 + 0x26);
          *(undefined4 *)(param_1 + 0xe) = uVar3;
          *(undefined **)(param_1 + 6) = &DAT_0055f5f8;
          param_1 = (char *)FUN_00473ea0((int)param_1,0x30);
          *(undefined4 *)(param_1 + 6) = *(undefined4 *)(iVar2 + 0xe);
        }
      }
      return param_1;
    }
    FUN_00474010((undefined4 *)pcVar1);
  }
  return param_1;
}



void FUN_004f57a0(void)

{
  char cVar1;
  bool bVar2;
  undefined4 uVar3;
  byte *pbVar4;
  char *pcVar5;
  byte *pbVar6;
  byte *pbVar7;
  undefined1 *puVar8;
  uint uVar9;
  undefined4 *puVar10;
  byte *local_84;
  uint local_80;
  int local_78;
  float local_28;
  undefined4 uStack_24;
  undefined4 uStack_20;
  undefined4 uStack_1c;
  byte *local_18 [3];
  
  if ((DAT_005882d8 != 0x28) || (uVar3 = FUN_0048ed50(), (char)uVar3 == '\0')) {
    FUN_004f6400();
    return;
  }
  DAT_005882d8 = FUN_00492070();
  FUN_00441db0((undefined1 *)&local_84,0x5c);
  FUN_0048c370((int *)&local_84,'\0');
  FUN_005028f0((int *)&local_84);
  if (DAT_005882d8 == 0x29) {
    DAT_005882d8 = FUN_00492070();
  }
  else {
    FUN_004461e0(0x73);
  }
  if (local_78 != 0) {
    FUN_004463d0(0xa4);
  }
  if ((((DAT_00584230 != '\0') && (DAT_005882d8 == 0x28)) && (*local_84 == 4)) &&
     (('\x03' < (char)local_84[0xe] && ((char)local_84[0xe] < '\x0f')))) {
    DAT_005882d8 = FUN_00492070();
    pbVar4 = FUN_004f1010();
    while (DAT_005882d8 == 0x2c) {
      pcVar5 = FUN_004fa340((char *)pbVar4);
      pbVar6 = (byte *)FUN_004fb4c0(pcVar5);
      DAT_005882d8 = FUN_00492070();
      pbVar4 = FUN_004f1010();
      pcVar5 = FUN_004fa340((char *)pbVar4);
      pbVar7 = (byte *)FUN_004fb4c0(pcVar5);
      if ((DAT_0058427a == '\0') ||
         (uVar3 = FUN_0046d220(0x2c,pbVar6,pbVar7,(int *)local_18), pbVar4 = local_18[0],
         (char)uVar3 == '\0')) {
        FUN_004f0e20(pbVar6);
        pbVar4 = (byte *)FUN_00473cf0((int)pbVar6,pbVar7);
        *(undefined4 *)(pbVar4 + 6) = *(undefined4 *)(pbVar7 + 6);
      }
      else if (local_18[0] == (byte *)0x0) {
        FUN_00445780();
      }
    }
    if (DAT_005882d8 == 0x29) {
      DAT_005882d8 = FUN_00492070();
    }
    else {
      FUN_004461e0(0x73);
    }
    cVar1 = FUN_004317b0((char *)pbVar4,&local_28,(int)local_84);
    if (cVar1 == '\0') {
      puVar8 = (undefined1 *)FUN_00473ea0((int)pbVar4,0x30);
    }
    else {
      puVar8 = (undefined1 *)FUN_00441fa0(0x1a);
      *puVar8 = 0x4a;
      puVar8[1] = pbVar4[1];
      if (puVar8[1] == '\0') {
        puVar8[1] = 1;
      }
      *(ushort *)(puVar8 + 2) = *(ushort *)(pbVar4 + 2) & 3;
      *(byte **)(puVar8 + 6) = local_84;
      *(float *)(puVar8 + 10) = local_28;
      *(undefined4 *)(puVar8 + 0xe) = uStack_24;
      *(undefined4 *)(puVar8 + 0x12) = uStack_20;
      *(undefined4 *)(puVar8 + 0x16) = uStack_1c;
    }
    *(byte **)(puVar8 + 6) = local_84;
    *(undefined2 *)(puVar8 + 2) = *(undefined2 *)(pbVar4 + 2);
    return;
  }
  if (((DAT_00584284 == '\0') && (DAT_005882d8 == 0x7b)) &&
     ((*local_84 != 4 || (((char)local_84[0xe] < '\x04' || ('\x0e' < (char)local_84[0xe])))))) {
    FUN_004cfd10(0,local_84,local_80);
    return;
  }
  pbVar4 = (byte *)FUN_004f57a0();
  if ((DAT_0058427a != '\0') &&
     ((bVar2 = FUN_00517ed0(local_84), bVar2 ||
      (uVar9 = FUN_00517eb0((int)pbVar4), (char)uVar9 != '\0')))) {
    puVar10 = (undefined4 *)FUN_00441fa0(8);
    *puVar10 = 0;
    puVar10[1] = pbVar4;
    puVar8 = FUN_00473fa0(3);
    *(undefined4 **)(puVar8 + 10) = puVar10;
    *(byte **)(puVar8 + 0xe) = local_84;
    *(uint *)(puVar8 + 0x12) = local_80;
    return;
  }
  if ((*local_84 != 0xb) || ((*(uint *)(local_84 + 10) & 0x20) == 0)) {
    pcVar5 = FUN_004fa340((char *)pbVar4);
    pbVar4 = (byte *)FUN_004fb4c0(pcVar5);
  }
  FUN_004f5aa0(pbVar4,(char *)local_84,local_80);
  return;
}


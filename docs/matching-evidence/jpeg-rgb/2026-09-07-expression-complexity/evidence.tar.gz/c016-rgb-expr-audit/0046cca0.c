
void __cdecl FUN_0046cca0(int *param_1,char param_2)

{
  char cVar1;
  byte *pbVar2;
  uint uVar3;
  undefined4 uVar4;
  undefined1 *puVar5;
  int iVar6;
  int local_40;
  byte *local_3c;
  int local_34 [9];
  
  if (DAT_005882d8 == 0x2a) {
    uVar3 = FUN_0046cea0();
    FUN_005045a0(param_1,uVar3);
    if (DAT_005882d8 != 0x5b) {
      FUN_0046cca0(param_1,param_2);
    }
  }
  else if ((DAT_005882d8 == -3) || (DAT_005882d8 == 0x174)) {
    uVar3 = FUN_004986e0(local_34,'\x01');
    if (((char)uVar3 == '\0') ||
       (((local_34[0] == 0 || (*(int *)(local_34[0] + 0xc) == 0)) || (DAT_005882d8 != 0x2a)))) {
      FUN_004463d0(0x79);
    }
    else {
      uVar3 = FUN_0046cea0();
      FUN_00502d80(param_1,*(int *)(local_34[0] + 0xc),uVar3);
      if (DAT_005882d8 != 0x5b) {
        FUN_0046cca0(param_1,param_2);
      }
    }
  }
  if (DAT_005882d8 == 0x5b) {
    DAT_005882d8 = FUN_00492070();
    pbVar2 = (byte *)FUN_004f0c90();
    cVar1 = **(char **)(pbVar2 + 6);
    if (cVar1 == '\x03') {
      *(undefined4 *)(pbVar2 + 6) = *(undefined4 *)(*(char **)(pbVar2 + 6) + 0xe);
    }
    else if ((cVar1 == '\x05') && (uVar4 = FUN_0046dee0(pbVar2,0,&local_40), (char)uVar4 != '\0')) {
      if (local_40 != 0) {
        FUN_00445780();
      }
      pbVar2 = local_3c;
      if (local_3c == (byte *)0x0) {
        FUN_00445780();
      }
    }
    if (**(char **)(pbVar2 + 6) != '\x01') {
      FUN_004463d0(0x7c);
    }
    if (DAT_005882d8 == 0x5d) {
      DAT_005882d8 = FUN_00492070();
    }
    else {
      FUN_004463d0(0x7d);
    }
    if (DAT_005882d8 == 0x5b) {
      FUN_0046cca0(param_1,'\0');
    }
    uVar3 = FUN_005046c0((char *)*param_1);
    if (((char)uVar3 == '\0') || (uVar4 = FUN_005047a0((undefined1 *)*param_1), (char)uVar4 == '\0')
       ) {
      FUN_004463d0(0x81);
    }
    else {
      puVar5 = FUN_00504960(*param_1,0);
      *param_1 = (int)puVar5;
      if (*pbVar2 == 0x32) {
        iVar6 = *(int *)(pbVar2 + 0xe);
        pbVar2 = DAT_005806a4;
      }
      else {
        iVar6 = 1;
        if (param_2 == '\0') {
          FUN_004463d0(0x7c);
          pbVar2 = DAT_005806a4;
        }
      }
      DAT_005806a4 = pbVar2;
      *(int *)(*param_1 + 2) = iVar6 * *(int *)(*(int *)(*param_1 + 6) + 2);
    }
  }
  return;
}


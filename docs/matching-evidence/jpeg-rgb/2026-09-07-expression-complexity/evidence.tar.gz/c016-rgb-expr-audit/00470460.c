
undefined4 __cdecl
FUN_00470460(byte *param_1,char *param_2,uint param_3,char param_4,char param_5,char param_6)

{
  uint uVar1;
  char *pcVar2;
  undefined *puVar3;
  byte bVar4;
  bool bVar5;
  bool bVar6;
  bool bVar7;
  undefined4 uVar8;
  undefined2 uVar9;
  bool bVar10;
  char cVar11;
  char *pcVar12;
  undefined4 *puVar13;
  undefined4 uVar14;
  undefined4 uVar15;
  undefined1 *puVar16;
  undefined1 *puVar17;
  byte *pbVar18;
  undefined4 *puVar19;
  int *piVar20;
  int iVar21;
  char *pcVar22;
  byte bVar23;
  ushort uVar24;
  char *local_74;
  char *local_6c;
  byte *local_68;
  int local_5c [4];
  undefined1 auStack_4c [8];
  char *local_44;
  undefined1 *local_40;
  undefined4 local_3c;
  undefined4 uStack_38;
  undefined2 uStack_34;
  undefined4 local_30;
  undefined4 uStack_2c;
  undefined2 uStack_28;
  undefined4 local_24;
  undefined4 uStack_20;
  undefined2 uStack_1c;
  int local_18;
  char *local_14;
  
  FUN_00441db0((undefined1 *)&local_3c,10);
  bVar5 = false;
  bVar7 = false;
  bVar6 = false;
  if (*(int *)(param_2 + 2) == 0) {
    FUN_00504850((byte *)param_2);
  }
  if (*(int *)(*(byte **)(param_1 + 6) + 2) == 0) {
    FUN_00504850(*(byte **)(param_1 + 6));
  }
  pcVar12 = *(char **)(param_1 + 6);
  if (*pcVar12 == '\x05') {
    FUN_00441db0((undefined1 *)local_5c,0x20);
    bVar4 = 0;
    if ((*(ushort *)(pcVar12 + 0x2a) & 0x40) != 0) {
      local_40 = auStack_4c;
      local_44 = pcVar12;
      FUN_00470ee0((int)local_40);
      FUN_00497fa0(local_5c,*(int *)(pcVar12 + 6));
    }
LAB_00470726:
    pcVar12 = FUN_00470d60(local_5c);
    if (pcVar12 != (char *)0x0) {
      iVar21 = *(int *)(pcVar12 + 0xe);
      pbVar18 = (byte *)FUN_00441fa0(0x1a);
      FUN_00441db0(pbVar18,0x1a);
      *pbVar18 = 0x3c;
      *(undefined4 *)(pbVar18 + 6) = *(undefined4 *)(iVar21 + 0xe);
      pcVar2 = *(char **)(pbVar18 + 6);
      if ((*pcVar2 == '\v') && ((*(uint *)(pcVar2 + 10) & 0x20) != 0)) {
        *(undefined4 *)(pbVar18 + 6) = *(undefined4 *)(pcVar2 + 6);
        bVar10 = FUN_0048ead0(*(char **)(pbVar18 + 6),*(uint *)(iVar21 + 0x12));
        if (!bVar10) {
          puVar16 = (undefined1 *)FUN_00441fa0(0x1a);
          *puVar16 = 4;
          puVar16[1] = pbVar18[1];
          if (puVar16[1] == '\0') {
            puVar16[1] = 1;
          }
          *(ushort *)(puVar16 + 2) = *(ushort *)(pbVar18 + 2) & 3;
          *(undefined4 *)(puVar16 + 6) = *(undefined4 *)(pbVar18 + 6);
          *(byte **)(puVar16 + 10) = pbVar18;
          *(undefined4 *)(*(int *)(puVar16 + 10) + 6) = 0x55d5d8;
          pbVar18 = (byte *)FUN_00441fa0(0x1a);
          *pbVar18 = 4;
          pbVar18[1] = puVar16[1];
          if (pbVar18[1] == 0) {
            pbVar18[1] = 1;
          }
          *(ushort *)(pbVar18 + 2) = *(ushort *)(puVar16 + 2) & 3;
          *(undefined4 *)(pbVar18 + 6) = *(undefined4 *)(puVar16 + 6);
          *(undefined1 **)(pbVar18 + 10) = puVar16;
          *(undefined4 *)(*(int *)(pbVar18 + 10) + 6) = 0x55d5d8;
        }
      }
      uVar14 = FUN_00470f50(pbVar18,param_2,'\0',param_6);
      if ((short)uVar14 != 0) {
        FUN_00472230((short)uVar14,(short *)&local_24,*(char **)(iVar21 + 0xe),
                     *(uint *)(iVar21 + 0x12),param_2,param_3,'\x01');
        if ((*(int *)(iVar21 + 6) == 0) || (**(char **)(*(int *)(iVar21 + 6) + 0xc) != '\v')) {
          FUN_00445780();
        }
        uVar24 = *(ushort *)(param_1 + 2);
        uVar1 = *(uint *)(*(int *)(iVar21 + 6) + 0x10);
        if ((((uVar1 & 1) != 0) || ((uVar24 & 1) == 0)) &&
           (((uVar1 & 2) != 0 || ((uVar24 & 2) == 0)))) {
          bVar23 = (uVar1 & 1) == (uVar24 & 1);
          if ((uVar1 & 2) == (uVar24 & 2)) {
            bVar23 = bVar23 + 1;
          }
          uVar14 = FUN_00471ff0((short *)&local_24,(short *)&local_3c,'\x01');
          if ((short)uVar14 != -1) {
            if ((short)uVar14 == 0) {
              if ((local_74 == pcVar12) || (bVar23 < bVar4)) goto LAB_00470726;
              if (bVar23 == bVar4) {
                bVar7 = true;
                goto LAB_00470726;
              }
            }
            local_3c = local_24;
            uStack_38 = uStack_20;
            uStack_34 = uStack_1c;
            bVar6 = true;
            bVar7 = false;
            local_74 = pcVar12;
            bVar4 = bVar23;
          }
        }
      }
      goto LAB_00470726;
    }
  }
  uVar14 = local_3c;
  uVar8 = uStack_38;
  uVar9 = uStack_34;
  if ((*param_2 == '\x05') &&
     (puVar13 = FUN_004ebce0((int)param_2), uVar14 = local_3c, uVar8 = uStack_38, uVar9 = uStack_34,
     puVar13 != (undefined4 *)0x0)) {
    FUN_00441db0((undefined1 *)&local_30,10);
    for (; puVar13 != (undefined4 *)0x0; puVar13 = (undefined4 *)*puVar13) {
      pcVar12 = (char *)puVar13[1];
      if ((((((*pcVar12 == '\x05') && (pcVar2 = *(char **)(pcVar12 + 0xe), *pcVar2 == '\x06')) &&
            ((param_5 != '\0' || ((*(uint *)(pcVar12 + 0x12) & 0x40) == 0)))) &&
           ((*(undefined4 **)(pcVar2 + 6) != (undefined4 *)0x0 &&
            (puVar19 = (undefined4 *)**(undefined4 **)(pcVar2 + 6), puVar19 != (undefined4 *)0x0))))
          && (((*(ushort *)(param_2 + 0x2a) & 0x20) == 0 ||
              (puVar19 = (undefined4 *)*puVar19, puVar19 != (undefined4 *)0x0)))) &&
         ((puVar19 != (undefined4 *)&DAT_00583098 &&
          (((puVar3 = (undefined *)*puVar19, puVar3 == (undefined *)0x0 ||
            (*(int *)(puVar3 + 8) != 0)) || (puVar3 == &DAT_00583098)))))) {
        pcVar22 = (char *)puVar19[3];
        if ((*pcVar22 == '\v') && ((*(uint *)(pcVar22 + 10) & 0x20) != 0)) {
          pcVar22 = *(char **)(pcVar22 + 6);
          bVar10 = FUN_0048ead0(pcVar22,puVar19[4]);
          if ((!bVar10) && (cVar11 = FUN_00472fc0(param_1), cVar11 == '\0')) goto LAB_004708cf;
        }
        uVar14 = FUN_00470f50(param_1,pcVar22,'\0',param_6);
        if ((short)uVar14 != 0) {
          FUN_00472230((short)uVar14,(short *)&local_24,*(char **)(pcVar2 + 0xe),
                       *(uint *)(pcVar2 + 0x12),param_2,param_3,'\0');
          uVar14 = FUN_00471ff0((short *)&local_24,(short *)&local_30,'\x01');
          if (1 < (int)(short)uVar14 + 1U) {
            local_68 = param_1;
            local_30 = local_24;
            uStack_2c = uStack_20;
            uStack_28 = uStack_1c;
            bVar5 = true;
            local_6c = pcVar12;
          }
        }
      }
LAB_004708cf:
    }
    uVar14 = local_3c;
    uVar8 = uStack_38;
    uVar9 = uStack_34;
    if ((bVar5) && (uVar14 = local_30, uVar8 = uStack_2c, uVar9 = uStack_28, bVar6)) {
      uVar15 = FUN_00471ff0((short *)&local_3c,(short *)&local_30,'\x01');
      if ((short)uVar15 == -1) {
        local_3c = local_30;
        uStack_38 = uStack_2c;
        uStack_34 = uStack_28;
        bVar6 = false;
        uVar14 = local_3c;
        uVar8 = uStack_38;
        uVar9 = uStack_34;
      }
      else {
        uVar14 = local_3c;
        uVar8 = uStack_38;
        uVar9 = uStack_34;
        if ((short)uVar15 == 0) {
          bVar7 = true;
        }
      }
    }
  }
  uStack_34 = uVar9;
  uStack_38 = uVar8;
  local_3c = uVar14;
  if ((bVar7) && (param_4 != '\0')) {
    FUN_004463d0(199);
  }
  if ((!bVar6) && (!bVar5)) {
    if (param_4 != '\0') {
      FUN_004463d0(0xf4);
    }
    return 0;
  }
  if (param_4 != '\0') {
    if (bVar6) {
      iVar21 = *(int *)(local_74 + 0xe);
      if ((*(uint *)(iVar21 + 0x16) & 0x10) == 0) {
        FUN_00445780();
      }
      if ((DAT_00587fd8 == (code *)0x0) || (cVar11 = (*DAT_00587fd8)(0,local_74), cVar11 != '\0')) {
        if (*(short *)(local_74 + 0x16) == 0x104) {
          FUN_004463d0(0x8d);
          puVar16 = (undefined1 *)FUN_00441fa0(0x1a);
          FUN_00441db0(puVar16,0x1a);
          *puVar16 = 0x32;
          *(undefined4 *)(puVar16 + 6) = 0x55d5d8;
          *(undefined4 *)(puVar16 + 0xe) = 0;
          *(undefined4 *)(puVar16 + 10) = 0;
        }
        else {
          puVar16 = (undefined1 *)FUN_00441fa0(0x1a);
          FUN_00441db0(puVar16,0x1a);
          *puVar16 = 0x38;
          *(char **)(puVar16 + 10) = local_74;
          puVar17 = FUN_00504930(*(undefined4 *)(local_74 + 0xe));
          *(undefined1 **)(puVar16 + 6) = puVar17;
          if (**(char **)(local_74 + 0xe) != '\x06') {
            *(ushort *)(puVar16 + 2) = *(ushort *)(local_74 + 0x12) & 3;
          }
          local_74[0x18] = local_74[0x18] | 1;
        }
      }
      else {
        puVar16 = (undefined1 *)FUN_00441fa0(0x1a);
        FUN_00441db0(puVar16,0x1a);
        *puVar16 = 0x32;
        *(undefined4 *)(puVar16 + 6) = 0x55d5d8;
        *(undefined4 *)(puVar16 + 0xe) = 0;
        *(undefined4 *)(puVar16 + 10) = 0;
      }
      local_74[0x18] = local_74[0x18] | 1;
      puVar13 = (undefined4 *)FUN_00441fa0(8);
      *puVar13 = 0;
      pbVar18 = (byte *)FUN_004f71b0(param_1,'\0');
      uVar24 = *(ushort *)(pbVar18 + 2);
      uVar14 = 0;
      pcVar12 = FUN_00504930(*(undefined4 *)(iVar21 + 0x1a));
      pbVar18 = FUN_004fa000(pbVar18,pcVar12,uVar24,uVar14);
      puVar13[1] = pbVar18;
      puVar19 = (undefined4 *)FUN_00441fa0(0x1a);
      *(undefined1 *)puVar19 = 0x36;
      *(undefined1 *)((int)puVar19 + 1) = 4;
      *(undefined4 *)((int)puVar19 + 6) = *(undefined4 *)(iVar21 + 0xe);
      *(ushort *)((int)puVar19 + 2) = *(ushort *)(iVar21 + 0x12) & 3;
      *(undefined1 **)((int)puVar19 + 10) = puVar16;
      *(undefined4 **)((int)puVar19 + 0xe) = puVar13;
      *(undefined4 *)((int)puVar19 + 0x12) = *(undefined4 *)(local_74 + 0xe);
      puVar13 = FUN_00472660(puVar19);
      DAT_00587c90 = (byte *)FUN_004fa3e0((int)puVar13);
      if (*(char **)(DAT_00587c90 + 6) != param_2) {
        DAT_00587c90 = FUN_004fa000(DAT_00587c90,param_2,(ushort)param_3,1);
      }
      if ((**(char **)(iVar21 + 0xe) == '\v') &&
         ((*(uint *)(*(char **)(iVar21 + 0xe) + 10) & 0x20) != 0)) {
        DAT_005806a8 = local_3c;
        DAT_005806ac = uStack_38;
        DAT_005806b0 = uStack_34;
        return 4;
      }
    }
    else {
      piVar20 = (int *)FUN_00441fa0(8);
      *piVar20 = 0;
      piVar20[1] = (int)local_68;
      if ((*(ushort *)(param_2 + 0x2a) & 0x20) != 0) {
        iVar21 = FUN_00441fa0(8);
        *piVar20 = iVar21;
        *(byte **)(*piVar20 + 4) = local_68;
        *(undefined4 *)*piVar20 = 0;
        puVar16 = (undefined1 *)FUN_00441fa0(0x1a);
        FUN_00441db0(puVar16,0x1a);
        *puVar16 = 0x32;
        *(undefined **)(puVar16 + 6) = &DAT_0055f5d0;
        *(undefined4 *)(puVar16 + 0xe) = 1;
        *(undefined4 *)(puVar16 + 10) = 0;
        piVar20[1] = (int)puVar16;
      }
      local_18 = 0;
      local_14 = param_2;
      puVar16 = FUN_0047c270(param_2);
      DAT_00587c90 = (byte *)FUN_00441fa0(0x1a);
      *DAT_00587c90 = 4;
      DAT_00587c90[1] = puVar16[1];
      if (DAT_00587c90[1] == 0) {
        DAT_00587c90[1] = 1;
      }
      *(ushort *)(DAT_00587c90 + 2) = *(ushort *)(puVar16 + 2) & 3;
      *(undefined4 *)(DAT_00587c90 + 6) = *(undefined4 *)(puVar16 + 6);
      *(undefined1 **)(DAT_00587c90 + 10) = puVar16;
      *(char **)(DAT_00587c90 + 6) = param_2;
      DAT_00587c90 = FUN_0046eb90(&local_18,DAT_00587c90,'\0',local_6c,(int *)0x0,0,piVar20,'\0',
                                  '\0','\x01');
      if ((*DAT_00587c90 == 0x36) || (*DAT_00587c90 == 0x37)) {
        puVar16 = FUN_00504930(param_2);
        *(undefined1 **)(DAT_00587c90 + 6) = puVar16;
        pbVar18 = DAT_00587c90;
        DAT_00587c90 = (byte *)FUN_00441fa0(0x1a);
        *DAT_00587c90 = 4;
        DAT_00587c90[1] = pbVar18[1];
        if (DAT_00587c90[1] == 0) {
          DAT_00587c90[1] = 1;
        }
        *(ushort *)(DAT_00587c90 + 2) = *(ushort *)(pbVar18 + 2) & 3;
        *(undefined4 *)(DAT_00587c90 + 6) = *(undefined4 *)(pbVar18 + 6);
        *(byte **)(DAT_00587c90 + 10) = pbVar18;
        *(char **)(DAT_00587c90 + 6) = param_2;
      }
    }
    DAT_0058850e = 1;
  }
  DAT_005806a8 = local_3c;
  DAT_005806ac = uStack_38;
  DAT_005806b0 = uStack_34;
  return 4;
}


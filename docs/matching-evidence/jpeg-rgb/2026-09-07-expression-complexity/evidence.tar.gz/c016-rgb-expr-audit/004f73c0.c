
byte * __cdecl FUN_004f73c0(char param_1)

{
  char cVar1;
  short sVar2;
  int iVar3;
  byte *pbVar4;
  byte *pbVar5;
  undefined1 *puVar6;
  int *piVar7;
  undefined4 *puVar8;
  undefined4 *puVar9;
  byte *pbVar10;
  char *pcVar11;
  byte *pbVar12;
  undefined4 uVar13;
  byte **ppbVar14;
  byte *local_a8;
  byte *local_a4;
  byte *local_a0;
  int local_9c [7];
  char local_80;
  char *local_78;
  uint local_74;
  byte *local_1c [3];
  
  if (DAT_0058427a != '\0') {
    iVar3 = (int)DAT_005882d8;
    if (((iVar3 - 0x106U < 9) || (iVar3 - 0x113U < 8)) || (iVar3 - 0x11cU < 2)) {
      FUN_00441db0((undefined1 *)&local_78,0x5c);
      if ((DAT_00584288 == '\0') && (sVar2 = FUN_004925d0(), sVar2 != 0x28)) {
        FUN_004463d0(0x72);
      }
      FUN_0048c370((int *)&local_78,'\0');
      pbVar4 = (byte *)FUN_004f9bb0(local_78,local_74);
      return pbVar4;
    }
    if (iVar3 == 0x152) {
      pbVar4 = FUN_005328a0();
      goto LAB_004f74c0;
    }
    if (iVar3 == 0x153) {
      pbVar4 = FUN_00532cb0();
      goto LAB_004f74c0;
    }
    if (iVar3 == 0x155) {
      pbVar4 = FUN_005329c0();
      goto LAB_004f74c0;
    }
    if (iVar3 == 0x156) {
      pbVar4 = (byte *)FUN_00532bd0();
      goto LAB_004f74c0;
    }
    if (iVar3 == 0x15a) {
      pbVar4 = (byte *)FUN_005334c0();
      goto LAB_004f74c0;
    }
  }
  pbVar4 = (byte *)FUN_004f8190(param_1);
LAB_004f74c0:
  while (DAT_005882d8 == 0x5b) {
    pcVar11 = FUN_004fa340((char *)pbVar4);
    pbVar12 = (byte *)FUN_004fb4c0(pcVar11);
    DAT_005882d8 = FUN_00492070();
    pbVar4 = FUN_004f1010();
    while (DAT_005882d8 == 0x2c) {
      pcVar11 = FUN_004fa340((char *)pbVar4);
      pbVar10 = (byte *)FUN_004fb4c0(pcVar11);
      DAT_005882d8 = FUN_00492070();
      pbVar4 = FUN_004f1010();
      pcVar11 = FUN_004fa340((char *)pbVar4);
      pbVar5 = (byte *)FUN_004fb4c0(pcVar11);
      if ((DAT_0058427a == '\0') ||
         (uVar13 = FUN_0046d220(0x2c,pbVar10,pbVar5,(int *)local_1c), pbVar4 = local_1c[0],
         (char)uVar13 == '\0')) {
        FUN_004f0e20(pbVar10);
        pbVar4 = (byte *)FUN_00473cf0((int)pbVar10,pbVar5);
        *(undefined4 *)(pbVar4 + 6) = *(undefined4 *)(pbVar5 + 6);
      }
      else if (local_1c[0] == (byte *)0x0) {
        FUN_00445780();
      }
    }
    pcVar11 = FUN_004fa340((char *)pbVar4);
    pbVar10 = (byte *)FUN_004fb4c0(pcVar11);
    if ((DAT_0058427a == '\0') ||
       (uVar13 = FUN_0046d220(0x5b,pbVar12,pbVar10,(int *)&local_a8), pbVar5 = local_a4,
       pbVar4 = local_a8, (char)uVar13 == '\0')) {
LAB_004f7666:
      if (**(char **)(pbVar12 + 6) < '\v') {
        if ('\n' < **(char **)(pbVar10 + 6)) {
          pcVar11 = FUN_004fa990((char *)pbVar10,(char *)pbVar12);
          goto LAB_004f76a0;
        }
        FUN_004463d0(0x94);
        pbVar4 = pbVar12;
      }
      else {
        pcVar11 = FUN_004fa990((char *)pbVar12,(char *)pbVar10);
LAB_004f76a0:
        pbVar4 = (byte *)FUN_00473ea0((int)pcVar11,4);
        *(undefined4 *)(pbVar4 + 6) = *(undefined4 *)(*(int *)(pbVar4 + 6) + 6);
      }
      if (DAT_005882d8 == 0x5d) {
        DAT_005882d8 = FUN_00492070();
      }
      else {
        FUN_004461e0(0x7d);
      }
    }
    else {
      if (local_a8 == (byte *)0x0) {
        if (local_a4 == (byte *)0x0) {
          FUN_00445780();
        }
        pbVar10 = local_a0;
        pbVar12 = pbVar5;
        if (local_a0 == (byte *)0x0) {
          FUN_00445780();
        }
        goto LAB_004f7666;
      }
      if (DAT_005882d8 == 0x5d) {
        DAT_005882d8 = FUN_00492070();
      }
      else {
        FUN_004461e0(0x7d);
      }
    }
  }
  if (DAT_005882d8 != 0x28) {
    if (DAT_005882d8 == 0x170) {
      pcVar11 = FUN_004fa340((char *)pbVar4);
      pbVar4 = (byte *)FUN_004fb4c0(pcVar11);
      if (DAT_0058427a != '\0') {
        while ((**(char **)(pbVar4 + 6) == '\x05' &&
               (uVar13 = FUN_0046d220(0x170,pbVar4,(byte *)0x0,(int *)&local_a8), pbVar12 = local_a8
               , (char)uVar13 != '\0'))) {
          if (local_a8 == (byte *)0x0) {
            FUN_00445780();
          }
          pcVar11 = FUN_004fa340((char *)pbVar12);
          pbVar4 = (byte *)FUN_004fb4c0(pcVar11);
        }
      }
      if (**(char **)(pbVar4 + 6) < '\v') {
        FUN_004461e0(0x94);
        return pbVar4;
      }
      if (((DAT_0058427a == '\0') || (DAT_0058427c == '\0')) ||
         (uVar13 = FUN_00509330(*(char **)(pbVar4 + 6)), (char)uVar13 == '\0')) {
        pbVar4 = (byte *)FUN_00473ea0((int)pbVar4,4);
        *(undefined4 *)(pbVar4 + 6) = *(undefined4 *)(*(int *)(pbVar4 + 6) + 6);
      }
      else {
        pbVar4 = (byte *)FUN_00473ea0((int)pbVar4,4);
        *(undefined4 *)(pbVar4 + 6) = *(undefined4 *)(*(int *)(pbVar4 + 6) + 6);
        pbVar12 = FUN_00509f10(0,(char *)pbVar4);
        if (pbVar12 != (byte *)0x0) {
          return pbVar12;
        }
      }
    }
    else if (DAT_005882d8 != 0x2e) {
      if (DAT_005882d8 != 0x16e) {
        if (DAT_005882d8 != 0x16f) {
          return pbVar4;
        }
        pcVar11 = FUN_004fa340((char *)pbVar4);
        pbVar12 = (byte *)FUN_004fb4c0(pcVar11);
        if (DAT_0058427a != '\0') {
          ppbVar14 = &local_a8;
          pbVar4 = FUN_00473f70();
          uVar13 = FUN_0046d220(0x16f,pbVar12,pbVar4,(int *)ppbVar14);
          pbVar4 = local_a8;
          if ((char)uVar13 != '\0') {
            if (local_a8 == (byte *)0x0) {
              FUN_00445780();
            }
            DAT_005882d8 = FUN_00492070();
            goto LAB_004f74c0;
          }
        }
        pbVar4 = FUN_00472ae0(pbVar12,'\x01','\x01');
        FUN_004fb400((char *)pbVar4);
        pbVar4 = (byte *)FUN_00473ea0((int)pbVar4,1);
        DAT_005882d8 = FUN_00492070();
        goto LAB_004f74c0;
      }
      pcVar11 = FUN_004fa340((char *)pbVar4);
      pbVar12 = (byte *)FUN_004fb4c0(pcVar11);
      if (DAT_0058427a != '\0') {
        ppbVar14 = &local_a8;
        pbVar4 = FUN_00473f70();
        uVar13 = FUN_0046d220(0x16e,pbVar12,pbVar4,(int *)ppbVar14);
        pbVar4 = local_a8;
        if ((char)uVar13 != '\0') {
          if (local_a8 == (byte *)0x0) {
            FUN_00445780();
          }
          DAT_005882d8 = FUN_00492070();
          goto LAB_004f74c0;
        }
      }
      pbVar4 = FUN_00472ae0(pbVar12,'\x01','\x01');
      if (*(undefined1 **)(pbVar4 + 6) == &DAT_0055f5a8) {
        pbVar4 = FUN_004730d0(pbVar4);
        DAT_005882d8 = FUN_00492070();
      }
      else {
        FUN_004fb400((char *)pbVar4);
        pbVar4 = (byte *)FUN_00473ea0((int)pbVar4,0);
        DAT_005882d8 = FUN_00492070();
      }
      goto LAB_004f74c0;
    }
    pcVar11 = FUN_004fa340((char *)pbVar4);
    pbVar12 = (byte *)FUN_004fb4c0(pcVar11);
    pbVar4 = pbVar12;
    if (*pbVar12 == 0x36) {
      cVar1 = **(char **)(pbVar12 + 6);
      if (((cVar1 == '\x05') || (cVar1 == '\x04')) &&
         (uVar13 = FUN_004a7af0(*(char **)(pbVar12 + 6)), (char)uVar13 == '\0')) {
        puVar8 = (undefined4 *)FUN_00473ae0(*(undefined4 *)(pbVar12 + 6),'\x01');
        puVar9 = (undefined4 *)FUN_00441fa0(0x1a);
        *puVar9 = *puVar8;
        puVar9[1] = puVar8[1];
        puVar9[2] = puVar8[2];
        puVar9[3] = puVar8[3];
        puVar9[4] = puVar8[4];
        puVar9[5] = puVar8[5];
        *(undefined2 *)(puVar9 + 6) = *(undefined2 *)(puVar8 + 6);
        iVar3 = FUN_00473ea0((int)puVar8,4);
        *(undefined4 *)(iVar3 + 6) = *(undefined4 *)(pbVar12 + 6);
        iVar3 = FUN_00473e30(iVar3,(int)pbVar12,0x1e);
        iVar3 = FUN_00473e30(iVar3,(int)puVar9,0x29);
        *(undefined4 *)(iVar3 + 6) = *(undefined4 *)((int)puVar9 + 6);
        pbVar4 = (byte *)FUN_00473ea0(iVar3,4);
        *(undefined4 *)(pbVar4 + 6) = *(undefined4 *)(pbVar12 + 6);
      }
    }
    pbVar12 = *(byte **)(pbVar4 + 6);
    if (*pbVar12 == 5) {
      FUN_00504850(pbVar12);
      if (((*(int *)(*(int *)(pbVar4 + 6) + 0x26) != 0) && (DAT_0058427a != '\0')) &&
         (pbVar12 = FUN_00509f10(*(int *)(pbVar4 + 6),(char *)pbVar4), pbVar12 != (byte *)0x0)) {
        return pbVar12;
      }
      if ((*(ushort *)(*(int *)(pbVar4 + 6) + 0x2a) & 2) == 0) {
        FUN_004463d0(0x88);
      }
      DAT_005882d8 = FUN_00492070();
      if (DAT_005882d8 == 0x14c) {
        DAT_005882d8 = FUN_00492070();
      }
      uVar13 = FUN_004979d0(*(int *)(pbVar4 + 6),local_9c,'\0');
      if ((char)uVar13 != '\0') {
        if (local_80 == '\0') {
          pbVar4 = (byte *)FUN_004f9090((int)local_9c,pbVar4,'\0','\0');
          if ((**(char **)(pbVar4 + 6) == '\v') &&
             ((*(uint *)(*(char **)(pbVar4 + 6) + 10) & 0x20) != 0)) {
            pbVar4 = (byte *)FUN_00473ea0((int)pbVar4,4);
            *(undefined4 *)(pbVar4 + 6) = *(undefined4 *)(*(int *)(pbVar4 + 6) + 6);
          }
        }
        else {
          DAT_005882d8 = FUN_00492070();
          if (DAT_005882d8 == 0x28) {
            DAT_005882d8 = FUN_00492070();
            if (DAT_005882d8 != 0x29) {
              iVar3 = 0x73;
              goto LAB_004f7ab4;
            }
            DAT_005882d8 = FUN_00492070();
          }
          else {
            iVar3 = 0x72;
LAB_004f7ab4:
            FUN_004463d0(iVar3);
          }
          pbVar4 = (byte *)FUN_00473ea0((int)pbVar4,0x30);
          *(undefined1 **)(pbVar4 + 6) = &DAT_0055d5d0;
        }
      }
    }
    else {
      if ((*pbVar12 != 4) || ('\x03' < (char)pbVar12[0xe])) {
        if ((DAT_0058427a != '\0') &&
           (pbVar12 = (byte *)FUN_004f7e30((char *)pbVar4), pbVar12 != (byte *)0x0)) {
          return pbVar12;
        }
        FUN_004461e0(0x95);
        return pbVar4;
      }
      pbVar10 = pbVar4;
      if (*pbVar4 != 4) {
        puVar8 = (undefined4 *)FUN_00473ae0(pbVar12,'\x01');
        puVar9 = (undefined4 *)FUN_00441fa0(0x1a);
        *puVar9 = *puVar8;
        puVar9[1] = puVar8[1];
        puVar9[2] = puVar8[2];
        puVar9[3] = puVar8[3];
        puVar9[4] = puVar8[4];
        puVar9[5] = puVar8[5];
        *(undefined2 *)(puVar9 + 6) = *(undefined2 *)(puVar8 + 6);
        iVar3 = FUN_00473ea0((int)puVar8,4);
        *(undefined4 *)(iVar3 + 6) = *(undefined4 *)(pbVar4 + 6);
        iVar3 = FUN_00473e30(iVar3,(int)pbVar4,0x1e);
        iVar3 = FUN_00473e30(iVar3,(int)puVar9,0x29);
        *(undefined4 *)(iVar3 + 6) = *(undefined4 *)((int)puVar9 + 6);
        pbVar10 = (byte *)FUN_00473ea0(iVar3,4);
        *(undefined4 *)(pbVar10 + 6) = *(undefined4 *)(pbVar4 + 6);
      }
      DAT_005882d8 = FUN_00492070();
      if (DAT_005882d8 != -3) {
        FUN_004463d0(0x6b);
        return pbVar10;
      }
      puVar8 = FUN_0048f160(*(int *)(pbVar10 + 6),DAT_00587fa0);
      if (puVar8 == (undefined4 *)0x0) {
        if (*(int *)(*(int *)(pbVar10 + 6) + 2) == 0) {
          FUN_004463d0(0x88);
        }
        else {
          FUN_004463d0(0x96);
        }
        return pbVar10;
      }
      if (**(char **)(*(int *)(pbVar10 + 10) + 6) < '\v') {
        FUN_004461e0(0x95);
        return pbVar10;
      }
      pbVar4 = (byte *)FUN_004e8fc0((int)pbVar10,(char *)puVar8[1],puVar8[4],puVar8[3]);
      if ((**(char **)(pbVar4 + 6) == '\v') &&
         ((*(uint *)(*(char **)(pbVar4 + 6) + 10) & 0x20) != 0)) {
        pbVar4 = (byte *)FUN_00473ea0((int)pbVar4,4);
        *(undefined4 *)(pbVar4 + 6) = *(undefined4 *)(*(int *)(pbVar4 + 6) + 6);
      }
      DAT_005882d8 = FUN_00492070();
    }
    goto LAB_004f74c0;
  }
  pbVar12 = pbVar4;
  if (*pbVar4 == 4) {
    cVar1 = **(char **)(pbVar4 + 6);
    if (cVar1 == '\f') {
      puVar6 = FUN_00504930(*(undefined4 *)(*(char **)(pbVar4 + 6) + 6));
      *(undefined1 **)(*(int *)(pbVar4 + 10) + 6) = puVar6;
      pbVar12 = *(byte **)(pbVar4 + 10);
    }
    else if (cVar1 == '\x06') {
      pbVar12 = *(byte **)(pbVar4 + 10);
    }
  }
  if (DAT_0058427a != '\0') {
    uVar13 = FUN_0046d220(0x28,pbVar12,(byte *)0x0,(int *)&local_a8);
    pbVar4 = local_a8;
    if ((char)uVar13 != '\0') {
      if (local_a8 == (byte *)0x0) {
        FUN_00445780();
      }
      goto LAB_004f74c0;
    }
    if (*pbVar12 == 0x39) {
      pbVar4 = FUN_004f80e0((int)pbVar12);
      if ((**(char **)(pbVar4 + 6) == '\v') &&
         ((*(uint *)(*(char **)(pbVar4 + 6) + 10) & 0x20) != 0)) {
        pbVar4 = (byte *)FUN_00473ea0((int)pbVar4,4);
        *(undefined4 *)(pbVar4 + 6) = *(undefined4 *)(*(int *)(pbVar4 + 6) + 6);
      }
      goto LAB_004f74c0;
    }
  }
  DAT_005882d8 = FUN_00492070();
  piVar7 = FUN_004f9dd0('\x01');
  if (DAT_005882d8 != 0x29) {
    FUN_004463d0(0x73);
  }
  if (*pbVar12 == 0x45) {
    pbVar4 = FUN_00473fd0(0x36);
    *(undefined **)(pbVar4 + 6) = &DAT_0055d5c0;
    *(byte **)(pbVar4 + 10) = pbVar12;
    *(int **)(pbVar4 + 0xe) = piVar7;
    *(undefined **)(pbVar4 + 0x12) = &DAT_0055d5e8;
    DAT_005882d8 = FUN_00492070();
  }
  else {
    pbVar4 = (byte *)FUN_0046e460((char *)pbVar12,piVar7);
    if ((**(char **)(pbVar4 + 6) == '\v') && ((*(uint *)(*(char **)(pbVar4 + 6) + 10) & 0x20) != 0))
    {
      pbVar4 = (byte *)FUN_00473ea0((int)pbVar4,4);
      *(undefined4 *)(pbVar4 + 6) = *(undefined4 *)(*(int *)(pbVar4 + 6) + 6);
    }
    DAT_005882d8 = FUN_00492070();
  }
  goto LAB_004f74c0;
}


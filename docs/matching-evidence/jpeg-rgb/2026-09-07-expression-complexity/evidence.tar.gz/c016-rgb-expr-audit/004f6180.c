
byte * __cdecl FUN_004f6180(byte *param_1,int param_2,int param_3)

{
  bool bVar1;
  uint uVar2;
  byte *pbVar3;
  undefined1 *puVar4;
  int iVar5;
  undefined4 *puVar6;
  undefined1 *puVar7;
  void *extraout_ECX;
  void *extraout_ECX_00;
  undefined8 uVar8;
  undefined1 uVar9;
  undefined1 uVar10;
  void *this;
  int *local_24;
  undefined2 local_1c;
  char local_19;
  int local_18;
  uint local_14;
  
  if (**(char **)(param_2 + 10) != '\x05') {
    FUN_00445780();
  }
  if (**(char **)(param_3 + 10) != '\x05') {
    FUN_00445780();
  }
  if (*(int *)(param_2 + 10) == *(int *)(param_3 + 10)) {
    *(int *)(param_1 + 6) = param_3;
    return param_1;
  }
  bVar1 = false;
  local_24 = FUN_004eb3a0(*(int *)(param_3 + 10),*(int *)(param_2 + 10),&local_1c,&local_19);
  this = extraout_ECX;
  if (local_24 == (int *)0x0) {
    local_24 = FUN_004eb3a0(*(int *)(param_2 + 10),*(int *)(param_3 + 10),&local_1c,&local_19);
    if (local_24 == (int *)0x0) goto LAB_004f6268;
    bVar1 = true;
    this = extraout_ECX_00;
  }
  if (local_19 != '\0') {
    this = (void *)0xbc;
    FUN_004463d0(0xbc);
  }
  uVar2 = FUN_004eaff0(this,local_24);
  if (-1 < (int)uVar2) {
    if (bVar1) {
      uVar2 = -uVar2;
    }
    FUN_004e9790(local_24,'\0');
    if (*(int *)(param_2 + 2) == *(int *)(param_3 + 2)) {
      if (uVar2 == 0) {
        *(int *)(param_1 + 6) = param_3;
        return param_1;
      }
      if (*(int *)(param_2 + 2) == 4) {
        if (*param_1 == 0x32) {
          if ((int)uVar2 < 0) {
            local_18 = -1;
          }
          else {
            local_18 = 0;
          }
          local_14 = uVar2;
          uVar8 = FUN_00476090(*(int *)(param_1 + 10),*(uint *)(param_1 + 0xe),local_18,uVar2);
          *(undefined8 *)(param_1 + 10) = uVar8;
          *(int *)(param_1 + 6) = param_3;
          return param_1;
        }
        *(undefined1 **)(param_1 + 6) = &DAT_0055f5f0;
        uVar10 = 0x30;
        uVar9 = 0xf;
        puVar4 = FUN_00473f30(&DAT_0055f5f0,uVar2);
        iVar5 = FUN_00473e30((int)param_1,(int)puVar4,uVar9);
        pbVar3 = (byte *)FUN_00473ea0(iVar5,uVar10);
        *(int *)(pbVar3 + 6) = param_3;
        return pbVar3;
      }
      iVar5 = 0;
      puVar4 = FUN_0047c270(&DAT_0058847c);
      puVar6 = FUN_004f71b0(param_1,'\0');
      puVar7 = FUN_00473f30(&DAT_0055f5f0,uVar2);
      iVar5 = FUN_004724b0(DAT_0058767c,(int)puVar7,(int)puVar6,(int)puVar4,iVar5);
      pbVar3 = (byte *)FUN_00473ea0(iVar5,4);
      *(int *)(pbVar3 + 6) = param_3;
      return pbVar3;
    }
  }
LAB_004f6268:
  FUN_004463d0(0xf7);
  pbVar3 = FUN_00473f70();
  return pbVar3;
}


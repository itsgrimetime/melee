
char * __cdecl FUN_004f4fe0(char *param_1,char *param_2)

{
  undefined1 uVar1;
  char *pcVar2;
  byte *pbVar3;
  byte *pbVar4;
  undefined4 uVar5;
  char *pcVar6;
  undefined3 extraout_var;
  undefined3 extraout_var_00;
  ulonglong uVar7;
  char *local_18;
  byte *local_14;
  byte *local_10;
  
  if ((**(char **)(param_1 + 6) == '\x0e') || (**(char **)(param_2 + 6) == '\x0e')) {
    pcVar2 = (char *)FUN_005179b0(param_1,0x12,param_2);
    return pcVar2;
  }
  pcVar2 = FUN_004fa340(param_1);
  pbVar3 = (byte *)FUN_004fb4c0(pcVar2);
  pcVar2 = FUN_004fa340(param_2);
  pbVar4 = (byte *)FUN_004fb4c0(pcVar2);
  if (DAT_0058427a != '\0') {
    uVar5 = FUN_0046d220(0x16d,pbVar3,pbVar4,(int *)&local_18);
    if ((char)uVar5 != '\0') {
      if (local_18 != (char *)0x0) {
        return local_18;
      }
      if (local_14 == (byte *)0x0) {
        FUN_00445780();
      }
      pbVar4 = local_10;
      pbVar3 = local_14;
      if (local_10 == (byte *)0x0) {
        FUN_00445780();
      }
    }
  }
  pcVar2 = FUN_004738d0((char *)pbVar3);
  pcVar6 = FUN_004738d0((char *)pbVar4);
  uVar1 = FUN_00473cb0(pcVar2);
  if ((short)CONCAT31(extraout_var,uVar1) == 0) {
    uVar1 = FUN_00473cb0(pcVar6);
    if ((short)CONCAT31(extraout_var_00,uVar1) == 0) {
      if ((*pcVar2 == '2') && (*pcVar6 == '2')) {
        uVar7 = FUN_004a9020(*(char **)(pcVar2 + 6),
                             CONCAT26((short)((uint)*(undefined4 *)(pcVar2 + 0xe) >> 0x10),
                                      *(undefined6 *)(pcVar2 + 10)),0x16d,*(uint *)(pcVar6 + 10),
                             *(uint *)(pcVar6 + 0xe));
        *(ulonglong *)(pcVar2 + 10) = uVar7;
        return pcVar2;
      }
      pcVar2 = (char *)FUN_00473e30((int)pcVar2,(int)pcVar6,0x12);
      return pcVar2;
    }
  }
  return pcVar2;
}


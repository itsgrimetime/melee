
char * __cdecl FUN_004f6e00(char *param_1)

{
  int *piVar1;
  int iVar2;
  undefined1 *puVar3;
  char *pcVar4;
  char *pcVar5;
  undefined4 uVar6;
  int *piVar7;
  
  if (*param_1 != 'D') {
    FUN_00445780();
  }
  if (*(int *)(*(int *)(param_1 + 10) + 4) != 0) {
    FUN_004463d0(0x8d);
  }
  *(undefined1 *)(*(int *)(param_1 + 10) + 0x11) = 1;
  piVar1 = (int *)(*(undefined4 **)(param_1 + 10))[2];
  if (*piVar1 != 0) {
    return param_1;
  }
  pcVar5 = (char *)piVar1[1];
  if (*pcVar5 != '\x04') {
    pcVar5 = (char *)FUN_004f6ed0(param_1,(char *)0x0,'\x01');
    return pcVar5;
  }
  piVar1 = (int *)**(undefined4 **)(param_1 + 10);
  do {
    piVar7 = piVar1;
    piVar1 = (int *)*piVar7;
  } while (piVar1 != (int *)0x0);
  puVar3 = (undefined1 *)FUN_00441fe0(0x12);
  FUN_00441db0(puVar3,0x12);
  *puVar3 = 10;
  *(undefined4 *)(puVar3 + 2) = 4;
  *(int *)(puVar3 + 10) = piVar7[1];
  *(undefined4 *)(puVar3 + 6) = *(undefined4 *)(pcVar5 + 0xc);
  pcVar4 = FUN_00473f70();
  *(undefined1 **)(pcVar4 + 6) = puVar3;
  iVar2 = *(int *)(pcVar5 + 0x14);
  *(int *)(pcVar4 + 0xe) = iVar2 + 1;
  if (iVar2 + 1 < 0) {
    uVar6 = 0xffffffff;
  }
  else {
    uVar6 = 0;
  }
  *(undefined4 *)(pcVar4 + 10) = uVar6;
  return pcVar4;
}



char * FUN_004f5450(void)

{
  undefined2 uVar1;
  int iVar2;
  char cVar3;
  char *pcVar4;
  byte *pbVar5;
  char *pcVar6;
  byte *pbVar7;
  undefined4 uVar8;
  undefined1 *puVar9;
  undefined8 uVar10;
  undefined1 uVar11;
  char *local_24 [3];
  undefined4 local_18;
  undefined4 local_14;
  
  pcVar4 = (char *)FUN_004f57a0();
  do {
    while (DAT_005882d8 == 0x173) {
      pcVar4 = FUN_004fa340(pcVar4);
      pbVar5 = (byte *)FUN_004fb4c0(pcVar4);
      DAT_005882d8 = FUN_00492070();
      pcVar4 = (char *)FUN_004f57a0();
      pcVar4 = FUN_004fa340(pcVar4);
      pbVar7 = (byte *)FUN_004fb4c0(pcVar4);
      uVar8 = FUN_0046d220(0x173,pbVar5,pbVar7,(int *)local_24);
      pcVar4 = local_24[0];
      if ((char)uVar8 == '\0') {
        if (**(char **)(pbVar5 + 6) < '\v') {
          FUN_004463d0(0x94);
          return (char *)pbVar5;
        }
        pcVar4 = (char *)FUN_00473ea0((int)pbVar5,4);
        *(undefined4 *)(pcVar4 + 6) = *(undefined4 *)(*(int *)(pcVar4 + 6) + 6);
        goto LAB_004f5570;
      }
      if (local_24[0] == (char *)0x0) {
        FUN_00445780();
      }
    }
    if (DAT_005882d8 != 0x172) {
      return pcVar4;
    }
    pcVar4 = FUN_004fa340(pcVar4);
    pcVar4 = FUN_004fb4c0(pcVar4);
    DAT_005882d8 = FUN_00492070();
    pcVar6 = (char *)FUN_004f57a0();
    pcVar6 = FUN_004fa340(pcVar6);
    pbVar7 = (byte *)FUN_004fb4c0(pcVar6);
    if (*pcVar4 != '\x04') {
      FUN_004463d0(0x8e);
      return pcVar4;
    }
LAB_004f5570:
    if (**(char **)(pcVar4 + 6) != '\x05') {
      FUN_004463d0(0x95);
      return pcVar4;
    }
    if (**(char **)(pbVar7 + 6) != '\n') {
      FUN_004463d0(0x90);
      return pcVar4;
    }
    if (*(char **)(pcVar4 + 6) != *(char **)(*(char **)(pbVar7 + 6) + 10)) {
      FUN_004eb810();
      cVar3 = FUN_004eb790(*(int *)(pcVar4 + 6),*(int *)(*(int *)(pbVar7 + 6) + 10),'\x01','\x01');
      if (cVar3 == '\0') {
        FUN_004463d0(0x92);
        return pcVar4;
      }
      pcVar6 = FUN_004eb0e0(*(char **)(pcVar4 + 10),*(int *)(pcVar4 + 6),
                            *(int *)(*(int *)(pbVar7 + 6) + 10),'\0','\x01');
      *(char **)(pcVar4 + 10) = pcVar6;
      *(undefined4 *)(pcVar4 + 6) = *(undefined4 *)(*(int *)(pbVar7 + 6) + 10);
    }
    uVar1 = *(undefined2 *)(pcVar4 + 2);
    pcVar6 = *(char **)(*(int *)(pbVar7 + 6) + 6);
    if (*pcVar6 == '\x06') {
      if (*pbVar7 != 4) {
        FUN_00445780();
      }
      pcVar6 = (char *)FUN_00441fa0(0x1a);
      *pcVar6 = '9';
      pcVar6[1] = '\x04';
      pcVar6[2] = '\0';
      pcVar6[3] = '\0';
      *(undefined1 **)(pcVar6 + 6) = &DAT_0055d5d0;
      *(char **)(pcVar6 + 10) = pcVar4;
      *(byte **)(pcVar6 + 0xe) = pbVar7;
      return pcVar6;
    }
    if (*pbVar7 == 0x32) {
      uVar10 = FUN_00475fe0(*(undefined8 *)(pbVar7 + 10),DAT_00555428,DAT_0055542c);
      *(undefined8 *)(pbVar7 + 10) = uVar10;
      uVar8 = FUN_004fab90(*(char **)(pcVar4 + 10),*(uint *)(pbVar7 + 10),*(uint *)(pbVar7 + 0xe));
      if ((short)uVar8 == 0) goto LAB_004f56ca;
    }
    else {
      local_18 = 0xffffffff;
      local_14 = 0xffffffff;
      uVar8 = FUN_004fab90(*(char **)(pcVar4 + 10),0xffffffff,0xffffffff);
      if ((short)uVar8 == 0) {
        uVar11 = 0xf;
        puVar9 = FUN_00473f70();
        uVar8 = FUN_00473e30(*(int *)(pcVar4 + 10),(int)puVar9,uVar11);
        *(undefined4 *)(pcVar4 + 10) = uVar8;
        iVar2 = *(int *)(*(int *)(pcVar4 + 10) + 0xe);
        *(undefined4 *)(iVar2 + 0xe) = 0xffffffff;
        *(undefined4 *)(iVar2 + 10) = 0xffffffff;
        FUN_004fb470(*(int *)(pcVar4 + 10));
      }
LAB_004f56ca:
      *(undefined1 **)(pbVar7 + 6) = &DAT_0055f5f0;
      uVar8 = FUN_00473e30(*(int *)(pcVar4 + 10),(int)pbVar7,0xf);
      *(undefined4 *)(pcVar4 + 10) = uVar8;
      FUN_004fb470(*(int *)(pcVar4 + 10));
    }
    if (*pcVar6 == '\a') {
      uVar8 = FUN_00473ea0(*(int *)(pcVar4 + 10),0x31);
      *(undefined4 *)(pcVar4 + 10) = uVar8;
      *(char **)(*(int *)(pcVar4 + 10) + 6) = pcVar6;
      *(undefined4 *)(pcVar4 + 6) = *(undefined4 *)(pcVar6 + 6);
    }
    else {
      *(char **)(pcVar4 + 6) = pcVar6;
    }
    *(undefined2 *)(pcVar4 + 2) = uVar1;
    if ((**(char **)(pcVar4 + 6) == '\v') && ((*(uint *)(*(char **)(pcVar4 + 6) + 10) & 0x20) != 0))
    {
      pcVar4 = (char *)FUN_00473ea0((int)pcVar4,4);
      *(undefined4 *)(pcVar4 + 6) = *(undefined4 *)(*(int *)(pcVar4 + 6) + 6);
    }
  } while( true );
}


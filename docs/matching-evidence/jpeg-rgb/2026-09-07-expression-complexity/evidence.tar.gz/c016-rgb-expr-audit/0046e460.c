
undefined4 * __cdecl FUN_0046e460(char *param_1,int *param_2)

{
  char cVar1;
  char cVar2;
  char *pcVar3;
  bool bVar4;
  undefined4 *puVar5;
  byte *pbVar6;
  int iVar7;
  char *pcVar8;
  char cVar9;
  int *piVar10;
  int *piVar11;
  byte *local_18;
  
  if ((*param_1 == 'C') && (*(int *)(param_1 + 0x12) != 0)) {
    puVar5 = FUN_0049b0e0(*(undefined4 **)(param_1 + 10),*(int *)(param_1 + 0x12),param_2,'\0');
    *(undefined4 **)(param_1 + 10) = puVar5;
    if (*(int *)(param_1 + 10) == 0) {
      FUN_00446db0((undefined4 *)0x0,*(int *)(param_1 + 0x12));
      FUN_004463d0(0x8c);
      puVar5 = (undefined4 *)FUN_00441fa0(0x1a);
      FUN_00441db0((undefined1 *)puVar5,0x1a);
      *(undefined1 *)puVar5 = 0x32;
      *(undefined1 **)((int)puVar5 + 6) = &DAT_0055f5f0;
      return puVar5;
    }
    pcVar3 = *(char **)(*(int *)(param_1 + 10) + 4);
    if (((*pcVar3 == '\x05') && ((*(uint *)(*(int *)(pcVar3 + 0xe) + 0x16) & 0x200) != 0)) &&
       (puVar5 = (undefined4 *)FUN_004322f0((int)pcVar3,param_2), puVar5 != (undefined4 *)0x0)) {
      return puVar5;
    }
    puVar5 = (undefined4 *)
             FUN_0046eb90((int *)0x0,(byte *)0x0,'\0',(char *)0x0,*(int **)(param_1 + 10),
                          *(undefined4 *)(param_1 + 0xe),param_2,'\0','\0','\x01');
    return puVar5;
  }
  if (*param_1 == 'D') {
    puVar5 = *(undefined4 **)(param_1 + 10);
    local_18 = (byte *)puVar5[1];
    piVar11 = (int *)*puVar5;
    cVar1 = *(char *)(puVar5 + 4);
    cVar9 = *(char *)((int)puVar5 + 0x12);
    param_1 = FUN_0046e8e0((int)param_1);
    if (param_1 == (char *)0x0) {
      FUN_004463d0(0xa1);
      puVar5 = (undefined4 *)FUN_00441fa0(0x1a);
      FUN_00441db0((undefined1 *)puVar5,0x1a);
      *(undefined1 *)puVar5 = 0x32;
      *(undefined1 **)((int)puVar5 + 6) = &DAT_0055f5f0;
      return puVar5;
    }
  }
  else {
    cVar1 = '\0';
    piVar11 = (int *)0x0;
    cVar9 = '\0';
    local_18 = (byte *)0x0;
  }
  cVar2 = *param_1;
  if (cVar2 == '8') {
    pcVar3 = *(char **)(*(int *)(param_1 + 10) + 0xe);
    if ((*pcVar3 == '\x06') && ((*(uint *)(pcVar3 + 0x16) & 0x200) != 0)) {
      puVar5 = (undefined4 *)FUN_004322f0(*(int *)(param_1 + 10),param_2);
      if (puVar5 == (undefined4 *)0x0) {
        puVar5 = (undefined4 *)
                 FUN_0046eb90(piVar11,local_18,cVar1,*(char **)(param_1 + 10),(int *)0x0,0,param_2,
                              '\0',cVar9,'\x01');
      }
      return puVar5;
    }
  }
  if (cVar2 == 'C') {
    puVar5 = (undefined4 *)
             FUN_0046eb90(piVar11,local_18,cVar1,(char *)0x0,*(int **)(param_1 + 10),
                          *(undefined4 *)(param_1 + 0xe),param_2,'\0',cVar9,'\x01');
    return puVar5;
  }
  if ((**(char **)(param_1 + 6) != '\v') ||
     (pcVar3 = *(char **)(*(char **)(param_1 + 6) + 6), *pcVar3 != '\x06')) {
    FUN_004463d0(0xa1);
    puVar5 = (undefined4 *)FUN_00441fa0(0x1a);
    FUN_00441db0((undefined1 *)puVar5,0x1a);
    *(undefined1 *)puVar5 = 0x32;
    *(undefined1 **)((int)puVar5 + 6) = &DAT_0055f5f0;
    return puVar5;
  }
  if (cVar2 == '8') {
    puVar5 = (undefined4 *)
             FUN_0046eb90(piVar11,local_18,cVar1,*(char **)(param_1 + 10),(int *)0x0,0,param_2,'\0',
                          cVar9,'\x01');
    return puVar5;
  }
  bVar4 = false;
  puVar5 = *(undefined4 **)(pcVar3 + 6);
  for (piVar11 = param_2; piVar11 != (int *)0x0; piVar11 = (int *)*piVar11) {
    if (bVar4) {
      pbVar6 = FUN_0046f260((byte *)piVar11[1],'\0');
      piVar11[1] = (int)pbVar6;
    }
    else {
      if (puVar5 == (undefined4 *)0x0) {
        FUN_004463d0(0xa2);
        puVar5 = (undefined4 *)FUN_00441fa0(0x1a);
        FUN_00441db0((undefined1 *)puVar5,0x1a);
        *(undefined1 *)puVar5 = 0x32;
        *(undefined1 **)((int)puVar5 + 6) = &DAT_0055f5f0;
        return puVar5;
      }
      if ((puVar5 == (undefined4 *)&DAT_00583098) || (puVar5 == (undefined4 *)&DAT_00584748)) {
        pbVar6 = FUN_0046f260((byte *)piVar11[1],puVar5 == (undefined4 *)&DAT_00583098);
        bVar4 = true;
        piVar11[1] = (int)pbVar6;
      }
      else {
        iVar7 = FUN_004f9ed0((byte *)piVar11[1],(char *)puVar5[3],*(ushort *)(puVar5 + 4),1);
        piVar11[1] = iVar7;
        puVar5 = (undefined4 *)*puVar5;
      }
    }
  }
  if (((!bVar4) && (puVar5 != (undefined4 *)0x0)) && (puVar5 != (undefined4 *)&DAT_00583098)) {
    while (puVar5 != (undefined4 *)&DAT_00584748) {
      if (puVar5[2] == 0) {
        FUN_004463d0(0xa2);
        puVar5 = (undefined4 *)FUN_00441fa0(0x1a);
        FUN_00441db0((undefined1 *)puVar5,0x1a);
        *(undefined1 *)puVar5 = 0x32;
        *(undefined1 **)((int)puVar5 + 6) = &DAT_0055f5f0;
        return puVar5;
      }
      piVar11 = param_2;
      if (param_2 == (int *)0x0) {
        param_2 = (int *)FUN_00441fa0(8);
        piVar11 = param_2;
      }
      else {
        do {
          piVar10 = piVar11;
          piVar11 = (int *)*piVar10;
        } while ((int *)*piVar10 != (int *)0x0);
        iVar7 = FUN_00441fa0(8);
        *piVar10 = iVar7;
        piVar11 = (int *)*piVar10;
      }
      *piVar11 = 0;
      pcVar8 = FUN_00513040((char *)puVar5[2],0);
      if (*pcVar8 == 'E') {
        if (pcVar8[0x16] != '\x03') {
          FUN_00445780();
        }
        pcVar8 = (char *)FUN_004f9d20(*(char **)(pcVar8 + 0xe),*(uint *)(pcVar8 + 0x12),
                                      *(int **)(pcVar8 + 10));
      }
      piVar11[1] = (int)pcVar8;
      puVar5 = (undefined4 *)*puVar5;
      if ((puVar5 == (undefined4 *)0x0) || (puVar5 == (undefined4 *)&DAT_00583098)) break;
    }
  }
  puVar5 = (undefined4 *)FUN_00441fa0(0x1a);
  FUN_00441db0((undefined1 *)puVar5,0x1a);
  *(undefined1 *)puVar5 = 0x36;
  *(undefined1 *)((int)puVar5 + 1) = 4;
  *(undefined4 *)((int)puVar5 + 6) = *(undefined4 *)(pcVar3 + 0xe);
  *(ushort *)((int)puVar5 + 2) = *(ushort *)(pcVar3 + 0x12) & 3;
  *(char **)((int)puVar5 + 10) = param_1;
  *(int **)((int)puVar5 + 0xe) = param_2;
  *(char **)((int)puVar5 + 0x12) = pcVar3;
  puVar5 = FUN_00472660(puVar5);
  return puVar5;
}


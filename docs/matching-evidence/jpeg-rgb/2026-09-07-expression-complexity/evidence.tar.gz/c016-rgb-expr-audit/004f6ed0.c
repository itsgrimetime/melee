
void __cdecl FUN_004f6ed0(char *param_1,char *param_2,char param_3)

{
  char *pcVar1;
  uint uVar2;
  undefined4 *puVar3;
  undefined1 *puVar4;
  undefined1 *puVar5;
  undefined4 uVar6;
  int iVar7;
  int *piVar8;
  char *unaff_EBP;
  undefined4 *puVar9;
  undefined4 *puVar10;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  if (*param_1 != 'D') {
    FUN_00445780();
  }
  if ((*(int *)(*(int *)(param_1 + 10) + 4) != 0) && (DAT_00584288 == '\0')) {
    FUN_004463d0(0x8d);
  }
  if ((DAT_00584288 == '\0') &&
     ((((*(char *)(*(int *)(param_1 + 10) + 0x11) == '\0' ||
        (*(char *)(*(int *)(param_1 + 10) + 0x10) == '\0')) && (param_2 != (char *)0x0)) &&
      (*param_2 == '\n')))) {
    FUN_004457e0(0x14b);
  }
  piVar8 = *(int **)(*(int *)(param_1 + 10) + 8);
  if (*piVar8 == 0) {
    unaff_EBP = (char *)piVar8[1];
  }
  else if (param_2 != (char *)0x0) {
    if (*param_2 != '\n') {
      FUN_004f7130(piVar8);
      return;
    }
    pcVar1 = *(char **)(param_2 + 6);
    for (; piVar8 != (int *)0x0; piVar8 = (int *)*piVar8) {
      if ((*(char *)piVar8[1] == '\x05') &&
         (uVar2 = FUN_0048fb60(*(char **)((char *)piVar8[1] + 0xe),pcVar1), (short)uVar2 != 0)) {
        unaff_EBP = (char *)piVar8[1];
        break;
      }
    }
    if (piVar8 == (int *)0x0) {
      FUN_004463d0(0x92);
      FUN_00473f70();
      return;
    }
  }
  for (; unaff_EBP[2] == '\x06'; unaff_EBP = *(char **)(unaff_EBP + 0x26)) {
  }
  if (((*unaff_EBP != '\x05') || (pcVar1 = *(char **)(unaff_EBP + 0xe), *pcVar1 != '\x06')) ||
     (((*(uint *)(pcVar1 + 0x16) & 0x10) == 0 || (pcVar1[0x26] != '\0')))) {
    FUN_00445780();
  }
  piVar8 = (int *)**(int **)(param_1 + 10);
  do {
    piVar8 = (int *)*piVar8;
  } while (piVar8 != (int *)0x0);
  puVar3 = (undefined4 *)FUN_00441fe0(0x28);
  FUN_00441db0((undefined1 *)puVar3,0x28);
  puVar10 = *(undefined4 **)(unaff_EBP + 0xe);
  puVar9 = puVar3;
  for (iVar7 = 10; iVar7 != 0; iVar7 = iVar7 + -1) {
    *puVar9 = *puVar10;
    puVar10 = puVar10 + 1;
    puVar9 = puVar9 + 1;
  }
  *(undefined4 *)((int)puVar3 + 6) = **(undefined4 **)((int)puVar3 + 6);
  FUN_00504420((int)puVar3);
  *(uint *)((int)puVar3 + 0x16) = *(uint *)((int)puVar3 + 0x16) & 0xfffffffd;
  puVar4 = (undefined1 *)FUN_00441fe0(0x12);
  FUN_00441db0(puVar4,0x12);
  *puVar4 = 10;
  *(undefined4 *)(puVar4 + 2) = 0xc;
  *(undefined4 *)(puVar4 + 10) = *(undefined4 *)(*(int *)(unaff_EBP + 0xe) + 0x1a);
  *(undefined4 **)(puVar4 + 6) = puVar3;
  iVar7 = *(int *)(unaff_EBP + 0xe);
  puVar5 = FUN_004900a0((undefined4 *)0x0);
  uVar6 = FUN_00490530();
  *(undefined4 *)(puVar5 + 10) = uVar6;
  *(undefined4 *)(puVar5 + 6) = DAT_00587fb4;
  *(undefined1 **)(puVar5 + 0xe) = puVar4;
  *(undefined2 *)(puVar5 + 0x16) = 0x102;
  if (param_3 != '\0') {
    local_1c = FUN_00441a70(0);
    if (unaff_EBP[2] == '\x04') {
      puVar10 = (undefined4 *)0x0;
      local_18 = FUN_00441a70(*(undefined4 *)(iVar7 + 0x1e));
      local_14 = FUN_00441a70(*(undefined4 *)(*(int *)(*(int *)(iVar7 + 0x1a) + 0x1e) + 8));
    }
    else {
      local_18 = FUN_00441a70(0xffffffff);
      local_14 = FUN_00441a70(0);
      puVar10 = (undefined4 *)FUN_00441fe0(0x10);
      *puVar10 = 0;
      puVar10[1] = unaff_EBP;
      puVar10[3] = 0;
      puVar10[2] = 8;
    }
    FUN_004ceab0((int)puVar5,&local_1c,puVar10,*(int *)(*(int *)(puVar5 + 0xe) + 2));
  }
  FUN_00472830((int)puVar5);
  return;
}


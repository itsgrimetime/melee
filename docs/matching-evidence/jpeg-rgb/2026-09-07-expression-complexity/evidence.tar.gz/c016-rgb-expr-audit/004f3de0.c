
/* WARNING: Removing unreachable block (ram,0x004f3fb4) */

byte * __cdecl FUN_004f3de0(byte *param_1,byte *param_2)

{
  byte *pbVar1;
  char *pcVar2;
  undefined4 uVar3;
  undefined1 *puVar4;
  uint uVar5;
  ulonglong uVar6;
  byte *local_c;
  byte *local_8;
  byte *local_4;
  
  if ((**(char **)(param_1 + 6) == '\x0e') || (**(char **)(param_2 + 6) == '\x0e')) {
    pbVar1 = (byte *)FUN_005179b0((char *)param_1,0x17,(char *)param_2);
    return pbVar1;
  }
  pcVar2 = FUN_004fa340((char *)param_1);
  param_1 = (byte *)FUN_004fb4c0(pcVar2);
  pcVar2 = FUN_004fa340((char *)param_2);
  param_2 = (byte *)FUN_004fb4c0(pcVar2);
  if ((DAT_0058427a != '\0') &&
     (uVar3 = FUN_0046d220(0x168,param_1,param_2,(int *)&local_c), (char)uVar3 != '\0')) {
    if (local_c != (byte *)0x0) {
      return local_c;
    }
    param_1 = local_8;
    if (local_8 == (byte *)0x0) {
      FUN_00445780();
    }
    param_2 = local_4;
    if (local_4 == (byte *)0x0) {
      FUN_00445780();
    }
  }
  if ((**(char **)(param_1 + 6) < '\v') && (**(char **)(param_2 + 6) < '\v')) {
    if ((**(char **)(param_1 + 6) != '\n') && (**(char **)(param_2 + 6) != '\n')) {
      FUN_004fb160((int *)&param_1,(int *)&param_2);
      if ((*param_1 == 0x32) && (*param_2 == 0x32)) {
        uVar6 = FUN_004a9020(*(char **)(param_1 + 6),
                             CONCAT26((short)((uint)*(undefined4 *)(param_1 + 0xe) >> 0x10),
                                      *(undefined6 *)(param_1 + 10)),0x168,*(uint *)(param_2 + 10),
                             *(uint *)(param_2 + 0xe));
        *(ulonglong *)(param_1 + 10) = uVar6;
        puVar4 = FUN_0048f2d0();
        *(undefined1 **)(param_1 + 6) = puVar4;
      }
      else if ((*param_1 == 0x33) && (*param_2 == 0x33)) {
        *param_1 = 0x32;
        uVar5 = FUN_004a8800(*(undefined4 *)(param_1 + 6),
                             (double)CONCAT26((short)((uint)*(undefined4 *)(param_1 + 0xe) >> 0x10),
                                              *(undefined6 *)(param_1 + 10)),0x168,
                             *(double *)(param_2 + 10));
        *(uint *)(param_1 + 0xe) = uVar5 & 0xff;
        param_1[10] = 0;
        param_1[0xb] = 0;
        param_1[0xc] = 0;
        param_1[0xd] = 0;
        *param_1 = 0x32;
        puVar4 = FUN_0048f2d0();
        *(undefined1 **)(param_1 + 6) = puVar4;
      }
      else {
        param_1 = (byte *)FUN_00473e30((int)param_1,(int)param_2,0x17);
        FUN_004fb470((int)param_1);
      }
      if ((DAT_0058427a == '\0') || (DAT_00584295 == '\0')) {
        *(undefined1 **)(param_1 + 6) = &DAT_0055f5e0;
      }
      else {
        *(undefined1 **)(param_1 + 6) = &DAT_0055f5a8;
      }
      return param_1;
    }
    pbVar1 = FUN_004f4030('\x17',param_1,param_2);
    return pbVar1;
  }
  pbVar1 = (byte *)FUN_004f4c00('\x17',param_1,param_2);
  return pbVar1;
}



void FUN_004f1d80(void)

{
  char cVar1;
  bool bVar2;
  bool bVar3;
  byte *pbVar4;
  char *pcVar5;
  byte *pbVar6;
  byte *pbVar7;
  byte *pbVar8;
  undefined4 uVar9;
  undefined1 *puVar10;
  byte *local_1c [3];
  
  bVar3 = false;
  pbVar4 = FUN_004f28f0((byte *)0x0,0,'\0');
  if (DAT_005882d8 != 0x3f) {
    return;
  }
  pcVar5 = FUN_004fa340((char *)pbVar4);
  pbVar4 = (byte *)FUN_004fb4c0(pcVar5);
  if (**(char **)(pbVar4 + 6) == '\x0e') {
    bVar3 = true;
  }
  else {
    pbVar4 = FUN_004702d0((char *)pbVar4,'\0','\x01');
    cVar1 = **(char **)(pbVar4 + 6);
    if (((cVar1 != '\x01') && (cVar1 != '\x02')) && (cVar1 != '\v')) {
      FUN_004463d0(0x90);
      FUN_00473f70();
      return;
    }
  }
  DAT_005882d8 = FUN_00492070();
  pbVar6 = FUN_004f1010();
  while (DAT_005882d8 == 0x2c) {
    pcVar5 = FUN_004fa340((char *)pbVar6);
    pbVar7 = (byte *)FUN_004fb4c0(pcVar5);
    DAT_005882d8 = FUN_00492070();
    pbVar6 = FUN_004f1010();
    pcVar5 = FUN_004fa340((char *)pbVar6);
    pbVar8 = (byte *)FUN_004fb4c0(pcVar5);
    if ((DAT_0058427a == '\0') ||
       (uVar9 = FUN_0046d220(0x2c,pbVar7,pbVar8,(int *)local_1c), pbVar6 = local_1c[0],
       (char)uVar9 == '\0')) {
      FUN_004f0e20(pbVar7);
      pbVar6 = (byte *)FUN_00473cf0((int)pbVar7,pbVar8);
      *(undefined4 *)(pbVar6 + 6) = *(undefined4 *)(pbVar8 + 6);
    }
    else if (local_1c[0] == (byte *)0x0) {
      FUN_00445780();
    }
  }
  pcVar5 = FUN_004fa340((char *)pbVar6);
  pbVar6 = (byte *)FUN_004fb4c0(pcVar5);
  if (DAT_005882d8 == 0x3a) {
    DAT_005882d8 = FUN_00492070();
  }
  else {
    FUN_004461e0(0x8d);
  }
  bVar2 = false;
  if ((DAT_0058427a != '\0') && (DAT_0058427e == '\0')) {
    bVar2 = true;
  }
  if (bVar2) {
    pbVar7 = FUN_004f1010();
  }
  else {
    pbVar7 = (byte *)FUN_004f1d80();
  }
  if (((!bVar3) && (**(char **)(pbVar6 + 6) != '\x0e')) && (**(char **)(pbVar7 + 6) != '\x0e')) {
    FUN_004f1f70((char *)pbVar4,pbVar6,pbVar7);
    return;
  }
  puVar10 = FUN_00473fd0(0x35);
  *(undefined **)(puVar10 + 6) = &DAT_0055d5c0;
  *(byte **)(puVar10 + 10) = pbVar4;
  *(byte **)(puVar10 + 0xe) = pbVar6;
  *(byte **)(puVar10 + 0x12) = pbVar7;
  return;
}


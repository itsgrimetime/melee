
/* WARNING: Removing unreachable block (ram,0x004faac0) */
/* WARNING: Removing unreachable block (ram,0x004faad0) */
/* WARNING: Removing unreachable block (ram,0x004faac8) */

char * __cdecl FUN_004faa60(char *param_1)

{
  char cVar1;
  char cVar2;
  char *pcVar3;
  ulonglong uVar4;
  
  if (**(char **)(param_1 + 6) != '\x01') {
    param_1 = FUN_00473ee0(param_1);
  }
  if (*(int *)(*(char **)(param_1 + 6) + 2) != DAT_0055f5fa) {
    pcVar3 = &DAT_0055f5f8;
    cVar1 = FUN_0048f180(*(char **)(param_1 + 6));
    cVar2 = FUN_0048f180(&DAT_0055f5f8);
    if (cVar2 != cVar1) {
      if (cVar1 == '\0') {
        if (DAT_0055f5f2 == DAT_0055f5fa) {
          pcVar3 = &DAT_0055f5f0;
        }
        else if (DAT_0055f5e2 == DAT_0055f5fa) {
          pcVar3 = &DAT_0055f5e0;
        }
        else {
          FUN_00445780();
        }
      }
      else {
        pcVar3 = &DAT_0055f5f8;
      }
    }
    if (*param_1 == '2') {
      uVar4 = FUN_00473870(pcVar3,*(char **)(param_1 + 6),*(undefined4 *)(param_1 + 10),
                           *(undefined4 *)(param_1 + 0xe));
      *(ulonglong *)(param_1 + 10) = uVar4;
    }
    else {
      param_1 = (char *)FUN_00473ea0((int)param_1,0x30);
    }
    *(char **)(param_1 + 6) = pcVar3;
  }
  return param_1;
}



char * __cdecl FUN_004f3670(char *param_1,char *param_2)

{
  undefined1 uVar1;
  char *pcVar2;
  undefined4 uVar3;
  undefined3 extraout_var;
  uint uVar4;
  undefined3 extraout_var_00;
  ulonglong uVar5;
  char *local_c;
  char *local_8;
  char *local_4;
  
  if ((**(char **)(param_1 + 6) == '\x0e') || (**(char **)(param_2 + 6) == '\x0e')) {
    pcVar2 = (char *)FUN_005179b0(param_1,0x1b,param_2);
    return pcVar2;
  }
  pcVar2 = FUN_004fa340(param_1);
  param_1 = FUN_004fb4c0(pcVar2);
  pcVar2 = FUN_004fa340(param_2);
  param_2 = FUN_004fb4c0(pcVar2);
  if (DAT_0058427a != '\0') {
    uVar3 = FUN_0046d220(0x7c,(byte *)param_1,(byte *)param_2,(int *)&local_c);
    if ((char)uVar3 != '\0') {
      if (local_c != (char *)0x0) {
        return local_c;
      }
      param_1 = local_8;
      if (local_8 == (char *)0x0) {
        FUN_00445780();
      }
      param_2 = local_4;
      if (local_4 == (char *)0x0) {
        FUN_00445780();
      }
    }
  }
  param_1 = FUN_004738d0(param_1);
  param_2 = FUN_004738d0(param_2);
  FUN_00473440((int *)&param_1,(int *)&param_2);
  uVar1 = FUN_00473cb0(param_2);
  if ((short)CONCAT31(extraout_var,uVar1) == 0) {
    uVar4 = FUN_00473b30(param_1);
    if ((char)uVar4 == '\0') {
      uVar1 = FUN_00473cb0(param_1);
      if ((short)CONCAT31(extraout_var_00,uVar1) == 0) {
        uVar4 = FUN_00473b30(param_2);
        if ((char)uVar4 == '\0') {
          if ((*param_1 == '2') && (*param_2 == '2')) {
            uVar5 = FUN_004a9020(*(char **)(param_1 + 6),
                                 CONCAT26((short)((uint)*(undefined4 *)(param_1 + 0xe) >> 0x10),
                                          *(undefined6 *)(param_1 + 10)),0x7c,
                                 *(uint *)(param_2 + 10),*(uint *)(param_2 + 0xe));
            *(ulonglong *)(param_1 + 10) = uVar5;
            return param_1;
          }
          param_1 = (char *)FUN_00473e30((int)param_1,(int)param_2,0x1b);
          FUN_004fb470((int)param_1);
          return param_1;
        }
      }
      return param_2;
    }
  }
  return param_1;
}


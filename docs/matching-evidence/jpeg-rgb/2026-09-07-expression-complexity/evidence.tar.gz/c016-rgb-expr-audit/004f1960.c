
byte * __cdecl FUN_004f1960(char *param_1,char param_2,undefined4 param_3)

{
  char cVar1;
  char *pcVar2;
  byte *pbVar3;
  byte *pbVar4;
  undefined4 uVar5;
  byte *pbVar6;
  undefined4 *puVar7;
  int *piVar8;
  byte *local_1c [3];
  
  cVar1 = **(char **)(param_1 + 6);
  pcVar2 = FUN_004fa340(param_1);
  pbVar3 = (byte *)FUN_004fb4c0(pcVar2);
  if ((DAT_0058427a == '\0') || ((short)param_3 == 0)) {
    pbVar3 = FUN_00472ae0(pbVar3,'\x01','\x01');
    DAT_005882d8 = FUN_00492070();
    pbVar4 = FUN_004f1010();
  }
  else {
    DAT_005882d8 = FUN_00492070();
    pbVar4 = FUN_004f1010();
    if (*pbVar4 != 0x44) {
      pcVar2 = FUN_004fa340((char *)pbVar4);
      pbVar4 = (byte *)FUN_004fb4c0(pcVar2);
    }
    uVar5 = FUN_0046d220((short)param_3,pbVar3,pbVar4,(int *)local_1c);
    if ((char)uVar5 != '\0') {
      if (local_1c[0] == (byte *)0x0) {
        FUN_00445780();
      }
      return local_1c[0];
    }
    if (**(char **)(pbVar3 + 6) == '\x05') {
      pcVar2 = FUN_004ebe20(*(char **)(pbVar3 + 6));
      if (pcVar2 != (char *)0x0) {
        FUN_004463d0(0x90);
      }
    }
    pbVar3 = FUN_00472ae0(pbVar3,'\x01','\x01');
  }
  if (cVar1 == '\f') {
    FUN_004463d0(0x90);
  }
  if (param_2 != '\x1e') {
    if (**(char **)(pbVar4 + 6) != '\x01') {
      pbVar4 = FUN_004702d0((char *)pbVar4,'\x01','\0');
      if (**(char **)(pbVar4 + 6) != '\x01') {
        FUN_004463d0(0x90);
        return pbVar3;
      }
    }
    if (**(char **)(pbVar3 + 6) != '\x01') {
      if (DAT_0058427a != '\0') {
        FUN_004463d0(0x90);
        return pbVar3;
      }
      pbVar3 = FUN_00473ee0(pbVar3);
      if (**(char **)(pbVar3 + 6) != '\x01') {
        FUN_004463d0(0x90);
        return pbVar3;
      }
    }
    pbVar3 = (byte *)FUN_004f1cb0((int)pbVar3,pbVar4,param_2);
    return pbVar3;
  }
  pcVar2 = *(char **)(pbVar3 + 6);
  if ((*pcVar2 == '\x05') && (*(int *)(pcVar2 + 0x22) != 0)) {
    FUN_004463d0(0x11d);
    return pbVar3;
  }
  if ((DAT_005842c7 == '\0') ||
     (((*pbVar3 != 4 || (**(char **)(pbVar3 + 10) != '1')) || (*pbVar4 == 0x32)))) {
    pbVar4 = FUN_004fa000(pbVar4,pcVar2,*(ushort *)(pbVar3 + 2),1);
  }
  else {
    DAT_005842c7 = 0;
    pbVar4 = FUN_004fa000(pbVar4,*(char **)(pbVar3 + 6),*(ushort *)(pbVar3 + 2),1);
    DAT_005842c7 = '\x01';
  }
  pbVar6 = pbVar4;
  if (((**(char **)(pbVar4 + 6) == '\x02') && (*pbVar4 == 0x30)) &&
     (*(int *)(*(char **)(pbVar4 + 6) + 2) == *(int *)(*(int *)(*(byte **)(pbVar4 + 10) + 6) + 2)))
  {
    pbVar6 = *(byte **)(pbVar4 + 10);
  }
  if (((*pbVar3 != 4) || (**(char **)(pbVar3 + 10) != '8')) ||
     ((*pbVar6 != 4 || ((pcVar2 = *(char **)(pbVar4 + 10), *pcVar2 != '6' && (*pcVar2 != '7'))))))
  goto LAB_004f1c88;
  if (*(int *)(pbVar3 + 6) != *(int *)(*(int *)(pcVar2 + 0x12) + 0xe)) goto LAB_004f1c88;
  uVar5 = FUN_004a7b80(*(int *)(pcVar2 + 0x12));
  if (((char)uVar5 != '\x01') || (piVar8 = *(int **)(pcVar2 + 0xe), piVar8 == (int *)0x0))
  goto LAB_004f1c88;
  uVar5 = FUN_0050e840();
  if ((short)uVar5 != 0) {
    if ((short)uVar5 == 1) {
      piVar8 = (int *)*piVar8;
      if (piVar8 != (int *)0x0) goto LAB_004f1c48;
      FUN_00445780();
    }
    FUN_00445780();
  }
LAB_004f1c48:
  if (*(char *)piVar8[1] == '<') {
    if (**(char **)(pbVar3 + 6) != '\x05') {
LAB_004f1c71:
      puVar7 = FUN_004f71b0(pbVar3,'\0');
      piVar8[1] = (int)puVar7;
      return pbVar4;
    }
    pcVar2 = FUN_004ebca0((int)*(char **)(pbVar3 + 6));
    if (pcVar2 == (char *)0x0) {
      pcVar2 = FUN_004ebe20(*(char **)(pbVar3 + 6));
      if (pcVar2 == (char *)0x0) goto LAB_004f1c71;
    }
  }
LAB_004f1c88:
  pbVar4 = (byte *)FUN_00473e30((int)pbVar3,(int)pbVar4,0x1e);
  *(undefined2 *)(pbVar4 + 2) = *(undefined2 *)(pbVar3 + 2);
  return pbVar4;
}


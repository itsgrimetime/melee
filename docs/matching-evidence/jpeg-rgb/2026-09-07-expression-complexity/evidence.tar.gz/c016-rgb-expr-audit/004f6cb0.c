
/* WARNING: Removing unreachable block (ram,0x004f6dba) */

byte * __cdecl FUN_004f6cb0(char *param_1)

{
  undefined2 uVar1;
  byte *pbVar2;
  char *pcVar3;
  undefined4 uVar4;
  undefined8 uVar5;
  byte *local_10;
  byte *local_c;
  
  if (**(char **)(param_1 + 6) == '\x0e') {
    pbVar2 = (byte *)FUN_005179b0((char *)0x0,7,param_1);
    return pbVar2;
  }
  pcVar3 = FUN_004fa340(param_1);
  pbVar2 = (byte *)FUN_004fb4c0(pcVar3);
  if ((DAT_0058427a != '\0') &&
     (uVar4 = FUN_0046d220(0x21,pbVar2,(byte *)0x0,(int *)&local_10), (char)uVar4 != '\0')) {
    if (local_10 != (byte *)0x0) {
      return local_10;
    }
    pbVar2 = local_c;
    if (local_c == (byte *)0x0) {
      FUN_00445780();
    }
  }
  switch(**(undefined1 **)(pbVar2 + 6)) {
  case 1:
  case 2:
  case 0xb:
  case 0xc:
    break;
  case 3:
    pbVar2 = FUN_00473ee0(pbVar2);
    break;
  default:
    FUN_004463d0(0x90);
    return pbVar2;
  case 10:
    pbVar2 = FUN_004702d0((char *)pbVar2,'\0','\0');
  }
  if (*pbVar2 == 0x32) {
    uVar5 = FUN_00476130();
    *(undefined8 *)(pbVar2 + 10) = uVar5;
  }
  else if (*pbVar2 == 0x33) {
    *pbVar2 = 0x32;
    uVar1 = FUN_004a85d0(*(double *)(pbVar2 + 10));
    *(uint *)(pbVar2 + 0xe) = (uint)(byte)uVar1;
    pbVar2[10] = 0;
    pbVar2[0xb] = 0;
    pbVar2[0xc] = 0;
    pbVar2[0xd] = 0;
  }
  else {
    pbVar2 = (byte *)FUN_00473ea0((int)pbVar2,7);
  }
  if ((DAT_0058427a == '\0') || (DAT_00584295 == '\0')) {
    *(undefined1 **)(pbVar2 + 6) = &DAT_0055f5e0;
  }
  else {
    *(undefined1 **)(pbVar2 + 6) = &DAT_0055f5a8;
  }
  return pbVar2;
}


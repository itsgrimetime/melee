
byte * __cdecl FUN_004719c0(int *param_1,int *param_2,byte *param_3,char param_4,char param_5)

{
  int iVar1;
  int *piVar2;
  byte *pbVar3;
  byte *pbVar4;
  
  if (param_3 != (byte *)0x0) {
LAB_00471a4d:
    if (param_1 == (int *)0x0) {
      FUN_00445780();
    }
    if (**(char **)(param_3 + 6) != '\x05') {
      FUN_00445780();
    }
    iVar1 = *(int *)(param_3 + 6);
    piVar2 = FUN_00497b20(param_1,iVar1);
    if ((piVar2 != (int *)0x0) && (piVar2[1] == iVar1)) {
      if (param_5 != '\0') {
        FUN_004e9790(piVar2,param_4);
      }
      if (*(int *)(piVar2[1] + 0x22) == 0) {
        if (param_2 != (int *)0x0) {
          piVar2 = FUN_004eba20(piVar2,param_2);
        }
        if (*param_3 != 4) {
          param_3 = FUN_00472ae0(param_3,'\0','\x01');
        }
        if (*param_3 == 4) {
          *(undefined2 *)(*(int *)(param_3 + 10) + 2) = *(undefined2 *)(param_3 + 2);
          pbVar4 = *(byte **)(param_3 + 10);
          pbVar3 = pbVar4;
          if (*pbVar4 < 4) {
            pbVar3 = (byte *)FUN_00441fa0(0x1a);
            *pbVar3 = 0x30;
            pbVar3[1] = pbVar4[1];
            if (pbVar3[1] == 0) {
              pbVar3[1] = 1;
            }
            *(ushort *)(pbVar3 + 2) = *(ushort *)(pbVar4 + 2) & 3;
            *(undefined4 *)(pbVar3 + 6) = *(undefined4 *)(pbVar4 + 6);
            *(byte **)(pbVar3 + 10) = pbVar4;
          }
          pbVar4 = FUN_00471b90(piVar2,pbVar3,'\0');
          param_3 = (byte *)FUN_00441fa0(0x1a);
          *param_3 = 4;
          param_3[1] = pbVar4[1];
          if (param_3[1] == 0) {
            param_3[1] = 1;
          }
          *(ushort *)(param_3 + 2) = *(ushort *)(pbVar4 + 2) & 3;
          *(undefined4 *)(param_3 + 6) = *(undefined4 *)(pbVar4 + 6);
          *(byte **)(param_3 + 10) = pbVar4;
          *(int *)(param_3 + 6) = iVar1;
        }
      }
      return param_3;
    }
    FUN_004463d0(0xdd);
    return (byte *)0x0;
  }
  if (((DAT_00588238 != 0) && (DAT_00588040 != 0)) && (DAT_005884f8 != '\0')) {
    iVar1 = FUN_004e9940();
    if (iVar1 != 0) {
      param_3 = (byte *)FUN_00441fa0(0x1a);
      *param_3 = 4;
      param_3[1] = *(byte *)(iVar1 + 1);
      if (param_3[1] == 0) {
        param_3[1] = 1;
      }
      *(ushort *)(param_3 + 2) = *(ushort *)(iVar1 + 2) & 3;
      *(undefined4 *)(param_3 + 6) = *(undefined4 *)(iVar1 + 6);
      *(int *)(param_3 + 10) = iVar1;
      *(int *)(param_3 + 6) = DAT_00588040;
      goto LAB_00471a4d;
    }
  }
  FUN_004463d0(0xdd);
  return (byte *)0x0;
}


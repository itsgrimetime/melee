
uint __cdecl FUN_0046dee0(byte *param_1,short param_2,undefined4 *param_3)

{
  char cVar1;
  bool bVar2;
  uint in_EAX;
  char *pcVar3;
  undefined4 uVar4;
  char *pcVar5;
  byte *pbVar6;
  bool bVar7;
  int local_30 [4];
  undefined1 auStack_20 [8];
  char *local_18;
  undefined1 *local_14;
  
  pcVar5 = *(char **)(param_1 + 6);
  if (*pcVar5 != '\x05') {
    return in_EAX & 0xffffff00;
  }
  if (param_2 == 4) {
    param_2 = 2;
  }
  else if (param_2 == 5) {
    param_2 = 1;
  }
  FUN_00441db0((undefined1 *)local_30,0x20);
  if ((*(ushort *)(pcVar5 + 0x2a) & 0x40) != 0) {
    local_14 = auStack_20;
    local_18 = pcVar5;
    FUN_00470ee0((int)local_14);
    FUN_00497fa0(local_30,*(int *)(pcVar5 + 6));
  }
  do {
    pcVar5 = FUN_00470d60(local_30);
    if (pcVar5 == (char *)0x0) {
      return 0;
    }
    pcVar5 = *(char **)(*(int *)(pcVar5 + 0xe) + 0xe);
    switch(param_2) {
    case 0:
      bVar7 = *pcVar5 == '\x01';
      break;
    case 1:
      bVar7 = true;
      if ((*pcVar5 != '\x01') && (*pcVar5 != '\x02')) {
        bVar7 = false;
      }
      break;
    case 2:
      cVar1 = *pcVar5;
      bVar7 = true;
      bVar2 = true;
      if ((cVar1 != '\x01') && (cVar1 != '\x02')) {
        bVar2 = false;
      }
      if ((!bVar2) && (cVar1 != '\v')) {
        bVar7 = false;
      }
      break;
    case 3:
      bVar7 = *pcVar5 == '\v';
      break;
    default:
      FUN_00445780();
      bVar7 = false;
    }
  } while (!bVar7);
  pcVar3 = FUN_00470d60(local_30);
  while (pcVar3 != (char *)0x0) {
    pcVar3 = *(char **)(*(int *)(pcVar3 + 0xe) + 0xe);
    switch(param_2) {
    case 0:
      bVar7 = *pcVar3 == '\x01';
      break;
    case 1:
      bVar7 = true;
      if ((*pcVar3 != '\x01') && (*pcVar3 != '\x02')) {
        bVar7 = false;
      }
      break;
    case 2:
      cVar1 = *pcVar3;
      bVar7 = true;
      bVar2 = true;
      if ((cVar1 != '\x01') && (cVar1 != '\x02')) {
        bVar2 = false;
      }
      if ((!bVar2) && (cVar1 != '\v')) {
        bVar7 = false;
      }
      break;
    case 3:
      bVar7 = *pcVar3 == '\v';
      break;
    default:
      FUN_00445780();
      bVar7 = false;
    }
    if (bVar7) {
      FUN_004463d0(199);
    }
    pcVar3 = FUN_00470d60(local_30);
  }
  *param_3 = 0;
  pbVar6 = param_1;
  if (((**(char **)(param_1 + 6) == '\x05') && (pcVar5 != (char *)0x0)) &&
     (uVar4 = FUN_00470460(param_1,pcVar5,0,'\x01','\0','\x01'), pbVar6 = DAT_00587c90,
     (short)uVar4 == 0)) {
    FUN_004463d0(0x90);
    pbVar6 = param_1;
  }
  param_3[1] = pbVar6;
  param_3[2] = 0;
  return CONCAT31((int3)((uint)param_3 >> 8),1);
}


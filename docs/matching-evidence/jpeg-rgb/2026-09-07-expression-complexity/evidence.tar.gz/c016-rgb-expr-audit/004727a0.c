
undefined4 __cdecl FUN_004727a0(char *param_1,int param_2,int *param_3)

{
  char *pcVar1;
  undefined4 uVar2;
  int *piVar3;
  
  if ((((*param_1 != '\x04') || (*(int *)(param_1 + 6) != param_2)) ||
      (pcVar1 = *(char **)(param_1 + 10), *pcVar1 != '6')) ||
     (piVar3 = *(int **)(pcVar1 + 0xe), piVar3 == (int *)0x0)) {
    return 0;
  }
  if (**(char **)(pcVar1 + 10) == '8') {
    uVar2 = FUN_004ebc70(*(int *)(*(char **)(pcVar1 + 10) + 10));
    if ((char)uVar2 != '\0') goto LAB_0047281c;
  }
  if (*(int *)(*(int *)(*(int *)(param_1 + 10) + 0x12) + 0xe) != param_2) {
    return 0;
  }
  uVar2 = FUN_0050e840();
  if (((short)uVar2 == 1) && (piVar3 = (int *)*piVar3, piVar3 == (int *)0x0)) {
    FUN_00445780();
  }
LAB_0047281c:
  if (param_3 != (int *)0x0) {
    *param_3 = piVar3[1];
  }
  return *(undefined4 *)(param_1 + 10);
}



char * FUN_004f0ba0(void)

{
  char cVar1;
  char *pcVar2;
  uint uVar3;
  
  pcVar2 = (char *)FUN_004f1d80();
  pcVar2 = FUN_004fa340(pcVar2);
  pcVar2 = FUN_004fb4c0(pcVar2);
  if (*pcVar2 == '2') {
    cVar1 = **(char **)(pcVar2 + 6);
    if (cVar1 == '\x01') {
      return pcVar2;
    }
    if (cVar1 == '\x03') {
      *(undefined4 *)(pcVar2 + 6) = *(undefined4 *)(*(char **)(pcVar2 + 6) + 0xe);
      return pcVar2;
    }
    FUN_00445780();
  }
  uVar3 = FUN_00517eb0((int)pcVar2);
  if ((char)uVar3 != '\0') {
    return pcVar2;
  }
  FUN_004463d0(0x7c);
  pcVar2 = FUN_00473f70();
  *(undefined **)(pcVar2 + 6) = &DAT_0055f5b0;
  return pcVar2;
}


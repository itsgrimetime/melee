
undefined4 __cdecl FUN_00471790(undefined4 *param_1,undefined4 param_2,char *param_3,char param_4)

{
  char *pcVar1;
  bool bVar2;
  bool bVar3;
  undefined4 uVar4;
  undefined4 *puVar5;
  uint uVar6;
  char *pcVar7;
  undefined1 *puVar8;
  undefined1 *puVar9;
  char *pcVar10;
  char *pcVar11;
  char *unaff_ESI;
  
  if ((*param_3 != '\v') || (pcVar1 = *(char **)(param_3 + 6), *pcVar1 != '\x06')) {
    return 0;
  }
  bVar3 = false;
  pcVar11 = (char *)0x0;
  bVar2 = false;
  for (; param_1 != (undefined4 *)0x0; param_1 = (undefined4 *)*param_1) {
    unaff_ESI = (char *)param_1[1];
    if (*unaff_ESI == '\x05') {
      pcVar7 = *(char **)(unaff_ESI + 0xe);
      if ((*pcVar7 == '\x06') && ((*(uint *)(pcVar7 + 0x16) & 0x400) != 0)) {
        if ((!bVar2) && (uVar4 = FUN_005159a0((int)unaff_ESI,pcVar1,param_2), (char)uVar4 != '\0'))
        {
          puVar5 = FUN_00515590((int)unaff_ESI,pcVar1,param_2,0);
          if (puVar5 == (undefined4 *)0x0) {
            FUN_00445780();
          }
          uVar6 = FUN_0048f2f0(*(char **)(puVar5[1] + 0xe),pcVar1);
          if ((short)uVar6 != 0) {
            if ((pcVar11 == (char *)0x0) || (pcVar11 == (char *)puVar5[1])) {
              pcVar11 = (char *)puVar5[1];
            }
            else {
              bVar3 = true;
            }
          }
        }
      }
      else {
        uVar6 = FUN_0048f2f0(pcVar7,pcVar1);
        if ((short)uVar6 != 0) {
          if ((pcVar11 == (char *)0x0) || (!bVar2)) {
            bVar3 = false;
            pcVar11 = unaff_ESI;
          }
          else {
            pcVar7 = unaff_ESI;
            if (unaff_ESI[2] == '\x06') {
              pcVar7 = *(char **)(unaff_ESI + 0x26);
            }
            pcVar10 = pcVar11;
            if (pcVar11[2] == '\x06') {
              pcVar10 = *(char **)(pcVar11 + 0x26);
            }
            if (pcVar7 != pcVar10) {
              bVar3 = true;
            }
          }
          bVar2 = true;
        }
      }
    }
  }
  if (pcVar11 == (char *)0x0) {
    return 0;
  }
  if (param_4 != '\0') {
    if (bVar3) {
      FUN_004463d0(199);
    }
    if (*(short *)(pcVar11 + 0x16) == 0x104) {
      FUN_004463d0(0x8d);
      puVar8 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar8,0x1a);
      *puVar8 = 0x32;
      *(undefined4 *)(puVar8 + 6) = 0x55d5d8;
      *(undefined4 *)(puVar8 + 0xe) = 0;
      *(undefined4 *)(puVar8 + 10) = 0;
    }
    else {
      puVar8 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar8,0x1a);
      *puVar8 = 0x38;
      *(char **)(puVar8 + 10) = pcVar11;
      puVar9 = FUN_00504930(*(undefined4 *)(pcVar11 + 0xe));
      *(undefined1 **)(puVar8 + 6) = puVar9;
      if (**(char **)(pcVar11 + 0xe) != '\x06') {
        *(ushort *)(puVar8 + 2) = *(ushort *)(pcVar11 + 0x12) & 3;
      }
      pcVar11[0x18] = pcVar11[0x18] | 1;
    }
    DAT_00587c90 = puVar8;
    puVar9 = FUN_00504930(*(undefined4 *)(pcVar11 + 0xe));
    *(undefined1 **)(puVar8 + 6) = puVar9;
    *(ushort *)(puVar8 + 2) = *(ushort *)(unaff_ESI + 0x12) & 3;
    pcVar11[0x18] = pcVar11[0x18] | 1;
    if (pcVar11[2] == '\x05') {
      FUN_004463d0(0xaf);
    }
  }
  return 1;
}


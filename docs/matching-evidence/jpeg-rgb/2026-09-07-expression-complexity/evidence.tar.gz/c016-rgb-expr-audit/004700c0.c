
void __cdecl FUN_004700c0(byte *param_1,char *param_2)

{
  int iVar1;
  char cVar2;
  char cVar3;
  uint uVar4;
  ulonglong uVar5;
  char *pcVar6;
  undefined4 uVar7;
  int local_14;
  int local_10;
  
  pcVar6 = *(char **)(param_1 + 6);
  if (pcVar6 == param_2) {
    return;
  }
  if (pcVar6 == &DAT_0055f5a8) {
    return;
  }
  if (*pcVar6 == '\x01') {
    if (*param_2 == '\x02') {
      return;
    }
    if (*param_2 != '\x01') {
      FUN_00445780();
    }
    iVar1 = *(int *)(*(char **)(param_1 + 6) + 2);
    if (iVar1 < *(int *)(param_2 + 2)) {
      return;
    }
    if (*(int *)(param_2 + 2) == iVar1) {
      cVar2 = FUN_0048f180(*(char **)(param_1 + 6));
      cVar3 = FUN_0048f180(param_2);
      if (cVar3 == cVar2) {
        return;
      }
    }
    uVar4 = (uint)*param_1;
    if (uVar4 == 0x32) {
      if ((((*(uint *)(param_1 + 10) & 0x80000000) == 0) ||
          (cVar2 = FUN_0048f180(*(char **)(param_1 + 6)), cVar2 != '\0')) ||
         (cVar2 = FUN_0048f180(param_2), cVar2 == '\0')) {
        if (param_2 == &DAT_0055f5a8) {
          uVar7 = 0x169;
          pcVar6 = *(char **)(param_1 + 6);
        }
        else {
          uVar7 = 0x2b;
          pcVar6 = param_2;
        }
        uVar5 = FUN_004a9020(pcVar6,*(ulonglong *)(param_1 + 10),uVar7,DAT_00555420,DAT_00555424);
        pcVar6 = *(char **)(param_1 + 6);
        if (pcVar6 == &DAT_0055f5a8) {
          uVar7 = 0x169;
          pcVar6 = param_2;
        }
        else {
          uVar7 = 0x2b;
        }
        uVar5 = FUN_004a9020(pcVar6,uVar5,uVar7,DAT_00555420,DAT_00555424);
        local_10 = (int)(uVar5 >> 0x20);
        local_14 = (int)uVar5;
        uVar7 = FUN_004750f0(local_14,local_10,*(int *)(param_1 + 10),*(int *)(param_1 + 0xe));
        if ((char)uVar7 != '\0') {
          return;
        }
      }
    }
    else if (((uVar4 == 7) || (uVar4 - 0x13 < 6)) || (uVar4 - 0x1c < 2)) {
      return;
    }
  }
  else if ((*param_2 == '\x02') && (*(int *)(pcVar6 + 2) <= *(int *)(param_2 + 2))) {
    return;
  }
  FUN_004457e0(0x13d);
  return;
}


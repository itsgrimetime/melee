
char * __cdecl FUN_004f9090(int param_1,byte *param_2,char param_3,char param_4)

{
  int iVar1;
  int *piVar2;
  char *pcVar3;
  bool bVar4;
  short sVar5;
  char *pcVar6;
  undefined4 uVar7;
  byte *pbVar8;
  undefined4 *puVar9;
  int iVar10;
  undefined1 *puVar11;
  int iVar12;
  int *piVar13;
  undefined1 uVar14;
  
  pcVar6 = *(char **)(param_1 + 8);
  if (pcVar6 != (char *)0x0) {
    if (DAT_0058427a == '\0') {
      FUN_004461e0(0x8d);
      DAT_005882d8 = FUN_00492070();
      pcVar6 = FUN_00473f70();
      return pcVar6;
    }
    if (*pcVar6 == '\t') {
      if ((pcVar6[6] == '\0') && (pcVar6[0xb] == '\0')) {
        pcVar6 = FUN_00473fa0(0);
        *(undefined4 *)(pcVar6 + 10) = *(undefined4 *)(*(int *)(param_1 + 8) + 8);
        DAT_005882d8 = FUN_00492070();
        return pcVar6;
      }
      if ((pcVar6[6] == '\x01') && (*(char *)(param_1 + 0x20) == '\0')) {
        pcVar6 = FUN_00473fa0(4);
        *(undefined4 *)(pcVar6 + 10) = *(undefined4 *)(*(int *)(param_1 + 8) + 8);
        *(undefined4 *)(pcVar6 + 0xe) = *(undefined4 *)(*(int *)(param_1 + 8) + 0xc);
        DAT_005882d8 = FUN_00492070();
        return pcVar6;
      }
    }
    DAT_005882d8 = FUN_00492070();
    pcVar6 = (char *)FUN_004f9bb0(*(char **)(param_1 + 8),*(uint *)(param_1 + 0xc));
    return pcVar6;
  }
  puVar11 = *(undefined1 **)(param_1 + 0x10);
  if (puVar11 != (undefined1 *)0x0) {
    switch(*puVar11) {
    case 0:
      FUN_004e9590(*(int **)(param_1 + 0x18),(int)puVar11);
      bVar4 = false;
      iVar10 = *(int *)(param_1 + 0x10);
      if ((*(int *)(iVar10 + 0xe) == 0) && (*(int *)(iVar10 + 0x12) == 0)) {
        bVar4 = true;
      }
      if ((((bVar4) && (pcVar6 = *(char **)(iVar10 + 10), *pcVar6 == '\x03')) &&
          (*(int *)(pcVar6 + 6) != 0)) &&
         ((iVar1 = *(int *)(*(int *)(pcVar6 + 6) + 0xc), iVar1 != 0 &&
          ((*(ushort *)(iVar1 + 0x2a) & 0x100) != 0)))) {
        iVar12 = 0;
        pcVar6 = (char *)0x0;
        for (puVar9 = *(undefined4 **)(iVar1 + 0x52); puVar9 != (undefined4 *)0x0;
            puVar9 = (undefined4 *)*puVar9) {
          if (*(char *)((int)puVar9 + 0x26) == '\x03') {
            if ((char *)puVar9[8] == (char *)0x0) {
              iVar12 = iVar12 + 1;
            }
            else {
              iVar12 = 0;
              pcVar6 = (char *)puVar9[8];
            }
            if (puVar9[7] == iVar10) {
              if (pcVar6 == (char *)0x0) {
                FUN_00445780();
              }
              pcVar6 = FUN_00513040(pcVar6,0);
              if (iVar12 != 0) {
                uVar14 = 0xf;
                puVar11 = FUN_00473f30(&DAT_0055f5f0,iVar12);
                pcVar6 = (char *)FUN_00473e30((int)pcVar6,(int)puVar11,uVar14);
              }
              DAT_005882d8 = FUN_00492070();
              return pcVar6;
            }
          }
        }
      }
      pcVar6 = (char *)FUN_00441fa0(0x1a);
      *pcVar6 = '2';
      pcVar6[1] = '\0';
      pcVar6[2] = '\0';
      pcVar6[3] = '\0';
      *(undefined4 *)(pcVar6 + 6) = *(undefined4 *)(*(int *)(param_1 + 0x10) + 10);
      uVar7 = *(undefined4 *)(*(int *)(param_1 + 0x10) + 0x12);
      *(undefined4 *)(pcVar6 + 10) = *(undefined4 *)(*(int *)(param_1 + 0x10) + 0xe);
      *(undefined4 *)(pcVar6 + 0xe) = uVar7;
      DAT_005882d8 = FUN_00492070();
      return pcVar6;
    default:
      FUN_00445780();
      break;
    case 4:
      if (((param_3 == '\0') || (param_2 != (byte *)0x0)) || (*(char *)(param_1 + 0x1d) == '\0')) {
        if (*(char *)(param_1 + 0x1e) != '\0') {
          FUN_004463d0(0xbc);
        }
        piVar2 = *(int **)(param_1 + 0x18);
        iVar10 = *(int *)(param_1 + 0x10);
        if (piVar2 == (int *)0x0) {
          FUN_00445780();
        }
        if (*(int *)(piVar2[1] + 0x22) == 0) {
          piVar13 = (int *)0x0;
          if (*(char *)(iVar10 + 3) != '\0') {
            piVar13 = *(int **)(iVar10 + 0x18);
          }
          pbVar8 = FUN_004719c0(piVar2,piVar13,param_2,*(char *)(iVar10 + 1),'\x01');
          if (pbVar8 == (byte *)0x0) {
            pcVar6 = FUN_00473f70();
          }
          else {
            pcVar6 = (char *)FUN_004e8fc0((int)pbVar8,*(char **)(iVar10 + 0xc),
                                          *(uint *)(iVar10 + 0x10),*(uint *)(iVar10 + 0x14));
          }
        }
        else {
          pcVar6 = (char *)FUN_004e38b0(piVar2,iVar10,(char *)param_2);
        }
        if ((**(char **)(pcVar6 + 6) == '\v') &&
           ((*(uint *)(*(char **)(pcVar6 + 6) + 10) & 0x20) != 0)) {
          pcVar6 = (char *)FUN_00473ea0((int)pcVar6,4);
          *(undefined4 *)(pcVar6 + 6) = *(undefined4 *)(*(int *)(pcVar6 + 6) + 6);
        }
        DAT_005882d8 = FUN_00492070();
        return pcVar6;
      }
      break;
    case 5:
      if (((*(int *)(puVar11 + 6) != 0) &&
          (iVar10 = *(int *)(*(int *)(puVar11 + 6) + 0xc), iVar10 != 0)) &&
         ((*(ushort *)(iVar10 + 0x2a) & 0x100) != 0)) {
        pcVar6 = FUN_00473fa0(5);
        *(undefined4 *)(pcVar6 + 10) = *(undefined4 *)(param_1 + 0x10);
        DAT_005882d8 = FUN_00492070();
        return pcVar6;
      }
      pcVar6 = *(char **)(puVar11 + 0xe);
      if (((*pcVar6 != '\x06') || ((*(uint *)(pcVar6 + 0x16) & 0x10) == 0)) ||
         (pcVar6[0x26] != '\0')) {
        DAT_005882d8 = FUN_00492070();
        if ((DAT_005882d8 == 0x3c) && (pcVar6 = FUN_004f9a60(param_1), pcVar6 != (char *)0x0)) {
          return pcVar6;
        }
        iVar10 = *(int *)(param_1 + 0x10);
        if ((*(char *)(iVar10 + 2) == '\x01') && (**(int **)(iVar10 + 0x26) != DAT_00588238)) {
          FUN_004463d0(0x14a);
          pcVar6 = FUN_00473f70();
          return pcVar6;
        }
        if (*(char *)(iVar10 + 2) == '\a') {
          pcVar6 = FUN_00513040(*(char **)(iVar10 + 0x26),0);
          if ((**(char **)(pcVar6 + 6) == '\v') && (*pcVar6 == '2')) {
            pcVar6 = (char *)FUN_00473ea0((int)pcVar6,0x30);
            *(undefined **)(*(int *)(pcVar6 + 10) + 6) = &DAT_0055f5f8;
          }
          return pcVar6;
        }
        FUN_004e9600(*(int **)(param_1 + 0x18),iVar10);
        if ((((DAT_005882d8 == 0x28) && (param_4 != '\0')) &&
            (*(char *)(*(int *)(param_1 + 0x10) + 2) == '\x03')) &&
           (((DAT_0058427a != '\0' && (*(char *)(param_1 + 0x1d) == '\0')) &&
            ((*(uint *)(*(int *)(*(int *)(param_1 + 0x10) + 0xe) + 0x16) & 0x10) == 0)))) {
          pcVar6 = FUN_00473fd0(0x43);
          *(undefined4 *)(pcVar6 + 6) = *(undefined4 *)(*(int *)(param_1 + 0x10) + 0xe);
          iVar10 = FUN_00441fe0(8);
          *(int *)(pcVar6 + 10) = iVar10;
          **(undefined4 **)(pcVar6 + 10) = *(undefined4 *)(param_1 + 0x14);
          *(undefined4 *)(*(int *)(pcVar6 + 10) + 4) = *(undefined4 *)(param_1 + 0x10);
          *(undefined4 *)(pcVar6 + 0x12) = *(undefined4 *)(*(int *)(param_1 + 0x10) + 10);
          return pcVar6;
        }
        pcVar6 = (char *)FUN_00472830(*(int *)(param_1 + 0x10));
        return pcVar6;
      }
      uVar7 = FUN_004ebc40((int)puVar11);
      if ((char)uVar7 != '\0') {
        DAT_005882d8 = FUN_00492070();
        if (DAT_005882d8 != 0x28) {
          FUN_004463d0(0x72);
          pcVar6 = FUN_00473f70();
          return pcVar6;
        }
        DAT_005882d8 = FUN_00492070();
        if (DAT_005882d8 != 0x29) {
          FUN_004463d0(0x73);
          pcVar6 = FUN_00473f70();
          return pcVar6;
        }
        if (param_2 == (byte *)0x0) {
          FUN_004463d0(0x8d);
          DAT_005882d8 = FUN_00492070();
          pcVar6 = FUN_00473f70();
          return pcVar6;
        }
        if (*(char *)(param_1 + 0x1e) != '\0') {
          FUN_004463d0(0xbc);
        }
        pbVar8 = FUN_004719c0(*(int **)(param_1 + 0x18),(int *)0x0,param_2,
                              *(char *)(*(int *)(param_1 + 0x10) + 1),'\x01');
        param_2 = (byte *)0x0;
        if (pbVar8 != (byte *)0x0) {
          DAT_005882d8 = FUN_00492070();
          pcVar6 = FUN_0050a260(*(int *)(param_1 + 0x10),*(int *)(pbVar8 + 10),1,
                                *(char *)(param_1 + 0x1d),'\0');
          return pcVar6;
        }
      }
    }
    puVar9 = (undefined4 *)FUN_00441fa0(0x14);
    FUN_00441db0((undefined1 *)puVar9,0x14);
    *puVar9 = *(undefined4 *)(param_1 + 0x18);
    puVar9[1] = param_2;
    *(undefined1 *)(puVar9 + 4) = *(undefined1 *)(param_1 + 0x1d);
    *(undefined1 *)((int)puVar9 + 0x12) = *(undefined1 *)(param_1 + 0x1e);
    DAT_005882d8 = FUN_00492070();
    if ((DAT_005882d8 == 0x3c) && (pcVar6 = FUN_004f9a60(param_1), pcVar6 != (char *)0x0)) {
      if (*pcVar6 != 'C') {
        FUN_00445780();
      }
      puVar9[2] = *(undefined4 *)(pcVar6 + 10);
      puVar9[3] = *(undefined4 *)(pcVar6 + 0xe);
    }
    else {
      iVar10 = FUN_00441fe0(8);
      puVar9[2] = iVar10;
      *(undefined4 *)puVar9[2] = 0;
      *(undefined4 *)(puVar9[2] + 4) = *(undefined4 *)(param_1 + 0x10);
    }
    pcVar6 = FUN_00473fd0(0x44);
    *(undefined1 **)(pcVar6 + 6) = &DAT_0055d5d0;
    *(undefined4 **)(pcVar6 + 10) = puVar9;
    return pcVar6;
  }
  if (*(int *)(param_1 + 0x14) != 0) {
    DAT_005882d8 = FUN_00492070();
    if ((DAT_005882d8 == 0x3c) && (pcVar6 = FUN_004f9a60(param_1), pcVar6 != (char *)0x0)) {
      if (*pcVar6 != 'C') {
        FUN_00445780();
      }
      puVar9 = *(undefined4 **)(pcVar6 + 10);
      while( true ) {
        if (puVar9 == (undefined4 *)0x0) {
          return pcVar6;
        }
        if ((((*(char *)puVar9[1] == '\x05') &&
             (pcVar3 = *(char **)((char *)puVar9[1] + 0xe), *pcVar3 == '\x06')) &&
            ((*(uint *)(pcVar3 + 0x16) & 0x10) != 0)) && (pcVar3[0x26] == '\0')) break;
        puVar9 = (undefined4 *)*puVar9;
      }
      puVar9 = (undefined4 *)FUN_00441fa0(0x14);
      FUN_00441db0((undefined1 *)puVar9,0x14);
      *puVar9 = *(undefined4 *)(param_1 + 0x18);
      puVar9[1] = param_2;
      puVar9[2] = *(undefined4 *)(pcVar6 + 10);
      puVar9[3] = *(undefined4 *)(pcVar6 + 0xe);
      *(undefined1 *)(puVar9 + 4) = *(undefined1 *)(param_1 + 0x1d);
      *(undefined1 *)((int)puVar9 + 0x12) = *(undefined1 *)(param_1 + 0x1e);
      pcVar6 = FUN_00473fd0(0x44);
      *(undefined1 **)(pcVar6 + 6) = &DAT_0055d5d0;
      *(undefined4 **)(pcVar6 + 10) = puVar9;
      return pcVar6;
    }
    puVar9 = *(undefined4 **)(param_1 + 0x14);
    while( true ) {
      if (puVar9 == (undefined4 *)0x0) {
        if ((DAT_005882d8 == 0x3c) && (pcVar6 = FUN_004f9a60(param_1), pcVar6 != (char *)0x0)) {
          return pcVar6;
        }
        pcVar6 = FUN_00473fd0(0x43);
        *(undefined4 *)(pcVar6 + 6) = *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x14) + 4) + 0xe);
        *(undefined4 *)(pcVar6 + 10) = *(undefined4 *)(param_1 + 0x14);
        if ((((DAT_005882d8 == 0x28) && (DAT_0058427a != '\0')) && (param_4 != '\0')) &&
           ((*(char *)(param_1 + 0x1d) == '\0' &&
            (pcVar3 = *(char **)(*(int *)(param_1 + 0x14) + 4), *pcVar3 == '\x05')))) {
          *(undefined4 *)(pcVar6 + 0x12) = *(undefined4 *)(pcVar3 + 10);
        }
        return pcVar6;
      }
      if (((*(char *)puVar9[1] == '\x05') &&
          (pcVar6 = *(char **)((char *)puVar9[1] + 0xe), *pcVar6 == '\x06')) &&
         (((*(uint *)(pcVar6 + 0x16) & 0x10) != 0 && (pcVar6[0x26] == '\0')))) break;
      puVar9 = (undefined4 *)*puVar9;
    }
    puVar9 = (undefined4 *)FUN_00441fa0(0x14);
    FUN_00441db0((undefined1 *)puVar9,0x14);
    *puVar9 = *(undefined4 *)(param_1 + 0x18);
    puVar9[1] = param_2;
    puVar9[2] = *(undefined4 *)(param_1 + 0x14);
    *(undefined1 *)(puVar9 + 4) = *(undefined1 *)(param_1 + 0x1d);
    *(undefined1 *)((int)puVar9 + 0x12) = *(undefined1 *)(param_1 + 0x1e);
    pcVar6 = FUN_00473fd0(0x44);
    *(undefined1 **)(pcVar6 + 6) = &DAT_0055d5d0;
    *(undefined4 **)(pcVar6 + 10) = puVar9;
    return pcVar6;
  }
  if (*(int *)(param_1 + 4) == 0) {
    FUN_00445780();
    return (char *)0x0;
  }
  if ((DAT_0058427a != '\0') && (param_4 != '\0')) {
    sVar5 = FUN_004925d0();
    if (sVar5 != 0x28) {
      FUN_004463d0(0x8c);
      DAT_005882d8 = FUN_00492070();
      pcVar6 = FUN_00473f70();
      return pcVar6;
    }
    pcVar6 = FUN_00473fd0(0x43);
    *(undefined1 **)(pcVar6 + 6) = &DAT_0055d5d0;
    *(undefined4 *)(pcVar6 + 0x12) = *(undefined4 *)(param_1 + 4);
    DAT_005882d8 = FUN_00492070();
    return pcVar6;
  }
  sVar5 = FUN_004925d0();
  if (sVar5 == 0x28) {
    if (DAT_00584280 != '\0') {
      FUN_004463d0(0xb2);
    }
    pcVar6 = FUN_0048ffd0((undefined4 *)0x0);
    *(undefined4 *)(pcVar6 + 10) = *(undefined4 *)(param_1 + 4);
    pcVar6[0x16] = '\x03';
    pcVar6[0x17] = '\x01';
    puVar11 = (undefined1 *)FUN_00441fe0(0x1a);
    FUN_00441db0(puVar11,0x1a);
    *puVar11 = 6;
    *(undefined1 **)(puVar11 + 0xe) = &DAT_0055f5e0;
    *(undefined **)(puVar11 + 6) = &DAT_00584748;
    FUN_00504240();
    *(undefined1 **)(pcVar6 + 0xe) = puVar11;
    FUN_0049ac80(pcVar6);
    DAT_005882d8 = FUN_00492070();
    pcVar6 = FUN_00472960((int)pcVar6);
    return pcVar6;
  }
  FUN_004463d0(0x8c);
  DAT_005882d8 = FUN_00492070();
  pcVar6 = FUN_00473f70();
  return pcVar6;
}



void __cdecl FUN_00473e30(int param_1,int param_2,undefined1 param_3)

{
  char cVar1;
  undefined1 *puVar2;
  
  puVar2 = (undefined1 *)FUN_00441fa0(0x1a);
  *puVar2 = param_3;
  *(undefined4 *)(puVar2 + 6) = *(undefined4 *)(param_1 + 6);
  *(int *)(puVar2 + 10) = param_1;
  *(int *)(puVar2 + 0xe) = param_2;
  cVar1 = *(char *)(param_2 + 1);
  if (*(char *)(param_1 + 1) == cVar1) {
    puVar2[1] = cVar1 + '\x01';
    if (200 < (byte)puVar2[1]) {
      puVar2[1] = 200;
    }
  }
  else {
    puVar2[1] = cVar1;
    if ((byte)puVar2[1] < *(byte *)(param_1 + 1)) {
      puVar2[1] = *(byte *)(param_1 + 1);
    }
  }
  *(ushort *)(puVar2 + 2) = (*(ushort *)(param_1 + 2) | *(ushort *)(param_2 + 2)) & 3;
  return;
}


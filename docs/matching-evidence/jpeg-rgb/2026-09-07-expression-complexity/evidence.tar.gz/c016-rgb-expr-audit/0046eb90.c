
undefined1 * __cdecl
FUN_0046eb90(int *param_1,byte *param_2,char param_3,char *param_4,int *param_5,undefined4 param_6,
            int *param_7,char param_8,char param_9,char param_10)

{
  byte *pbVar1;
  char *pcVar2;
  char *pcVar3;
  char cVar4;
  char cVar5;
  int iVar6;
  undefined1 *puVar7;
  undefined1 *puVar8;
  int *piVar9;
  byte *pbVar10;
  int *piVar11;
  undefined4 *puVar12;
  char *local_38 [6];
  undefined4 *local_1e;
  int local_18;
  char *local_14;
  
  FUN_00441db0((undefined1 *)local_38,0x1e);
  if ((param_4 == (char *)0x0) ||
     ((**(char **)(param_4 + 0xe) == '\x06' &&
      ((*(uint *)(*(char **)(param_4 + 0xe) + 0x16) & 0x400) != 0)))) {
    if ((param_2 == (byte *)0x0) &&
       (((DAT_00588238 != 0 && (DAT_00588040 != 0)) && (DAT_005884f8 != '\0')))) {
      iVar6 = FUN_004e9940();
      param_2 = (byte *)0x0;
      if (iVar6 != 0) {
        param_2 = (byte *)FUN_00441fa0(0x1a);
        *param_2 = 4;
        param_2[1] = *(byte *)(iVar6 + 1);
        if (param_2[1] == 0) {
          param_2[1] = 1;
        }
        *(ushort *)(param_2 + 2) = *(ushort *)(iVar6 + 2) & 3;
        *(undefined4 *)(param_2 + 6) = *(undefined4 *)(iVar6 + 6);
        *(int *)(param_2 + 10) = iVar6;
        *(int *)(param_2 + 6) = DAT_00588040;
      }
    }
    if (param_4 != (char *)0x0) {
      local_18 = 0;
      local_14 = param_4;
      param_5 = &local_18;
    }
    FUN_0046f760(param_5,param_6,param_7,(int *)local_38,(int)param_2,param_8);
    if (local_38[0] == (char *)0x0) {
      FUN_00445cc0(0xf8,param_5,param_7);
      puVar7 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar7,0x1a);
      *puVar7 = 0x32;
      *(undefined1 **)(puVar7 + 6) = &DAT_0055f5f0;
      return puVar7;
    }
    param_4 = local_38[0];
    if (local_1e != (undefined4 *)0x0) {
      FUN_00445960((int)local_38[0],local_1e);
      param_4 = local_38[0];
    }
  }
  if ((DAT_00587fd8 == (code *)0x0) || (cVar4 = (*DAT_00587fd8)(0,param_4), cVar4 != '\0')) {
    if (*(short *)(param_4 + 0x16) == 0x104) {
      FUN_004463d0(0x8d);
      puVar8 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar8,0x1a);
      *puVar8 = 0x32;
      *(undefined4 *)(puVar8 + 6) = 0x55d5d8;
      *(undefined4 *)(puVar8 + 0xe) = 0;
      *(undefined4 *)(puVar8 + 10) = 0;
    }
    else {
      puVar8 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar8,0x1a);
      *puVar8 = 0x38;
      *(char **)(puVar8 + 10) = param_4;
      puVar7 = FUN_00504930(*(undefined4 *)(param_4 + 0xe));
      *(undefined1 **)(puVar8 + 6) = puVar7;
      if (**(char **)(param_4 + 0xe) != '\x06') {
        *(ushort *)(puVar8 + 2) = *(ushort *)(param_4 + 0x12) & 3;
      }
      param_4[0x18] = param_4[0x18] | 1;
    }
  }
  else {
    puVar8 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar8,0x1a);
    *puVar8 = 0x32;
    *(undefined4 *)(puVar8 + 6) = 0x55d5d8;
    *(undefined4 *)(puVar8 + 0xe) = 0;
    *(undefined4 *)(puVar8 + 10) = 0;
  }
  pcVar2 = *(char **)(param_4 + 0xe);
  if (*pcVar2 != '\x06') {
    FUN_004463d0(0xa1);
    puVar7 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar7,0x1a);
    *puVar7 = 0x32;
    *(undefined1 **)(puVar7 + 6) = &DAT_0055f5f0;
    return puVar7;
  }
  if (((*(uint *)(pcVar2 + 0x16) & 0x10) == 0) || (pcVar2[0x26] != '\0')) {
    if ((param_10 != '\0') && (param_4[1] != '\x02')) {
      FUN_004e9600(param_1,(int)param_4);
    }
    puVar12 = *(undefined4 **)(pcVar2 + 6);
    piVar11 = param_7;
    if (((*(uint *)(pcVar2 + 0x16) & 0x10) != 0) && (*(int *)(*(int *)(pcVar2 + 0x1a) + 0x22) != 0))
    {
      FUN_00445780();
    }
  }
  else {
    cVar4 = param_4[1];
    piVar11 = (int *)0x0;
    while (param_4[2] == '\x06') {
      if (piVar11 == (int *)0x0) {
        piVar11 = FUN_004eba60(*(int **)(param_4 + 0x2a),'\0');
      }
      else {
        piVar9 = FUN_004eba60(*(int **)(param_4 + 0x2a),'\0');
        piVar11 = FUN_004eba20(piVar11,piVar9);
      }
      param_4 = *(char **)(param_4 + 0x26);
      if ((DAT_00587fd8 == (code *)0x0) || (cVar5 = (*DAT_00587fd8)(0,param_4), cVar5 != '\0')) {
        if (*(short *)(param_4 + 0x16) == 0x104) {
          FUN_004463d0(0x8d);
          puVar8 = (undefined1 *)FUN_00441fa0(0x1a);
          FUN_00441db0(puVar8,0x1a);
          *puVar8 = 0x32;
          *(undefined4 *)(puVar8 + 6) = 0x55d5d8;
          *(undefined4 *)(puVar8 + 0xe) = 0;
          *(undefined4 *)(puVar8 + 10) = 0;
        }
        else {
          puVar8 = (undefined1 *)FUN_00441fa0(0x1a);
          FUN_00441db0(puVar8,0x1a);
          *puVar8 = 0x38;
          *(char **)(puVar8 + 10) = param_4;
          puVar7 = FUN_00504930(*(undefined4 *)(param_4 + 0xe));
          *(undefined1 **)(puVar8 + 6) = puVar7;
          if (**(char **)(param_4 + 0xe) != '\x06') {
            *(ushort *)(puVar8 + 2) = *(ushort *)(param_4 + 0x12) & 3;
          }
          param_4[0x18] = param_4[0x18] | 1;
        }
      }
      else {
        puVar8 = (undefined1 *)FUN_00441fa0(0x1a);
        FUN_00441db0(puVar8,0x1a);
        *puVar8 = 0x32;
        *(undefined4 *)(puVar8 + 6) = 0x55d5d8;
        *(undefined4 *)(puVar8 + 0xe) = 0;
        *(undefined4 *)(puVar8 + 10) = 0;
      }
    }
    if (param_9 != '\0') {
      FUN_004463d0(0xbc);
    }
    if ((*(int *)(*(int *)(pcVar2 + 0x1a) + 0x22) == 0) ||
       (((*(uint *)(param_4 + 0x12) & 0x10) != 0 && ((param_4[2] != '\x04' || (param_3 != '\0'))))))
    {
      if ((param_4[2] == '\x04') &&
         ((param_3 != '\0' ||
          (((DAT_0058429a == '\0' && (param_2 != (byte *)0x0)) &&
           (cVar5 = FUN_0046f3c0((char *)param_2), cVar5 != '\0')))))) {
        *(ushort *)(puVar8 + 2) = *(ushort *)(puVar8 + 2) | 0x80;
      }
      pbVar10 = FUN_004719c0(param_1,piVar11,param_2,cVar4,param_10);
      if (pbVar10 == (byte *)0x0) {
        puVar7 = (undefined1 *)FUN_00441fa0(0x1a);
        FUN_00441db0(puVar7,0x1a);
        *puVar7 = 0x32;
        *(undefined1 **)(puVar7 + 6) = &DAT_0055f5f0;
        return puVar7;
      }
    }
    else {
      piVar9 = FUN_004eba60(param_1,'\0');
      pbVar10 = FUN_004719c0(param_1,piVar11,param_2,cVar4,param_10);
      if (pbVar10 == (byte *)0x0) {
        puVar7 = (undefined1 *)FUN_00441fa0(0x1a);
        FUN_00441db0(puVar7,0x1a);
        *puVar7 = 0x32;
        *(undefined1 **)(puVar7 + 6) = &DAT_0055f5f0;
        return puVar7;
      }
      puVar8 = FUN_004e36d0(piVar9,param_4,param_3);
    }
    if ((((((*(uint *)(pcVar2 + 0x16) & 8) != 0) && (DAT_00588238 != 0)) &&
         (((*(uint *)(*(int *)(DAT_00588238 + 0xe) + 0x16) & 0x6000) != 0 &&
          ((DAT_00588040 == *(int *)(pcVar2 + 0x1a) && (*pbVar10 == 4)))))) &&
        (**(char **)(pbVar10 + 10) == '\x04')) &&
       (((pcVar3 = *(char **)(*(char **)(pbVar10 + 10) + 10), *pcVar3 == '8' &&
         (*(int *)(*(int *)(pcVar3 + 10) + 10) == DAT_00587684)) &&
        ((*(ushort *)(puVar8 + 2) & 0x80) == 0)))) {
      FUN_004457e0(0xc3);
    }
    piVar9 = (int *)FUN_00441fa0(8);
    *piVar9 = (int)param_7;
    piVar9[1] = *(int *)(pbVar10 + 10);
    if (*(char *)piVar9[1] == '8') {
      pbVar1 = (byte *)(*(int *)((char *)piVar9[1] + 10) + 0x18);
      *pbVar1 = *pbVar1 | 2;
    }
    if (((((*(ushort *)(pbVar10 + 2) & 1) != 0) &&
         ((*(uint *)(*(int *)(pcVar2 + 6) + 0x10) & 1) == 0)) ||
        (((*(ushort *)(pbVar10 + 2) & 2) != 0 && ((*(uint *)(*(int *)(pcVar2 + 6) + 0x10) & 2) == 0)
         ))) && ((*(uint *)(pcVar2 + 0x16) & 0x6000) == 0)) {
      FUN_004463d0(0xec);
    }
    puVar12 = (undefined4 *)**(undefined4 **)(pcVar2 + 6);
    piVar11 = (int *)*piVar9;
    param_7 = piVar9;
  }
  for (; piVar11 != (int *)0x0; piVar11 = (int *)*piVar11) {
    if (((puVar12 == (undefined4 *)0x0) || (puVar12 == (undefined4 *)&DAT_00583098)) ||
       (puVar12 == (undefined4 *)&DAT_00584748)) {
      if (puVar12 == (undefined4 *)0x0) {
        local_18 = 0;
        local_14 = param_4;
        FUN_00445cc0(0xf8,&local_18,param_7);
      }
      pbVar10 = FUN_0046f260((byte *)piVar11[1],puVar12 == (undefined4 *)&DAT_00583098);
      piVar11[1] = (int)pbVar10;
    }
    else {
      iVar6 = FUN_004f9ed0((byte *)piVar11[1],(char *)puVar12[3],*(ushort *)(puVar12 + 4),1);
      piVar11[1] = iVar6;
      puVar12 = (undefined4 *)*puVar12;
    }
  }
  if (puVar12 != (undefined4 *)0x0) {
    if ((puVar12 != (undefined4 *)&DAT_00583098) && (puVar12 != (undefined4 *)&DAT_00584748)) {
      if (puVar12[2] != 0) goto LAB_0046f23e;
      local_18 = 0;
      local_14 = param_4;
      FUN_00445cc0(0xf8,&local_18,param_7);
    }
    puVar12 = (undefined4 *)0x0;
  }
LAB_0046f23e:
  puVar7 = (undefined1 *)FUN_0046f660((int)puVar8,param_7,(int)pcVar2,puVar12);
  return puVar7;
}


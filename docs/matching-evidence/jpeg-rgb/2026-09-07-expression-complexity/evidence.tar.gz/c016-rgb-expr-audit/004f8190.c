
/* WARNING: Removing unreachable block (ram,0x004f887a) */
/* WARNING: Removing unreachable block (ram,0x004f8777) */
/* WARNING: Removing unreachable block (ram,0x004f86d7) */
/* WARNING: Removing unreachable block (ram,0x004f8602) */
/* WARNING: Removing unreachable block (ram,0x004f866b) */
/* WARNING: Removing unreachable block (ram,0x004f8707) */
/* WARNING: Removing unreachable block (ram,0x004f8844) */
/* WARNING: Removing unreachable block (ram,0x004f88a7) */

char * __cdecl FUN_004f8190(char param_1)

{
  char cVar1;
  char cVar2;
  undefined1 *puVar3;
  undefined *puVar4;
  undefined1 *puVar5;
  byte *pbVar6;
  byte *pbVar7;
  byte *pbVar8;
  uint uVar9;
  undefined4 uVar10;
  char *pcVar11;
  int iVar12;
  char *pcVar13;
  char *pcVar14;
  char *pcVar15;
  int local_38 [9];
  byte *local_14 [3];
  
  if (DAT_005882d8 == 0x158) {
    pcVar11 = (char *)FUN_00441fa0(0x1a);
    *pcVar11 = '2';
    pcVar11[1] = '\0';
    pcVar11[2] = '\0';
    pcVar11[3] = '\0';
    *(undefined1 **)(pcVar11 + 6) = &DAT_0055f5a8;
    pcVar11[0xe] = '\x01';
    pcVar11[0xf] = '\0';
    pcVar11[0x10] = '\0';
    pcVar11[0x11] = '\0';
    pcVar11[10] = '\0';
    pcVar11[0xb] = '\0';
    pcVar11[0xc] = '\0';
    pcVar11[0xd] = '\0';
    DAT_005882d8 = FUN_00492070();
    return pcVar11;
  }
  if (DAT_005882d8 == 0x159) {
    pcVar11 = (char *)FUN_00441fa0(0x1a);
    *pcVar11 = '2';
    pcVar11[1] = '\0';
    pcVar11[2] = '\0';
    pcVar11[3] = '\0';
    *(undefined1 **)(pcVar11 + 6) = &DAT_0055f5a8;
    pcVar11[0xe] = '\0';
    pcVar11[0xf] = '\0';
    pcVar11[0x10] = '\0';
    pcVar11[0x11] = '\0';
    pcVar11[10] = '\0';
    pcVar11[0xb] = '\0';
    pcVar11[0xc] = '\0';
    pcVar11[0xd] = '\0';
    DAT_005882d8 = FUN_00492070();
    return pcVar11;
  }
  if (DAT_005882d8 == -1) {
    pcVar11 = (char *)FUN_00441fa0(0x1a);
    *pcVar11 = '2';
    pcVar11[1] = '\0';
    pcVar11[2] = '\0';
    pcVar11[3] = '\0';
    puVar3 = FUN_0048fe70();
    *(undefined1 **)(pcVar11 + 6) = puVar3;
    uVar10 = DAT_00584764;
    *(undefined4 *)(pcVar11 + 10) = DAT_00584760;
    *(undefined4 *)(pcVar11 + 0xe) = uVar10;
    DAT_005882d8 = FUN_00492070();
    return pcVar11;
  }
  if (DAT_005882d8 == -2) {
    pcVar11 = (char *)FUN_00441fa0(0x1a);
    *pcVar11 = '3';
    pcVar11[1] = '\0';
    pcVar11[2] = '\0';
    pcVar11[3] = '\0';
    puVar3 = FUN_0048fe70();
    *(undefined1 **)(pcVar11 + 6) = puVar3;
    uVar10 = DAT_005868dc;
    *(undefined4 *)(pcVar11 + 10) = DAT_005868d8;
    *(undefined4 *)(pcVar11 + 0xe) = uVar10;
    DAT_005882d8 = FUN_00492070();
    return pcVar11;
  }
  if (DAT_005882d8 == -4) {
    puVar3 = FUN_00473fd0(0x34);
    if (DAT_005882de == 0) {
      puVar4 = &DAT_0055f5b0;
    }
    else {
      puVar4 = &DAT_0055f5c0;
    }
    puVar5 = FUN_00504960(puVar4,DAT_00588004);
    *(undefined1 **)(puVar3 + 6) = puVar5;
    *(undefined4 *)(puVar3 + 10) = DAT_00588004;
    *(undefined4 *)(puVar3 + 0xe) = DAT_00588058;
    puVar3[0x12] = (undefined1)DAT_005882de;
    if (DAT_005842b4 != '\0') {
      *(undefined2 *)(puVar3 + 2) = 1;
    }
    pcVar11 = (char *)FUN_00473ea0((int)puVar3,4);
    puVar3 = FUN_00504930(*(undefined4 *)(pcVar11 + 6));
    *(undefined1 **)(*(int *)(pcVar11 + 10) + 6) = puVar3;
    DAT_005882d8 = FUN_00492070();
    return pcVar11;
  }
  if (DAT_005882d8 == -5) {
    puVar3 = FUN_00473fd0(0x34);
    uVar10 = DAT_00588004;
    puVar4 = FUN_0048f2b0();
    puVar5 = FUN_00504960(puVar4,uVar10);
    *(undefined1 **)(puVar3 + 6) = puVar5;
    *(undefined4 *)(puVar3 + 10) = DAT_00588004;
    *(undefined4 *)(puVar3 + 0xe) = DAT_00588058;
    puVar3[0x12] = (undefined1)DAT_005882de;
    if (DAT_005842b4 != '\0') {
      *(undefined2 *)(puVar3 + 2) = 1;
    }
    pcVar11 = (char *)FUN_00473ea0((int)puVar3,4);
    puVar3 = FUN_00504930(*(undefined4 *)(pcVar11 + 6));
    *(undefined1 **)(*(int *)(pcVar11 + 10) + 6) = puVar3;
    DAT_005882d8 = FUN_00492070();
    return pcVar11;
  }
  if ((DAT_005882d8 == 0x14d) || (DAT_005882d8 == 0x180)) {
    pcVar11 = (char *)FUN_004e9940();
    if (pcVar11 == (char *)0x0) {
      pcVar11 = FUN_00473f70();
    }
    DAT_005882d8 = FUN_00492070();
    return pcVar11;
  }
  if (DAT_005882d8 == 0x17d) {
    pcVar11 = FUN_005049d0();
    return pcVar11;
  }
  if (DAT_005882d8 == 0x17e) {
    pcVar11 = FUN_00504e40();
    return pcVar11;
  }
  if (DAT_005882d8 == 0x177) {
    pcVar11 = FUN_00504be0();
    return pcVar11;
  }
  if (DAT_005882d8 == 0x40) {
    if (DAT_0058427c != '\0') {
      pcVar11 = FUN_00504c90();
      return pcVar11;
    }
  }
  else {
    if (DAT_005882d8 == 0x28) {
      DAT_005882d8 = FUN_00492070();
      pbVar8 = FUN_004f1010();
      while (DAT_005882d8 == 0x2c) {
        pcVar11 = FUN_004fa340((char *)pbVar8);
        pbVar6 = (byte *)FUN_004fb4c0(pcVar11);
        DAT_005882d8 = FUN_00492070();
        pbVar8 = FUN_004f1010();
        pcVar11 = FUN_004fa340((char *)pbVar8);
        pbVar7 = (byte *)FUN_004fb4c0(pcVar11);
        if ((DAT_0058427a == '\0') ||
           (uVar10 = FUN_0046d220(0x2c,pbVar6,pbVar7,(int *)local_14), pbVar8 = local_14[0],
           (char)uVar10 == '\0')) {
          FUN_004f0e20(pbVar6);
          pbVar8 = (byte *)FUN_00473cf0((int)pbVar6,pbVar7);
          *(undefined4 *)(pbVar8 + 6) = *(undefined4 *)(pbVar7 + 6);
        }
        else if (local_14[0] == (byte *)0x0) {
          FUN_00445780();
        }
      }
      if (DAT_005882d8 == 0x29) {
        DAT_005882d8 = FUN_00492070();
      }
      else {
        FUN_004461e0(0x73);
      }
      if (*pbVar8 == 0x1e) {
        *(ushort *)(pbVar8 + 2) = *(ushort *)(pbVar8 + 2) | 0x80;
      }
      return (char *)pbVar8;
    }
    if (DAT_005882d8 != 0x5b) {
      if (DAT_005882d8 == -3) {
        if ((*(char *)(DAT_00587fa0 + 10) == '_') && (*(char *)(DAT_00587fa0 + 0xb) == '_')) {
          iVar12 = 0x10;
          pcVar11 = (char *)(DAT_00587fa0 + 10);
          pcVar14 = s___builtin_align_005727e4;
          do {
            pcVar13 = pcVar11;
            pcVar15 = pcVar14;
            if (iVar12 == 0) break;
            iVar12 = iVar12 + -1;
            pcVar15 = pcVar14 + 1;
            pcVar13 = pcVar11 + 1;
            cVar2 = *pcVar14;
            cVar1 = *pcVar11;
            pcVar11 = pcVar13;
            pcVar14 = pcVar15;
          } while (cVar1 == cVar2);
          if (pcVar13[-1] == pcVar15[-1]) {
            pcVar11 = FUN_00473f30(&DAT_0055f5e0,0);
            pbVar8 = FUN_004f8960();
            iVar12 = FUN_004a80a0(pbVar8);
            *(int *)(pcVar11 + 0xe) = (int)(short)iVar12;
            if ((short)iVar12 < 0) {
              uVar10 = 0xffffffff;
            }
            else {
              uVar10 = 0;
            }
            *(undefined4 *)(pcVar11 + 10) = uVar10;
            return pcVar11;
          }
          iVar12 = 0x10;
          pcVar11 = (char *)(DAT_00587fa0 + 10);
          pcVar14 = s___builtin_ntype_005727f4;
          do {
            pcVar13 = pcVar11;
            pcVar15 = pcVar14;
            if (iVar12 == 0) break;
            iVar12 = iVar12 + -1;
            pcVar15 = pcVar14 + 1;
            pcVar13 = pcVar11 + 1;
            cVar2 = *pcVar14;
            cVar1 = *pcVar11;
            pcVar11 = pcVar13;
            pcVar14 = pcVar15;
          } while (cVar1 == cVar2);
          if (pcVar13[-1] == pcVar15[-1]) {
            pcVar11 = FUN_00473f30(&DAT_0055f5e0,0);
            pbVar8 = FUN_004f8960();
            uVar9 = FUN_004f8b50(pbVar8);
            *(uint *)(pcVar11 + 0xe) = uVar9;
            if ((int)uVar9 < 0) {
              uVar10 = 0xffffffff;
            }
            else {
              uVar10 = 0;
            }
            *(undefined4 *)(pcVar11 + 10) = uVar10;
            return pcVar11;
          }
          iVar12 = 0xf;
          pcVar11 = (char *)(DAT_00587fa0 + 10);
          pcVar14 = s___builtin_type_00572804;
          do {
            pcVar13 = pcVar11;
            pcVar15 = pcVar14;
            if (iVar12 == 0) break;
            iVar12 = iVar12 + -1;
            pcVar15 = pcVar14 + 1;
            pcVar13 = pcVar11 + 1;
            cVar2 = *pcVar14;
            cVar1 = *pcVar11;
            pcVar11 = pcVar13;
            pcVar14 = pcVar15;
          } while (cVar1 == cVar2);
          if (pcVar13[-1] == pcVar15[-1]) {
LAB_004f8720:
            pcVar11 = FUN_00473f30(&DAT_0055f5e0,0);
            pbVar8 = FUN_004f8960();
            iVar12 = FUN_004f8a40((char *)pbVar8);
            *(int *)(pcVar11 + 0xe) = iVar12;
            if (iVar12 < 0) {
              uVar10 = 0xffffffff;
            }
            else {
              uVar10 = 0;
            }
            *(undefined4 *)(pcVar11 + 10) = uVar10;
            return pcVar11;
          }
          iVar12 = 0x13;
          pcVar11 = (char *)(DAT_00587fa0 + 10);
          pcVar14 = s___builtin_vargtype_00572814;
          do {
            pcVar13 = pcVar11;
            pcVar15 = pcVar14;
            if (iVar12 == 0) break;
            iVar12 = iVar12 + -1;
            pcVar15 = pcVar14 + 1;
            pcVar13 = pcVar11 + 1;
            cVar2 = *pcVar14;
            cVar1 = *pcVar11;
            pcVar11 = pcVar13;
            pcVar14 = pcVar15;
          } while (cVar1 == cVar2);
          if (pcVar13[-1] == pcVar15[-1]) goto LAB_004f8720;
          iVar12 = 0x18;
          pcVar11 = (char *)(DAT_00587fa0 + 10);
          pcVar14 = s___builtin_classify_type_00572828;
          do {
            pcVar13 = pcVar11;
            pcVar15 = pcVar14;
            if (iVar12 == 0) break;
            iVar12 = iVar12 + -1;
            pcVar15 = pcVar14 + 1;
            pcVar13 = pcVar11 + 1;
            cVar2 = *pcVar14;
            cVar1 = *pcVar11;
            pcVar11 = pcVar13;
            pcVar14 = pcVar15;
          } while (cVar1 == cVar2);
          if (pcVar13[-1] == pcVar15[-1]) {
            pcVar11 = FUN_00473f30(&DAT_0055f5e0,0);
            pbVar8 = FUN_004f8960();
            switch(*pbVar8) {
            case 0:
              iVar12 = 0;
              break;
            case 1:
              iVar12 = 1;
              break;
            case 2:
              iVar12 = 8;
              break;
            case 3:
              iVar12 = 3;
              break;
            case 4:
              iVar12 = 0xc;
              break;
            case 5:
              iVar12 = 0xc;
              break;
            case 6:
              iVar12 = 10;
              break;
            default:
              iVar12 = -1;
              break;
            case 10:
            case 0xb:
              iVar12 = 5;
              break;
            case 0xc:
              iVar12 = 0xe;
            }
            *(int *)(pcVar11 + 0xe) = iVar12;
            if (iVar12 < 0) {
              uVar10 = 0xffffffff;
            }
            else {
              uVar10 = 0;
            }
            *(undefined4 *)(pcVar11 + 10) = uVar10;
            return pcVar11;
          }
        }
        if (DAT_00584230 != '\0') {
          iVar12 = 9;
          pcVar11 = s_vec_step_00572840;
          pcVar14 = (char *)(DAT_00587fa0 + 10);
          do {
            pcVar13 = pcVar11;
            pcVar15 = pcVar14;
            if (iVar12 == 0) break;
            iVar12 = iVar12 + -1;
            pcVar15 = pcVar14 + 1;
            pcVar13 = pcVar11 + 1;
            cVar2 = *pcVar14;
            cVar1 = *pcVar11;
            pcVar11 = pcVar13;
            pcVar14 = pcVar15;
          } while (cVar1 == cVar2);
          if (pcVar13[-1] == pcVar15[-1]) {
            pcVar11 = FUN_004f8f20();
            return pcVar11;
          }
        }
        iVar12 = 6;
        pcVar11 = &DAT_0057284c;
        pcVar14 = (char *)(DAT_00587fa0 + 10);
        do {
          pcVar13 = pcVar11;
          pcVar15 = pcVar14;
          if (iVar12 == 0) break;
          iVar12 = iVar12 + -1;
          pcVar15 = pcVar14 + 1;
          pcVar13 = pcVar11 + 1;
          cVar2 = *pcVar14;
          cVar1 = *pcVar11;
          pcVar11 = pcVar13;
          pcVar14 = pcVar15;
        } while (cVar1 == cVar2);
        if (pcVar13[-1] != pcVar15[-1]) {
          iVar12 = 0x10;
          pcVar11 = s__var_arg_typeof_00572854;
          pcVar14 = (char *)(DAT_00587fa0 + 10);
          do {
            pcVar13 = pcVar11;
            pcVar15 = pcVar14;
            if (iVar12 == 0) break;
            iVar12 = iVar12 + -1;
            pcVar15 = pcVar14 + 1;
            pcVar13 = pcVar11 + 1;
            cVar2 = *pcVar14;
            cVar1 = *pcVar11;
            pcVar11 = pcVar13;
            pcVar14 = pcVar15;
          } while (cVar1 == cVar2);
          if (pcVar13[-1] != pcVar15[-1]) goto LAB_004f8900;
        }
        pcVar11 = FUN_00473f30(&DAT_0055f5e0,0);
        pbVar8 = FUN_004f8960();
        iVar12 = FUN_004f8a40((char *)pbVar8);
        *(int *)(pcVar11 + 0xe) = iVar12;
        if (iVar12 < 0) {
          uVar10 = 0xffffffff;
        }
        else {
          uVar10 = 0;
        }
        *(undefined4 *)(pcVar11 + 10) = uVar10;
        return pcVar11;
      }
      if ((((DAT_005882d8 != 0x7e) && (DAT_005882d8 != 0x148)) && (DAT_005882d8 != 0x151)) &&
         (DAT_005882d8 != 0x174)) goto LAB_004f8946;
LAB_004f8900:
      uVar10 = FUN_00498fb0(local_38);
      if ((char)uVar10 != '\0') {
        pcVar11 = FUN_004f9090((int)local_38,(byte *)0x0,param_1,'\x01');
        return pcVar11;
      }
      DAT_005882d8 = FUN_00492070();
      pcVar11 = FUN_00473f70();
      return pcVar11;
    }
    if (DAT_0058427c != '\0') {
      pcVar11 = FUN_00504fb0();
      return pcVar11;
    }
  }
LAB_004f8946:
  FUN_004461e0(0x8d);
  pcVar11 = FUN_00473f70();
  return pcVar11;
}



byte * FUN_004f6400(void)

{
  short sVar1;
  undefined4 uVar2;
  char *pcVar3;
  byte *pbVar4;
  undefined *puVar5;
  undefined4 *puVar6;
  undefined1 *puVar7;
  byte *pbVar8;
  undefined8 uVar9;
  int iVar10;
  byte *local_20;
  byte *local_1c;
  byte *local_14;
  byte *local_10;
  
  if (DAT_005882d8 == 0x174) {
    sVar1 = FUN_004925d0();
    if (sVar1 == 0x147) {
      DAT_005882d8 = FUN_00492070();
      pbVar8 = FUN_0046bba0('\x01');
      return pbVar8;
    }
    if (sVar1 == 0x145) {
      DAT_005882d8 = FUN_00492070();
      pbVar8 = FUN_0046b3f0('\x01');
      return pbVar8;
    }
    pbVar8 = FUN_004f73c0('\0');
    return pbVar8;
  }
  if (DAT_005882d8 == 0x147) {
    pbVar8 = FUN_0046bba0('\0');
    return pbVar8;
  }
  if (DAT_005882d8 == 0x145) {
    pbVar8 = FUN_0046b3f0('\0');
    return pbVar8;
  }
  if (DAT_005882d8 == 0x16e) {
    DAT_005882d8 = FUN_00492070();
    pbVar8 = FUN_004f6400();
    pcVar3 = FUN_004fa340((char *)pbVar8);
    pbVar8 = (byte *)FUN_004fb4c0(pcVar3);
    if ((DAT_0058427a != '\0') &&
       (uVar2 = FUN_0046d220(0x16e,pbVar8,(byte *)0x0,(int *)&local_20), (char)uVar2 != '\0')) {
      if (local_20 == (byte *)0x0) {
        FUN_00445780();
      }
      return local_20;
    }
    pbVar8 = FUN_00472ae0(pbVar8,'\x01','\x01');
    if (*(undefined1 **)(pbVar8 + 6) != &DAT_0055f5a8) {
      FUN_004fb400((char *)pbVar8);
      pbVar8 = (byte *)FUN_00473ea0((int)pbVar8,2);
      return pbVar8;
    }
    puVar7 = FUN_00473f70();
    *(undefined1 **)(puVar7 + 6) = &DAT_0055f5a8;
    *(undefined4 *)(puVar7 + 0xe) = 1;
    *(undefined4 *)(puVar7 + 10) = 0;
    pbVar8 = (byte *)FUN_00473e30((int)pbVar8,(int)puVar7,0x1e);
    return pbVar8;
  }
  if (DAT_005882d8 == 0x16f) {
    DAT_005882d8 = FUN_00492070();
    pbVar8 = FUN_004f6400();
    pcVar3 = FUN_004fa340((char *)pbVar8);
    pbVar8 = (byte *)FUN_004fb4c0(pcVar3);
    if ((DAT_0058427a != '\0') &&
       (uVar2 = FUN_0046d220(0x16f,pbVar8,(byte *)0x0,(int *)&local_20), (char)uVar2 != '\0')) {
      if (local_20 == (byte *)0x0) {
        FUN_00445780();
      }
      return local_20;
    }
    pbVar8 = FUN_00472ae0(pbVar8,'\x01','\x01');
    FUN_004fb400((char *)pbVar8);
    pbVar8 = (byte *)FUN_00473ea0((int)pbVar8,3);
    return pbVar8;
  }
  if (DAT_005882d8 == 0x26) {
    if (DAT_0058427a == '\0') {
      DAT_005882d8 = FUN_00492070();
      pbVar8 = (byte *)FUN_004f57a0();
    }
    else {
      DAT_005882d8 = FUN_00492070();
      if (((DAT_005882d8 == -3) || (DAT_005882d8 == 0x151)) || (DAT_005882d8 == 0x174)) {
        pbVar8 = FUN_004f73c0('\x01');
        if (*pbVar8 == 0x44) {
          pbVar8 = (byte *)FUN_004f6e00((char *)pbVar8);
          return pbVar8;
        }
      }
      else {
        pbVar8 = (byte *)FUN_004f57a0();
      }
      uVar2 = FUN_0046d220(0x26,pbVar8,(byte *)0x0,(int *)&local_20);
      if ((char)uVar2 != '\0') {
        if (local_20 == (byte *)0x0) {
          FUN_00445780();
        }
        return local_20;
      }
    }
    if (((DAT_00584285 != '\0') && (DAT_0058427a == '\0')) &&
       ((**(char **)(pbVar8 + 6) == '\f' && (*pbVar8 == 4)))) {
      pcVar3 = FUN_004fa340((char *)pbVar8);
      pbVar8 = (byte *)FUN_004fb4c0(pcVar3);
      return pbVar8;
    }
    if (*pbVar8 != 0x43) {
      pbVar8 = (byte *)FUN_004f71b0(pbVar8,'\x01');
      return pbVar8;
    }
    return pbVar8;
  }
  if (DAT_005882d8 != 0x2a) {
    if (DAT_005882d8 == 0x2b) {
      DAT_005882d8 = FUN_00492070();
      pcVar3 = (char *)FUN_004f57a0();
      pcVar3 = FUN_004fa340(pcVar3);
      pbVar8 = (byte *)FUN_004fb4c0(pcVar3);
      if ((DAT_0058427a != '\0') &&
         (uVar2 = FUN_0046d220(0x2b,pbVar8,(byte *)0x0,(int *)&local_20), (char)uVar2 != '\0')) {
        if (local_20 != (byte *)0x0) {
          return local_20;
        }
        pbVar8 = local_1c;
        if (local_1c == (byte *)0x0) {
          FUN_00445780();
        }
      }
      switch(**(undefined1 **)(pbVar8 + 6)) {
      case 1:
      case 3:
        pbVar8 = (byte *)FUN_004738d0((char *)pbVar8);
        return pbVar8;
      case 2:
      case 0xb:
      case 0xc:
        return pbVar8;
      default:
        FUN_004463d0(0x90);
        return pbVar8;
      }
    }
    if (DAT_005882d8 == 0x2d) {
      DAT_005882d8 = FUN_00492070();
      pcVar3 = (char *)FUN_004f57a0();
      pbVar8 = (byte *)FUN_004f6b80(pcVar3);
      return pbVar8;
    }
    if (DAT_005882d8 == 0x7e) {
      DAT_005882d8 = FUN_00492070();
      pcVar3 = (char *)FUN_004f57a0();
      if (**(char **)(pcVar3 + 6) == '\x0e') {
        pbVar8 = (byte *)FUN_005179b0((char *)0x0,6,pcVar3);
      }
      else {
        pcVar3 = FUN_004fa340(pcVar3);
        pbVar8 = (byte *)FUN_004fb4c0(pcVar3);
        if ((DAT_0058427a != '\0') &&
           (uVar2 = FUN_0046d220(0x7e,pbVar8,(byte *)0x0,(int *)&local_14), (char)uVar2 != '\0')) {
          if (local_14 != (byte *)0x0) {
            return local_14;
          }
          pbVar8 = local_10;
          if (local_10 == (byte *)0x0) {
            FUN_00445780();
          }
        }
        pbVar8 = (byte *)FUN_004738d0((char *)pbVar8);
        if (*pbVar8 == 0x32) {
          uVar9 = FUN_004a8db0(*(char **)(pbVar8 + 6),0x7e,*(undefined8 *)(pbVar8 + 10));
          *(undefined8 *)(pbVar8 + 10) = uVar9;
        }
        else {
          pbVar8 = (byte *)FUN_00473ea0((int)pbVar8,6);
        }
      }
      return pbVar8;
    }
    if (DAT_005882d8 == 0x21) {
      DAT_005882d8 = FUN_00492070();
      pcVar3 = (char *)FUN_004f57a0();
      pbVar8 = FUN_004f6cb0(pcVar3);
      return pbVar8;
    }
    if (DAT_005882d8 == 0x143) {
      pbVar8 = FUN_004f8960();
      if ((*pbVar8 == 5) && (*(int *)(pbVar8 + 0x22) != 0)) {
        FUN_004463d0(0x11e);
      }
      if (*pbVar8 == 9) {
        pbVar4 = FUN_00473fa0(1);
        *(byte **)(pbVar4 + 10) = pbVar8;
      }
      else {
        if (*(int *)(pbVar8 + 2) == 0) {
          if ((byte)(*pbVar8 - 4) < 2) {
            FUN_004463d0(0x88);
          }
          else {
            FUN_004463d0(0x92);
          }
        }
        iVar10 = *(int *)(pbVar8 + 2);
        puVar5 = FUN_0050e830();
        pbVar4 = FUN_00473f30(puVar5,iVar10);
      }
      return pbVar4;
    }
    if ((DAT_005882d8 == 0x167) && (DAT_00584284 == '\0')) {
      DAT_005882d8 = FUN_00492070();
      if (DAT_005882d8 == -3) {
        pbVar8 = (byte *)FUN_00441fa0(0x1a);
        *pbVar8 = 0x3f;
        pbVar8[1] = 0;
        pbVar8[2] = 0;
        pbVar8[3] = 0;
        pbVar8[6] = 0xd8;
        pbVar8[7] = 0xd5;
        pbVar8[8] = 0x55;
        pbVar8[9] = 0;
        puVar6 = FUN_0047c440();
        *(undefined4 **)(pbVar8 + 10) = puVar6;
        if (*(int *)(pbVar8 + 10) == 0) {
          puVar7 = FUN_0047c410();
          *(undefined1 **)(pbVar8 + 10) = puVar7;
          *(undefined4 *)(*(int *)(pbVar8 + 10) + 0xc) = DAT_00587fa0;
          **(undefined4 **)(pbVar8 + 10) = DAT_0058822c;
          DAT_0058822c = *(undefined4 *)(pbVar8 + 10);
        }
        DAT_005882d8 = FUN_00492070();
        return pbVar8;
      }
      FUN_004463d0(0x6b);
      pbVar8 = FUN_00473f70();
      return pbVar8;
    }
    pbVar8 = FUN_004f73c0('\0');
    return pbVar8;
  }
  DAT_005882d8 = FUN_00492070();
  pcVar3 = (char *)FUN_004f57a0();
  pcVar3 = FUN_004fa340(pcVar3);
  pbVar8 = (byte *)FUN_004fb4c0(pcVar3);
  if ((DAT_0058427a != '\0') &&
     (uVar2 = FUN_0046d220(0x2a,pbVar8,(byte *)0x0,(int *)&local_20), (char)uVar2 != '\0')) {
    if (local_20 != (byte *)0x0) {
      return local_20;
    }
    pbVar8 = local_1c;
    if (local_1c == (byte *)0x0) {
      FUN_00445780();
    }
  }
  if ('\n' < **(char **)(pbVar8 + 6)) {
    pbVar8 = (byte *)FUN_00473ea0((int)pbVar8,4);
    *(undefined4 *)(pbVar8 + 6) = *(undefined4 *)(*(int *)(pbVar8 + 6) + 6);
    FUN_00504850(*(byte **)(pbVar8 + 6));
    return pbVar8;
  }
  FUN_004463d0(0x94);
  return pbVar8;
}


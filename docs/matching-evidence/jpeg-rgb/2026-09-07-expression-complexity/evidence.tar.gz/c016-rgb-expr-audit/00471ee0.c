
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 __cdecl FUN_00471ee0(char *param_1,undefined4 *param_2,char param_3)

{
  char cVar1;
  short sVar2;
  byte *pbVar3;
  uint uVar4;
  
  pbVar3 = (byte *)FUN_00441fa0(0x1a);
  *(undefined4 *)pbVar3 = *param_2;
  *(undefined4 *)(pbVar3 + 4) = param_2[1];
  *(undefined4 *)(pbVar3 + 8) = param_2[2];
  *(undefined4 *)(pbVar3 + 0xc) = param_2[3];
  *(undefined4 *)(pbVar3 + 0x10) = param_2[4];
  *(undefined4 *)(pbVar3 + 0x14) = param_2[5];
  *(undefined2 *)(pbVar3 + 0x18) = *(undefined2 *)(param_2 + 6);
  if (**(char **)(pbVar3 + 6) != '\n') {
    pbVar3 = (byte *)FUN_004f6120((char *)pbVar3,param_1,param_3);
    uVar4 = FUN_0048f800(*(char **)(pbVar3 + 6),param_1);
    if ((short)uVar4 != 0) {
      if (param_3 != '\0') {
        DAT_00587c90 = pbVar3;
      }
      return 3;
    }
  }
  if (**(char **)(pbVar3 + 6) == '\n') {
    if (**(char **)(param_1 + 10) != '\x05') {
      FUN_00445780();
    }
    if (**(char **)(*(int *)(pbVar3 + 6) + 10) != '\x05') {
      FUN_00445780();
    }
    FUN_004eb810();
    cVar1 = FUN_004eb790(*(int *)(param_1 + 10),*(int *)(*(int *)(pbVar3 + 6) + 10),'\0','\x01');
    if (cVar1 != '\0') {
      sVar2 = FUN_004eb780();
      _DAT_005806a0 = 1000 - sVar2;
      if (param_3 != '\0') {
        DAT_00587c90 = FUN_004f6180(pbVar3,*(int *)(pbVar3 + 6),(int)param_1);
      }
      return 3;
    }
  }
  return 0;
}


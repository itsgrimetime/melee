
byte * __cdecl FUN_004741b0(byte *param_1)

{
  undefined4 *puVar1;
  byte *pbVar2;
  byte *pbVar3;
  
  pbVar2 = param_1;
  if (((&DAT_005806fd)[*param_1] != '\0') &&
     (pbVar2 = (byte *)(*DAT_0058074c)(param_1), pbVar2 == (byte *)0x0)) {
    return param_1;
  }
  switch(*pbVar2) {
  case 0:
  case 1:
  case 2:
  case 3:
  case 4:
  case 5:
  case 6:
  case 7:
  case 8:
  case 0x30:
  case 0x31:
    pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 10));
    *(byte **)(pbVar2 + 10) = pbVar3;
    return pbVar2;
  case 9:
  case 10:
  case 0xb:
  case 0xc:
  case 0xd:
  case 0xe:
  case 0xf:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x18:
  case 0x19:
  case 0x1a:
  case 0x1b:
  case 0x1c:
  case 0x1d:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x21:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
  case 0x26:
  case 0x27:
  case 0x28:
  case 0x29:
  case 0x2a:
  case 0x2b:
  case 0x2c:
  case 0x2d:
  case 0x2e:
  case 0x2f:
    pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 10));
    *(byte **)(pbVar2 + 10) = pbVar3;
    pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 0xe));
    *(byte **)(pbVar2 + 0xe) = pbVar3;
    return pbVar2;
  case 0x32:
  case 0x33:
  case 0x34:
  case 0x38:
  case 0x3b:
  case 0x3c:
  case 0x3d:
  case 0x3e:
  case 0x3f:
  case 0x44:
  case 0x46:
  case 0x4a:
    return pbVar2;
  case 0x35:
    pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 10));
    *(byte **)(pbVar2 + 10) = pbVar3;
    pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 0xe));
    *(byte **)(pbVar2 + 0xe) = pbVar3;
    pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 0x12));
    *(byte **)(pbVar2 + 0x12) = pbVar3;
    return pbVar2;
  case 0x36:
  case 0x37:
    break;
  case 0x39:
    pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 10));
    *(byte **)(pbVar2 + 10) = pbVar3;
    pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 0xe));
    *(byte **)(pbVar2 + 0xe) = pbVar3;
    return pbVar2;
  case 0x3a:
    pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 10));
    *(byte **)(pbVar2 + 10) = pbVar3;
    pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 0xe));
    *(byte **)(pbVar2 + 0xe) = pbVar3;
    return pbVar2;
  default:
    FUN_00445780();
    return (byte *)0x0;
  }
  for (puVar1 = *(undefined4 **)(pbVar2 + 0xe); puVar1 != (undefined4 *)0x0;
      puVar1 = (undefined4 *)*puVar1) {
    pbVar3 = FUN_004741b0((byte *)puVar1[1]);
    puVar1[1] = pbVar3;
  }
  pbVar3 = FUN_004741b0(*(byte **)(pbVar2 + 10));
  *(byte **)(pbVar2 + 10) = pbVar3;
  return pbVar2;
}



undefined1 * __cdecl FUN_0046fde0(char *param_1,char param_2)

{
  char cVar1;
  undefined1 *puVar2;
  undefined4 uVar3;
  undefined1 *puVar4;
  undefined1 *puVar5;
  int iVar6;
  char *pcVar7;
  float local_4c [16];
  
  if (param_2 == '\0') {
    puVar2 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar2,0x1a);
    *puVar2 = 0x32;
    *(undefined1 **)(puVar2 + 6) = &DAT_0055f5f0;
    *(undefined4 *)(puVar2 + 0xe) = 0xffffffff;
    *(undefined4 *)(puVar2 + 10) = 0xffffffff;
    puVar4 = FUN_00504930(*(undefined4 *)(param_1 + 6));
    *(undefined1 **)(puVar2 + 6) = puVar4;
    return puVar2;
  }
  if ((*param_1 != '2') && (*param_1 != '3')) {
    if (DAT_0058757c == (code *)0x0) {
      uVar3 = *(undefined4 *)(param_1 + 6);
      puVar2 = (undefined1 *)FUN_00441fa0(0x1a);
      *puVar2 = 0x3c;
      puVar2[1] = 0;
      *(undefined2 *)(puVar2 + 2) = 0;
      puVar4 = FUN_00504930(uVar3);
      *(undefined1 **)(puVar2 + 6) = puVar4;
      *(undefined4 *)(puVar2 + 10) = uVar3;
      iVar6 = FUN_00490650();
      *(int *)(puVar2 + 0xe) = iVar6;
      puVar2[0x12] = 0;
    }
    else {
      puVar2 = (undefined1 *)(*DAT_0058757c)(*(undefined4 *)(param_1 + 6),0);
    }
    puVar4 = (undefined1 *)FUN_00441fa0(0x1a);
    *puVar4 = 4;
    puVar4[1] = puVar2[1];
    if (puVar4[1] == '\0') {
      puVar4[1] = 1;
    }
    *(ushort *)(puVar4 + 2) = *(ushort *)(puVar2 + 2) & 3;
    *(undefined4 *)(puVar4 + 6) = *(undefined4 *)(puVar2 + 6);
    *(undefined1 **)(puVar4 + 10) = puVar2;
    *(undefined4 *)(puVar4 + 6) = *(undefined4 *)(*(int *)(puVar4 + 6) + 6);
    puVar2 = (undefined1 *)FUN_00441fa0(0x1a);
    *puVar2 = 0x1e;
    *(undefined4 *)(puVar2 + 6) = *(undefined4 *)(puVar4 + 6);
    *(undefined1 **)(puVar2 + 10) = puVar4;
    *(char **)(puVar2 + 0xe) = param_1;
    cVar1 = param_1[1];
    if (puVar4[1] == cVar1) {
      puVar2[1] = cVar1 + '\x01';
      if (200 < (byte)puVar2[1]) {
        puVar2[1] = 200;
      }
    }
    else {
      puVar2[1] = cVar1;
      if ((byte)puVar2[1] < (byte)puVar4[1]) {
        puVar2[1] = puVar4[1];
      }
    }
    *(ushort *)(puVar2 + 2) = (*(ushort *)(puVar4 + 2) | *(ushort *)(param_1 + 2)) & 3;
    puVar2 = (undefined1 *)FUN_00473cf0((int)puVar2,*(byte **)(puVar4 + 10));
    return puVar2;
  }
  puVar2 = FUN_00490060();
  *(undefined4 *)(puVar2 + 0xe) = *(undefined4 *)(param_1 + 6);
  uVar3 = FUN_00490530();
  *(undefined4 *)(puVar2 + 10) = uVar3;
  *(undefined2 *)(puVar2 + 0x16) = 0x102;
  if (*param_1 == '2') {
    pcVar7 = *(char **)(param_1 + 6);
    switch(*pcVar7) {
    case '\x01':
      break;
    default:
      FUN_00445780();
      break;
    case '\x03':
      pcVar7 = *(char **)(pcVar7 + 0xe);
      break;
    case '\v':
      pcVar7 = &DAT_0055f5f8;
    }
    FUN_004a8be0(pcVar7,*(undefined4 *)(param_1 + 10),*(undefined4 *)(param_1 + 0xe),local_4c);
  }
  else {
    FUN_004a8500(*(char **)(param_1 + 6),*(float *)(param_1 + 10),*(float *)(param_1 + 0xe),local_4c
                );
  }
  FUN_004ceab0((int)puVar2,local_4c,(undefined4 *)0x0,*(int *)(*(int *)(puVar2 + 0xe) + 2));
  if ((DAT_00587fd8 == (code *)0x0) || (cVar1 = (*DAT_00587fd8)(0,puVar2), cVar1 != '\0')) {
    if (*(short *)(puVar2 + 0x16) == 0x104) {
      FUN_004463d0(0x8d);
      puVar4 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar4,0x1a);
      *puVar4 = 0x32;
      *(undefined4 *)(puVar4 + 6) = 0x55d5d8;
      *(undefined4 *)(puVar4 + 0xe) = 0;
      *(undefined4 *)(puVar4 + 10) = 0;
    }
    else {
      puVar4 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar4,0x1a);
      *puVar4 = 0x38;
      *(undefined1 **)(puVar4 + 10) = puVar2;
      puVar5 = FUN_00504930(*(undefined4 *)(puVar2 + 0xe));
      *(undefined1 **)(puVar4 + 6) = puVar5;
      if (**(char **)(puVar2 + 0xe) != '\x06') {
        *(ushort *)(puVar4 + 2) = *(ushort *)(puVar2 + 0x12) & 3;
      }
      puVar2[0x18] = puVar2[0x18] | 1;
    }
  }
  else {
    puVar4 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar4,0x1a);
    *puVar4 = 0x32;
    *(undefined4 *)(puVar4 + 6) = 0x55d5d8;
    *(undefined4 *)(puVar4 + 0xe) = 0;
    *(undefined4 *)(puVar4 + 10) = 0;
  }
  return puVar4;
}


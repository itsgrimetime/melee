
byte * __cdecl FUN_004f33f0(char *param_1,char *param_2)

{
  undefined1 uVar1;
  bool bVar2;
  byte *pbVar3;
  char *pcVar4;
  byte *pbVar5;
  undefined4 uVar6;
  undefined3 extraout_var;
  undefined1 *puVar7;
  undefined3 extraout_var_00;
  undefined3 extraout_var_01;
  undefined3 extraout_var_02;
  int iVar8;
  undefined3 extraout_var_03;
  undefined3 extraout_var_04;
  byte *local_18;
  byte *local_14;
  byte *local_10;
  
  if ((**(char **)(param_1 + 6) == '\x0e') || (**(char **)(param_2 + 6) == '\x0e')) {
    pbVar3 = (byte *)FUN_005179b0(param_1,0x1c,param_2);
    return pbVar3;
  }
  pcVar4 = FUN_004fa340(param_1);
  pbVar5 = (byte *)FUN_004fb4c0(pcVar4);
  pcVar4 = FUN_004fa340(param_2);
  pbVar3 = (byte *)FUN_004fb4c0(pcVar4);
  if ((DAT_0058427a != '\0') &&
     (uVar6 = FUN_0046d220(0x167,pbVar5,pbVar3,(int *)&local_18), (char)uVar6 != '\0')) {
    if (local_18 != (byte *)0x0) {
      return local_18;
    }
    if (local_14 == (byte *)0x0) {
      FUN_00445780();
    }
    pbVar3 = local_10;
    pbVar5 = local_14;
    if (local_10 == (byte *)0x0) {
      FUN_00445780();
    }
  }
  switch(**(undefined1 **)(pbVar5 + 6)) {
  case 1:
  case 2:
  case 0xb:
  case 0xc:
    break;
  case 3:
  case 10:
    pbVar5 = FUN_004702d0((char *)pbVar5,'\0','\0');
    break;
  default:
    FUN_004463d0(0x90);
    pbVar5 = FUN_00473f70();
  }
  switch(**(undefined1 **)(pbVar3 + 6)) {
  case 1:
  case 2:
  case 0xb:
  case 0xc:
    break;
  case 3:
  case 10:
    pbVar3 = FUN_004702d0((char *)pbVar3,'\0','\0');
    break;
  default:
    FUN_004463d0(0x90);
    pbVar3 = FUN_00473f70();
  }
  uVar1 = FUN_00473cb0((char *)pbVar5);
  if ((short)CONCAT31(extraout_var,uVar1) != 0) {
    *pbVar5 = 0x32;
    puVar7 = FUN_0048f2d0();
    *(undefined1 **)(pbVar5 + 6) = puVar7;
    pbVar5[0xe] = 0;
    pbVar5[0xf] = 0;
    pbVar5[0x10] = 0;
    pbVar5[0x11] = 0;
    pbVar5[10] = 0;
    pbVar5[0xb] = 0;
    pbVar5[0xc] = 0;
    pbVar5[0xd] = 0;
    return pbVar5;
  }
  bVar2 = FUN_00473be0(pbVar5);
  if ((short)CONCAT31(extraout_var_00,bVar2) == 0) {
    bVar2 = FUN_00473be0(pbVar3);
    if ((short)CONCAT31(extraout_var_03,bVar2) != 0) {
      iVar8 = FUN_00473ea0((int)pbVar5,7);
      puVar7 = FUN_0048f2d0();
      *(undefined1 **)(iVar8 + 6) = puVar7;
      pbVar3 = (byte *)FUN_00473ea0(iVar8,7);
      return pbVar3;
    }
    uVar1 = FUN_00473cb0((char *)pbVar3);
    if ((short)CONCAT31(extraout_var_04,uVar1) != 0) {
      *pbVar3 = 0x32;
      puVar7 = FUN_0048f2d0();
      *(undefined1 **)(pbVar3 + 6) = puVar7;
      pbVar3[0xe] = 0;
      pbVar3[0xf] = 0;
      pbVar3[0x10] = 0;
      pbVar3[0x11] = 0;
      pbVar3[10] = 0;
      pbVar3[0xb] = 0;
      pbVar3[0xc] = 0;
      pbVar3[0xd] = 0;
      pbVar3 = (byte *)FUN_00473cf0((int)pbVar5,pbVar3);
      return pbVar3;
    }
    pbVar3 = (byte *)FUN_00473e30((int)pbVar5,(int)pbVar3,0x1c);
    puVar7 = FUN_0048f2d0();
    *(undefined1 **)(pbVar3 + 6) = puVar7;
    return pbVar3;
  }
  uVar1 = FUN_00473cb0((char *)pbVar3);
  if ((short)CONCAT31(extraout_var_01,uVar1) != 0) {
    *pbVar5 = 0x32;
    puVar7 = FUN_0048f2d0();
    *(undefined1 **)(pbVar5 + 6) = puVar7;
    pbVar5[0xe] = 0;
    pbVar5[0xf] = 0;
    pbVar5[0x10] = 0;
    pbVar5[0x11] = 0;
    pbVar5[10] = 0;
    pbVar5[0xb] = 0;
    pbVar5[0xc] = 0;
    pbVar5[0xd] = 0;
    return pbVar5;
  }
  bVar2 = FUN_00473be0(pbVar3);
  if ((short)CONCAT31(extraout_var_02,bVar2) != 0) {
    *pbVar5 = 0x32;
    puVar7 = FUN_0048f2d0();
    *(undefined1 **)(pbVar5 + 6) = puVar7;
    pbVar5[0xe] = 1;
    pbVar5[0xf] = 0;
    pbVar5[0x10] = 0;
    pbVar5[0x11] = 0;
    pbVar5[10] = 0;
    pbVar5[0xb] = 0;
    pbVar5[0xc] = 0;
    pbVar5[0xd] = 0;
    return pbVar5;
  }
  iVar8 = FUN_00473ea0((int)pbVar3,7);
  puVar7 = FUN_0048f2d0();
  *(undefined1 **)(iVar8 + 6) = puVar7;
  pbVar3 = (byte *)FUN_00473ea0(iVar8,7);
  return pbVar3;
}



/* WARNING: Removing unreachable block (ram,0x0046d0cc) */

byte * __cdecl
FUN_0046cf20(char *param_1,int param_2,int *param_3,char param_4,char param_5,char param_6,
            undefined4 param_7,char param_8)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  char *pcVar4;
  byte *pbVar5;
  int *piVar6;
  int *piVar7;
  undefined1 *puVar8;
  byte *pbVar9;
  int local_18;
  char *local_14;
  
  if (**(char **)(param_2 + 6) != '\v') {
    FUN_00445780();
  }
  pbVar3 = (byte *)FUN_00441fa0(0x1a);
  *pbVar3 = 4;
  pbVar3[1] = *(byte *)(param_2 + 1);
  if (pbVar3[1] == 0) {
    pbVar3[1] = 1;
  }
  *(ushort *)(pbVar3 + 2) = *(ushort *)(param_2 + 2) & 3;
  *(undefined4 *)(pbVar3 + 6) = *(undefined4 *)(param_2 + 6);
  *(int *)(pbVar3 + 10) = param_2;
  *(char **)(pbVar3 + 6) = param_1;
  if ((((param_6 == '\0') && (param_3 != (int *)0x0)) && (*param_3 == 0)) &&
     ((*(char **)(param_3[1] + 6) == param_1 &&
      (pcVar4 = FUN_004ebd50((int)param_1), pcVar4 == (char *)0x0)))) {
    if (**(char **)(pbVar3 + 6) != '\x05') {
      FUN_00445780();
    }
    iVar2 = param_3[1];
    pbVar5 = (byte *)FUN_00441fa0(0x1a);
    *pbVar5 = 0x1e;
    *(undefined4 *)(pbVar5 + 6) = *(undefined4 *)(pbVar3 + 6);
    *(byte **)(pbVar5 + 10) = pbVar3;
    *(int *)(pbVar5 + 0xe) = iVar2;
    bVar1 = *(byte *)(iVar2 + 1);
    if (pbVar3[1] == bVar1) {
      pbVar5[1] = bVar1 + 1;
      if (200 < pbVar5[1]) {
        pbVar5[1] = 200;
      }
    }
    else {
      pbVar5[1] = bVar1;
      if (pbVar5[1] < pbVar3[1]) {
        pbVar5[1] = pbVar3[1];
      }
    }
    *(ushort *)(pbVar5 + 2) = (*(ushort *)(pbVar3 + 2) | *(ushort *)(iVar2 + 2)) & 3;
    if (param_4 == '\0') {
      pbVar5 = (byte *)FUN_004f71b0(pbVar5,'\0');
    }
    return pbVar5;
  }
  piVar6 = FUN_004ebce0((int)param_1);
  if (piVar6 != (int *)0x0) {
    piVar7 = param_3;
    if ((*(ushort *)(param_1 + 0x2a) & 0x20) != 0) {
      piVar7 = (int *)FUN_00441fa0(8);
      *piVar7 = (int)param_3;
      puVar8 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar8,0x1a);
      *puVar8 = 0x32;
      *(undefined **)(puVar8 + 6) = &DAT_0055f5d0;
      *(uint *)(puVar8 + 0xe) = (uint)(param_5 != '\0');
      *(undefined4 *)(puVar8 + 10) = 0;
      piVar7[1] = (int)puVar8;
    }
    local_18 = 0;
    local_14 = param_1;
    pbVar3 = FUN_0046eb90(&local_18,pbVar3,'\0',(char *)0x0,piVar6,0,piVar7,param_8 == '\0','\0',
                          (char)param_7);
    if ((*pbVar3 == 0x36) || (*pbVar3 == 0x37)) {
      puVar8 = FUN_00504930(param_1);
      *(undefined1 **)(pbVar3 + 6) = puVar8;
    }
    pbVar5 = pbVar3;
    if (param_4 != '\0') {
      pbVar5 = (byte *)FUN_00441fa0(0x1a);
      *pbVar5 = 4;
      pbVar5[1] = pbVar3[1];
      if (pbVar5[1] == 0) {
        pbVar5[1] = 1;
      }
      *(ushort *)(pbVar5 + 2) = *(ushort *)(pbVar3 + 2) & 3;
      *(undefined4 *)(pbVar5 + 6) = *(undefined4 *)(pbVar3 + 6);
      *(byte **)(pbVar5 + 10) = pbVar3;
      *(char **)(pbVar5 + 6) = param_1;
    }
    return pbVar5;
  }
  if (param_3 != (int *)0x0) {
    if ((*param_3 == 0) && (*pbVar3 == 4)) {
      pbVar5 = FUN_004fa000((byte *)param_3[1],param_1,0,1);
      pbVar9 = (byte *)FUN_00441fa0(0x1a);
      *pbVar9 = 0x1e;
      *(undefined4 *)(pbVar9 + 6) = *(undefined4 *)(pbVar3 + 6);
      *(byte **)(pbVar9 + 10) = pbVar3;
      *(byte **)(pbVar9 + 0xe) = pbVar5;
      bVar1 = pbVar5[1];
      if (pbVar3[1] == bVar1) {
        pbVar9[1] = bVar1 + 1;
        if (200 < pbVar9[1]) {
          pbVar9[1] = 200;
        }
      }
      else {
        pbVar9[1] = bVar1;
        if (pbVar9[1] < pbVar3[1]) {
          pbVar9[1] = pbVar3[1];
        }
      }
      *(ushort *)(pbVar9 + 2) = (*(ushort *)(pbVar3 + 2) | *(ushort *)(pbVar5 + 2)) & 3;
      return pbVar9;
    }
    FUN_004463d0(0xae);
  }
  return pbVar3;
}


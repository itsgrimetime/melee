
void __cdecl FUN_0046f660(int param_1,int *param_2,int param_3,undefined4 *param_4)

{
  byte *pbVar1;
  int iVar2;
  char *pcVar3;
  undefined4 *puVar4;
  undefined1 *puVar5;
  int *piVar6;
  int *piVar7;
  
  for (; param_4 != (undefined4 *)0x0; param_4 = (undefined4 *)*param_4) {
    if (param_4[2] != 0) {
      piVar6 = param_2;
      if (param_2 == (int *)0x0) {
        param_2 = (int *)FUN_00441fa0(8);
        piVar6 = param_2;
      }
      else {
        do {
          piVar7 = piVar6;
          piVar6 = (int *)*piVar7;
        } while ((int *)*piVar7 != (int *)0x0);
        iVar2 = FUN_00441fa0(8);
        *piVar7 = iVar2;
        piVar6 = (int *)*piVar7;
      }
      *piVar6 = 0;
      pcVar3 = FUN_00513040((char *)param_4[2],0);
      if (*pcVar3 == 'E') {
        if (pcVar3[0x16] != '\x03') {
          FUN_00445780();
        }
        pcVar3 = (char *)FUN_004f9d20(*(char **)(pcVar3 + 0xe),*(uint *)(pcVar3 + 0x12),
                                      *(int **)(pcVar3 + 10));
      }
      piVar6[1] = (int)pcVar3;
    }
  }
  puVar4 = (undefined4 *)FUN_00441fa0(0x1a);
  *(undefined1 *)puVar4 = 0x36;
  *(undefined1 *)((int)puVar4 + 1) = 4;
  *(undefined4 *)((int)puVar4 + 6) = *(undefined4 *)(param_3 + 0xe);
  *(ushort *)((int)puVar4 + 2) = *(ushort *)(param_3 + 0x12) & 3;
  *(int *)((int)puVar4 + 10) = param_1;
  puVar5 = FUN_00504930(param_3);
  *(undefined1 **)(*(int *)((int)puVar4 + 10) + 6) = puVar5;
  *(int **)((int)puVar4 + 0xe) = param_2;
  *(int *)((int)puVar4 + 0x12) = param_3;
  pbVar1 = (byte *)(*(int *)(param_1 + 10) + 0x18);
  *pbVar1 = *pbVar1 | 1;
  FUN_00472660(puVar4);
  return;
}


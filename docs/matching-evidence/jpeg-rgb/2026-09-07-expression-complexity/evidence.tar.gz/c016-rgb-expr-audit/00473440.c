
void __cdecl FUN_00473440(int *param_1,int *param_2)

{
  char *pcVar1;
  char cVar2;
  uint uVar3;
  undefined1 *puVar4;
  char *pcVar5;
  char *pcVar6;
  int *piVar7;
  char *pcVar8;
  
  pcVar6 = *(char **)(*param_1 + 6);
  uVar3 = (int)*pcVar6 - 1;
  if (1 < uVar3) {
    if (uVar3 == 2) {
      *(undefined4 *)(*param_1 + 6) = *(undefined4 *)(pcVar6 + 0xe);
    }
    else {
      FUN_004463d0(0x90);
      puVar4 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar4,0x1a);
      *puVar4 = 0x32;
      *(undefined1 **)(puVar4 + 6) = &DAT_0055f5f0;
      *param_1 = (int)puVar4;
    }
  }
  pcVar6 = *(char **)(*param_2 + 6);
  uVar3 = (int)*pcVar6 - 1;
  if (1 < uVar3) {
    if (uVar3 == 2) {
      *(undefined4 *)(*param_2 + 6) = *(undefined4 *)(pcVar6 + 0xe);
    }
    else {
      FUN_004463d0(0x90);
      puVar4 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar4,0x1a);
      *puVar4 = 0x32;
      *(undefined1 **)(puVar4 + 6) = &DAT_0055f5f0;
      *param_2 = (int)puVar4;
    }
  }
  pcVar6 = (char *)*param_1;
  pcVar5 = *(char **)(pcVar6 + 6);
  if ((*pcVar5 == '\x02') || (**(char **)(*param_2 + 6) == '\x02')) {
    pcVar8 = (char *)*param_2;
    pcVar1 = *(char **)(pcVar8 + 6);
    if (pcVar5 == pcVar1) {
      return;
    }
    if ((byte)pcVar5[6] <= (byte)pcVar1[6]) {
      pcVar6 = FUN_00473720(pcVar6,pcVar1);
      *param_1 = (int)pcVar6;
      return;
    }
  }
  else {
    if (*pcVar5 != '\x01') {
      if (**(char **)(pcVar6 + 6) == '\x03') {
        *(undefined4 *)(pcVar6 + 6) = *(undefined4 *)(*(char **)(pcVar6 + 6) + 0xe);
      }
      else {
        FUN_004463d0(0x90);
        pcVar6 = (char *)FUN_00441fa0(0x1a);
        FUN_00441db0(pcVar6,0x1a);
        *pcVar6 = '2';
        *(undefined1 **)(pcVar6 + 6) = &DAT_0055f5f0;
      }
    }
    pcVar5 = pcVar6;
    if (*(byte *)(*(int *)(pcVar6 + 6) + 6) < 7) {
      if (*pcVar6 != '2') {
        pcVar5 = (char *)FUN_00441fa0(0x1a);
        *pcVar5 = '0';
        pcVar5[1] = pcVar6[1];
        if (pcVar5[1] == '\0') {
          pcVar5[1] = '\x01';
        }
        *(ushort *)(pcVar5 + 2) = *(ushort *)(pcVar6 + 2) & 3;
        *(undefined4 *)(pcVar5 + 6) = *(undefined4 *)(pcVar6 + 6);
        *(char **)(pcVar5 + 10) = pcVar6;
      }
      *(undefined1 **)(pcVar5 + 6) = &DAT_0055f5e0;
    }
    *param_1 = (int)pcVar5;
    pcVar6 = (char *)*param_2;
    if (**(char **)(pcVar6 + 6) != '\x01') {
      if (**(char **)(pcVar6 + 6) == '\x03') {
        *(undefined4 *)(pcVar6 + 6) = *(undefined4 *)(*(char **)(pcVar6 + 6) + 0xe);
      }
      else {
        FUN_004463d0(0x90);
        pcVar6 = (char *)FUN_00441fa0(0x1a);
        FUN_00441db0(pcVar6,0x1a);
        *pcVar6 = '2';
        *(undefined1 **)(pcVar6 + 6) = &DAT_0055f5f0;
      }
    }
    pcVar5 = pcVar6;
    if (*(byte *)(*(int *)(pcVar6 + 6) + 6) < 7) {
      if (*pcVar6 != '2') {
        pcVar5 = (char *)FUN_00441fa0(0x1a);
        *pcVar5 = '0';
        pcVar5[1] = pcVar6[1];
        if (pcVar5[1] == '\0') {
          pcVar5[1] = '\x01';
        }
        *(ushort *)(pcVar5 + 2) = *(ushort *)(pcVar6 + 2) & 3;
        *(undefined4 *)(pcVar5 + 6) = *(undefined4 *)(pcVar6 + 6);
        *(char **)(pcVar5 + 10) = pcVar6;
      }
      *(undefined1 **)(pcVar5 + 6) = &DAT_0055f5e0;
    }
    *param_2 = (int)pcVar5;
    if (*(int *)(*param_1 + 6) == *(int *)(*param_2 + 6)) {
      return;
    }
    piVar7 = param_2;
    if (*(byte *)(*(int *)(*param_1 + 6) + 6) < *(byte *)(*(int *)(*param_2 + 6) + 6)) {
      piVar7 = param_1;
      param_1 = param_2;
    }
    if (((*(int *)(*(char **)(*param_1 + 6) + 2) == *(int *)(*(int *)(*piVar7 + 6) + 2)) &&
        (cVar2 = FUN_0048f180(*(char **)(*param_1 + 6)), cVar2 == '\0')) &&
       (cVar2 = FUN_0048f180(*(char **)(*piVar7 + 6)), cVar2 != '\0')) {
      pcVar6 = (char *)*param_1;
      if (*(undefined1 **)(pcVar6 + 6) == &DAT_0055f5f0) {
        pcVar5 = &DAT_0055f5f8;
      }
      else {
        if (*(undefined1 **)(pcVar6 + 6) != &DAT_0055f600) {
          FUN_00445780();
        }
        pcVar6 = (char *)*param_1;
        pcVar5 = &DAT_0055f608;
      }
      pcVar6 = FUN_00473720(pcVar6,pcVar5);
      *param_1 = (int)pcVar6;
    }
    pcVar5 = *(char **)(*param_1 + 6);
    pcVar8 = (char *)*piVar7;
    param_2 = piVar7;
  }
  pcVar6 = FUN_00473720(pcVar8,pcVar5);
  *param_2 = (int)pcVar6;
  return;
}


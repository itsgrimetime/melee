
undefined4 __cdecl FUN_004720b0(char *param_1,uint param_2,int param_3,int param_4)

{
  undefined4 uVar1;
  uint uVar2;
  short sVar3;
  
  uVar1 = FUN_0046fb80((byte *)param_3,(byte *)param_1,param_2,'\0','\0','\x01');
  uVar2 = (uint)(short)uVar1;
  if (uVar2 < 5) {
    sVar3 = (short)uVar1 >> 0xf;
    switch(uVar2) {
    case 0:
      return (uint)(uint3)(int3)(char)((uint)uVar1 >> 8) << 8;
    case 1:
      *(short *)(param_4 + 4) = *(short *)(param_4 + 4) + 1;
      break;
    case 2:
      *(short *)(param_4 + 6) = *(short *)(param_4 + 6) + 1;
      break;
    case 3:
      *(short *)(param_4 + 8) = *(short *)(param_4 + 8) + 1;
      uVar2 = CONCAT22(sVar3,DAT_005806a0);
      *(short *)(param_4 + 10) = *(short *)(param_4 + 10) + DAT_005806a0;
      break;
    case 4:
      *(short *)(param_4 + 0xe) = *(short *)(param_4 + 0xe) + 1;
      *(short *)(param_4 + 0x10) = *(short *)(param_4 + 0x10) + (short)DAT_005806a8;
      *(short *)(param_4 + 0x12) = *(short *)(param_4 + 0x12) + DAT_005806a8._2_2_;
      *(short *)(param_4 + 0x14) = *(short *)(param_4 + 0x14) + (short)DAT_005806ac;
      *(short *)(param_4 + 0x16) = *(short *)(param_4 + 0x16) + DAT_005806ac._2_2_;
      uVar2 = CONCAT22(sVar3,DAT_005806b0);
      *(short *)(param_4 + 0x18) = *(short *)(param_4 + 0x18) + DAT_005806b0;
    }
  }
  else {
    uVar2 = FUN_00445780();
  }
  if (*param_1 == '\v') {
    uVar2 = FUN_00472180(*(char **)(param_3 + 6),*(ushort *)(param_3 + 2) & 3,param_1,param_2,
                         param_4);
  }
  return CONCAT31((int3)(uVar2 >> 8),1);
}


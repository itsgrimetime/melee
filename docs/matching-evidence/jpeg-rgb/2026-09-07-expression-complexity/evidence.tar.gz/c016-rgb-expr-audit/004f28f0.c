
byte * __cdecl FUN_004f28f0(byte *param_1,byte param_2,char param_3)

{
  bool bVar1;
  undefined1 uVar2;
  byte *pbVar3;
  undefined1 uVar4;
  bool bVar5;
  undefined4 uVar6;
  undefined3 extraout_var;
  undefined3 extraout_var_00;
  byte *pbVar7;
  char *pcVar8;
  byte *pbVar9;
  undefined4 local_1c;
  byte *local_18;
  byte *local_14;
  byte *local_10;
  
  uVar2 = DAT_005884f7;
  DAT_005884f7 = uVar2;
  if (param_1 == (byte *)0x0) {
    DAT_005884f7 = 0;
    param_1 = (byte *)FUN_004f5450();
    DAT_005884f7 = uVar2;
  }
  do {
    uVar6 = FUN_004f2b80(DAT_005882d8,(undefined1 *)&local_1c);
    if ((char)uVar6 == '\0') {
      return param_1;
    }
    if ((local_1c & 0xff) == 0x1c) {
      if (((DAT_005842c1 != '\0') && (*param_1 == 0x1e)) && ((*(ushort *)(param_1 + 2) & 0x80) == 0)
         ) {
        FUN_004457e0(0xcf);
      }
      uVar4 = FUN_00473cb0((char *)param_1);
      if ((short)CONCAT31(extraout_var,uVar4) != 0) {
        param_3 = '\x01';
      }
      bVar5 = true;
    }
    else if ((local_1c & 0xff) == 0x1d) {
      if (((DAT_005842c1 != '\0') && (*param_1 == 0x1e)) && ((*(ushort *)(param_1 + 2) & 0x80) == 0)
         ) {
        FUN_004457e0(0xcf);
      }
      bVar5 = FUN_00473be0(param_1);
      if ((short)CONCAT31(extraout_var_00,bVar5) != 0) {
        param_3 = '\x01';
      }
      bVar5 = true;
    }
    else {
      bVar5 = false;
    }
    DAT_005882d8 = FUN_00492070();
    DAT_005884f7 = 0;
    pbVar7 = (byte *)FUN_004f5450();
    DAT_005884f7 = uVar2;
    while (uVar6 = FUN_004f2b80(DAT_005882d8,(undefined1 *)((int)&local_1c + 2)),
          (char)uVar6 != '\0') {
      if (local_1c._3_1_ <= local_1c._1_1_) {
        bVar1 = local_1c._3_1_ <= param_2;
        goto LAB_004f2a48;
      }
      pbVar7 = FUN_004f28f0(pbVar7,local_1c._1_1_,param_3);
    }
    bVar1 = true;
LAB_004f2a48:
    if (((bVar5) && (DAT_005842c1 != '\0')) &&
       ((*pbVar7 == 0x1e && ((*(ushort *)(pbVar7 + 2) & 0x80) == 0)))) {
      FUN_004457e0(0xcf);
    }
    if ((local_1c & 0xff) == 0xb) {
      if ((**(char **)(param_1 + 6) == '\x0e') || (**(char **)(pbVar7 + 6) == '\x0e')) {
        param_1 = (byte *)FUN_005179b0((char *)param_1,0xb,(char *)pbVar7);
      }
      else {
        pcVar8 = FUN_004fa340((char *)param_1);
        pbVar9 = (byte *)FUN_004fb4c0(pcVar8);
        pcVar8 = FUN_004fa340((char *)pbVar7);
        pbVar7 = (byte *)FUN_004fb4c0(pcVar8);
        if ((DAT_0058427a != '\0') &&
           (uVar6 = FUN_0046d220(0x2f,pbVar9,pbVar7,(int *)&local_18), pbVar3 = local_14,
           (char)uVar6 != '\0')) {
          param_1 = local_18;
          if (local_18 != (byte *)0x0) goto LAB_004f2b63;
          if (local_14 == (byte *)0x0) {
            FUN_00445780();
          }
          pbVar7 = local_10;
          pbVar9 = pbVar3;
          if (local_10 == (byte *)0x0) {
            FUN_00445780();
          }
        }
        param_1 = (byte *)FUN_004fad60((char *)pbVar9,(char *)pbVar7,param_3);
      }
    }
    else if ((local_1c & 0xff) == 0xc) {
      param_1 = (byte *)FUN_004f5260((char *)param_1,(char *)pbVar7,param_3);
    }
    else {
      param_1 = FUN_004f2d80(param_1,(char)local_1c,pbVar7);
    }
LAB_004f2b63:
    if (bVar1) {
      return param_1;
    }
  } while( true );
}


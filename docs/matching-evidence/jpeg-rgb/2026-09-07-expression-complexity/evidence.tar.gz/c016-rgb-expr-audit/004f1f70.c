
byte * __cdecl FUN_004f1f70(char *param_1,byte *param_2,byte *param_3)

{
  byte bVar1;
  char *pcVar2;
  int iVar3;
  byte bVar4;
  byte *pbVar5;
  bool bVar6;
  undefined1 uVar7;
  char cVar8;
  char *pcVar9;
  byte *pbVar10;
  uint uVar11;
  undefined3 extraout_var;
  undefined3 extraout_var_00;
  undefined4 *puVar12;
  int *piVar13;
  int iVar14;
  undefined4 uVar15;
  byte *pbVar16;
  undefined3 extraout_var_01;
  byte *pbVar17;
  undefined3 extraout_var_02;
  undefined3 extraout_var_03;
  undefined3 extraout_var_04;
  ushort uVar18;
  byte *local_28;
  int local_1c;
  byte *local_18;
  byte *local_14;
  
  pcVar9 = FUN_004fa340(param_1);
  pcVar9 = FUN_004fb4c0(pcVar9);
  pbVar10 = FUN_004702d0(pcVar9,'\0','\x01');
  pcVar9 = FUN_004fa340((char *)param_2);
  param_2 = (byte *)FUN_004fb4c0(pcVar9);
  pcVar9 = FUN_004fa340((char *)param_3);
  param_3 = (byte *)FUN_004fb4c0(pcVar9);
  cVar8 = **(char **)(pbVar10 + 6);
  if (((cVar8 != '\x01') && (cVar8 != '\x02')) && (cVar8 != '\v')) {
    FUN_004463d0(0x90);
    pbVar10 = FUN_00473f70();
    return pbVar10;
  }
  bVar1 = param_3[1];
  bVar4 = bVar1;
  if (bVar1 < param_2[1]) {
    bVar4 = param_2[1];
  }
  uVar18 = pbVar10[1] + 1 + (ushort)bVar4;
  if (uVar18 < bVar1) {
    uVar18 = (ushort)bVar1;
  }
  if (200 < uVar18) {
    uVar18 = 200;
  }
  local_28 = FUN_00473fd0(0x35);
  local_28[1] = (byte)uVar18;
  *(undefined4 *)(local_28 + 6) = *(undefined4 *)(param_2 + 6);
  *(ushort *)(local_28 + 2) = *(ushort *)(param_2 + 2) | *(ushort *)(param_3 + 2);
  *(byte **)(local_28 + 10) = pbVar10;
  if (((*param_2 == 0x36) && (*(undefined1 **)(param_2 + 6) == &DAT_0055d5d0)) &&
     ((*(ushort *)(param_2 + 2) & 2) != 0)) {
    *(undefined4 *)(local_28 + 6) = *(undefined4 *)(param_3 + 6);
    *(undefined2 *)(local_28 + 2) = *(undefined2 *)(param_3 + 2);
    *(byte **)(local_28 + 0xe) = param_2;
    *(byte **)(local_28 + 0x12) = param_3;
    return local_28;
  }
  if (((*param_3 == 0x36) && (*(undefined1 **)(param_3 + 6) == &DAT_0055d5d0)) &&
     ((*(ushort *)(param_3 + 2) & 2) != 0)) {
    *(undefined4 *)(local_28 + 6) = *(undefined4 *)(param_2 + 6);
    *(undefined2 *)(local_28 + 2) = *(undefined2 *)(param_2 + 2);
    *(byte **)(local_28 + 0xe) = param_2;
    *(byte **)(local_28 + 0x12) = param_3;
    return local_28;
  }
  if ((((*param_2 == 4) && (*param_3 == 4)) &&
      (uVar11 = FUN_0048f2f0(*(char **)(param_2 + 6),*(char **)(param_3 + 6)), (short)uVar11 != 0))
     && ((*(ushort *)(param_2 + 2) & 3) == (*(ushort *)(param_3 + 2) & 3))) {
    uVar11 = (int)**(char **)(param_2 + 6) - 4;
    if (uVar11 < 2) {
      bVar6 = true;
    }
    else if ((uVar11 == 6) && (*(int *)(*(char **)(param_2 + 6) + 2) != 4)) {
      bVar6 = true;
    }
    else {
      bVar6 = false;
    }
    if (((bVar6) && (**(char **)(param_2 + 10) != '1')) && (**(char **)(param_3 + 10) != '1')) {
      bVar6 = FUN_00473be0(pbVar10);
      if ((short)CONCAT31(extraout_var,bVar6) != 0) {
        return param_2;
      }
      uVar7 = FUN_00473cb0((char *)pbVar10);
      if ((short)CONCAT31(extraout_var_00,uVar7) != 0) {
        return param_3;
      }
      puVar12 = FUN_004f71b0(param_2,'\0');
      *(undefined4 **)(local_28 + 0xe) = puVar12;
      puVar12 = FUN_004f71b0(param_3,'\0');
      *(undefined4 **)(local_28 + 0x12) = puVar12;
      *(undefined4 *)(local_28 + 6) = *(undefined4 *)(*(int *)(local_28 + 0xe) + 6);
      pbVar10 = (byte *)FUN_00473ea0((int)local_28,4);
      *(undefined4 *)(pbVar10 + 6) = *(undefined4 *)(*(int *)(pbVar10 + 6) + 6);
      return pbVar10;
    }
  }
  if (((**(char **)(param_2 + 6) == '\x05') || (**(char **)(param_3 + 6) == '\x05')) &&
     (uVar11 = FUN_0048f2f0(*(char **)(param_2 + 6),*(char **)(param_3 + 6)), (short)uVar11 == 0)) {
    piVar13 = (int *)FUN_00441fa0(8);
    piVar13[1] = (int)param_2;
    iVar14 = FUN_00441fa0(8);
    *piVar13 = iVar14;
    *(byte **)(*piVar13 + 4) = param_3;
    *(undefined4 *)*piVar13 = 0;
    uVar15 = FUN_0046d690(0x3a,param_2,param_3,piVar13,&local_1c);
    if ((char)uVar15 != '\0') {
      if (local_1c != 0) {
        FUN_00445780();
      }
      param_2 = local_18;
      param_3 = local_14;
    }
    *(undefined4 *)(local_28 + 6) = *(undefined4 *)(param_2 + 6);
  }
  pcVar9 = *(char **)(param_2 + 6);
  switch(*pcVar9) {
  case '\0':
    uVar11 = FUN_0048f980(pcVar9,*(char **)(param_3 + 6));
    if ((short)uVar11 == 0) {
      FUN_004463d0(0xf5);
    }
    break;
  case '\x01':
    goto switchD_004f233a_caseD_1;
  case '\x02':
    goto switchD_004f233a_caseD_2;
  case '\x03':
    if (pcVar9 == *(char **)(param_3 + 6)) break;
    param_2 = FUN_00473ee0(param_2);
switchD_004f233a_caseD_1:
    if ((**(char **)(param_3 + 6) == '\v') && (*param_2 == 0x32)) {
      bVar6 = false;
      if ((*(int *)(param_2 + 10) == 0) && (*(int *)(param_2 + 0xe) == 0)) {
        bVar6 = true;
      }
      if (bVar6) {
        *(undefined **)(param_2 + 6) = &DAT_0055f5f8;
        *(undefined4 *)(local_28 + 6) = *(undefined4 *)(param_3 + 6);
        break;
      }
    }
switchD_004f233a_caseD_2:
    if (*(int *)(param_2 + 6) != *(int *)(param_3 + 6)) {
      FUN_00473440((int *)&param_2,(int *)&param_3);
      *(undefined4 *)(local_28 + 6) = *(undefined4 *)(param_2 + 6);
    }
    break;
  case '\x04':
  case '\x05':
    uVar11 = FUN_0048f980(pcVar9,*(char **)(param_3 + 6));
    if ((short)uVar11 == 0) {
      FUN_004463d0(0xf5);
    }
    *(undefined4 *)(local_28 + 6) = *(undefined4 *)(param_2 + 6);
    break;
  default:
    FUN_004463d0(0xf5);
    pbVar10 = FUN_00473f70();
    return pbVar10;
  case '\n':
    uVar11 = FUN_0048f980(pcVar9,*(char **)(param_3 + 6));
    if ((short)uVar11 == 0) {
      if (**(char **)(param_3 + 6) == '\n') {
        param_2 = FUN_004f6180(param_2,*(int *)(param_2 + 6),(int)*(char **)(param_3 + 6));
      }
      else {
        FUN_004463d0(0xf5);
      }
    }
    *(undefined4 *)(local_28 + 6) = *(undefined4 *)(param_2 + 6);
    break;
  case '\v':
    if (*param_3 == 0x32) {
      bVar6 = false;
      if ((*(int *)(param_3 + 10) == 0) && (*(int *)(param_3 + 0xe) == 0)) {
        bVar6 = true;
      }
      if (bVar6) {
        *(undefined **)(param_3 + 6) = &DAT_0055f5f8;
        break;
      }
    }
    pcVar2 = *(char **)(param_3 + 6);
    if (*pcVar2 == '\v') {
      if ((**(char **)(pcVar9 + 6) == '\x05') && (**(char **)(pcVar2 + 6) == '\x05')) {
        if (*(char **)(pcVar9 + 6) != *(char **)(pcVar2 + 6)) {
          FUN_004eb810();
          cVar8 = FUN_004eb790(*(int *)(*(int *)(param_2 + 6) + 6),
                               *(int *)(*(int *)(param_3 + 6) + 6),'\0','\x01');
          pbVar5 = param_2;
          if (cVar8 == '\0') {
            cVar8 = FUN_004eb790(*(int *)(*(int *)(param_3 + 6) + 6),
                                 *(int *)(*(int *)(param_2 + 6) + 6),'\0','\x01');
            pbVar5 = param_3;
            if (cVar8 == '\0') {
              FUN_004463d0(0xf5);
            }
            else {
              iVar14 = *(int *)(*(int *)(param_2 + 6) + 6);
              iVar3 = *(int *)(*(int *)(param_3 + 6) + 6);
              FUN_004eb810();
              pbVar16 = (byte *)FUN_004eb0e0((char *)pbVar5,iVar3,iVar14,'\0','\x01');
              pbVar17 = pbVar16;
              if ((pbVar16 != pbVar5) &&
                 (((*pbVar16 != 0x30 || (*(byte **)(pbVar16 + 10) != pbVar5)) &&
                  (bVar6 = FUN_00473be0(pbVar5), (short)CONCAT31(extraout_var_02,bVar6) == 0)))) {
                pbVar17 = (byte *)FUN_00441fa0(0x1a);
                *(undefined4 *)pbVar17 = *(undefined4 *)pbVar16;
                *(undefined4 *)(pbVar17 + 4) = *(undefined4 *)(pbVar16 + 4);
                *(undefined4 *)(pbVar17 + 8) = *(undefined4 *)(pbVar16 + 8);
                *(undefined4 *)(pbVar17 + 0xc) = *(undefined4 *)(pbVar16 + 0xc);
                *(undefined4 *)(pbVar17 + 0x10) = *(undefined4 *)(pbVar16 + 0x10);
                *(undefined4 *)(pbVar17 + 0x14) = *(undefined4 *)(pbVar16 + 0x14);
                *(undefined2 *)(pbVar17 + 0x18) = *(undefined2 *)(pbVar16 + 0x18);
                *pbVar17 = 0x3a;
                iVar14 = FUN_00441fa0(0x1a);
                *(int *)(pbVar17 + 10) = iVar14;
                puVar12 = *(undefined4 **)(pbVar17 + 10);
                *puVar12 = *(undefined4 *)pbVar5;
                puVar12[1] = *(undefined4 *)(pbVar5 + 4);
                puVar12[2] = *(undefined4 *)(pbVar5 + 8);
                puVar12[3] = *(undefined4 *)(pbVar5 + 0xc);
                puVar12[4] = *(undefined4 *)(pbVar5 + 0x10);
                puVar12[5] = *(undefined4 *)(pbVar5 + 0x14);
                *(undefined2 *)(puVar12 + 6) = *(undefined2 *)(pbVar5 + 0x18);
                *(byte **)(pbVar17 + 0xe) = pbVar16;
                iVar14 = FUN_00490650();
                *(int *)(pbVar17 + 0x12) = iVar14;
                *pbVar5 = 0x3b;
                *(undefined4 *)(pbVar5 + 10) = *(undefined4 *)(pbVar17 + 0x12);
              }
              *(undefined4 *)(pbVar17 + 6) = *(undefined4 *)(param_2 + 6);
              param_3 = pbVar17;
            }
          }
          else {
            iVar14 = *(int *)(*(int *)(param_3 + 6) + 6);
            iVar3 = *(int *)(*(int *)(param_2 + 6) + 6);
            FUN_004eb810();
            pbVar16 = (byte *)FUN_004eb0e0((char *)pbVar5,iVar3,iVar14,'\0','\x01');
            pbVar17 = pbVar16;
            if (((pbVar16 != pbVar5) && ((*pbVar16 != 0x30 || (*(byte **)(pbVar16 + 10) != pbVar5)))
                ) && (bVar6 = FUN_00473be0(pbVar5), (short)CONCAT31(extraout_var_01,bVar6) == 0)) {
              pbVar17 = (byte *)FUN_00441fa0(0x1a);
              *(undefined4 *)pbVar17 = *(undefined4 *)pbVar16;
              *(undefined4 *)(pbVar17 + 4) = *(undefined4 *)(pbVar16 + 4);
              *(undefined4 *)(pbVar17 + 8) = *(undefined4 *)(pbVar16 + 8);
              *(undefined4 *)(pbVar17 + 0xc) = *(undefined4 *)(pbVar16 + 0xc);
              *(undefined4 *)(pbVar17 + 0x10) = *(undefined4 *)(pbVar16 + 0x10);
              *(undefined4 *)(pbVar17 + 0x14) = *(undefined4 *)(pbVar16 + 0x14);
              *(undefined2 *)(pbVar17 + 0x18) = *(undefined2 *)(pbVar16 + 0x18);
              *pbVar17 = 0x3a;
              iVar14 = FUN_00441fa0(0x1a);
              *(int *)(pbVar17 + 10) = iVar14;
              puVar12 = *(undefined4 **)(pbVar17 + 10);
              *puVar12 = *(undefined4 *)pbVar5;
              puVar12[1] = *(undefined4 *)(pbVar5 + 4);
              puVar12[2] = *(undefined4 *)(pbVar5 + 8);
              puVar12[3] = *(undefined4 *)(pbVar5 + 0xc);
              puVar12[4] = *(undefined4 *)(pbVar5 + 0x10);
              puVar12[5] = *(undefined4 *)(pbVar5 + 0x14);
              *(undefined2 *)(puVar12 + 6) = *(undefined2 *)(pbVar5 + 0x18);
              *(byte **)(pbVar17 + 0xe) = pbVar16;
              iVar14 = FUN_00490650();
              *(int *)(pbVar17 + 0x12) = iVar14;
              *pbVar5 = 0x3b;
              *(undefined4 *)(pbVar5 + 10) = *(undefined4 *)(pbVar17 + 0x12);
            }
            *(undefined4 *)(pbVar17 + 6) = *(undefined4 *)(param_3 + 6);
            param_2 = pbVar17;
          }
        }
        *(undefined4 *)(local_28 + 6) = *(undefined4 *)(param_2 + 6);
        break;
      }
      if (*(undefined1 **)(pcVar2 + 6) == &DAT_0055d5d0) {
        *(char **)(local_28 + 6) = pcVar2;
      }
    }
    uVar11 = FUN_0048f980(*(char **)(param_2 + 6),*(char **)(param_3 + 6));
    if ((short)uVar11 == 0) {
      if ((DAT_0058427c == '\0') ||
         (uVar11 = FUN_005090c0(*(char **)(param_2 + 6),*(char **)(param_3 + 6)),
         (char)uVar11 == '\0')) {
        FUN_004463d0(0xf5);
      }
      else {
        pcVar9 = FUN_00509440('\x01');
        *(char **)(param_3 + 6) = pcVar9;
        *(undefined4 *)(param_2 + 6) = *(undefined4 *)(param_3 + 6);
      }
    }
  }
  *(byte **)(local_28 + 0xe) = param_2;
  *(byte **)(local_28 + 0x12) = param_3;
  bVar6 = FUN_00473be0(pbVar10);
  if (((short)CONCAT31(extraout_var_03,bVar6) != 0) ||
     (uVar7 = FUN_00473cb0((char *)pbVar10), param_2 = param_3,
     (short)CONCAT31(extraout_var_04,uVar7) != 0)) {
    local_28 = param_2;
  }
  return local_28;
}



byte * __cdecl FUN_0046c2e0(undefined4 *param_1,int param_2,char param_3)

{
  char cVar1;
  bool bVar2;
  undefined4 *puVar3;
  char *pcVar4;
  undefined4 uVar5;
  byte *pbVar6;
  undefined4 *puVar7;
  int *piVar8;
  undefined1 *puVar9;
  char *pcVar10;
  int iVar11;
  undefined1 *puVar12;
  char *pcVar13;
  undefined1 *puVar14;
  undefined1 *puVar15;
  undefined1 *puVar16;
  int iVar17;
  byte *local_38;
  char *local_24;
  char *local_1c;
  undefined1 *local_14;
  
  puVar3 = (undefined4 *)FUN_00441fe0(0xe);
  *puVar3 = *param_1;
  puVar3[1] = param_1[1];
  puVar3[2] = param_1[2];
  *(undefined2 *)(puVar3 + 3) = *(undefined2 *)(param_1 + 3);
  *(undefined1 *)puVar3 = 0xb;
  *(undefined4 *)((int)puVar3 + 2) = 4;
  *(undefined4 *)((int)puVar3 + 10) = 0;
  for (pcVar4 = *(char **)((int)param_1 + 6); *pcVar4 == '\f'; pcVar4 = *(char **)(pcVar4 + 6)) {
  }
  uVar5 = FUN_00504750(pcVar4);
  if ((char)uVar5 == '\0') {
LAB_0046c357:
    pbVar6 = (byte *)FUN_00441fa0(0x1a);
    FUN_00441db0(pbVar6,0x1a);
    *pbVar6 = 0x32;
    *(undefined1 **)(pbVar6 + 6) = &DAT_0055f5f0;
    return pbVar6;
  }
  uVar5 = FUN_005047a0(pcVar4);
  if ((char)uVar5 == '\0') goto LAB_0046c357;
  local_24 = (char *)0x0;
  bVar2 = false;
  if (*pcVar4 == '\x05') {
    puVar7 = FUN_004ebce0((int)pcVar4);
    if (puVar7 == (undefined4 *)0x0) {
      pcVar10 = FUN_004ebca0((int)pcVar4);
      if (pcVar10 != (char *)0x0) goto LAB_0046c3de;
    }
    else {
      local_24 = FUN_004ebea0((int)pcVar4);
      if (local_24 == (char *)0x0) {
        FUN_004463d0(0xcb);
      }
      else {
        local_24[0x18] = local_24[0x18] | 1;
LAB_0046c3de:
        bVar2 = true;
      }
    }
  }
  if (!bVar2) {
    piVar8 = (int *)FUN_00441fa0(8);
    *piVar8 = param_2;
    iVar11 = *(int *)((int)param_1 + 2);
    puVar9 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar9,0x1a);
    *puVar9 = 0x32;
    *(undefined **)(puVar9 + 6) = &DAT_0055f5f8;
    *(int *)(puVar9 + 0xe) = iVar11;
    if (iVar11 < 0) {
      uVar5 = 0xffffffff;
    }
    else {
      uVar5 = 0;
    }
    *(undefined4 *)(puVar9 + 10) = uVar5;
    piVar8[1] = (int)puVar9;
    if (DAT_005806a4 != (char *)0x0) {
      pcVar10 = FUN_00473720(DAT_005806a4,&DAT_0055f5f8);
      iVar11 = piVar8[1];
      puVar9 = (undefined1 *)FUN_00441fa0(0x1a);
      *puVar9 = 9;
      *(undefined4 *)(puVar9 + 6) = *(undefined4 *)(iVar11 + 6);
      *(int *)(puVar9 + 10) = iVar11;
      *(char **)(puVar9 + 0xe) = pcVar10;
      cVar1 = pcVar10[1];
      if (*(char *)(iVar11 + 1) == cVar1) {
        puVar9[1] = cVar1 + '\x01';
        if (200 < (byte)puVar9[1]) {
          puVar9[1] = 200;
        }
      }
      else {
        puVar9[1] = cVar1;
        if ((byte)puVar9[1] < *(byte *)(iVar11 + 1)) {
          puVar9[1] = *(byte *)(iVar11 + 1);
        }
      }
      *(ushort *)(puVar9 + 2) = (*(ushort *)(iVar11 + 2) | *(ushort *)(pcVar10 + 2)) & 3;
      piVar8[1] = (int)puVar9;
      FUN_004fb470(piVar8[1]);
    }
    pbVar6 = (byte *)FUN_0046cba0(pcVar4,piVar8,param_3,'\x01');
    *(undefined4 **)(pbVar6 + 6) = puVar3;
    return pbVar6;
  }
  local_14 = (undefined1 *)0x0;
  if (*pcVar4 != '\x05') {
    FUN_00445780();
  }
  local_1c = FUN_004ebca0((int)pcVar4);
  if (local_1c != (char *)0x0) {
    local_1c = (char *)FUN_0050a340(local_1c);
  }
  piVar8 = (int *)FUN_00441fa0(8);
  *piVar8 = param_2;
  if (DAT_005806a4 == (char *)0x0) {
    iVar11 = *(int *)((int)param_1 + 2) + 8;
    puVar9 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar9,0x1a);
    *puVar9 = 0x32;
    *(undefined **)(puVar9 + 6) = &DAT_0055f5f8;
    *(int *)(puVar9 + 0xe) = iVar11;
    if (iVar11 < 0) {
      uVar5 = 0xffffffff;
    }
    else {
      uVar5 = 0;
    }
    *(undefined4 *)(puVar9 + 10) = uVar5;
    piVar8[1] = (int)puVar9;
    if (*(int *)(pcVar4 + 2) == 0) {
      iVar11 = 0;
    }
    else {
      iVar11 = *(int *)((int)param_1 + 2) / *(int *)(pcVar4 + 2);
    }
    puVar9 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar9,0x1a);
    *puVar9 = 0x32;
    *(undefined **)(puVar9 + 6) = &DAT_0055f5f8;
    *(int *)(puVar9 + 0xe) = iVar11;
    if (iVar11 < 0) {
      uVar5 = 0xffffffff;
    }
    else {
      uVar5 = 0;
    }
    *(undefined4 *)(puVar9 + 10) = uVar5;
    DAT_005806a4 = puVar9;
  }
  else {
    puVar9 = FUN_0047c2c0(&DAT_0055f5f8);
    pcVar10 = FUN_00473720(DAT_005806a4,&DAT_0055f5f8);
    if (*(int *)(pcVar4 + 2) == 0) {
      iVar11 = 0;
    }
    else {
      iVar11 = *(int *)((int)param_1 + 2) / *(int *)(pcVar4 + 2);
    }
    pcVar13 = pcVar10;
    if (1 < iVar11) {
      puVar12 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar12,0x1a);
      *puVar12 = 0x32;
      *(undefined **)(puVar12 + 6) = &DAT_0055f5f8;
      *(int *)(puVar12 + 0xe) = iVar11;
      if (iVar11 < 0) {
        uVar5 = 0xffffffff;
      }
      else {
        uVar5 = 0;
      }
      *(undefined4 *)(puVar12 + 10) = uVar5;
      pcVar13 = (char *)FUN_00441fa0(0x1a);
      *pcVar13 = '\t';
      *(undefined4 *)(pcVar13 + 6) = *(undefined4 *)(pcVar10 + 6);
      *(char **)(pcVar13 + 10) = pcVar10;
      *(undefined1 **)(pcVar13 + 0xe) = puVar12;
      cVar1 = puVar12[1];
      if (pcVar10[1] == cVar1) {
        pcVar13[1] = cVar1 + '\x01';
        if (200 < (byte)pcVar13[1]) {
          pcVar13[1] = -0x38;
        }
      }
      else {
        pcVar13[1] = cVar1;
        if ((byte)pcVar13[1] < (byte)pcVar10[1]) {
          pcVar13[1] = pcVar10[1];
        }
      }
      *(ushort *)(pcVar13 + 2) = (*(ushort *)(pcVar10 + 2) | *(ushort *)(puVar12 + 2)) & 3;
      FUN_004fb470((int)pcVar13);
    }
    iVar11 = FUN_00472830((int)puVar9);
    local_14 = (undefined1 *)FUN_00441fa0(0x1a);
    *local_14 = 0x1e;
    *(undefined4 *)(local_14 + 6) = *(undefined4 *)(iVar11 + 6);
    *(int *)(local_14 + 10) = iVar11;
    *(char **)(local_14 + 0xe) = pcVar13;
    cVar1 = pcVar13[1];
    if (*(char *)(iVar11 + 1) == cVar1) {
      local_14[1] = cVar1 + '\x01';
      if (200 < (byte)local_14[1]) {
        local_14[1] = 200;
      }
    }
    else {
      local_14[1] = cVar1;
      if ((byte)local_14[1] < *(byte *)(iVar11 + 1)) {
        local_14[1] = *(byte *)(iVar11 + 1);
      }
    }
    *(ushort *)(local_14 + 2) = (*(ushort *)(iVar11 + 2) | *(ushort *)(pcVar13 + 2)) & 3;
    iVar11 = *(int *)(pcVar4 + 2);
    puVar12 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar12,0x1a);
    *puVar12 = 0x32;
    *(undefined **)(puVar12 + 6) = &DAT_0055f5f8;
    *(int *)(puVar12 + 0xe) = iVar11;
    if (iVar11 < 0) {
      uVar5 = 0xffffffff;
    }
    else {
      uVar5 = 0;
    }
    *(undefined4 *)(puVar12 + 10) = uVar5;
    iVar11 = FUN_00472830((int)puVar9);
    puVar14 = (undefined1 *)FUN_00441fa0(0x1a);
    *puVar14 = 9;
    *(undefined4 *)(puVar14 + 6) = *(undefined4 *)(iVar11 + 6);
    *(int *)(puVar14 + 10) = iVar11;
    *(undefined1 **)(puVar14 + 0xe) = puVar12;
    cVar1 = puVar12[1];
    if (*(char *)(iVar11 + 1) == cVar1) {
      puVar14[1] = cVar1 + '\x01';
      if (200 < (byte)puVar14[1]) {
        puVar14[1] = 200;
      }
    }
    else {
      puVar14[1] = cVar1;
      if ((byte)puVar14[1] < *(byte *)(iVar11 + 1)) {
        puVar14[1] = *(byte *)(iVar11 + 1);
      }
    }
    *(ushort *)(puVar14 + 2) = (*(ushort *)(iVar11 + 2) | *(ushort *)(puVar12 + 2)) & 3;
    FUN_004fb470((int)puVar14);
    puVar12 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar12,0x1a);
    *puVar12 = 0x32;
    *(undefined **)(puVar12 + 6) = &DAT_0055f5f8;
    *(undefined4 *)(puVar12 + 0xe) = 8;
    *(undefined4 *)(puVar12 + 10) = 0;
    puVar15 = (undefined1 *)FUN_00441fa0(0x1a);
    *puVar15 = 0xf;
    *(undefined4 *)(puVar15 + 6) = *(undefined4 *)(puVar14 + 6);
    *(undefined1 **)(puVar15 + 10) = puVar14;
    *(undefined1 **)(puVar15 + 0xe) = puVar12;
    cVar1 = puVar12[1];
    if (puVar14[1] == cVar1) {
      puVar15[1] = cVar1 + '\x01';
      if (200 < (byte)puVar15[1]) {
        puVar15[1] = 200;
      }
    }
    else {
      puVar15[1] = cVar1;
      if ((byte)puVar15[1] < (byte)puVar14[1]) {
        puVar15[1] = puVar14[1];
      }
    }
    *(ushort *)(puVar15 + 2) = (*(ushort *)(puVar14 + 2) | *(ushort *)(puVar12 + 2)) & 3;
    FUN_004fb470((int)puVar15);
    piVar8[1] = (int)puVar15;
    DAT_005806a4 = (char *)FUN_00472830((int)puVar9);
  }
  puVar7 = (undefined4 *)FUN_0046cba0(pcVar4,piVar8,param_3,'\x01');
  *(undefined4 **)((int)puVar7 + 6) = puVar3;
  if (((DAT_00588238 != 0) && (param_2 == 0)) && (DAT_0058428b != '\0')) {
    pcVar10 = FUN_0048fd50(pcVar4,'\x01',param_3);
    if (pcVar10 != (char *)0x0) {
      local_38 = (byte *)FUN_00441fa0(0x1a);
      *(undefined4 *)local_38 = *puVar7;
      *(undefined4 *)(local_38 + 4) = puVar7[1];
      *(undefined4 *)(local_38 + 8) = puVar7[2];
      *(undefined4 *)(local_38 + 0xc) = puVar7[3];
      *(undefined4 *)(local_38 + 0x10) = puVar7[4];
      *(undefined4 *)(local_38 + 0x14) = puVar7[5];
      *(undefined2 *)(local_38 + 0x18) = *(undefined2 *)(puVar7 + 6);
      puVar9 = FUN_0047c2c0(0x55d5d8);
      iVar11 = FUN_00472830((int)puVar9);
      puVar12 = (undefined1 *)FUN_00441fa0(0x1a);
      *puVar12 = 0x1e;
      *(undefined4 *)(puVar12 + 6) = *(undefined4 *)(iVar11 + 6);
      *(int *)(puVar12 + 10) = iVar11;
      *(undefined4 **)(puVar12 + 0xe) = puVar7;
      cVar1 = *(char *)((int)puVar7 + 1);
      if (*(char *)(iVar11 + 1) == cVar1) {
        puVar12[1] = cVar1 + '\x01';
        if (200 < (byte)puVar12[1]) {
          puVar12[1] = 200;
        }
      }
      else {
        puVar12[1] = cVar1;
        if ((byte)puVar12[1] < *(byte *)(iVar11 + 1)) {
          puVar12[1] = *(byte *)(iVar11 + 1);
        }
      }
      *(ushort *)(puVar12 + 2) = (*(ushort *)(iVar11 + 2) | *(ushort *)((int)puVar7 + 2)) & 3;
      *local_38 = 0x42;
      *(undefined1 **)(local_38 + 10) = puVar12;
      iVar11 = *(int *)(pcVar4 + 2);
      puVar12 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar12,0x1a);
      *puVar12 = 0x32;
      *(undefined **)(puVar12 + 6) = &DAT_0055f5f8;
      *(int *)(puVar12 + 0xe) = iVar11;
      if (iVar11 < 0) {
        uVar5 = 0xffffffff;
      }
      else {
        uVar5 = 0;
      }
      *(undefined4 *)(puVar12 + 10) = uVar5;
      if (local_1c == (char *)0x0) {
        puVar14 = (undefined1 *)FUN_00441fa0(0x1a);
        FUN_00441db0(puVar14,0x1a);
        *puVar14 = 0x32;
        *(undefined1 **)(puVar14 + 6) = &DAT_0055f5f0;
      }
      else {
        puVar14 = FUN_00472960((int)local_1c);
      }
      if (local_24 == (char *)0x0) {
        puVar15 = (undefined1 *)FUN_00441fa0(0x1a);
        FUN_00441db0(puVar15,0x1a);
        *puVar15 = 0x32;
        *(undefined1 **)(puVar15 + 6) = &DAT_0055f5f0;
      }
      else {
        puVar15 = FUN_00472960((int)local_24);
      }
      iVar17 = 0;
      puVar16 = DAT_005806a4;
      iVar11 = FUN_00472830((int)puVar9);
      uVar5 = FUN_00472300(DAT_00587c6c,iVar11,(int)puVar15,(int)puVar14,(int)puVar12,(int)puVar16,
                           iVar17);
      *(undefined4 *)(local_38 + 0xe) = uVar5;
      iVar11 = *(int *)(local_38 + 0xe);
      iVar17 = FUN_00472830((int)puVar9);
      puVar12 = (undefined1 *)FUN_00441fa0(0x1a);
      *puVar12 = 0x1e;
      *(undefined4 *)(puVar12 + 6) = *(undefined4 *)(iVar17 + 6);
      *(int *)(puVar12 + 10) = iVar17;
      *(int *)(puVar12 + 0xe) = iVar11;
      cVar1 = *(char *)(iVar11 + 1);
      if (*(char *)(iVar17 + 1) == cVar1) {
        puVar12[1] = cVar1 + '\x01';
        if (200 < (byte)puVar12[1]) {
          puVar12[1] = 200;
        }
      }
      else {
        puVar12[1] = cVar1;
        if ((byte)puVar12[1] < *(byte *)(iVar17 + 1)) {
          puVar12[1] = *(byte *)(iVar17 + 1);
        }
      }
      *(ushort *)(puVar12 + 2) = (*(ushort *)(iVar17 + 2) | *(ushort *)(iVar11 + 2)) & 3;
      *(undefined1 **)(local_38 + 0xe) = puVar12;
      *(undefined1 **)(local_38 + 0x12) = puVar9;
      *(char **)(local_38 + 0x16) = pcVar10;
      goto LAB_0046ca71;
    }
  }
  iVar11 = *(int *)(pcVar4 + 2);
  puVar9 = (undefined1 *)FUN_00441fa0(0x1a);
  FUN_00441db0(puVar9,0x1a);
  *puVar9 = 0x32;
  *(undefined **)(puVar9 + 6) = &DAT_0055f5f8;
  *(int *)(puVar9 + 0xe) = iVar11;
  if (iVar11 < 0) {
    uVar5 = 0xffffffff;
  }
  else {
    uVar5 = 0;
  }
  *(undefined4 *)(puVar9 + 10) = uVar5;
  if (local_1c == (char *)0x0) {
    puVar12 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar12,0x1a);
    *puVar12 = 0x32;
    *(undefined1 **)(puVar12 + 6) = &DAT_0055f5f0;
  }
  else {
    puVar12 = FUN_00472960((int)local_1c);
  }
  if (local_24 == (char *)0x0) {
    puVar14 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar14,0x1a);
    *puVar14 = 0x32;
    *(undefined1 **)(puVar14 + 6) = &DAT_0055f5f0;
  }
  else {
    puVar14 = FUN_00472960((int)local_24);
  }
  local_38 = (byte *)FUN_00472300(DAT_00587c6c,(int)puVar7,(int)puVar14,(int)puVar12,(int)puVar9,
                                  (int)DAT_005806a4,0);
LAB_0046ca71:
  if (local_14 != (undefined1 *)0x0) {
    local_38 = (byte *)FUN_00473cf0((int)local_14,local_38);
  }
  *(undefined4 **)(local_38 + 6) = puVar3;
  return local_38;
}


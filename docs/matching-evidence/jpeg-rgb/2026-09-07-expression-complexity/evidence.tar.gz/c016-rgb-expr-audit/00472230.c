
void __cdecl
FUN_00472230(undefined2 param_1,short *param_2,char *param_3,uint param_4,char *param_5,uint param_6
            ,char param_7)

{
  bool bVar1;
  
  FUN_00441db0((undefined1 *)param_2,10);
  switch(param_1) {
  case 1:
    *param_2 = *param_2 + 1;
    break;
  case 2:
    param_2[1] = param_2[1] + 1;
    break;
  case 3:
    param_2[2] = param_2[2] + 1;
    param_2[3] = param_2[3] + DAT_005806a0;
    break;
  default:
    FUN_00445780();
  }
  if (param_7 == '\0') {
    if (*param_5 != '\v') {
      return;
    }
    bVar1 = true;
    if ((*param_3 != '\v') && ((*(uint *)(param_5 + 10) & 0x20) == 0)) {
      bVar1 = false;
    }
    if (!bVar1) {
      return;
    }
  }
  if ((param_6 & 1) == (param_4 & 1)) {
    param_2[4] = param_2[4] + 1;
  }
  if ((param_6 & 2) == (param_4 & 2)) {
    param_2[4] = param_2[4] + 1;
  }
  return;
}


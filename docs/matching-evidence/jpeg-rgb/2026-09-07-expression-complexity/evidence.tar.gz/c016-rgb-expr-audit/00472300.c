
void __cdecl
FUN_00472300(int param_1,int param_2,int param_3,int param_4,int param_5,int param_6,int param_7)

{
  char *pcVar1;
  char cVar2;
  undefined4 *puVar3;
  undefined1 *puVar4;
  undefined1 *puVar5;
  int *piVar6;
  int iVar7;
  
  pcVar1 = *(char **)(param_1 + 0xe);
  if (*pcVar1 != '\x06') {
    FUN_00445780();
  }
  puVar3 = (undefined4 *)FUN_00441fa0(0x1a);
  *(undefined1 *)puVar3 = 0x36;
  *(undefined1 *)((int)puVar3 + 1) = 4;
  *(undefined4 *)((int)puVar3 + 6) = *(undefined4 *)(pcVar1 + 0xe);
  *(ushort *)((int)puVar3 + 2) = *(ushort *)(pcVar1 + 0x12) & 3;
  if (DAT_00587fd8 != (code *)0x0) {
    cVar2 = (*DAT_00587fd8)(0,param_1);
    if (cVar2 == '\0') {
      puVar4 = (undefined1 *)FUN_00441fa0(0x1a);
      FUN_00441db0(puVar4,0x1a);
      *puVar4 = 0x32;
      *(undefined4 *)(puVar4 + 6) = 0x55d5d8;
      *(undefined4 *)(puVar4 + 0xe) = 0;
      *(undefined4 *)(puVar4 + 10) = 0;
      goto LAB_00472415;
    }
  }
  if (*(short *)(param_1 + 0x16) == 0x104) {
    FUN_004463d0(0x8d);
    puVar4 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar4,0x1a);
    *puVar4 = 0x32;
    *(undefined4 *)(puVar4 + 6) = 0x55d5d8;
    *(undefined4 *)(puVar4 + 0xe) = 0;
    *(undefined4 *)(puVar4 + 10) = 0;
  }
  else {
    puVar4 = (undefined1 *)FUN_00441fa0(0x1a);
    FUN_00441db0(puVar4,0x1a);
    *puVar4 = 0x38;
    *(int *)(puVar4 + 10) = param_1;
    puVar5 = FUN_00504930(*(undefined4 *)(param_1 + 0xe));
    *(undefined1 **)(puVar4 + 6) = puVar5;
    if (**(char **)(param_1 + 0xe) != '\x06') {
      *(ushort *)(puVar4 + 2) = *(ushort *)(param_1 + 0x12) & 3;
    }
    *(byte *)(param_1 + 0x18) = *(byte *)(param_1 + 0x18) | 1;
  }
LAB_00472415:
  *(undefined1 **)((int)puVar3 + 10) = puVar4;
  *(char **)((int)puVar3 + 0x12) = pcVar1;
  piVar6 = (int *)FUN_00441fa0(8);
  *(int **)((int)puVar3 + 0xe) = piVar6;
  piVar6[1] = param_2;
  iVar7 = FUN_00441fa0(8);
  *piVar6 = iVar7;
  piVar6 = (int *)*piVar6;
  piVar6[1] = param_3;
  iVar7 = FUN_00441fa0(8);
  *piVar6 = iVar7;
  piVar6 = (int *)*piVar6;
  piVar6[1] = param_4;
  iVar7 = FUN_00441fa0(8);
  *piVar6 = iVar7;
  piVar6 = (int *)*piVar6;
  piVar6[1] = param_5;
  iVar7 = FUN_00441fa0(8);
  *piVar6 = iVar7;
  piVar6 = (int *)*piVar6;
  piVar6[1] = param_6;
  if (param_7 != 0) {
    iVar7 = FUN_00441fa0(8);
    *piVar6 = iVar7;
    piVar6 = (int *)*piVar6;
    piVar6[1] = param_7;
  }
  *piVar6 = 0;
  FUN_00472660(puVar3);
  return;
}


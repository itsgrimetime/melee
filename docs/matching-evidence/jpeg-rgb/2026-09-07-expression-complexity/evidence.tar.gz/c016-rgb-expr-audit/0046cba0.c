
void __cdecl FUN_0046cba0(char *param_1,int *param_2,char param_3,char param_4)

{
  bool bVar1;
  bool bVar2;
  int iVar3;
  uint uVar4;
  int *unaff_EBP;
  char *unaff_EDI;
  int local_34 [4];
  char *local_24;
  int *local_20;
  
  bVar2 = false;
  if ((param_3 == '\0') && (*param_1 == '\x05')) {
    bVar1 = false;
    unaff_EBP = (int *)0x0;
    unaff_EDI = (char *)0x0;
    if ((param_4 != '\0') && (DAT_005842a6 != '\0')) {
      bVar1 = true;
    }
    iVar3 = DAT_00587f74;
    if (bVar1) {
      iVar3 = DAT_00588008;
    }
    uVar4 = FUN_00497fd0((int)param_1,local_34,*(undefined4 *)(iVar3 + 4));
    if ((char)uVar4 == '\0') {
      if ((*(ushort *)(param_1 + 0x2a) & 1) == 0) goto LAB_0046cc4e;
      local_24 = DAT_00588094;
      if (param_4 != '\0') {
        FUN_00445780();
        local_24 = DAT_00588094;
      }
    }
    else {
      unaff_EBP = local_20;
      if ((local_20 == (int *)0x0) && (local_24 == (char *)0x0)) {
        FUN_00445780();
      }
    }
    bVar2 = true;
    unaff_EDI = local_24;
  }
LAB_0046cc4e:
  if (!bVar2) {
    iVar3 = DAT_00587f74;
    if ((param_4 != '\0') && (DAT_005842a6 != '\0')) {
      iVar3 = DAT_00588008;
    }
    unaff_EBP = (int *)(iVar3 + 8);
    unaff_EDI = (char *)0x0;
  }
  FUN_0046eb90((int *)0x0,(byte *)0x0,'\0',unaff_EDI,unaff_EBP,0,param_2,'\0','\0','\x01');
  return;
}


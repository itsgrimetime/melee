
void __cdecl FUN_004f0e20(byte *param_1)

{
  char cVar1;
  byte *pbVar2;
  char cVar3;
  
  pbVar2 = param_1;
  if (DAT_005842c1 != '\0') {
    for (; *pbVar2 == 0x30; pbVar2 = *(byte **)(pbVar2 + 10)) {
    }
    if (*pbVar2 == 0x17) {
      FUN_004457e0(0xd0);
      return;
    }
  }
  if (DAT_005842cb == '\0') goto LAB_004f0f00;
  switch(*param_1) {
  case 0:
  case 1:
  case 2:
  case 3:
  case 8:
  case 0x1e:
  case 0x1f:
  case 0x20:
  case 0x21:
  case 0x22:
  case 0x23:
  case 0x24:
  case 0x25:
  case 0x26:
  case 0x27:
  case 0x28:
  case 0x36:
  case 0x37:
  case 0x39:
  case 0x3a:
  case 0x3b:
  case 0x3f:
  case 0x46:
    cVar3 = '\x01';
    break;
  case 4:
    if (1 < **(byte **)(param_1 + 10) - 0x36) goto LAB_004f0ee5;
    cVar3 = '\x01';
    break;
  case 5:
  case 6:
  case 7:
  case 9:
  case 0xb:
  case 0xc:
  case 0xf:
  case 0x10:
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
  case 0x15:
  case 0x16:
  case 0x17:
  case 0x18:
  case 0x19:
  case 0x1a:
  case 0x1b:
  case 0x1c:
  case 0x1d:
  case 0x2b:
  case 0x2c:
  case 0x31:
  case 0x32:
  case 0x33:
  case 0x34:
  case 0x38:
  case 0x3c:
  case 0x3d:
  case 0x3e:
  case 0x43:
  case 0x44:
  case 0x4a:
    goto LAB_004f0ee5;
  default:
    FUN_00445780();
LAB_004f0ee5:
    cVar3 = '\0';
    break;
  case 0x29:
    cVar3 = FUN_00513910(*(undefined1 **)(param_1 + 0xe));
    break;
  case 0x30:
    cVar3 = **(char **)(param_1 + 6) == '\0';
    break;
  case 0x35:
    cVar3 = '\x01';
    cVar1 = FUN_00513910(*(undefined1 **)(param_1 + 0xe));
    if ((cVar1 == '\0') && (cVar1 = FUN_00513910(*(undefined1 **)(param_1 + 0x12)), cVar1 == '\0'))
    {
      cVar3 = '\0';
    }
  }
  if (cVar3 == '\0') {
    FUN_004457e0(0x171);
    return;
  }
LAB_004f0f00:
  if ((DAT_005842cc != '\0') && (**(char **)(param_1 + 6) != '\0')) {
    if (*param_1 == 4) {
      param_1 = *(byte **)(param_1 + 10);
    }
    if (*param_1 - 0x36 < 2) {
      FUN_004457e0(0x172);
      return;
    }
  }
  return;
}


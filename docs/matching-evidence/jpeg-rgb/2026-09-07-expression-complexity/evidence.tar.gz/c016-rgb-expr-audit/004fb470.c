
void __cdecl FUN_004fb470(int param_1)

{
  char *pcVar1;
  char *pcVar2;
  
  pcVar1 = *(char **)(param_1 + 0xe);
  if (*pcVar1 == '2') {
    return;
  }
  pcVar2 = *(char **)(param_1 + 10);
  if (*pcVar2 != '2') {
    if (*pcVar2 == '3') {
      return;
    }
    if (*pcVar1 != '3') {
      if ('\x02' < **(char **)(param_1 + 6)) {
        return;
      }
      if ((byte)pcVar2[1] <= (byte)pcVar1[1]) {
        return;
      }
    }
  }
  *(char **)(param_1 + 0xe) = pcVar2;
  *(char **)(param_1 + 10) = pcVar1;
  return;
}


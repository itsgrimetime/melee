
char * __cdecl FUN_004f6ac0(char *param_1)

{
  char *pcVar1;
  byte *pbVar2;
  undefined4 uVar3;
  undefined8 uVar4;
  char *local_10;
  byte *local_c;
  
  if (**(char **)(param_1 + 6) == '\x0e') {
    pcVar1 = (char *)FUN_005179b0((char *)0x0,6,param_1);
    return pcVar1;
  }
  pcVar1 = FUN_004fa340(param_1);
  pbVar2 = (byte *)FUN_004fb4c0(pcVar1);
  if (DAT_0058427a != '\0') {
    uVar3 = FUN_0046d220(0x7e,pbVar2,(byte *)0x0,(int *)&local_10);
    if ((char)uVar3 != '\0') {
      if (local_10 != (char *)0x0) {
        return local_10;
      }
      pbVar2 = local_c;
      if (local_c == (byte *)0x0) {
        FUN_00445780();
      }
    }
  }
  pcVar1 = FUN_004738d0((char *)pbVar2);
  if (*pcVar1 == '2') {
    uVar4 = FUN_004a8db0(*(char **)(pcVar1 + 6),0x7e,*(undefined8 *)(pcVar1 + 10));
    *(undefined8 *)(pcVar1 + 10) = uVar4;
    return pcVar1;
  }
  pcVar1 = (char *)FUN_00473ea0((int)pcVar1,6);
  return pcVar1;
}


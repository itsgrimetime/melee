
uint __cdecl FUN_0046dcb0(char *param_1,char *param_2,undefined2 param_3)

{
  char cVar1;
  char cVar2;
  uint3 uVar4;
  uint uVar3;
  
  if (*param_1 == '\x03') {
    param_1 = *(char **)(param_1 + 0xe);
  }
  if (*param_2 == '\x03') {
    param_2 = *(char **)(param_2 + 0xe);
  }
  if ((*param_1 == '\v') && ((*(uint *)(param_1 + 10) & 0x20) != 0)) {
    param_1 = *(char **)(param_1 + 6);
  }
  if ((*param_2 == '\v') && ((*(uint *)(param_2 + 10) & 0x20) != 0)) {
    param_2 = *(char **)(param_2 + 6);
  }
  cVar1 = *param_1;
  cVar2 = *param_2;
  uVar4 = (uint3)((uint)param_2 >> 8);
  switch(param_3) {
  case 0:
    goto switchD_0046dd04_caseD_0;
  case 1:
    break;
  case 3:
    if ((cVar1 != '\v') || (cVar2 != '\v')) {
      return (uint)uVar4 << 8;
    }
    goto LAB_0046dd20;
  case 4:
    if (cVar1 == '\v') {
      if (cVar2 == '\x01') {
        DAT_005550cc = param_1;
        DAT_005550b4 = param_2;
        return CONCAT31(uVar4,1);
      }
      return (uint)uVar4 << 8;
    }
    if (cVar2 == '\v') {
      if (cVar1 == '\x01') {
        DAT_005550cc = param_1;
        DAT_005550b4 = param_2;
        return CONCAT31(uVar4,1);
      }
      return (uint)uVar4 << 8;
    }
    break;
  case 5:
    if (cVar1 == '\v') {
      if (cVar2 != '\v') {
        if (cVar2 == '\x01') {
          DAT_005550cc = param_1;
          DAT_005550b4 = param_2;
          return CONCAT31(uVar4,1);
        }
        return (uint)uVar4 << 8;
      }
      goto LAB_0046dd20;
    }
    break;
  case 6:
    if (((cVar1 == '\v') && (cVar2 == '\x01')) || ((cVar1 == '\x01' && (cVar2 == '\v')))) {
      DAT_005550cc = param_1;
      DAT_005550b4 = param_2;
      return CONCAT31(uVar4,1);
    }
  case 2:
    if ((cVar1 == '\v') || (cVar2 == '\v')) {
LAB_0046dd20:
      DAT_005550b4 = param_2;
      DAT_005550cc = param_1;
      uVar3 = FUN_0048f800(param_1,param_2);
      return uVar3;
    }
    break;
  case 7:
    if (((cVar1 != '\v') || (cVar2 != '\x01')) && ((cVar1 != '\x01' || (cVar2 != '\v')))) {
      return (uint)uVar4 << 8;
    }
    DAT_005550cc = param_1;
    DAT_005550b4 = param_2;
    return CONCAT31(uVar4,1);
  default:
    uVar3 = FUN_00445780();
    return uVar3 & 0xffffff00;
  }
  if ((cVar1 == '\x02') || (cVar2 == '\x02')) {
    if (cVar1 != '\x02') {
      if (cVar1 == '\x01') {
        DAT_005550b4 = param_2;
        DAT_005550cc = param_2;
        return CONCAT31(uVar4,1);
      }
      return (uint)uVar4 << 8;
    }
    if (cVar2 != '\x02') {
      if (cVar2 == '\x01') {
        DAT_005550b4 = param_1;
        DAT_005550cc = param_1;
        return CONCAT31((int3)((uint)param_1 >> 8),1);
      }
      return (uint)uVar4 << 8;
    }
    if ((byte)param_1[6] < (byte)param_2[6]) {
      param_1 = param_2;
    }
    DAT_005550b4 = param_1;
    DAT_005550cc = param_1;
    return CONCAT31((int3)((uint)param_1 >> 8),1);
  }
switchD_0046dd04_caseD_0:
  if ((cVar1 == '\x01') && (cVar2 == '\x01')) {
    if ((byte)param_1[6] < (byte)param_2[6]) {
      param_1 = param_2;
    }
    if ((byte)param_1[6] < 7) {
      param_1 = &DAT_0055f5e0;
    }
    DAT_005550b4 = param_1;
    DAT_005550cc = param_1;
    return CONCAT31((int3)((uint)param_1 >> 8),1);
  }
  return (uint)uVar4 << 8;
}


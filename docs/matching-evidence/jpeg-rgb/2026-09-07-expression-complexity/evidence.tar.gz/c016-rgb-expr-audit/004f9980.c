
undefined1 * __cdecl FUN_004f9980(int param_1)

{
  undefined4 uVar1;
  undefined1 *puVar2;
  
  puVar2 = *(undefined1 **)(param_1 + 0x10);
  if (puVar2 != (undefined1 *)0x0) {
    switch(*puVar2) {
    case 0:
      FUN_004e9590(*(int **)(param_1 + 0x18),(int)puVar2);
      puVar2 = (undefined1 *)FUN_00441fa0(0x1a);
      *puVar2 = 0x32;
      puVar2[1] = 0;
      *(undefined2 *)(puVar2 + 2) = 0;
      *(undefined4 *)(puVar2 + 6) = *(undefined4 *)(*(int *)(param_1 + 0x10) + 10);
      uVar1 = *(undefined4 *)(*(int *)(param_1 + 0x10) + 0x12);
      *(undefined4 *)(puVar2 + 10) = *(undefined4 *)(*(int *)(param_1 + 0x10) + 0xe);
      *(undefined4 *)(puVar2 + 0xe) = uVar1;
      return puVar2;
    default:
      FUN_00445780();
      break;
    case 4:
      FUN_004463d0(0xdd);
      puVar2 = FUN_00473f70();
      return puVar2;
    case 5:
      FUN_004e9600(*(int **)(param_1 + 0x18),(int)puVar2);
      puVar2 = (undefined1 *)FUN_00472830(*(int *)(param_1 + 0x10));
      return puVar2;
    }
  }
  if (*(int *)(param_1 + 0x14) != 0) {
    puVar2 = FUN_00473fd0(0x43);
    *(undefined4 *)(puVar2 + 6) = *(undefined4 *)(*(int *)(*(int *)(param_1 + 0x14) + 4) + 0xe);
    *(undefined4 *)(puVar2 + 10) = *(undefined4 *)(param_1 + 0x14);
    return puVar2;
  }
  FUN_00445780();
  return (undefined1 *)0x0;
}


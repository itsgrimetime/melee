
byte * __cdecl FUN_00471b90(undefined4 *param_1,byte *param_2,char param_3)

{
  byte bVar1;
  int iVar2;
  int *piVar3;
  undefined4 *puVar4;
  uint uVar5;
  bool bVar6;
  short sVar7;
  byte *pbVar8;
  undefined1 *puVar9;
  undefined4 uVar10;
  byte *pbVar11;
  byte *pbVar12;
  int *piVar13;
  
  iVar2 = param_1[1];
  bVar6 = false;
  if (param_1 == (undefined4 *)0x0) {
    FUN_00445780();
  }
  if (**(char **)(param_2 + 6) == '\v') {
    piVar3 = (int *)*param_1;
    pbVar8 = param_2;
    while( true ) {
      if (piVar3 == (int *)0x0) {
        if ((param_3 != '\0') && (bVar6)) {
          pbVar8 = (byte *)FUN_004f6380((undefined4 *)pbVar8,param_2);
        }
        return pbVar8;
      }
      for (puVar4 = *(undefined4 **)(iVar2 + 0xe);
          (puVar4 != (undefined4 *)0x0 && (puVar4[1] != piVar3[1])); puVar4 = (undefined4 *)*puVar4)
      {
      }
      if (puVar4 == (undefined4 *)0x0) break;
      pbVar12 = pbVar8;
      if (*(char *)((int)puVar4 + 0x11) == '\0') {
        uVar5 = puVar4[2];
        if (uVar5 != 0) {
          bVar6 = true;
          sVar7 = FUN_004fab50((char *)pbVar8,uVar5);
          if (sVar7 == 0) {
            puVar9 = (undefined1 *)FUN_00441fa0(0x1a);
            FUN_00441db0(puVar9,0x1a);
            *puVar9 = 0x32;
            *(undefined **)(puVar9 + 6) = &DAT_0055f5f8;
            *(uint *)(puVar9 + 0xe) = uVar5;
            if ((int)uVar5 < 0) {
              uVar10 = 0xffffffff;
            }
            else {
              uVar10 = 0;
            }
            *(undefined4 *)(puVar9 + 10) = uVar10;
            pbVar12 = (byte *)FUN_00441fa0(0x1a);
            *pbVar12 = 0xf;
            *(undefined4 *)(pbVar12 + 6) = *(undefined4 *)(pbVar8 + 6);
            *(byte **)(pbVar12 + 10) = pbVar8;
            *(undefined1 **)(pbVar12 + 0xe) = puVar9;
            bVar1 = puVar9[1];
            if (pbVar8[1] == bVar1) {
              pbVar12[1] = bVar1 + 1;
              if (200 < pbVar12[1]) {
                pbVar12[1] = 200;
              }
            }
            else {
              pbVar12[1] = bVar1;
              if (pbVar12[1] < pbVar8[1]) {
                pbVar12[1] = pbVar8[1];
              }
            }
            *(ushort *)(pbVar12 + 2) = (*(ushort *)(pbVar8 + 2) | *(ushort *)(puVar9 + 2)) & 3;
            FUN_004fb470((int)pbVar12);
          }
        }
      }
      else if (*(int *)(puVar4[1] + 0x22) == 0) {
        bVar6 = true;
        uVar5 = puVar4[2];
        pbVar11 = pbVar8;
        if ((uVar5 != 0) && (sVar7 = FUN_004fab50((char *)pbVar8,uVar5), sVar7 == 0)) {
          puVar9 = (undefined1 *)FUN_00441fa0(0x1a);
          FUN_00441db0(puVar9,0x1a);
          *puVar9 = 0x32;
          *(undefined **)(puVar9 + 6) = &DAT_0055f5f8;
          *(uint *)(puVar9 + 0xe) = uVar5;
          if ((int)uVar5 < 0) {
            uVar10 = 0xffffffff;
          }
          else {
            uVar10 = 0;
          }
          *(undefined4 *)(puVar9 + 10) = uVar10;
          pbVar11 = (byte *)FUN_00441fa0(0x1a);
          *pbVar11 = 0xf;
          *(undefined4 *)(pbVar11 + 6) = *(undefined4 *)(pbVar8 + 6);
          *(byte **)(pbVar11 + 10) = pbVar8;
          *(undefined1 **)(pbVar11 + 0xe) = puVar9;
          bVar1 = puVar9[1];
          if (pbVar8[1] == bVar1) {
            pbVar11[1] = bVar1 + 1;
            if (200 < pbVar11[1]) {
              pbVar11[1] = 200;
            }
          }
          else {
            pbVar11[1] = bVar1;
            if (pbVar11[1] < pbVar8[1]) {
              pbVar11[1] = pbVar8[1];
            }
          }
          *(ushort *)(pbVar11 + 2) = (*(ushort *)(pbVar8 + 2) | *(ushort *)(puVar9 + 2)) & 3;
          FUN_004fb470((int)pbVar11);
        }
        puVar9 = FUN_00504930(puVar4[1]);
        puVar9 = FUN_00504930(puVar9);
        *(undefined1 **)(pbVar11 + 6) = puVar9;
        pbVar12 = (byte *)FUN_00441fa0(0x1a);
        *pbVar12 = 4;
        pbVar12[1] = pbVar11[1];
        if (pbVar12[1] == 0) {
          pbVar12[1] = 1;
        }
        *(ushort *)(pbVar12 + 2) = *(ushort *)(pbVar11 + 2) & 3;
        *(undefined4 *)(pbVar12 + 6) = *(undefined4 *)(pbVar11 + 6);
        *(byte **)(pbVar12 + 10) = pbVar11;
      }
      pbVar8 = pbVar12;
      if (*pbVar12 < 4) {
        pbVar8 = (byte *)FUN_00441fa0(0x1a);
        *pbVar8 = 0x30;
        pbVar8[1] = pbVar12[1];
        if (pbVar8[1] == 0) {
          pbVar8[1] = 1;
        }
        *(ushort *)(pbVar8 + 2) = *(ushort *)(pbVar12 + 2) & 3;
        *(undefined4 *)(pbVar8 + 6) = *(undefined4 *)(pbVar12 + 6);
        *(byte **)(pbVar8 + 10) = pbVar12;
      }
      puVar9 = FUN_00504930(puVar4[1]);
      *(undefined1 **)(pbVar8 + 6) = puVar9;
      iVar2 = piVar3[1];
      piVar3 = (int *)*piVar3;
    }
    FUN_004463d0(0xdd);
    do {
      piVar13 = piVar3;
      piVar3 = (int *)*piVar13;
    } while (piVar3 != (int *)0x0);
    pbVar8 = (byte *)FUN_00441fa0(0x1a);
    FUN_00441db0(pbVar8,0x1a);
    *pbVar8 = 0x32;
    *(undefined1 **)(pbVar8 + 6) = &DAT_0055f5f0;
    puVar9 = FUN_00504930(piVar13[1]);
    *(undefined1 **)(pbVar8 + 6) = puVar9;
    return pbVar8;
  }
  FUN_004463d0(0x8d);
  return param_2;
}



byte * __cdecl FUN_004f1780(char *param_1,char param_2,undefined4 param_3)

{
  char cVar1;
  undefined1 uVar2;
  char *pcVar3;
  byte *pbVar4;
  byte *pbVar5;
  byte *pbVar6;
  undefined4 uVar7;
  undefined3 extraout_var;
  byte *local_18 [3];
  
  cVar1 = **(char **)(param_1 + 6);
  pcVar3 = FUN_004fa340(param_1);
  pbVar4 = (byte *)FUN_004fb4c0(pcVar3);
  if (DAT_0058427a == '\0') {
    pbVar5 = FUN_00472ae0(pbVar4,'\x01','\x01');
    DAT_005882d8 = FUN_00492070();
    pbVar4 = FUN_004f1010();
    pcVar3 = FUN_004fa340((char *)pbVar4);
    pbVar6 = (byte *)FUN_004fb4c0(pcVar3);
  }
  else {
    DAT_005882d8 = FUN_00492070();
    pbVar5 = FUN_004f1010();
    pcVar3 = FUN_004fa340((char *)pbVar5);
    pbVar6 = (byte *)FUN_004fb4c0(pcVar3);
    uVar7 = FUN_0046d220((short)param_3,pbVar4,pbVar6,(int *)local_18);
    if ((char)uVar7 != '\0') {
      if (local_18[0] == (byte *)0x0) {
        FUN_00445780();
      }
      return local_18[0];
    }
    pbVar5 = FUN_00472ae0(pbVar4,'\x01','\x01');
  }
  if (cVar1 == '\f') {
    FUN_004463d0(0x90);
  }
  switch(**(undefined1 **)(pbVar5 + 6)) {
  case 1:
  case 2:
  case 0xb:
    goto switchD_004f1871_caseD_1;
  case 3:
    break;
  default:
    FUN_004463d0(0x90);
    return pbVar5;
  }
  if (DAT_0058427a != '\0') {
    FUN_004463d0(0x90);
    return pbVar5;
  }
  pbVar5 = FUN_00473ee0(pbVar5);
switchD_004f1871_caseD_1:
  if (**(char **)(pbVar6 + 6) == '\x03') {
    pbVar6 = FUN_00473ee0(pbVar6);
  }
  uVar2 = FUN_00473cb0((char *)pbVar6);
  if ((short)CONCAT31(extraout_var,uVar2) != 0) {
    return pbVar5;
  }
  if (**(char **)(pbVar5 + 6) != '\v') {
    pbVar4 = (byte *)FUN_004f1cb0((int)pbVar5,pbVar6,param_2);
    return pbVar4;
  }
  if (**(char **)(pbVar6 + 6) == '\x01') {
    if (param_2 == '#') {
      pbVar4 = (byte *)FUN_004fa7b0((char *)pbVar5,(char *)pbVar6);
      if (*pbVar4 == 0x10) {
        *pbVar4 = 0x23;
      }
    }
    else {
      pbVar4 = (byte *)FUN_004fa990((char *)pbVar5,(char *)pbVar6);
      if (*pbVar4 == 0xf) {
        *pbVar4 = 0x22;
      }
    }
    return pbVar4;
  }
  FUN_004463d0(0x90);
  return pbVar5;
}



undefined1 * __cdecl FUN_004f15d0(char *param_1,char param_2,undefined4 param_3)

{
  char cVar1;
  char *pcVar2;
  byte *pbVar3;
  byte *pbVar4;
  undefined4 uVar5;
  undefined1 *puVar6;
  undefined1 *local_18 [3];
  
  cVar1 = **(char **)(param_1 + 6);
  pcVar2 = FUN_004fa340(param_1);
  pbVar3 = (byte *)FUN_004fb4c0(pcVar2);
  if (DAT_0058427a == '\0') {
    if (**(char **)(pbVar3 + 6) == '\x03') {
      pbVar3 = FUN_00473ee0(pbVar3);
    }
    if ((**(char **)(pbVar3 + 6) != '\x01') &&
       ((**(char **)(pbVar3 + 6) != '\x02' || (param_2 == '!')))) {
      FUN_004463d0(0x90);
      puVar6 = FUN_00473f70();
      return puVar6;
    }
    pbVar3 = FUN_00472ae0(pbVar3,'\x01','\x01');
    DAT_005882d8 = FUN_00492070();
    pbVar4 = FUN_004f1010();
    pcVar2 = FUN_004fa340((char *)pbVar4);
    pbVar4 = (byte *)FUN_004fb4c0(pcVar2);
  }
  else {
    DAT_005882d8 = FUN_00492070();
    pbVar4 = FUN_004f1010();
    pcVar2 = FUN_004fa340((char *)pbVar4);
    pbVar4 = (byte *)FUN_004fb4c0(pcVar2);
    uVar5 = FUN_0046d220((short)param_3,pbVar3,pbVar4,(int *)local_18);
    if ((char)uVar5 != '\0') {
      if (local_18[0] == (undefined1 *)0x0) {
        FUN_00445780();
      }
      return local_18[0];
    }
    if ((**(char **)(pbVar3 + 6) != '\x01') &&
       ((**(char **)(pbVar3 + 6) != '\x02' || (param_2 == '!')))) {
      FUN_004463d0(0x90);
      puVar6 = FUN_00473f70();
      return puVar6;
    }
    pbVar3 = FUN_00472ae0(pbVar3,'\x01','\x01');
  }
  if (cVar1 == '\f') {
    FUN_004463d0(0x90);
  }
  if (**(char **)(pbVar4 + 6) == '\x03') {
    pbVar4 = FUN_00473ee0(pbVar4);
  }
  if (((**(char **)(pbVar3 + 6) == '\x01') && (**(char **)(pbVar4 + 6) == '\x02')) &&
     (param_2 == '!')) {
    FUN_004463d0(0x90);
    puVar6 = FUN_00473f70();
    return puVar6;
  }
  puVar6 = (undefined1 *)FUN_004f1cb0((int)pbVar3,pbVar4,param_2);
  return puVar6;
}


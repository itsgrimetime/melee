
char * FUN_004f0d60(void)

{
  byte *pbVar1;
  char *pcVar2;
  byte *pbVar3;
  byte *pbVar4;
  undefined4 uVar5;
  byte *local_14 [3];
  
  pbVar1 = FUN_004f1010();
  while (DAT_005882d8 == 0x2c) {
    pcVar2 = FUN_004fa340((char *)pbVar1);
    pbVar3 = (byte *)FUN_004fb4c0(pcVar2);
    DAT_005882d8 = FUN_00492070();
    pbVar1 = FUN_004f1010();
    pcVar2 = FUN_004fa340((char *)pbVar1);
    pbVar4 = (byte *)FUN_004fb4c0(pcVar2);
    if ((DAT_0058427a == '\0') ||
       (uVar5 = FUN_0046d220(0x2c,pbVar3,pbVar4,(int *)local_14), pbVar1 = local_14[0],
       (char)uVar5 == '\0')) {
      FUN_004f0e20(pbVar3);
      pbVar1 = (byte *)FUN_00473cf0((int)pbVar3,pbVar4);
      *(undefined4 *)(pbVar1 + 6) = *(undefined4 *)(pbVar4 + 6);
    }
    else if (local_14[0] == (byte *)0x0) {
      FUN_00445780();
    }
  }
  return (char *)pbVar1;
}


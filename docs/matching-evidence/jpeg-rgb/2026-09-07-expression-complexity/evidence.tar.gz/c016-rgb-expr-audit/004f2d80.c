
byte * __cdecl FUN_004f2d80(byte *param_1,undefined1 param_2,byte *param_3)

{
  byte *pbVar1;
  char *pcVar2;
  byte *pbVar3;
  undefined4 uVar4;
  byte *local_40;
  byte *local_3c;
  byte *local_38;
  byte *local_34;
  byte *local_30;
  byte *local_2c;
  byte *local_28;
  byte *local_24;
  byte *local_20;
  byte *local_1c;
  byte *local_18;
  byte *local_14;
  
  switch(param_2) {
  case 9:
    break;
  default:
    FUN_00445780();
  case 0xf:
    if ((**(char **)(param_1 + 6) == '\x0e') || (**(char **)(param_3 + 6) == '\x0e')) {
      pbVar1 = (byte *)FUN_005179b0((char *)param_1,0xf,(char *)param_3);
    }
    else {
      pcVar2 = FUN_004fa340((char *)param_1);
      pbVar3 = (byte *)FUN_004fb4c0(pcVar2);
      pcVar2 = FUN_004fa340((char *)param_3);
      pbVar1 = (byte *)FUN_004fb4c0(pcVar2);
      if ((DAT_0058427a != '\0') &&
         (uVar4 = FUN_0046d220(0x2b,pbVar3,pbVar1,(int *)&local_40), (char)uVar4 != '\0')) {
        if (local_40 != (byte *)0x0) {
          return local_40;
        }
        if (local_3c == (byte *)0x0) {
          FUN_00445780();
        }
        pbVar1 = local_38;
        pbVar3 = local_3c;
        if (local_38 == (byte *)0x0) {
          FUN_00445780();
        }
      }
      pbVar1 = (byte *)FUN_004fa620((char *)pbVar3,(char *)pbVar1);
    }
    return pbVar1;
  case 0xb:
    if ((**(char **)(param_1 + 6) == '\x0e') || (**(char **)(param_3 + 6) == '\x0e')) {
      pbVar1 = (byte *)FUN_005179b0((char *)param_1,0xb,(char *)param_3);
    }
    else {
      pcVar2 = FUN_004fa340((char *)param_1);
      pbVar3 = (byte *)FUN_004fb4c0(pcVar2);
      pcVar2 = FUN_004fa340((char *)param_3);
      pbVar1 = (byte *)FUN_004fb4c0(pcVar2);
      if ((DAT_0058427a != '\0') &&
         (uVar4 = FUN_0046d220(0x2f,pbVar3,pbVar1,(int *)&local_1c), (char)uVar4 != '\0')) {
        if (local_1c != (byte *)0x0) {
          return local_1c;
        }
        if (local_18 == (byte *)0x0) {
          FUN_00445780();
        }
        pbVar1 = local_14;
        pbVar3 = local_18;
        if (local_14 == (byte *)0x0) {
          FUN_00445780();
        }
      }
      pbVar1 = (byte *)FUN_004fad60((char *)pbVar3,(char *)pbVar1,'\x01');
    }
    return pbVar1;
  case 0xc:
    pbVar1 = (byte *)FUN_004f5260((char *)param_1,(char *)param_3,'\x01');
    return pbVar1;
  case 0x10:
    if ((**(char **)(param_1 + 6) == '\x0e') || (**(char **)(param_3 + 6) == '\x0e')) {
      pbVar1 = (byte *)FUN_005179b0((char *)param_1,0x10,(char *)param_3);
    }
    else {
      pcVar2 = FUN_004fa340((char *)param_1);
      pbVar1 = (byte *)FUN_004fb4c0(pcVar2);
      pcVar2 = FUN_004fa340((char *)param_3);
      pbVar3 = (byte *)FUN_004fb4c0(pcVar2);
      if ((DAT_0058427a != '\0') &&
         (uVar4 = FUN_0046d220(0x2d,pbVar1,pbVar3,(int *)&local_34), (char)uVar4 != '\0')) {
        if (local_34 != (byte *)0x0) {
          return local_34;
        }
        if (local_30 == (byte *)0x0) {
          FUN_00445780();
        }
        pbVar1 = local_30;
        pbVar3 = local_2c;
        if (local_2c == (byte *)0x0) {
          FUN_00445780();
        }
      }
      pbVar1 = (byte *)FUN_004fa410((char *)pbVar1,(char *)pbVar3);
    }
    return pbVar1;
  case 0x11:
    pbVar1 = (byte *)FUN_004f5120((char *)param_1,(char *)param_3);
    return pbVar1;
  case 0x12:
    pbVar1 = (byte *)FUN_004f4fe0((char *)param_1,(char *)param_3);
    return pbVar1;
  case 0x13:
    pbVar1 = FUN_004f4820(param_1,param_3);
    return pbVar1;
  case 0x14:
    pbVar1 = FUN_004f4420(param_1,param_3);
    return pbVar1;
  case 0x15:
    pbVar1 = FUN_004f4620(param_1,param_3);
    return pbVar1;
  case 0x16:
    pbVar1 = FUN_004f4220(param_1,param_3);
    return pbVar1;
  case 0x17:
    pbVar1 = FUN_004f3de0(param_1,param_3);
    return pbVar1;
  case 0x18:
    pbVar1 = FUN_004f3b90(param_1,param_3);
    return pbVar1;
  case 0x19:
    pbVar1 = (byte *)FUN_004f39d0((char *)param_1,(char *)param_3);
    return pbVar1;
  case 0x1a:
    pbVar1 = (byte *)FUN_004f3830((char *)param_1,(char *)param_3);
    return pbVar1;
  case 0x1b:
    pbVar1 = (byte *)FUN_004f3670((char *)param_1,(char *)param_3);
    return pbVar1;
  case 0x1c:
    pbVar1 = FUN_004f33f0((char *)param_1,(char *)param_3);
    return pbVar1;
  case 0x1d:
    pbVar1 = FUN_004f3180((char *)param_1,(char *)param_3);
    return pbVar1;
  }
  if ((**(char **)(param_1 + 6) == '\x0e') || (**(char **)(param_3 + 6) == '\x0e')) {
    pbVar1 = (byte *)FUN_005179b0((char *)param_1,9,(char *)param_3);
  }
  else {
    pcVar2 = FUN_004fa340((char *)param_1);
    pbVar3 = (byte *)FUN_004fb4c0(pcVar2);
    pcVar2 = FUN_004fa340((char *)param_3);
    pbVar1 = (byte *)FUN_004fb4c0(pcVar2);
    if ((DAT_0058427a != '\0') &&
       (uVar4 = FUN_0046d220(0x2a,pbVar3,pbVar1,(int *)&local_28), (char)uVar4 != '\0')) {
      if (local_28 != (byte *)0x0) {
        return local_28;
      }
      if (local_24 == (byte *)0x0) {
        FUN_00445780();
      }
      pbVar1 = local_20;
      pbVar3 = local_24;
      if (local_20 == (byte *)0x0) {
        FUN_00445780();
      }
    }
    pbVar1 = (byte *)FUN_004faf20((char *)pbVar3,(char *)pbVar1);
  }
  return pbVar1;
}


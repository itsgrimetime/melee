
undefined4 __cdecl FUN_004f8e20(undefined1 param_1)

{
  switch(param_1) {
  case 0:
    return 1;
  case 1:
    return 2;
  case 2:
    return 3;
  case 3:
    return 4;
  case 4:
    return 5;
  case 5:
    return 6;
  case 6:
    return 7;
  case 7:
    return 8;
  case 8:
    return 9;
  case 9:
    return 10;
  case 10:
    return 10;
  case 0xb:
    return 0xc;
  case 0xc:
    return 0xd;
  case 0xd:
    return 0xe;
  case 0xe:
    return 0xf;
  case 0xf:
    return 0x10;
  case 0x10:
    return 0x11;
  case 0x11:
    return 0x20;
  case 0x12:
    return 0x21;
  case 0x13:
    return 0x22;
  case 0x14:
    return 0x23;
  case 0x15:
    return 0x24;
  case 0x16:
    return 0x25;
  case 0x17:
    return 0x26;
  case 0x18:
    return 0x27;
  default:
    FUN_00445780();
    return 0;
  }
}


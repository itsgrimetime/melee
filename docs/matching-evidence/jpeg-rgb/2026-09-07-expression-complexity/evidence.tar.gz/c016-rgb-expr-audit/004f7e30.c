
char * __cdecl FUN_004f7e30(char *param_1)

{
  int *piVar1;
  bool bVar2;
  uint uVar3;
  int *piVar4;
  int iVar5;
  char *local_8c;
  int local_88;
  short local_52;
  int local_30;
  int *local_2c [2];
  char *local_24;
  int local_20;
  
  FUN_004400e0(&local_30);
  piVar4 = DAT_0058824c;
  DAT_005882d8 = FUN_00492070();
  piVar1 = DAT_00587fb4;
  if (DAT_005882d8 == 0x174) {
    DAT_005882d8 = FUN_00492070();
    piVar4 = piVar1;
  }
  else if (((DAT_005882d8 != 0x7e) && (DAT_005882d8 != -3)) &&
          ((DAT_005882d8 < 0x100 || (0x131 < DAT_005882d8)))) {
    FUN_00440020(&local_30);
    return (char *)0x0;
  }
  while (DAT_005882d8 != 0x7e) {
    if (DAT_005882d8 != -3) {
      if ((DAT_005882d8 < 0x100) || (0x131 < DAT_005882d8)) goto LAB_004f7fe4;
      FUN_00441db0((undefined1 *)&local_8c,0x5c);
      FUN_0048c370((int *)&local_8c,'\0');
      if ((local_52 == 0) && (local_88 == 0)) {
        uVar3 = FUN_0048f2f0(local_8c,*(char **)(param_1 + 6));
        if ((short)uVar3 != 0) goto LAB_004f7fc4;
      }
      FUN_004463d0(0x92);
LAB_004f7fc4:
      if (DAT_005882d8 == 0x174) {
        DAT_005882d8 = FUN_00492070();
        if (DAT_005882d8 == 0x7e) break;
      }
LAB_004f7fe4:
      FUN_004463d0(0x8d);
      return (char *)0x0;
    }
    uVar3 = FUN_00497d30(piVar4,DAT_00587fa0,(int *)local_2c);
    if ((char)uVar3 == '\0') goto LAB_004f7fe4;
    if (local_2c[0] == (int *)0x0) {
      if (local_20 == 0) {
        uVar3 = FUN_0048f2f0(local_24,*(char **)(param_1 + 6));
        if ((short)uVar3 == 0) goto LAB_004f7f4c;
      }
      else {
LAB_004f7f4c:
        FUN_004463d0(0x92);
      }
      DAT_005882d8 = FUN_00492070();
      goto LAB_004f7fc4;
    }
    DAT_005882d8 = FUN_00492070();
    if (DAT_005882d8 != 0x174) goto LAB_004f7fe4;
    DAT_005882d8 = FUN_00492070();
    piVar4 = local_2c[0];
  }
  DAT_005882d8 = FUN_00492070();
  FUN_00441db0((undefined1 *)&local_8c,0x5c);
  FUN_0048c370((int *)&local_8c,'\0');
  if (local_52 == 0) {
    uVar3 = FUN_0048f2f0(local_8c,*(char **)(param_1 + 6));
    if ((short)uVar3 == 0) goto LAB_004f8044;
  }
  else {
LAB_004f8044:
    FUN_004463d0(0x92);
  }
  bVar2 = FUN_0048ead0(*(char **)(param_1 + 6),*(ushort *)(param_1 + 2) & 3);
  if (bVar2) {
    FUN_004463d0(0xfe);
  }
  if (DAT_005882d8 == 0x28) {
    DAT_005882d8 = FUN_00492070();
    if (DAT_005882d8 == 0x29) {
      DAT_005882d8 = FUN_00492070();
      goto LAB_004f80ac;
    }
    iVar5 = 0x73;
  }
  else {
    iVar5 = 0x72;
  }
  FUN_004463d0(iVar5);
LAB_004f80ac:
  if (*param_1 != '\x04') {
    FUN_00445780();
  }
  *param_1 = '0';
  *(undefined1 **)(param_1 + 6) = &DAT_0055d5d0;
  return param_1;
}


from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-final-out');root.mkdir(exist_ok=True);rows=[]
try:
 for shape in ['baseline','corrected']:
  for variant in ['tile-first','out-first','out-cast','local-tile']:
   n=shape+'-'+variant;s=base;params='s32 tile, s32* row';args='tile_y * 16 + tile_x * 2, &dst_row';body='*row = tile + *row;'
   if variant=='out-first':params='s32* row, s32 tile';args='&dst_row, tile_y * 16 + tile_x * 2'
   if variant=='out-cast':body='*row = tile + (u32) *row;'
   if variant=='local-tile':body='s32 value = tile; *row = value + *row;'
   s=s.replace('void hsd_803B3408(','static inline void jpeg_add_row('+params+') { '+body+' }\n\nvoid hsd_803B3408(',1).replace('dst_row = (tile_y * 16 + tile_x * 2) + dst_row;','jpeg_add_row('+args+');')
   if shape=='corrected':s=s.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

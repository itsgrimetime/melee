from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-guarded-row');root.mkdir(exist_ok=True);rows=[]
try:
 for mode in ['if','early-return','value-return']:
  s=Path('/tmp/c016-rgb-final-out/corrected-tile-first.c').read_text();n=mode
  if mode=='if':s=s.replace('{ *row = tile + *row; }','{ if (row != NULL) { *row = tile + *row; } }')
  elif mode=='early-return':s=s.replace('{ *row = tile + *row; }','{ if (row == NULL) { return; } *row = tile + *row; }')
  else:s=s.replace('static inline void jpeg_add_row(s32 tile, s32* row) { *row = tile + *row; }','static inline s32 jpeg_add_row(s32 tile, s32* row) { if (row != NULL) { return tile + *row; } return tile; }').replace('jpeg_add_row(tile_y * 16 + tile_x * 2, &dst_row);','dst_row = jpeg_add_row(tile_y * 16 + tile_x * 2, &dst_row);')
  p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

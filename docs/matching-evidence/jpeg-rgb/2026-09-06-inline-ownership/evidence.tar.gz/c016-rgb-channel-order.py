from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-channel-order');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
cb='''(s32) ((0.5f * (f32) ((pixel * 8) & 0xF8)) +
                               ((-0.1687f * (f32) ((pixel >> 8U) & 0xF8)) -
                                (0.3313f * (f32) ((pixel >> 3U) & 0xFC))))'''
cr='''(s32) (((0.5f * (f32) ((pixel >> 8U) & 0xF8)) -
                                (0.4187f * (f32) ((pixel >> 3U) & 0xFC))) -
                               (0.0813f * (f32) ((pixel * 8) & 0xF8)))'''
assert cb in part and cr in part
R='(f32) ((pixel >> 8U) & 0xF8)';G='(f32) ((pixel >> 3U) & 0xFC)';B='(f32) ((pixel * 8) & 0xF8)'
rows=[]
try:
 for shape in ['baseline','corrected-pixel']:
  source=part if shape=='baseline' else part.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
  vs={
   'cb-blue-last':source.replace(cb,'(s32) (((-0.1687f * '+R+') - (0.3313f * '+G+')) + (0.5f * '+B+'))'),
   'cb-negative-sum':source.replace(cb,'(s32) ((0.5f * '+B+') - ((0.1687f * '+R+') + (0.3313f * '+G+')))'),
   'cr-reverse-outer-sub':source.replace(cr,'(s32) (-((0.0813f * '+B+') - ((0.5f * '+R+') - (0.4187f * '+G+'))))'),
   'constant-last-products':source,
  }
  s=vs['constant-last-products']
  for c,v in [('0.5f',B),('-0.1687f',R),('0.3313f',G),('0.5f',R),('0.4187f',G),('0.0813f',B)]:s=s.replace(c+' * '+v,v+' * '+c)
  vs['constant-last-products']=s
  for name,s in vs.items():
   label=shape+'-'+name;full=base[:a]+s+base[b:];p.write_text(full);(out/(label+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   assert r.returncode in [0,1],(label,r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

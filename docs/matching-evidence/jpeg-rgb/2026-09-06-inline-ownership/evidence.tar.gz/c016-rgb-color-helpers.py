from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-color-helpers');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
assignments={}
for channel,field in [('cb','x518'),('cr','x618')]:
 start=part.index('                    chroma_dest->data.'+field+'[0] =');end=part.index(';',start)+1
 assignments[channel]=(field,part[start:end],part[start:end].split('=',1)[1])
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
rows=[]
try:
 for shape in ['baseline','corrected-pixel']:
  source=part if shape=='baseline' else part.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
  for kind in ['cb-result','cr-result','both-result','both-store-dest-first','both-store-pixel-first']:
   helper='';s=source
   for channel,(field,old,rhs) in assignments.items():
    if kind in ['cb-result','cr-result'] and not kind.startswith(channel):continue
    if kind.endswith('result'):
     helper+='static inline s32 jpeg_'+channel+'(u16 pixel) { return'+rhs+' }\n'
     new='                    chroma_dest->data.'+field+'[0] = jpeg_'+channel+'(pixel);'
    else:
     params='JpegWork* dst, u16 pixel' if kind.endswith('dest-first') else 'u16 pixel, JpegWork* dst'
     args='chroma_dest, pixel' if kind.endswith('dest-first') else 'pixel, chroma_dest'
     helper+='static inline void jpeg_'+channel+'('+params+') { dst->data.'+field+'[0] ='+rhs+' }\n'
     new='                    jpeg_'+channel+'('+args+');'
    assert old in s;s=s.replace(old,new)
   label=shape+'-'+kind;full=base[:a]+helper+s+base[b:];p.write_text(full);(out/(label+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120)
   (out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   assert r.returncode in [0,1],(label,r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

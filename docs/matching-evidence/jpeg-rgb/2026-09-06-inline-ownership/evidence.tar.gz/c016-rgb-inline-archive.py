from pathlib import Path
import json,hashlib,subprocess,tarfile
root=Path('docs/matching-evidence/jpeg-rgb/2026-09-06-inline-ownership');root.mkdir(parents=True,exist_ok=True)
src=Path('src/sysdolphin/baselib/hsd_3B34.c');assert src.read_bytes()==subprocess.check_output(['git','show','HEAD:'+str(src)])
d=json.loads(Path('/tmp/c016-rgb-inline-final.json').read_text());assert d['fuzzy_match_percent']==98.7788
u=next(u for u in json.loads(Path('build/GALE01/report.json').read_text())['units'] if u['name'].endswith('sysdolphin/baselib/hsd_3B34'))
fs=[{'name':f['name'],'percent':f['fuzzy_match_percent']} for f in u['functions']];assert len(fs)==8 and all(f['percent']=={'hsd_803B3408':98.7788,'hsd_803B3CD8':99.70266}.get(f['name'],100) for f in fs)
sha={str(p):hashlib.sha1(p.read_bytes()).hexdigest() for p in [Path('build/GALE01/main.dol'),Path('orig/GALE01/sys/main.dol')]};assert set(sha.values())=={'08e0bf20134dfcb260699671004527b2d6bb1a45'}
files=[];rows=[]
for family in ['color-helpers','shared-work','channel-order']:
 p=Path('/tmp/c016-rgb-'+family);files.extend((f,str(f.relative_to('/tmp'))) for f in p.rglob('*') if f.is_file());files.append((Path(str(p)+'.py'),p.name+'.py'))
 rows.extend({'family':family,**r} for r in json.loads((p/'results.json').read_text()))
assert len(rows)==24
for suffix in ['doctor.log','final.json','final.log','build.log','attempt.log','archive.py']:
 p=Path('/tmp/c016-rgb-inline-'+suffix);files.append((p,p.name))
files.append((src,'retained-hsd_3B34.c'))
m={'function':'hsd_803B3408','scratch':None,'retained_source_change':False,'ordinary_match_percent':98.7788,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'unit_functions':fs,'dol_sha1':sha,'runs':rows,'caveat':'Shared work-pointer and negative arithmetic forms are source-shape diagnostics only; none retained. Mathematical expression equivalence does not prove identical contracted floating-point evaluation.','members':[]}
assert len(set(n for _,n in files))==len(files)
with tarfile.open(root/'evidence.tar.gz','w:gz') as t:
 for p,n in sorted(files,key=lambda x:x[1]):
  d=p.read_bytes();m['members'].append({'path':n,'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()});t.add(p,arcname=n)
with tarfile.open(root/'evidence.tar.gz') as t:
 for f in m['members']:assert hashlib.sha256(t.extractfile(f['path']).read()).hexdigest()==f['sha256']
m['archive_sha256']=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest();(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified',len(files),'members,',len(rows),'runs,',(root/'evidence.tar.gz').stat().st_size,'bytes')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-shared-work');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
old='''                    s32* luma_base;

                    for (pixel_index = 0;
                         luma_base =
                             (s32*) (HSD_804D2648_BUF +
                                     (tile_x * 4 +
                                      ((tile_y * 4 + luma_y) * 8 + luma_x)) *
                                         4 +
                                     0x118),''';assert old in part
rows=[]
try:
 for shape in ['baseline','corrected-pixel']:
  source=part if shape=='baseline' else part.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
  for kind in ['luma-work-view','shared-function','shared-tile']:
   s=source.replace(old,'''                    JpegWork* luma_work;

                    for (pixel_index = 0;
                         luma_work = (JpegWork*) (HSD_804D2648_BUF +
                             (tile_x * 4 + ((tile_y * 4 + luma_y) * 8 + luma_x)) * 4),''').replace('luma_base[pixel_index * 64]','luma_work->data.x118[pixel_index * 64]')
   if kind.startswith('shared'):
    s=s.replace('                    JpegWork* luma_work;\n','').replace('                    JpegWork* chroma_dest;\n','').replace('luma_work','work').replace('chroma_dest','work')
    if kind=='shared-function':s=s.replace('    s32 stride;','    s32 stride;\n    JpegWork* work;')
    else:s=s.replace('        u16* src;','        u16* src;\n        JpegWork* work;')
   label=shape+'-'+kind;full=base[:a]+s+base[b:];p.write_text(full);(out/(label+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   assert r.returncode in [0,1],(label,r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

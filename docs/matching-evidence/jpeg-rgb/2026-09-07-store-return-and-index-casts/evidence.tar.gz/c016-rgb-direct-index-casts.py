from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('/tmp/c016-rgb-direct-index/row-low-high-expression.c').read_text();out=Path('/tmp/c016-rgb-direct-index-casts');out.mkdir(exist_ok=True)
old='(dst_row + (chroma_x & 1) + (chroma_x & 2) * 4)'
try:
 for typ in ['int','u32','unsigned int']:
  for form in ['row','bits','sum']:
   if form=='row':expr='(('+typ+') dst_row + (chroma_x & 1) + (chroma_x & 2) * 4)'
   elif form=='bits':expr='(dst_row + ('+typ+') ((chroma_x & 1) + (chroma_x & 2) * 4))'
   else:expr='(('+typ+') (dst_row + (chroma_x & 1)) + (chroma_x & 2) * 4)'
   s=seed.replace(old,expr);assert s!=seed;name=typ.replace(' ','-')+'-'+form;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

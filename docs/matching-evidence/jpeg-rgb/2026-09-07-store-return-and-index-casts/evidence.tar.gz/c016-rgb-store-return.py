from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-store-return');out.mkdir(exist_ok=True)
assign='                    chroma_dest =\n                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);'
index='                    chroma_index = (chroma_x & 2) * 4;\n                    chroma_index = (chroma_x & 1) + chroma_index;\n                    chroma_index += dst_row;'
try:
 for order in ['value-first','offset-first']:
  for caller in ['local','direct']:
   for frame in ['full','no-luma-offsets']:
    s=seed.replace(assign,'');idx='chroma_index'
    if caller=='direct':s=s.replace('                    s32 chroma_index;','').replace(index,'');idx='((chroma_x & 2) * 4 + (chroma_x & 1) + dst_row)'
    marker='chroma_dest->data.x518[0] =';start=s.index(marker);end=s.index(';',start);rhs=s[start+len(marker):end].strip();params='s32 value, s32 offset' if order=='value-first' else 's32 offset, s32 value';args=rhs+', '+idx if order=='value-first' else idx+', '+rhs
    helper='static inline JpegWork* jpeg_store_cb(s32 value, s32 offset) { JpegWork* dest = (JpegWork*) (HSD_804D2648_BUF + offset * 4); dest->data.x518[0] = value; return dest; }'.replace('s32 value, s32 offset',params)
    s=s[:start]+'chroma_dest = jpeg_store_cb('+args+');'+s[end+1:];s=s.replace('void hsd_803B3408(',helper+'\n\nvoid hsd_803B3408(',1)
    if frame!='full':s=s.replace('s32 row_offset = (pixel_index & 2) * stride;','').replace('s32 column_offset = (pixel_index & 1) * 0x20;','').replace('src[column_offset + row_offset]','src[(pixel_index & 1) * 0x20 + (pixel_index & 2) * stride]')
    name=order+'-'+caller+'-'+frame;(out/(name+'.c')).write_text(s);p.write_text(s)
    r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

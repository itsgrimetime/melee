from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-store-boundary');out.mkdir(exist_ok=True)
assign='                    chroma_dest =\n                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);'
index='                    chroma_index = (chroma_x & 2) * 4;\n                    chroma_index = (chroma_x & 1) + chroma_index;\n                    chroma_index += dst_row;'
try:
 for mode in ['pointer','last-index','all-index']:
  for side in ['lhs','rhs-comma']:
   s=seed.replace(assign,'');expr='(JpegWork*) (HSD_804D2648_BUF + chroma_index * 4)'
   if mode=='last-index':s=s.replace('                    chroma_index += dst_row;','');expr=expr.replace('chroma_index * 4','(chroma_index += dst_row) * 4')
   if mode=='all-index':s=s.replace(index,'');expr=expr.replace('chroma_index * 4','(chroma_index = (chroma_x & 2) * 4, chroma_index = (chroma_x & 1) + chroma_index, chroma_index += dst_row) * 4')
   if side=='lhs':s=s.replace('chroma_dest->data.x518[0]','(chroma_dest = '+expr+')->data.x518[0]')
   else:
    # Evaluate the address assignment before the conversion RHS; LHS uses an independently formed same address, avoiding unsequenced pointer read.
    s=s.replace('chroma_dest->data.x518[0] =','((JpegWork*) (HSD_804D2648_BUF + '+ ('(dst_row + (chroma_x & 1) + (chroma_x & 2) * 4)' if mode!='pointer' else 'chroma_index') +' * 4))->data.x518[0] =\n                        (chroma_dest = '+expr+',')
    marker='(0.3313f * (f32) ((pixel >> 3U) & 0xFC))));';s=s.replace(marker,marker[:-1]+');',1)
   name=mode+'-'+side;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-index-low-first');out.mkdir(exist_ok=True)
old='chroma_index = (chroma_x & 2) * 4;\n                    chroma_index = (chroma_x & 1) + chroma_index;'
load='                    pixel = src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row];\n'
forms={'low-self':'chroma_index = (chroma_x & 1);\n                    chroma_index = (chroma_x & 2) * 4 + chroma_index;', 'low-compound':'chroma_index = (chroma_x & 1);\n                    chroma_index += (chroma_x & 2) * 4;', 'direct-low':'chroma_index = (chroma_x & 1) + (chroma_x & 2) * 4;', 'direct-high':'chroma_index = (chroma_x & 2) * 4 + (chroma_x & 1);'}
try:
 for name,form in forms.items():
  for position in ['after-load','before-load']:
   s=seed.replace(old,form)
   if position=='before-load':
    start=s.index(load);s=s[:start]+s[start:].replace(load,'',1);pos=s.index('                    chroma_dest =',start);s=s[:pos]+load+s[pos:]
   label=name+'-'+position;(out/(label+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(label+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(label,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

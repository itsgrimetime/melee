from pathlib import Path
import json,sys,itertools
sys.path.insert(0,'/Users/mike/code/mwcc-decomp/tools')
from coloring_model import replay_simplify
b=json.load(open('/tmp/c016-rgb-donor-swap-stages/creation/coloring-0001-gpr-01-before.json'));a=json.load(open('/tmp/c016-rgb-donor-swap-stages/creation/coloring-0001-gpr-01-after.json'));t={int(k):v for k,v in json.load(open('/tmp/c016-rgb-donor-swap-correspondence.json'))['target_assignments'].items()};actual={n['virtual_register']:n['physical_register'] for n in a['nodes']}
base=replay_simplify(b);assert base['simplify_order']==b['simplify_order'] and all(actual[v]==c for v,c in base['colors'].items())
rows=[]
for family in ['rank','degree']:
 pairs=itertools.product([31.5,38.5,60.5,90.5,100.5,120.5,140.5],repeat=2) if family=='rank' else itertools.product(range(-4,5),repeat=2)
 for x,y in pairs:
  params={'ranks':{37:x,38:y}} if family=='rank' else {'extra_permanent_degree':{37:x,38:y}}
  r=replay_simplify(b,**params);miss={v:[r['colors'].get(v),c] for v,c in t.items() if r['colors'].get(v)!=c};rows.append({'family':family,'inputs':[x,y],'misses':miss,'count':len(miss),'order':r['simplify_order']})
 best=sorted([r for r in rows if r['family']==family],key=lambda r:r['count'])[:5];print(family,[(r['inputs'],r['count']) for r in best],flush=True)
Path('/tmp/c016-rgb-simplify-inputs.json').write_text(json.dumps({'scope':'Hypothetical rank and degree perturbations; no compiler changes, no source-realizability proof. Full baseline replay verified. Degree deltas are abstract, not actual new edges.','rows':rows},indent=2))

from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-offset-reuse');out.mkdir(exist_ok=True)
try:
 for old in ['dst_row','src_row','chroma_index']:
  for new in ['row_offset','column_offset']:
   s=base;a=s.index('void hsd_803B3408(');b=s.index('static void fn_803B376C',a);body=s[a:b]
   body=re.sub(r'^\s*s32 '+old+r';\n','\n',body,flags=re.M)
   body=body.replace('    s32 stride;','    s32 stride;\n    s32 '+old+';')
   body=body.replace('s32 '+new+' =',old+' =');body=re.sub(r'\b'+new+r'\b',old,body)
   t=s[:a]+body+s[b:];name=old+'-'+new;(out/(name+'.c')).write_text(t);p.write_text(t)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout)
   x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification']['stack_frame_sizes'],flush=True)
finally:p.write_text(base)

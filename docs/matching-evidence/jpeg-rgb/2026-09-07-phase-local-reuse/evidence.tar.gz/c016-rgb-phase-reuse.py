from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-phase-reuse');out.mkdir(exist_ok=True)
try:
 for fam,s in [('baseline',base),('structural',Path('docs/matching-evidence/jpeg-rgb/2026-09-07-direct-row-call/structural-candidate.c.txt').read_text())]:
  for old,new in [('chroma_x','luma_x'),('chroma_y','luma_y'),('chroma_index','pixel_index'),('dst_row','luma_y'),('src_row','luma_x'),('chroma_index','luma_y')]:
   a=s.index('void hsd_803B3408(');b=s.index('static void fn_803B376C',a);body=s[a:b]
   body=re.sub(r'^\s*s32 '+old+r';\n','\n',body,flags=re.M)
   body=re.sub(r'\b'+old+r'\b',new,body)
   t=s[:a]+body+s[b:];name=fam+'-'+old+'-'+new;(out/(name+'.c')).write_text(t);p.write_text(t)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout)
   try:
    x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification']['stack_frame_sizes'],flush=True)
   except Exception:print(name,r.stderr[-500:],r.stdout[:500],flush=True)
finally:p.write_text(base)

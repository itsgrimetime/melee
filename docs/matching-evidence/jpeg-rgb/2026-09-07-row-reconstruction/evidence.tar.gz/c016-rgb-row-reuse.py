from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-row-reuse');root.mkdir(exist_ok=True);rows=[]
variants={
'row-reuse':('s32 row, s32 tile','row = (row & 1) * 4 + (row & 2) * 16; return tile + row;','chroma_y, tile_y * 16 + tile_x * 2'),
'row-reuse-reversed':('s32 tile, s32 row','row = (row & 1) * 4 + (row & 2) * 16; return row + tile;','tile_y * 16 + tile_x * 2, chroma_y'),
'low-reuse':('s32 low, s32 high, s32 tile','low += high; return tile + low;','(chroma_y & 1) * 4, (chroma_y & 2) * 16, tile_y * 16 + tile_x * 2'),
'high-reuse':('s32 high, s32 low, s32 tile','high += low; return high + tile;','(chroma_y & 2) * 16, (chroma_y & 1) * 4, tile_y * 16 + tile_x * 2'),
'out-row':('s32* row, s32 low, s32 high, s32 tile','*row = low + high; *row += tile;','&dst_row, (chroma_y & 1) * 4, (chroma_y & 2) * 16, tile_y * 16 + tile_x * 2')}
old='dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;\n                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;'
try:
 for corrected in [False,True]:
  for name,(params,body,args) in variants.items():
   n=('corrected-' if corrected else 'baseline-')+name;s=base
   if corrected:s=s.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
   out=name=='out-row';s=s.replace(old,('' if out else 'dst_row = ')+'rgb_row('+args+');');s=s.replace('void hsd_803B3408(', 'static inline '+('void' if out else 's32')+' rgb_row('+params+') { '+body+' }\n\nvoid hsd_803B3408(',1)
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr)
   try:
    x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')}
   except Exception:row={'name':n,'score':None,'exit':r.returncode}
   rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();src=Path('/tmp/c016-rgb-row-frame/corrected-no-row.c').read_text();root=Path('/tmp/c016-rgb-row-return');root.mkdir(exist_ok=True);rows=[]
old='low += high; return tile + low;'
variants={'reuse-final':'low += high; low = tile + low; return low;','result-final':'s32 result; low += high; result = tile + low; return result;','tile-final':'low += high; tile += low; return tile;','result-sum':'s32 result = low + high; return tile + result;','high-sum':'high = low + high; return tile + high;','comma-final':'return low += high, tile + low;'}
try:
 for n,body in variants.items():
  s=src.replace(old,body);assert s!=src;p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

from pathlib import Path
import json,subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-row-frame');root.mkdir(exist_ok=True);rows=[]
old='''                        s32 row_offset = (pixel_index & 2) * stride;

                        {
                            s32 column_offset = (pixel_index & 1) * 0x20;
                            pixel = src[column_offset + row_offset];
                        }'''
try:
 for shape in ['baseline','corrected']:
  src=Path('/tmp/c016-rgb-row-reuse/'+shape+'-low-reuse.c').read_text()
  for mode in ['no-row','no-column','no-both']:
   n=shape+'-'+mode;s=src
   if mode=='no-both':s=s.replace(old,'                        pixel = src[(pixel_index & 1) * 0x20 + (pixel_index & 2) * stride];')
   elif mode=='no-row':s=s.replace('                        s32 row_offset = (pixel_index & 2) * stride;','').replace('src[column_offset + row_offset]','src[column_offset + (pixel_index & 2) * stride]')
   else:s=s.replace('                            s32 column_offset = (pixel_index & 1) * 0x20;','').replace('src[column_offset + row_offset]','src[(pixel_index & 1) * 0x20 + row_offset]')
   assert s!=src;p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

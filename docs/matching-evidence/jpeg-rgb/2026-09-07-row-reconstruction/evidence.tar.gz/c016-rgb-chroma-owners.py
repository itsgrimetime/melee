from pathlib import Path
import re,json,subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-chroma-owners');root.mkdir(exist_ok=True);a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);fn=base[a:b];sig,body=fn.split('{',1);rows=[]
try:
 for corrected in [False,True]:
  for owners in [('chroma_dest',),('chroma_index',),('chroma_dest','chroma_index'),('chroma_index','chroma_dest')]:
   name=('corrected-' if corrected else 'baseline-')+'-'.join(owners);bs=body;params=[];decl=[];args=[]
   if corrected:
    bs=bs.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
   for v in owners:
    typ='JpegWork*' if v=='chroma_dest' else 's32'
    bs,n=re.subn(r'\s*'+re.escape(typ)+r' '+v+r';','',bs,count=1);assert n==1
    bs=re.sub(r'\b'+v+r'\b','(*'+v+'_out)',bs)
    params.append(typ+'* '+v+'_out');decl.append('    '+typ+' '+v+';');args.append('&'+v)
   new='#ifdef MUST_MATCH\n#pragma push\n#pragma inline_depth(8)\n#endif\nstatic inline void jpeg_rgb_inner(u8* image, s32 x, s32 y, s32 width, s32 height, '+', '.join(params)+')\n{'+bs
   new+='#ifdef MUST_MATCH\n#pragma auto_inline off\n#endif\n'+sig+'{\n'+'\n'.join(decl)+'\n    jpeg_rgb_inner(image, x, y, width, height, '+', '.join(args)+');\n}\n#ifdef MUST_MATCH\n#pragma pop\n#endif\n\n'
   full=base[:a]+new+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
   try:
    x=json.loads(r.stdout);row={'name':name,'score':x.get('fuzzy_match_percent'),'match':x.get('match'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')}
   except Exception:row={'name':name,'score':None,'exit':r.returncode}
   rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

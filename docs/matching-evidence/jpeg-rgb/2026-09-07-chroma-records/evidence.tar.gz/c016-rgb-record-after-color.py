from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-record-after-color');out.mkdir(exist_ok=True)
try:
 for record in ['index','index-dest']:
  for frame in ['full','no-luma-row','no-luma-offsets']:
   s=Path('/tmp/c016-rgb-chroma-record/'+record+'-pixel.c').read_text();dest='chroma.dest' if record=='index-dest' else 'chroma_dest';marker=dest+'->data.x518[0] =';start=s.index(marker);end=s.index(';',start);rhs=s[start+len(marker):end].strip();s=s[:start]+dest+'->data.x518[0] = cb_value'+s[end:]
   pos=s.index('                    chroma.index =');s=s[:pos]+'                    cb_value = '+rhs+';\n'+s[pos:]
   s=s.replace('                for (chroma_x = 0; chroma_x < 4; chroma_x++) {','                for (chroma_x = 0; chroma_x < 4; chroma_x++) {\n                    s32 cb_value;',1)
   if frame!='full':s=s.replace('s32 row_offset = (pixel_index & 2) * stride;','').replace('src[column_offset + row_offset]','src[column_offset + (pixel_index & 2) * stride]')
   if frame=='no-luma-offsets':s=s.replace('s32 column_offset = (pixel_index & 1) * 0x20;','').replace('src[column_offset + (pixel_index & 2) * stride]','src[(pixel_index & 1) * 0x20 + (pixel_index & 2) * stride]')
   name=record+'-'+frame;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

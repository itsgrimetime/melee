from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-chroma-record-frame');out.mkdir(exist_ok=True)
try:
 for members in ['index-dest','dest-index','index','dest']:
  for scope in ['pixel']:
   s=seed;fields=members.split('-');decl='struct { '+' '.join('s32 index;' if f=='index' else 'JpegWork* dest;' for f in fields)+' } chroma;'
   for f in fields:
    var='chroma_index' if f=='index' else 'chroma_dest';typ='s32' if f=='index' else 'JpegWork*';s=s.replace('                    '+typ+' '+var+';','');s=re.sub(r'\b'+var+r'\b','chroma.'+f,s)
   anchor='                for (chroma_x = 0; chroma_x < 4; chroma_x++) {' if scope=='pixel' else '                s32 row_part;'
   s=s.replace(anchor,anchor+'\n                    '+decl,1)
   s=s.replace('s32 row_offset = (pixel_index & 2) * stride;', '').replace('src[column_offset + row_offset]','src[column_offset + (pixel_index & 2) * stride]');name=members+'-'+scope;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

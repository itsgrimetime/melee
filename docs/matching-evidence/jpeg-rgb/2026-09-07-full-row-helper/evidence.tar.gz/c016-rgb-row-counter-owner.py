from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-row-counter-owner');root.mkdir(exist_ok=True);rows=[]
try:
 for source in ['pixel','both']:
  for tileptr in [False,True]:
   n=source+('-tileptr' if tileptr else '-rowptr');s=Path('/tmp/c016-rgb-complete-row/'+source+'.c').read_text();a=s.index('static inline void jpeg_chroma_row(');b=s.index('void hsd_803B3408(',a);helper=s[a:b]
   helper=helper.replace('s32 chroma_y','s32* row_index');helper=re.sub(r'\bchroma_y\b','(*row_index)',helper)
   if tileptr:helper=helper.replace('s32 tile_offset','s32* tile_index');helper=re.sub(r'\btile_offset\b','(*tile_index)',helper)
   s=s[:a]+helper+s[b:];s=s.replace('jpeg_chroma_row(src, chroma_y, tile_offset, stride,','jpeg_chroma_row(src, &chroma_y, '+('&tile_offset' if tileptr else 'tile_offset')+', stride,')
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

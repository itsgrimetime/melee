from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();src=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-direct-row-call/structural-candidate.c.txt').read_text();root=Path('/tmp/c016-rgb-complete-row');root.mkdir(exist_ok=True);rows=[]
start=src.index('            for (chroma_y = 0; chroma_y < 4; chroma_y++) {')
a=src.index('\n',start)+1;b=src.index('\n            }\n            luma_y = 0;',a);body=src[a:b]
try:
 for owner in ['local','pixel','counter','both']:
  n=owner;bb=body;params='u16* src, s32 chroma_y, s32 tile_offset, s32 stride';args='src, chroma_y, tile_offset, stride';decl=''
  if owner in ['pixel','both']:params+=', u16* pixel_value';args+=', &pixel';bb=re.sub(r'\bpixel\b','(*pixel_value)',bb)
  else:decl+='    u16 pixel;\n'
  if owner in ['counter','both']:params+=', s32* column';args+=', &chroma_x';bb=re.sub(r'\bchroma_x\b','(*column)',bb)
  else:decl+='    s32 chroma_x;\n'
  helper='static inline void jpeg_chroma_row('+params+') {\n'+decl+bb+'\n}\n\n'
  s=src[:a]+'                jpeg_chroma_row('+args+');'+src[b:];s=s.replace('void hsd_803B3408(',helper+'void hsd_803B3408(',1)
  if owner not in ['counter','both']:
   pos=s.index('void hsd_803B3408(');s=s[:pos]+s[pos:].replace('    s32 chroma_x;\n','',1)
  p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

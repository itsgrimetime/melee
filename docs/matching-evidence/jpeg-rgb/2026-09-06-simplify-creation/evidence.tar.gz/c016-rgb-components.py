from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-components');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]';correct='src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]'
start=part.index('                    s32 chroma_index;');end=part.index('\n                }',start);body=part[start:end]
terms={'red':'((pixel >> 8U) & 0xF8)','green':'((pixel >> 3U) & 0xFC)','blue':'((pixel * 8) & 0xF8)'}
rows=[]
try:
 for shape in ['baseline','corrected-pixel']:
  for kind,channels in [('scalar-rgb',['red','green','blue']),('scalar-bgr',['blue','green','red']),('scalar-grb',['green','red','blue']),('record-rgb',['red','green','blue']),('record-bgr',['blue','green','red']),('float-rgb',['red','green','blue'])]:
   bb=body;names={c:'rgb.'+c if kind.startswith('record') else c for c in channels}
   for c,t in terms.items():bb=bb.replace('(f32) '+t,('(f32) ' if not kind.startswith('float') else '')+names[c])
   decl=('struct { s32 '+', '.join(channels)+'; } rgb;' if kind.startswith('record') else ('f32 ' if kind.startswith('float') else 's32 ')+', '.join(channels)+';')
   bb=bb.replace('                    JpegWork* chroma_dest;','                    JpegWork* chroma_dest;\n                    '+decl)
   stores=''.join('\n                    '+names[c]+' = '+('(f32) ' if kind.startswith('float') else '')+terms[c]+';' for c in channels)
   bb=bb.replace('pixel = '+expr+';','pixel = '+expr+';'+stores)
   if shape=='corrected-pixel':bb=bb.replace(expr,correct)
   s=part[:start]+bb+part[end:];label=shape+'-'+kind;full=base[:a]+s+base[b:];p.write_text(full);(out/(label+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   assert r.returncode in [0,1],(label,r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

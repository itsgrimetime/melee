from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-pointer-helper');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]';part=part.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
init='''                    chroma_index = (chroma_x & 2) * 4;
                    chroma_index = (chroma_x & 1) + chroma_index;
                    chroma_index += dst_row;
                    chroma_dest =
                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);
''';assert init in part
part=part.replace(init,'').replace('                    s32 chroma_index;\n','').replace('                    JpegWork* chroma_dest;\n','')
rows=[]
try:
 for kind in ['expression','local-index','passed-base']:
  params='s32 x, s32 row';args='chroma_x, dst_row';body='return (JpegWork*) (HSD_804D2648_BUF + (((x & 1) + (x & 2) * 4) + row) * 4);'
  if kind=='local-index':body='s32 index = (x & 2) * 4; index = (x & 1) + index; index += row; return (JpegWork*) (HSD_804D2648_BUF + index * 4);'
  if kind=='passed-base':params='JpegWork* base, s32 x, s32 row';args='(JpegWork*) HSD_804D2648_BUF, chroma_x, dst_row';body='s32 index = (x & 2) * 4; index = (x & 1) + index; index += row; return (JpegWork*) ((u8*) base + index * 4);'
  helper='static inline JpegWork* jpeg_chroma_destination('+params+') { '+body+' }\n'
  s=part.replace('chroma_dest->','jpeg_chroma_destination('+args+')->');full=base[:a]+helper+s+base[b:];p.write_text(full);(out/(kind+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120);(out/(kind+'.json')).write_text(r.stdout);(out/(kind+'.log')).write_text(r.stderr)
  assert r.returncode in [0,1],(kind,r.stderr)
  d=json.loads(r.stdout);row={'name':kind,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

exec(compile(open('/tmp/c016-rgb-target-correspondence.py').read(),'/tmp/c016-rgb-target-correspondence.py','exec'))
import itertools
raw=json.loads((root/'coloring-0001-gpr-01-before.json').read_text());rawnodes={n['virtual_register']:n for n in raw['nodes']}
def replay(rename):
 rev={v:k for k,v in rename.items()}
 def f(n):return rename.get(n,n)
 edges={f(v):[f(u) for u in n['neighbors']] for v,n in rawnodes.items()};degree={v:len(ns) for v,ns in edges.items()};active={f(v) for v,n in rawnodes.items() if v>=32 and not n['flags']&4};removed=[];scans=[]
 while active:
  step=[]
  for v in sorted(active):
   if degree[v]<29:
    step.append([rev.get(v,v),degree[v]]);active.remove(v);removed.append(rev.get(v,v))
    for u in edges[v]:degree[u]-=1
  if not step:return {'jam':len(active),'select':list(reversed(removed)),'scans':scans}
  scans.append(step)
 return {'jam':0,'select':list(reversed(removed)),'scans':scans}
baseline=replay({});assert baseline['select']==order and not baseline['jam'];extended=dict(base);extended.update(assignments)
rows=[]
for p,i in itertools.permutations(range(32,37),2):
 rename={37:p,p:37,38:i,i:38};r=replay(rename);pred=predict_assignments(ig,order=r['select']);wrong={n:[v,extended[n]] for n,v in pred.items() if v!=extended[n]};rows.append({'pointer_label':p,'index_label':i,'jam':r['jam'],'positions':{n:r['select'].index(n) for n in [37,38]},'wrong':wrong,'order':r['select']})
result={'scope':'Exact baseline simplify replay; diagnostic graph relabeling only. No source realization or claim of unused C parameter to exact vertex mapping.','baseline':baseline,'rows':rows};Path('/tmp/c016-rgb-simplify-labels.json').write_text(json.dumps(result,indent=2)+'\n');print('Baseline scans',len(baseline['scans']),'20 label pairs:',[(r['pointer_label'],r['index_label'],len(r['wrong']),r['positions']) for r in rows])

exec(compile(open('/tmp/c016-rgb-simplify-labels.py').read(),'/tmp/c016-rgb-simplify-labels.py','exec'))
rows=[];best=999;wins=0;count=0
for pm,im in itertools.product([v for v in range(39,139)],repeat=2):
 labels=list(range(32,139));labels.remove(37);labels.insert(labels.index(pm)+1,37);labels.remove(38);labels.insert(labels.index(im)+1,38)
 rename={v:32+i for i,v in enumerate(labels)};r=replay(rename);count+=1
 if r['jam']:continue
 pred=predict_assignments(ig,order=r['select']);wrong={n:[v,extended[n]] for n,v in pred.items() if v!=extended[n]}
 if len(wrong)<best:best=len(wrong);rows=[]
 if not wrong:wins+=1
 if len(wrong)==best and len(rows)<12:rows.append({'pointer_insert_after':pm,'index_insert_after':im,'rename':rename,'select':r['select'],'wrong':wrong,'scan_count':len(r['scans'])})
result={'scope':'Graph-isomorphic virtual-label insertion, full simplify then SELECT. Preserves other relative labels. Source realization unproven. Target extends unmapped observed colors.','tried':count,'best_wrong':best,'wins':wins,'best_rows':rows};Path('/tmp/c016-rgb-simplify-insertion.json').write_text(json.dumps(result,indent=2)+'\n');print('Insertion search',count,'best wrong',best,'wins',wins);print([(r['pointer_insert_after'],r['index_insert_after'],r['wrong']) for r in rows])

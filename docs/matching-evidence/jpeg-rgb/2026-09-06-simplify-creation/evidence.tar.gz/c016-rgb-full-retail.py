from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');original=p.read_text();expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]';assert original.count(expr)==2
candidate=original.replace(expr,'src[(((chroma_x & 1) * 2) + ((chroma_x & 2) * 4)) + src_row]');Path('/tmp/c016-rgb-full-retail-source.c').write_text(candidate)
try:
 p.write_text(candidate)
 r=subprocess.run(['melee-agent','debug','retro','backend',str(p),'-f','hsd_803B3408','-O','/tmp/c016-rgb-full-retail'],capture_output=True,text=True)
 Path('/tmp/c016-rgb-full-retail.log').write_text(r.stdout+r.stderr);print('exit',r.returncode,r.stdout[-2000:],r.stderr[-1000:])
finally:p.write_text(original)

from pathlib import Path
import json,hashlib,subprocess,tarfile
root=Path('docs/matching-evidence/jpeg-rgb/2026-09-06-simplify-creation');root.mkdir(parents=True,exist_ok=True)
src=Path('src/sysdolphin/baselib/hsd_3B34.c');assert src.read_bytes()==subprocess.check_output(['git','show','HEAD:'+str(src)])
d=json.loads(Path('/tmp/c016-rgb-creation-final.json').read_text());assert d['fuzzy_match_percent']==98.7788
u=next(u for u in json.loads(Path('build/GALE01/report.json').read_text())['units'] if u['name'].endswith('sysdolphin/baselib/hsd_3B34'))
fs=[{'name':f['name'],'percent':f['fuzzy_match_percent']} for f in u['functions']];assert len(fs)==8 and all(f['percent']=={'hsd_803B3408':98.7788,'hsd_803B3CD8':99.70266}.get(f['name'],100) for f in fs)
sha={str(p):hashlib.sha1(p.read_bytes()).hexdigest() for p in [Path('build/GALE01/main.dol'),Path('orig/GALE01/sys/main.dol')]};assert set(sha.values())=={'08e0bf20134dfcb260699671004527b2d6bb1a45'}
files=[];rows=[]
for family in ['components','pointer-helper']:
 p=Path('/tmp/c016-rgb-'+family);files.extend((f,str(f.relative_to('/tmp'))) for f in p.rglob('*') if f.is_file());files.append((Path(str(p)+'.py'),p.name+'.py'))
 rows.extend({'family':family,**r} for r in json.loads((p/'results.json').read_text()))
assert len(rows)==15
for suffix in ['components-doctor.log','creation-final.json','creation-final.log','creation-build.log','creation-attempt.log','creation-archive.py','full-retail.py','full-retail.log','full-retail-source.c','full-retail-consistency.json','full-pressure.json','full-pressure.log','pressure-issue.log','simplify-labels.py','simplify-labels.json','simplify-labels.log','simplify-insertion.py','simplify-insertion.json','simplify-insertion.log','target-correspondence.py','target-correspondence.json']:
 p=Path('/tmp/c016-rgb-'+suffix);files.append((p,p.name))
p=Path('/tmp/c016-rgb-full-retail');files.extend((f,str(f.relative_to('/tmp'))) for f in p.rglob('*') if f.is_file())
old=Path('/tmp/c016-rgb-corrected-stages/creation')
for name in ['pcode-0001-forward_peephole.json','pcode-0001-final.json','coloring-0001-gpr-01-before.json','coloring-0001-gpr-01-after.json','coloring-0001-fpr-01-before.json','coloring-0001-fpr-01-after.json','validation.json']:
 files.append((old/name,'prior-retail-reference/'+name))
for ext in ['c','json']:files.append((Path('/tmp/c016-rgb-combine-rule/LHR-left.'+ext),'prior-retail-reference/candidate.'+ext))
files.append((Path('tools/melee-agent/src/mwcc_debug/tiebreak.py'),'model-reference/tiebreak.py'));files.append((src,'retained-hsd_3B34.c'))
m={'function':'hsd_803B3408','scratch':None,'retained_source_change':False,'ordinary_match_percent':98.7788,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'unit_functions':fs,'dol_sha1':sha,'runs':rows,'scope':'Exact baseline simplify/SELECT replay; label-insertion diagnostics have no source realization. Backendv1 lacks live intervals/first-def/source attribution. Pressure causality issue1524.','members':[]}
assert len(set(n for _,n in files))==len(files)
with tarfile.open(root/'evidence.tar.gz','w:gz') as t:
 for p,n in sorted(files,key=lambda x:x[1]):
  data=p.read_bytes();m['members'].append({'path':n,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});t.add(p,arcname=n)
with tarfile.open(root/'evidence.tar.gz') as t:
 for f in m['members']:assert hashlib.sha256(t.extractfile(f['path']).read()).hexdigest()==f['sha256']
m['archive_sha256']=hashlib.sha256((root/'evidence.tar.gz').read_bytes()).hexdigest();(root/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('Verified',len(files),'members,',len(rows),'runs,',(root/'evidence.tar.gz').stat().st_size,'bytes')

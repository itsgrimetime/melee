from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();src=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-direct-row-call/structural-candidate.c.txt').read_text();root=Path('/tmp/c016-rgb-row-lifetime-call');root.mkdir(exist_ok=True);rows=[]
try:
 for form in ['combined','sequential','pointer','inner-local','inner-update']:
  n=form;s=src.replace('dst_row = tile_offset + jpeg_row_sum(chroma_y);','dst_row = jpeg_row_sum(chroma_y);')
  if form=='combined':s=s.replace('chroma_index += dst_row;','chroma_index += tile_offset + dst_row;')
  elif form=='sequential':s=s.replace('chroma_index += dst_row;','chroma_index += dst_row;\n                    chroma_index += tile_offset;')
  elif form=='pointer':s=s.replace('(HSD_804D2648_BUF + chroma_index * 4)','(HSD_804D2648_BUF + (chroma_index + tile_offset) * 4)')
  else:
   s=s.replace('                    s32 chroma_index;','                    s32 chroma_index;\n                    s32 row = tile_offset + dst_row;' if form=='inner-local' else '                    s32 chroma_index;\n                    s32 row = dst_row;\n                    row = tile_offset + row;')
   s=s.replace('chroma_index += dst_row;','chroma_index += row;')
  p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

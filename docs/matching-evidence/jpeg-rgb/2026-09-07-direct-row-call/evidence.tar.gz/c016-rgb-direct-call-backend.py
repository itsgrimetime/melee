from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text()
try:
 p.write_text(Path('/tmp/c016-rgb-direct-row-call/local-local-no-row.c').read_text())
 r=subprocess.run(['melee-agent','debug','retro','backend',str(p),'-f','hsd_803B3408','-O','/tmp/c016-rgb-direct-call-backend'],capture_output=True,text=True,timeout=210)
 print(r.returncode,r.stdout[-500:],r.stderr[-500:])
finally:p.write_text(base)

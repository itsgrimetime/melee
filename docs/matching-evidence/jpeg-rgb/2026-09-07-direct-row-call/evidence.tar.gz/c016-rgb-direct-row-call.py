from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');root=Path('/tmp/c016-rgb-direct-row-call');root.mkdir(exist_ok=True)
def run():
 base=p.read_text();rows=[];old='''                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;
                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;'''
 assert old in base
 try:
  for tile in ['local','expression']:
   for ret in ['direct','local']:
    for frame in ['full','no-row']:
     n=tile+'-'+ret+'-'+frame
     body='return (y & 1) * 4 + (y & 2) * 16;' if ret=='direct' else 's32 sum = (y & 1) * 4 + (y & 2) * 16; return sum;'
     s=base.replace('void hsd_803B3408(','static inline s32 jpeg_row_sum(s32 y) { '+body+' }\n\nvoid hsd_803B3408(',1)
     s=s.replace(old,'                dst_row = '+('tile_offset' if tile=='local' else '(tile_y * 16 + tile_x * 2)')+' + jpeg_row_sum(chroma_y);')
     if tile=='local':s=s.replace('            s32 chroma_y;','            s32 chroma_y;\n            s32 tile_offset = tile_y * 16 + tile_x * 2;')
     s=s.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
     if frame=='no-row':s=s.replace('                        s32 row_offset = (pixel_index & 2) * stride;','').replace('src[column_offset + row_offset]','src[column_offset + (pixel_index & 2) * stride]')
     p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
 finally:p.write_text(base)
if __name__=='__main__':run()

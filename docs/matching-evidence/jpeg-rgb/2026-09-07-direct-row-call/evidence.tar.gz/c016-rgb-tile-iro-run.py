from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text()
try:
 p.write_text(Path('/tmp/c016-rgb-tile-complexity/row-update.c').read_text())
 r=subprocess.run(['melee-agent','debug','retro','dump',str(p),'-f','hsd_803B3408','--phases','frontend','--timeout','180','-O','/tmp/c016-rgb-tile-iro'],capture_output=True,text=True,timeout=210)
 print(r.returncode,r.stdout[-1000:],r.stderr[-1000:])
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-typed-chroma-array');out.mkdir(exist_ok=True)
assign='                    chroma_dest =\n                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);'
index='                    chroma_index = (chroma_x & 2) * 4;\n                    chroma_index = (chroma_x & 1) + chroma_index;\n                    chroma_index += dst_row;'
try:
 for mode in ['local-index','column-first','row-first']:
  for owner in ['direct','local-work']:
   s=seed.replace('                    JpegWork* chroma_dest;','').replace(assign,'');idx='chroma_index'
   if mode!='local-index':s=s.replace('                    s32 chroma_index;','').replace(index,'');idx='(chroma_x & 1) + (chroma_x & 2) * 4 + dst_row' if mode=='column-first' else 'dst_row + (chroma_x & 1) + (chroma_x & 2) * 4'
   ptr='((JpegWork*) HSD_804D2648_BUF)'
   if owner=='local-work':s=s.replace('    s32 stride;','    s32 stride;\n    JpegWork* work = (JpegWork*) HSD_804D2648_BUF;');ptr='work'
   for field in ['518','618']:s=s.replace('chroma_dest->data.x'+field+'[0]',ptr+'->data.x'+field+'['+idx+']')
   name=mode+'-'+owner;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

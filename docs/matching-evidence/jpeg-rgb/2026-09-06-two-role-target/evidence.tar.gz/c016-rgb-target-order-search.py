exec(compile(open('/tmp/c016-rgb-target-correspondence.py').read(),'/tmp/c016-rgb-target-correspondence.py','exec'))
from itertools import product
rows=[];wins=[];best=999;count=0
extended=dict(base);extended.update(assignments)
for pm,im in product([n for n in order if n not in [37,38]],repeat=2):
 oo=list(order);oo.remove(37);oo.insert(oo.index(pm)+1,37);oo.remove(38);oo.insert(oo.index(im)+1,38)
 pred=predict_assignments(ig,order=oo);count+=1
 wrong={n:[v,extended[n]] for n,v in pred.items() if v!=extended[n]}
 if len(wrong)<best:best=len(wrong);rows=[]
 row={'moves':[[37,'after',pm],[38,'after',im]],'wrong':wrong,'order':oo,'assignments':pred}
 if len(wrong)==best and len(rows)<8:rows.append(row)
 if not wrong:wins.append(row)
result={'scope':'Abstract SELECT-only search, two moved roots37 and38, graph unchanged. Target extension assumes unmapped observed colors unchanged. Not a source100 result.','candidate_orders_evaluated':count,'best_wrong_count':best,'best_rows':rows,'wins':wins}
Path('/tmp/c016-rgb-target-order-search.json').write_text(json.dumps(result,indent=2)+'\n')
print('Orders',count,'best wrong',best,'wins',len(wins));print([(r['moves'],r['wrong']) for r in rows])

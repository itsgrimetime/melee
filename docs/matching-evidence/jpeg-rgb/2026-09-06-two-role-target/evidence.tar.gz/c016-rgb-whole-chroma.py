from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-whole-chroma');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
begin=part.index('                    s32 chroma_index;');end=part.index('\n                }',begin);body=part[begin:end]
init='''                    chroma_index = (chroma_x & 2) * 4;
                    chroma_index = (chroma_x & 1) + chroma_index;
                    chroma_index += dst_row;
                    chroma_dest =
                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);
''';assert init in body
rows=[]
try:
 for shape in ['baseline','corrected-pixel']:
  bb=body if shape=='baseline' else body.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
  for kind in ['whole-source-first','whole-dest-first','load-pointer','whole-loop']:
   if kind.startswith('whole-') and kind!='whole-loop':
    params='u16* src, s32 chroma_x, s32 src_row, s32 dst_row' if kind.endswith('source-first') else 's32 dst_row, s32 src_row, s32 chroma_x, u16* src'
    args='src, chroma_x, src_row, dst_row' if kind.endswith('source-first') else 'dst_row, src_row, chroma_x, src'
    helper='static inline void jpeg_chroma('+params+') { u16 pixel;\n'+bb+'\n}\n'
    s=part[:begin]+'                    jpeg_chroma('+args+');'+part[end:]
   elif kind=='load-pointer':
    for_exp=expr if shape=='baseline' else 'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]'
    inside=bb.replace('                    s32 chroma_index;\n','').replace('                    JpegWork* chroma_dest;\n','').replace(init,'').replace(for_exp,'*input')
    helper='static inline void jpeg_chroma(u16* input, JpegWork* chroma_dest) { u16 pixel;\n'+inside+'\n}\n'
    callbody='                    s32 chroma_index;\n                    JpegWork* chroma_dest;\n'+init+'                    jpeg_chroma(&'+for_exp+', chroma_dest);'
    s=part[:begin]+callbody+part[end:]
   else:
    ls=part.rfind('                for (chroma_x',0,begin)
    helper='static inline void jpeg_chroma(u16* src, s32 src_row, s32 dst_row) { s32 chroma_x; u16 pixel; for (chroma_x=0;chroma_x<4;chroma_x++) {\n'+bb+'\n} }\n'
    s=part[:ls]+'                jpeg_chroma(src, src_row, dst_row);'+part[end+len('\n                }'):]
   label=shape+'-'+kind;full=base[:a]+helper+s+base[b:];p.write_text(full);(out/(label+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   assert r.returncode in [0,1],(label,r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

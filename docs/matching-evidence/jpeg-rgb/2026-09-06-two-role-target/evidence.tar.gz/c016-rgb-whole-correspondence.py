from pathlib import Path
import json
roots=[Path('/tmp/c016-rgb-corrected-stages/creation'),Path('/tmp/c016-rgb-whole-stages/creation')]
rows=[];final_map={}
for phase in ['initial','optimized','forward_peephole']:
 ds=[json.loads((p/('pcode-0001-'+phase+'.json')).read_text()) for p in roots]
 ins=[[i for b in d['blocks'] for i in b['instructions']] for d in ds];mapping={};inverse={};errors=[]
 if len(ins[0])!=len(ins[1]):errors.append(['count',len(ins[0]),len(ins[1])])
 for num,(a,b) in enumerate(zip(*ins)):
  if a['opcode']!=b['opcode'] or len(a['operands'])!=len(b['operands']):errors.append([num,'opcode/arity']);continue
  for x,y in zip(a['operands'],b['operands']):
   if x['kind']!=y['kind']:errors.append([num,'kind']);continue
   if x['kind'] in [0,1]:
    ar=(x['kind'],x['reg']);br=(y['kind'],y['reg'])
    if ar[1]<32 and ar!=br:errors.append([num,'physical',ar,br])
    if (ar in mapping and mapping[ar]!=br) or (br in inverse and inverse[br]!=ar):errors.append([num,'bijection',ar,br]);continue
    mapping[ar]=br;inverse[br]=ar
   elif x['kind']==4 and x['value_signed']!=y['value_signed']:errors.append([num,'immediate',x['value_signed'],y['value_signed']])
 row={'phase':phase,'counts':list(map(len,ins)),'consistent_bijection':not errors,'errors':errors[:20],'map':{str(k):v for k,v in mapping.items()}};rows.append(row)
 if phase=='forward_peephole' and not errors:final_map=mapping
 print(phase,row['counts'],not errors,errors[:3])
color=[]
if final_map:
 for c in [0,1]:
  cl='gpr' if c==0 else 'fpr';bs=[json.loads((p/('coloring-0001-'+cl+'-01-before.json')).read_text()) for p in roots];aa=[json.loads((p/('coloring-0001-'+cl+'-01-after.json')).read_text()) for p in roots];ns=[{n['virtual_register']:n for n in a['nodes']} for a in aa];orders=[{v:i for i,v in enumerate(b['simplify_order'])} for b in bs];diff=[];mapped=0
  for (kind,n),(kind2,m) in final_map.items():
   if kind!=c or n not in orders[0] or m not in orders[1]:continue
   mapped+=1;x=ns[0][n]['physical_register'];y=ns[1][m]['physical_register']
   if x!=y or orders[0][n]!=orders[1][m]:diff.append({'old':n,'new':m,'old_phys':x,'new_phys':y,'old_select':orders[0][n],'new_select':orders[1][m]})
  color.append({'class':c,'mapped':mapped,'differences':diff});print('color',color[-1])
Path('/tmp/c016-rgb-whole-correspondence.json').write_text(json.dumps({'scope':'Instruction order/opcode/arity/register bijection and immediate check; symbol identity not proved by this mapping. Mapped color decisions only, not full graph isomorphism.','phases':rows,'colors':color},indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-direct-array');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
pi='''                    chroma_dest =
                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);
'''
ii='''                    chroma_index = (chroma_x & 2) * 4;
                    chroma_index = (chroma_x & 1) + chroma_index;
                    chroma_index += dst_row;
''';assert pi in part and ii in part
rows=[]
try:
 for shape in ['baseline','corrected-pixel']:
  source=part if shape=='baseline' else part.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
  for kind in ['array-index','array-expression','array-helper','pointer-expression']:
   s=source.replace(pi,'').replace('                    JpegWork* chroma_dest;\n','');helper='';idx='chroma_index'
   if kind!='array-index':
    s=s.replace(ii,'').replace('                    s32 chroma_index;\n','');idx='((chroma_x & 1) + (chroma_x & 2) * 4) + dst_row'
   if kind=='array-helper':
    helper='static inline s32 jpeg_chroma_index(s32 x, s32 row) { s32 index = (x & 2) * 4; index = (x & 1) + index; index += row; return index; }\n';idx='jpeg_chroma_index(chroma_x, dst_row)'
   for field in ['x518','x618']:
    new='((JpegWork*) HSD_804D2648_BUF)->data.'+field+'['+idx+']' if kind!='pointer-expression' else '((JpegWork*) (HSD_804D2648_BUF + ('+idx+') * 4))->data.'+field+'[0]'
    s=s.replace('chroma_dest->data.'+field+'[0]',new)
   label=shape+'-'+kind;full=base[:a]+helper+s+base[b:];p.write_text(full);(out/(label+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   assert r.returncode in [0,1],(label,r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();src=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-direct-row-call/structural-candidate.c.txt').read_text();root=Path('/tmp/c016-rgb-row-input-return');root.mkdir(exist_ok=True);rows=[]
old='static inline s32 jpeg_row_sum(s32 y) { s32 sum = (y & 1) * 4 + (y & 2) * 16; return sum; }'
try:
 for typ in ['s32','u32','u16','u8']:
  for frame in ['full','no-row']:
   n=typ+'-'+frame;s=src.replace(old,'static inline s32 jpeg_row_sum('+typ+' y) { y = (y & 1) * 4 + (y & 2) * 16; return y; }')
   if frame=='full':s=s.replace('src[column_offset + (pixel_index & 2) * stride]','src[column_offset + row_offset]').replace('                        {\n                            s32 column_offset','                        s32 row_offset = (pixel_index & 2) * stride;\n                        {\n                            s32 column_offset')
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();src=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-direct-row-call/structural-candidate.c.txt').read_text();root=Path('/tmp/c016-rgb-row-input');root.mkdir(exist_ok=True);rows=[]
try:
 for typ in ['u16','s16','u8','s8','int','unsigned int','s32-mask','u16-mask']:
  n=typ.replace(' ','-');actual=typ.replace('-mask','');s=src.replace('jpeg_row_sum(s32 y)','jpeg_row_sum('+actual+' y)')
  if '-mask' in typ:s=s.replace('{ s32 sum = (y & 1) * 4 + (y & 2) * 16; return sum; }','{ s32 sum; y &= 3; sum = (y & 1) * 4 + (y & 2) * 16; return sum; }')
  assert s!=src;p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

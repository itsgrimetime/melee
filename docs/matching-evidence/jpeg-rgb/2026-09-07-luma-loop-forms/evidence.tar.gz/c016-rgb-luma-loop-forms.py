from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-luma-loop-forms');out.mkdir(exist_ok=True)
try:
 for family,seed in [('production',base),('coherent',Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text())]:
  start=seed.index('                    for (pixel_index = 0;');bodypos=seed.index('                        s32 row_offset',start);close=seed.index('                    }\n                    src += 1;',bodypos)
  header=seed[start:bodypos];assignment=header[header.index('luma_base ='):header.index(',\n                        pixel_index')].strip();body=seed[bodypos:close]
  variants={
   'while-condition':'                    pixel_index = 0;\n                    while (('+assignment+'), pixel_index != 4) {\n'+body+'                        pixel_index++;\n',
   'do-base-before':'                    '+assignment+';\n                    pixel_index = 0;\n                    do {\n'+body+'                        pixel_index++;\n',
   'do-base-inside':'                    pixel_index = 0;\n                    do {\n                        '+assignment+';\n                        {\n'+body+'                        }\n'+'                        pixel_index++;\n',
   'for-init-base':'                    for (pixel_index = 0, '+assignment+'; pixel_index != 4; pixel_index++) {\n'+body,
   'for-body-base':'                    for (pixel_index = 0; pixel_index != 4; pixel_index++) {\n                        '+assignment+';\n                        {\n'+body+'                        }\n',
  }
  for mode,chunk in variants.items():
   ending='                    } while (pixel_index != 4);\n' if mode.startswith('do-') else '                    }\n'
   s=seed[:start]+chunk+ending+seed[close+22:];name=family+'-'+mode;
   if mode in ['while-condition','do-base-before'] and family=='production':continue
   (out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout)
   x=json.loads(r.stdout);print(name,x.get('fuzzy_match_percent'),x.get('classification',{}).get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-parameter-storage');out.mkdir(exist_ok=True)
pairs=[(v,'height') for v in ['chroma_index','row_part','dst_row','chroma_y','chroma_x','pixel_index']]+[('chroma_index',v) for v in ['x','y','width']]
try:
 for old,new in pairs:
  a=seed.index('void hsd_803B3408(');b=seed.index('static void fn_803B376C',a);body=seed[a:b];body=re.sub(r'^\s*s32 '+old+r';\n','\n',body,flags=re.M);body=re.sub(r'\b'+old+r'\b',new,body);s=seed[:a]+body+seed[b:]
  name=old+'-'+new;(out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

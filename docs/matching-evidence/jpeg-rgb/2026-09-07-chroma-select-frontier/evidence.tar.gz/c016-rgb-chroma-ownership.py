from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-chroma-ownership');out.mkdir(exist_ok=True)
assign='                    chroma_dest =\n                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);'
variants={}
for typ in ['int','u32','unsigned int']:
 variants['index-'+typ.replace(' ','-')]=seed.replace('s32 chroma_index;',typ+' chroma_index;')
expr='((JpegWork*) (HSD_804D2648_BUF + chroma_index * 4))'
variants['dest-expression']=seed.replace('                    JpegWork* chroma_dest;','').replace(assign,'').replace('chroma_dest->',expr+'->')
for typ in ['u8*','void*','s32*']:
 s=seed.replace('JpegWork* chroma_dest;',typ+' chroma_dest;').replace('(JpegWork*) (HSD_804D2648_BUF + chroma_index * 4)','('+typ+') (HSD_804D2648_BUF + chroma_index * 4)').replace('chroma_dest->','((JpegWork*)chroma_dest)->');variants['dest-'+typ.replace('*','ptr')]=s
for var,typ in [('chroma_dest','JpegWork*'),('chroma_index','s32')]:
 for scope in ['row','function']:
  s=seed.replace('                    '+typ+' '+var+';','')
  anchor='                s32 row_part;' if scope=='row' else '    s32 stride;'
  s=s.replace(anchor,anchor+'\n    '+typ+' '+var+';');variants[var+'-'+scope]=s
try:
 for name,s in variants.items():
  (out/(name+'.c')).write_text(s);p.write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

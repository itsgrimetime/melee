from pathlib import Path
import json,sys,itertools
sys.path.insert(0,'/Users/mike/code/mwcc-decomp/tools')
from coloring_model import replay_selection,replay_simplify
r=Path('/tmp/c016-rgb-donor-swap-stages/creation');b=json.loads((r/'coloring-0001-gpr-01-before.json').read_text());a=json.loads((r/'coloring-0001-gpr-01-after.json').read_text());m=json.load(open('/tmp/c016-rgb-donor-swap-correspondence.json'));t={int(k):v for k,v in m['target_assignments'].items()};order=b['simplify_order'];actual={n['virtual_register']:n['physical_register'] for n in a['nodes']};replay=replay_simplify(b);assert replay['simplify_order']==order and all(actual[n]==c for n,c in replay['colors'].items())
def score(o):
 c,d=replay_selection(b,o);miss={n:[c.get(n),v] for n,v in t.items() if c.get(n)!=v};return miss
best=[]
for v in [37,38]:
 for pos in range(len(order)):
  o=[n for n in order if n!=v];o.insert(pos,v);miss=score(o)
  best.append({'move':v,'position':pos,'misses':miss,'count':len(miss),'order':o})
best.sort(key=lambda x:x['count']);print('baseline',len(score(order)),'best single',[(x['move'],x['position'],x['count']) for x in best[:8]])
paired=[]
for a_pos in range(len(order)):
 for b_pos in range(a_pos+1,len(order)):
  o=[n for n in order if n not in [37,38]];o.insert(a_pos,38);o.insert(b_pos,37);miss=score(o)
  if len(miss)<best[0]['count']:paired.append({'positions':[a_pos,b_pos],'misses':miss,'count':len(miss),'order':o})
paired.sort(key=lambda x:x['count']);print('best paired',[(x['positions'],x['count']) for x in paired[:8]])
Path('/tmp/c016-rgb-donor-order.json').write_text(json.dumps({'scope':'Offline SELECT order hypotheses only. No compiler intervention or source-realizability proof. Baseline full replay verified.', 'baseline_misses':score(order),'single':best[:8],'paired':paired[:8]},indent=2))

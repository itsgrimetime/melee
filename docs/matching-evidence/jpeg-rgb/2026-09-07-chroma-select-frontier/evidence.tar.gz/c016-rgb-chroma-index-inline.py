from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text();out=Path('/tmp/c016-rgb-chroma-index-inline');out.mkdir(exist_ok=True)
index='                    chroma_index = (chroma_x & 2) * 4;\n                    chroma_index = (chroma_x & 1) + chroma_index;\n                    chroma_index += dst_row;'
forbidden=[]
try:
 for bodyname,body in [('local','s32 index = (x & 2) * 4; index = (x & 1) + index; return index + row;'),('direct','return (x & 1) + (x & 2) * 4 + row;')]:
  for caller in ['local','expression']:
   for frame in ['full','no-luma-row']:
    s=seed.replace('void hsd_803B3408(','static inline s32 jpeg_chroma_offset(s32 x, s32 row) { '+body+' }\n\nvoid hsd_803B3408(',1)
    if caller=='local':s=s.replace(index,'                    chroma_index = jpeg_chroma_offset(chroma_x, dst_row);')
    else:s=s.replace('                    s32 chroma_index;','').replace(index,'').replace('chroma_index * 4','jpeg_chroma_offset(chroma_x, dst_row) * 4')
    if frame=='no-luma-row':s=s.replace('s32 row_offset = (pixel_index & 2) * stride;','').replace('src[column_offset + row_offset]','src[column_offset + (pixel_index & 2) * stride]')
    name=bodyname+'-'+caller+'-'+frame;(out/(name+'.c')).write_text(s);p.write_text(s)
    r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text()
try:
 p.write_text(Path('docs/matching-evidence/jpeg-rgb/2026-09-07-donor-row-breakthrough/structural-candidate.c.txt').read_text())
 r=subprocess.run(['melee-agent','debug','retro','backend',str(p),'-f','hsd_803B3408','-O','/tmp/c016-rgb-donor-fullbackend'],capture_output=True,text=True,timeout=240);Path('/tmp/c016-rgb-donor-fullbackend.log').write_text(r.stdout+r.stderr);print(r.returncode,r.stdout[-1000:],r.stderr[-500:])
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-common-offset');out.mkdir(exist_ok=True)
helpers={
 'sum':'s32 offset = (i & 1) * low_stride + (i & 2) * high_stride; return offset;',
 'direct':'return (i & 1) * low_stride + (i & 2) * high_stride;',
 'parts':'s32 low = (i & 1) * low_stride; s32 high = (i & 2) * high_stride; return low + high;'
}
try:
 for shape,body in helpers.items():
  for mode in ['rows','rows-luma','rows-columns-luma']:
   s=base;prefix='static inline s32 jpeg_offset(s32 i, s32 low_stride, s32 high_stride) { '+body+' }\n\n'
   s=s.replace('void hsd_803B3408(',prefix+'void hsd_803B3408(',1)
   s=s.replace('dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;\n                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;', 'dst_row = (tile_y * 16 + tile_x * 2) + jpeg_offset(chroma_y, 4, 16);')
   s=s.replace('(chroma_y & 1) * 32 + (chroma_y & 2) * stride','jpeg_offset(chroma_y, 32, stride)')
   if 'luma' in mode:
    s=s.replace('s32 row_offset = (pixel_index & 2) * stride;','').replace('s32 column_offset = (pixel_index & 1) * 0x20;','').replace('src[column_offset + row_offset]','src[jpeg_offset(pixel_index, 32, stride)]')
   if 'columns' in mode:
    s=s.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','jpeg_offset(chroma_x, 2, 4) + src_row')
    s=s.replace('chroma_index = (chroma_x & 2) * 4;\n                    chroma_index = (chroma_x & 1) + chroma_index;','chroma_index = jpeg_offset(chroma_x, 1, 4);')
   name=shape+'-'+mode;(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification']['stack_frame_sizes'],flush=True)
finally:p.write_text(base)

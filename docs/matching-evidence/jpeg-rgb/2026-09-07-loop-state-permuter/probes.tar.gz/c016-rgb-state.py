from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-state');root.mkdir(exist_ok=True);rows=[]
a=base.index('void hsd_803B3408(');b=base.index('\nstatic void fn_803B376C',a)
groups={'counters':['chroma_x','luma_y','luma_x','tile_y','tile_x','pixel_index'],'all':['chroma_x','luma_y','luma_x','tile_y','tile_x','pixel','pixel_index','image_offset','stride'],'tiles':['tile_y','tile_x','chroma_x','chroma_y'],'luma':['luma_y','luma_x','pixel_index','image_offset','stride']}
try:
 for name,names in groups.items():
  for corrected in [False,True]:
   body=base[a:b]
   for n in names:body=re.sub(r'^\s+(?:s32|u16) '+n+r';\n','\n',body,flags=re.M)
   for n in names:body=re.sub(r'\b'+n+r'\b','state.'+n,body)
   decl='\n    struct {\n'+''.join('        '+('u16' if n=='pixel' else 's32')+' '+n+';\n' for n in names)+'    } state;'
   pos=body.index('{')+1;body=body[:pos]+decl+body[pos:]
   if corrected:body=body.replace('(state.chroma_x & 1) * 2 +\n                                (((state.chroma_x & 2) * 4) + src_row)','((state.chroma_x & 1) * 2 + (state.chroma_x & 2) * 4) + src_row').replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
   s=base[:a]+body+base[b:];n=name+('-corrected' if corrected else '');p.write_text(s);(root/(n+'.c')).write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr)
   x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

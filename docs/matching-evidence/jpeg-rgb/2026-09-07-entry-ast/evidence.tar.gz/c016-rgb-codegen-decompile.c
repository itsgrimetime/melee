
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void __cdecl FUN_004351c0(int *param_1,undefined1 *param_2)

{
  byte *pbVar1;
  undefined4 *puVar2;
  undefined1 *puVar3;
  int iVar4;
  int *piVar5;
  undefined4 *puVar6;
  undefined4 *puVar7;
  undefined2 extraout_var;
  undefined2 extraout_var_00;
  undefined2 uVar11;
  undefined4 *puVar8;
  undefined4 uVar9;
  uint uVar10;
  char cVar12;
  int iVar13;
  int local_34;
  int local_30;
  int local_2c;
  char local_28 [24];
  
  if (DAT_00584220 == '\0') {
    DAT_005884f0 = 0;
    DAT_005883e8 = 4;
    DAT_00588460 = 3;
    DAT_005882e4 = 4;
    DAT_005884f2 = 5;
    DAT_0058842e = 6;
  }
  else {
    DAT_005884f0 = 4;
    DAT_005883e8 = 0;
    DAT_00588460 = 4;
    DAT_005882e4 = 3;
    DAT_005884f2 = 6;
    DAT_0058842e = 5;
  }
  DAT_005882b0 = 0;
  DAT_005884f9 = 0;
  DAT_005884ff = 0;
  if (*(char *)(DAT_00588050 + 0xe0) == '\x01') {
    FUN_004463d0(0xb4);
  }
  if (param_2 == (undefined1 *)0x0) {
    param_2 = FUN_0049d330();
    FUN_004888f0((int)param_2);
  }
  else if ((param_2 != (undefined1 *)0x0) && (*(int *)(param_2 + 10) != 0)) {
    FUN_0041e110();
  }
  DAT_00587c80 = 0;
  for (puVar6 = *(undefined4 **)(*(int *)(param_2 + 0xe) + 6);
      (puVar6 != (undefined4 *)0x0 && (puVar6 != (undefined4 *)&DAT_00583098));
      puVar6 = (undefined4 *)*puVar6) {
  }
  uVar10 = (uint)(puVar6 == (undefined4 *)&DAT_00583098);
  DAT_005882c0 = 0;
  DAT_00586fc0._0_1_ = 0;
  iVar4 = FUN_004aa440((int)param_2);
  DAT_00587c80 = DAT_00587c80 + iVar4;
  DAT_00587620 = 0;
  if (puVar6 == (undefined4 *)&DAT_00583098) {
    FUN_004aa580();
  }
  FUN_00437870();
  DAT_0058851f = 0;
  DAT_00588224 = 0;
  DAT_00588280 = 0;
  DAT_00587130 = (undefined4 *)0x0;
  _DAT_0058718c = 0;
  DAT_005875a8 = 0;
  DAT_0057f6c0 = (undefined4 *)0x0;
  FUN_004bc980();
  DAT_00587fa8 = FUN_0047c410();
  DAT_0058802c = DAT_00587fa8;
  if (DAT_00584224._2_1_ != '\0') {
    FUN_004be830();
  }
  piVar5 = FUN_004be990((int)param_2,param_1);
  if (DAT_00584224._2_1_ != '\0') {
    FUN_004be830();
  }
  FUN_0049f530();
  FUN_004c23c0();
  FUN_0049d420(piVar5);
  if (DAT_00584224._2_1_ != '\0') {
    FUN_004be830();
  }
  if (DAT_005842da != '\0') {
    DAT_00588521 = '\0';
  }
  FUN_0049d2f0();
  puVar6 = (undefined4 *)FUN_0049d240();
  DAT_00588230 = FUN_0049d1b0();
  FUN_0049d170(DAT_00588230,puVar6);
  *(ushort *)(DAT_00588230 + 0x2e) = *(ushort *)(DAT_00588230 + 0x2e) | 1;
  if ((char)uVar10 == '\0') {
    puVar7 = (undefined4 *)FUN_0049d240();
    puVar6 = (undefined4 *)FUN_0049d1b0();
    FUN_0049d170((int)puVar6,puVar7);
    iVar4 = puVar6[2];
    iVar13 = DAT_00588230;
  }
  else {
    if ((DAT_00584244 == '\0') && (DAT_00584243 != '\0')) {
      puVar6 = (undefined4 *)FUN_0049d240();
      local_34 = FUN_0049d1b0();
      FUN_0049d170(local_34,puVar6);
      FUN_0049d140(DAT_00588230,*(int *)(local_34 + 8));
      puVar6 = (undefined4 *)FUN_0049d240();
      local_30 = FUN_0049d1b0();
      FUN_0049d170(local_30,puVar6);
      FUN_0049d140(local_34,*(int *)(local_30 + 8));
      puVar6 = (undefined4 *)FUN_0049d240();
      local_2c = FUN_0049d1b0();
      FUN_0049d170(local_2c,puVar6);
      FUN_0049d140(local_34,*(int *)(local_2c + 8));
      FUN_0049d140(local_30,*(int *)(local_2c + 8));
      *(ushort *)(local_34 + 0x2e) = *(ushort *)(local_34 + 0x2e) | 1;
      *(ushort *)(local_30 + 0x2e) = *(ushort *)(local_30 + 0x2e) | 1;
    }
    else {
      local_34 = 0;
      local_30 = 0;
      puVar6 = (undefined4 *)FUN_0049d240();
      local_2c = FUN_0049d1b0();
      FUN_0049d170(local_2c,puVar6);
      FUN_0049d140(DAT_00588230,*(int *)(local_2c + 8));
    }
    *(ushort *)(local_2c + 0x2e) = *(ushort *)(local_2c + 0x2e) | 1;
    puVar7 = (undefined4 *)FUN_0049d240();
    puVar6 = (undefined4 *)FUN_0049d1b0();
    FUN_0049d170((int)puVar6,puVar7);
    iVar4 = puVar6[2];
    iVar13 = local_2c;
  }
  FUN_0049d140(iVar13,iVar4);
  FUN_004ac4e0();
  FUN_004c2390();
  FUN_00436c90();
  FUN_004376f0(&LAB_004365d0);
  if ((DAT_00584224._1_1_ != '\0') || (DAT_00584230 != '\0')) {
    puVar7 = (undefined4 *)FUN_0049d240();
    FUN_004a24e0(puVar7);
  }
  if (DAT_005842da != '\0') {
    puVar7 = FUN_004c2560((int)param_2);
    FUN_00435e00((char *)((int)puVar7 + 10));
  }
  FUN_00436550();
  puVar8 = (undefined4 *)*piVar5;
  puVar7 = (undefined4 *)0x0;
  while (puVar2 = puVar8, puVar2 != (undefined4 *)0x0) {
    if ((*(char *)(puVar2 + 1) == '\x02') && (*(int *)(*(int *)((int)puVar2 + 0xe) + 0x10) == 0)) {
      if ((puVar7 == (undefined4 *)0x0) || (*(char *)(puVar7 + 1) != '\x02')) {
        uVar9 = FUN_0049d240();
        *(undefined4 *)(*(int *)((int)puVar2 + 0xe) + 0x10) = uVar9;
      }
      else {
        *(undefined4 *)(*(int *)((int)puVar2 + 0xe) + 0x10) =
             *(undefined4 *)(*(int *)((int)puVar7 + 0xe) + 0x10);
      }
    }
    puVar7 = puVar2;
    puVar8 = (undefined4 *)*puVar2;
  }
  FUN_004c1900();
  puVar7 = (undefined4 *)*piVar5;
  do {
    if (puVar7 == (undefined4 *)0x0) {
      FUN_004c17c0();
      puVar3 = DAT_00587fa8;
      if (*(int *)(DAT_00587fa8 + 0x10) == 0) {
        uVar9 = FUN_0049d240();
        *(undefined4 *)(puVar3 + 0x10) = uVar9;
      }
      puVar7 = *(undefined4 **)(puVar3 + 0x10);
      puVar8 = DAT_0057f6c0;
      iVar4 = DAT_005880c4;
      if (*(short *)(puVar7 + 2) == 0) {
        FUN_004a24e0(puVar7);
        puVar8 = DAT_0057f6c0;
        iVar4 = DAT_005880c4;
      }
      for (; DAT_00587ec8 = iVar4, DAT_005880c4 = DAT_00587ec8, puVar8 != (undefined4 *)0x0;
          puVar8 = (undefined4 *)*puVar8) {
        *(undefined4 *)(puVar8[1] + 0x2a) = 0;
        iVar4 = DAT_005880c4;
      }
      DAT_00587130 = (undefined4 *)0x0;
      *(ushort *)(DAT_00587ec8 + 0x2e) = *(ushort *)(DAT_00587ec8 + 0x2e) | 2;
      FUN_0049d0f0();
      FUN_0049d0b0();
      if ((DAT_005842e1 < '\x01') || (DAT_00588224 != 0)) {
        FUN_004c2560((int)param_2);
        FUN_004c4bd0();
      }
      else {
        FUN_004c4430((int)param_2);
      }
      if (DAT_00584224._1_1_ == '\x02') {
        if (DAT_005842d7 != '\0') {
          FUN_004c6100(param_2,'\0');
        }
        if (DAT_00584224._2_1_ != '\0') {
          FUN_004c2560((int)param_2);
          FUN_004c4bb0();
        }
        FUN_004ccae0('\0');
        if (DAT_00584224._2_1_ != '\0') {
          FUN_004c4ba0();
        }
        if (DAT_00584224._2_1_ != '\0') {
          FUN_004c2560((int)param_2);
          FUN_004c4bd0();
        }
      }
      if (DAT_005842d7 != '\0') {
        if ((DAT_00584224._1_1_ == '\0') && ('\x01' < DAT_005842e1)) {
          FUN_004c6100(param_2,'\0');
        }
        FUN_004c62f0();
        if (DAT_00584224._2_1_ != '\0') {
          FUN_004c2560((int)param_2);
          FUN_004c4bd0();
        }
      }
      FUN_004cdef0((int)param_2);
      puVar7 = DAT_0057f6c0;
      if (DAT_00584224._2_1_ != '\0') {
        FUN_004c2560((int)param_2);
        FUN_004c4bd0();
        puVar7 = DAT_0057f6c0;
      }
      for (; cVar12 = (char)uVar10, puVar7 != (undefined4 *)0x0; puVar7 = (undefined4 *)*puVar7) {
        FUN_004ac4a0(puVar7[1]);
      }
      if (cVar12 == '\0') {
        FUN_004aa890();
      }
      FUN_004ac240(puVar6);
      FUN_004abe90(DAT_00588230);
      if (cVar12 != '\0') {
        FUN_004aa4a0(local_34,local_30,local_2c);
      }
      if (DAT_005842da != '\0') {
        FUN_004a2130(DAT_00587c8c,1,0,0,0);
      }
      FUN_004aba30(DAT_00587ec8,'\x01');
      if (DAT_00584224._2_1_ != '\0') {
        FUN_004c2560((int)param_2);
        FUN_004c4bd0();
      }
      if (DAT_005842d7 != '\0') {
        if ((DAT_00584224._1_1_ != '\0') &&
           (FUN_004c6100(param_2,'\x01'), DAT_00584224._2_1_ != '\0')) {
          FUN_004c2560((int)param_2);
          FUN_004c4bd0();
        }
        FUN_004c60b0((int)param_2);
        if (DAT_00584224._2_1_ != '\0') {
          FUN_004c2560((int)param_2);
          FUN_004c4bd0();
        }
      }
      if (DAT_00584224._1_1_ != '\0') {
        if (DAT_00584224._2_1_ != '\0') {
          FUN_004c2560((int)param_2);
          FUN_004c4bb0();
        }
        FUN_004ccae0('\x01');
        if (DAT_00584224._2_1_ != '\0') {
          FUN_004c4ba0();
        }
      }
      if (DAT_00584224._2_1_ != '\0') {
        FUN_004c2560((int)param_2);
        FUN_004c4bd0();
      }
      uVar10 = FUN_004a2b70((int)param_2,(undefined4 *)0x0);
      FUN_004babb0((int)param_2);
      FUN_0049ed70();
      if ((DAT_005842d3 != '\0') && (DAT_00588521 == '\0')) {
        FUN_004bc0a0((int)param_2,uVar10);
      }
      return;
    }
    DAT_00587130 = puVar7;
    switch(*(undefined1 *)(puVar7 + 1)) {
    case 1:
      break;
    case 2:
      iVar4 = *(int *)((int)puVar7 + 0xe);
      if (*(int *)(iVar4 + 0x10) == 0) {
        uVar9 = FUN_0049d240();
        *(undefined4 *)(iVar4 + 0x10) = uVar9;
      }
      puVar8 = DAT_0057f6c0;
      if (*(short *)(*(undefined4 **)(iVar4 + 0x10) + 2) == 0) {
        FUN_004a24e0(*(undefined4 **)(iVar4 + 0x10));
        puVar8 = DAT_0057f6c0;
      }
      for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
        *(undefined4 *)(puVar8[1] + 0x2a) = 0;
      }
      break;
    case 3:
      FUN_00436470(*(undefined4 *)((int)puVar7 + 0x16),(uint)*(ushort *)(puVar7 + 2),
                   (uint)((*(byte *)((int)puVar7 + 6) & 0x10) != 0));
      iVar4 = *(int *)((int)puVar7 + 0xe);
      if (*(int *)(iVar4 + 0x10) == 0) {
        uVar9 = FUN_0049d240();
        *(undefined4 *)(iVar4 + 0x10) = uVar9;
      }
      FUN_004a23f0(*(int *)(iVar4 + 0x10));
      for (puVar8 = DAT_0057f6c0; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
        *(undefined4 *)(puVar8[1] + 0x2a) = 0;
      }
      break;
    case 4:
      FUN_00436470(*(undefined4 *)((int)puVar7 + 0x16),(uint)*(ushort *)(puVar7 + 2),
                   (uint)((*(byte *)((int)puVar7 + 6) & 0x10) != 0));
      FUN_00436390(*(byte **)((int)puVar7 + 10));
      break;
    case 5:
      FUN_00436470(*(undefined4 *)((int)puVar7 + 0x16),(uint)*(ushort *)(puVar7 + 2),
                   (uint)((*(byte *)((int)puVar7 + 6) & 0x10) != 0));
      FUN_004bac10(*(byte **)((int)puVar7 + 10),*(undefined4 **)((int)puVar7 + 0xe));
      break;
    case 6:
      FUN_00436470(*(undefined4 *)((int)puVar7 + 0x16),(uint)*(ushort *)(puVar7 + 2),
                   (uint)((*(byte *)((int)puVar7 + 6) & 0x10) != 0));
      FUN_00436240(*(byte **)((int)puVar7 + 10),*(int *)((int)puVar7 + 0xe),1);
      break;
    case 7:
      FUN_00436470(*(undefined4 *)((int)puVar7 + 0x16),(uint)*(ushort *)(puVar7 + 2),
                   (uint)((*(byte *)((int)puVar7 + 6) & 0x10) != 0));
      FUN_00436240(*(byte **)((int)puVar7 + 10),*(int *)((int)puVar7 + 0xe),0);
      break;
    case 8:
      FUN_00436470(*(undefined4 *)((int)puVar7 + 0x16),(uint)*(ushort *)(puVar7 + 2),
                   (uint)((*(byte *)((int)puVar7 + 6) & 0x10) != 0));
      for (puVar8 = (undefined4 *)*puVar7; puVar8 != (undefined4 *)0x0;
          puVar8 = (undefined4 *)*puVar8) {
        if (2 < *(byte *)(puVar8 + 1)) {
          cVar12 = '\0';
          goto LAB_004358b8;
        }
      }
      cVar12 = '\x01';
LAB_004358b8:
      FUN_00435f60(*(byte **)((int)puVar7 + 10),cVar12);
      break;
    default:
      FUN_00445780();
      break;
    case 0xc:
      iVar4 = *(int *)(*(int *)((int)puVar7 + 10) + 10);
      puVar8 = (undefined4 *)FUN_0049d240();
      FUN_004a24e0(puVar8);
      uVar11 = extraout_var;
      if (*(char *)(iVar4 + 2) != '\x01') {
        FUN_00445780();
        uVar11 = extraout_var_00;
      }
      FUN_004a1dd0(0x31,1,CONCAT22(uVar11,DAT_0058842a),iVar4,0x14);
      puVar8 = (undefined4 *)FUN_0049d240();
      FUN_004a24e0(puVar8);
      break;
    case 0xe:
      if (*(char *)(*(int *)(*(int *)((int)puVar7 + 10) + 10) + 2) != '\x01') {
        FUN_00445780();
      }
      FUN_004a2060(3,DAT_0058842a,*(int *)(*(int *)((int)puVar7 + 10) + 10),0);
      FUN_004a2130(DAT_005875a0,1,8,0,0);
    case 0xd:
      if (*(char *)(*(int *)(*(int *)((int)puVar7 + 10) + 10) + 2) != '\x01') {
        FUN_00445780();
      }
      puVar8 = (undefined4 *)FUN_0049d240();
      FUN_004a24e0(puVar8);
      FUN_004a1dd0(0x22,0,1,0,0);
      puVar8 = (undefined4 *)FUN_004a2620(0x22);
      *(uint *)((int)puVar8 + 0x16) = *(uint *)((int)puVar8 + 0x16) | 0x400;
      FUN_0049d060(DAT_005880c4,puVar8);
      FUN_004a1dd0(0x31,0,1,0,0);
      puVar8 = (undefined4 *)FUN_0049d240();
      FUN_004a24e0(puVar8);
      break;
    case 0xf:
      FUN_00436470(*(undefined4 *)((int)puVar7 + 0x16),(uint)*(ushort *)(puVar7 + 2),
                   (uint)((*(byte *)((int)puVar7 + 6) & 0x10) != 0));
      pbVar1 = *(byte **)((int)puVar7 + 10);
      FUN_00441db0(local_28,0x16);
      (*(code *)(&PTR_DAT_00560648)[*pbVar1])(pbVar1,0,0,local_28);
      if (local_28[0] != '\0') {
        FUN_004a0ba0(local_28,(char *)((int)&DAT_0055d5d6 + 2),0);
      }
      puVar8 = DAT_00588288;
      if (local_28[0] != '\0') {
        FUN_00445780();
        puVar8 = DAT_00588288;
      }
      for (; puVar8 != (undefined4 *)0x0; puVar8 = (undefined4 *)*puVar8) {
        FUN_0049d140(DAT_005880c4,*(int *)(puVar8[2] + 0x10));
      }
      FUN_004a25d0(0x78);
      FUN_004a2380();
      break;
    case 0x10:
      if (*(int *)((int)puVar7 + 10) != 0) {
        if ((*(byte *)(*(int *)((int)puVar7 + 10) + 4) & 1) == 0) {
          puVar8 = (undefined4 *)FUN_0049d240();
          FUN_004a24e0(puVar8);
          *(undefined4 *)(DAT_005880c4 + 0x20) = *(undefined4 *)((int)puVar7 + 0x16);
          FUN_00463440((int)puVar7);
        }
        else {
          FUN_00445780();
        }
      }
    }
    FUN_004c1850();
    puVar7 = (undefined4 *)*puVar7;
  } while( true );
}


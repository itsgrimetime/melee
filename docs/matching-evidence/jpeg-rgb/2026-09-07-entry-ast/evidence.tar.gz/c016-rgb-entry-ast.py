def intervene(ctx):
    from pathlib import Path
    import json
    ctx.cad.NODE_NAMES[:] = json.loads(Path("/tmp/c016-rgb-node-names.json").read_text())
    for bp in ctx.gdb.breakpoints():bp.enabled=False
    class Entry(ctx.gdb.Breakpoint):
        def stop(self):
            sp=int(ctx.gdb.parse_and_eval('$esp'))
            obj=ctx.cad.MwccObject.load(ctx.cad.read_u32(sp+8),load_linkname=False)
            if obj.name!=ctx.fn:return False
            ptr=ctx.cad.read_u32(sp+4)
            out=Path(ctx.out_dir)/'entry-ast.txt'
            with out.open('w') as f:
                seen=set()
                while ptr:
                    if ptr in seen:raise RuntimeError('statement cycle')
                    seen.add(ptr)
                    stmt=ctx.cad.MwccStatement.load(ptr)
                    ctx.cad.print_statement(f,stmt)
                    ptr=stmt.next_addr
            (Path(ctx.out_dir)/'entry-complete.json').write_text(json.dumps({'function':obj.name,'statements':len(seen),'stage':'CodeGen entry 0x4351c0 before frontend optimizer','source':'esp+4 first parameter; read-only'}))
            return True
    Entry('*0x4351c0',internal=True)
    ctx.cont()

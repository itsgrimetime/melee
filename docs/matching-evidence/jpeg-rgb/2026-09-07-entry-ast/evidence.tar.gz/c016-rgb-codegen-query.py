from pathlib import Path
import pyghidra
pyghidra.start()
from ghidra.app.decompiler import DecompInterface
from ghidra.util.task import ConsoleTaskMonitor
proj=pyghidra.open_project(str(Path('tools/mwcc_debug/ghidra_project').resolve()),'mwcceppc',create=False)
try:
 with pyghidra.program_context(proj,'/mwcceppc.exe') as p:
  f=p.getFunctionManager().getFunctionAt(p.getAddressFactory().getAddress('004351c0'))
  d=DecompInterface();d.openProgram(p);r=d.decompileFunction(f,40,ConsoleTaskMonitor());Path('/tmp/c016-rgb-codegen-decompile.c').write_text(r.getDecompiledFunction().getC());d.dispose()
finally:proj.close()

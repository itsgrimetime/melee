from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-row-union');root.mkdir(exist_ok=True);rows=[]
old='''                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;
                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;'''
try:
 for other in ['s32','u32','int','unsigned int']:
  for update in [False,True]:
   n=other.replace(' ','-')+('-update' if update else '-separate');s=base.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
   new='                union { s32 sum; '+other+' value; } row;\n                row.sum = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;\n                '
   if update:new+='row.sum = (tile_y * 16 + tile_x * 2) + row.value; dst_row = row.sum;'
   else:new+='dst_row = (tile_y * 16 + tile_x * 2) + row.value;'
   s=s.replace(old,new);p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

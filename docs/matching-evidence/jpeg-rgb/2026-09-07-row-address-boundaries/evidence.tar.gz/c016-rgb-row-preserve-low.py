from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-row-preserve-low');root.mkdir(exist_ok=True);rows=[]
old='''                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;
                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;
                src_row = (chroma_y & 1) * 32 + (chroma_y & 2) * stride;'''
try:
 for frame in ['full','no-row']:
  for form in ['copy-first','sum-separate','output-first']:
   n=frame+'-'+form
   if form=='copy-first':body='s32 low = (y & 1) * 4; s32 original = low; low += (y & 2) * 16; *src = original * 8 + (y & 2) * stride; return tile + low;'
   elif form=='sum-separate':body='s32 low = (y & 1) * 4; s32 sum = low; sum += (y & 2) * 16; *src = low * 8 + (y & 2) * stride; return tile + sum;'
   else:body='s32 low = (y & 1) * 4; *src = low * 8 + (y & 2) * stride; low += (y & 2) * 16; return tile + low;'
   s=base.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row');s=s.replace(old,'                dst_row = rgb_preserve_low(chroma_y, tile_y * 16 + tile_x * 2, stride, &src_row);');s=s.replace('void hsd_803B3408(','static inline s32 rgb_preserve_low(s32 y, s32 tile, s32 stride, s32* src) { '+body+' }\nvoid hsd_803B3408(',1)
   if frame=='no-row':s=s.replace('                        s32 row_offset = (pixel_index & 2) * stride;','').replace('src[column_offset + row_offset]','src[column_offset + (pixel_index & 2) * stride]')
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

from pathlib import Path
import json,subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-row-address');root.mkdir(exist_ok=True);rows=[]
tile='(tile_y * 16 + tile_x * 2)';rs='((chroma_y & 1) * 4 + (chroma_y & 2) * 16)'
try:
 for shape in ['use-sum','use-sum-reverse','sequential','index-full','address-full','inner-row-local','inner-full-row-local','inner-row-helper']:
  s=base.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
  s=s.replace('                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;','')
  if shape=='use-sum':s=s.replace('chroma_index += dst_row;','chroma_index += '+tile+' + dst_row;')
  elif shape=='use-sum-reverse':s=s.replace('chroma_index += dst_row;','chroma_index += dst_row + '+tile+';')
  elif shape=='sequential':s=s.replace('chroma_index += dst_row;','chroma_index += dst_row; chroma_index += '+tile+';')
  elif shape=='index-full':s=s.replace('chroma_index += dst_row;','chroma_index = ('+tile+' + dst_row) + chroma_index;')
  elif shape=='address-full':s=s.replace('                    chroma_index += dst_row;','').replace('HSD_804D2648_BUF + chroma_index * 4','HSD_804D2648_BUF + ('+tile+' + dst_row + chroma_index) * 4')
  elif shape=='inner-row-local':s=s.replace('chroma_index += dst_row;','{ s32 row = '+tile+' + dst_row; chroma_index += row; }')
  else:
   s=s.replace('                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;','')
   if shape=='inner-full-row-local':s=s.replace('chroma_index += dst_row;','{ s32 row = '+tile+' + '+rs+'; chroma_index += row; }')
   else:
    s=s.replace('chroma_index += dst_row;','chroma_index += rgb_address_row(chroma_y, '+tile+');');s=s.replace('void hsd_803B3408(','static inline s32 rgb_address_row(s32 y, s32 tile) { return tile + ((y & 1) * 4 + (y & 2) * 16); }\nvoid hsd_803B3408(',1)
  p.write_text(s);(root/(shape+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(shape+'.json')).write_text(r.stdout);(root/(shape+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':shape,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

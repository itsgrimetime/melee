from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-pointer-storage');root.mkdir(exist_ok=True);rows=[]
try:
 for shape in ['baseline','structural']:
  src=base if shape=='baseline' else Path('docs/matching-evidence/jpeg-rgb/2026-09-07-direct-row-call/structural-candidate.c.txt').read_text()
  a=src.index('void hsd_803B3408(');b=src.index('static void fn_803B376C',a)
  for kind in ['union','void']:
   n=shape+'-'+kind;s=src[a:b].replace('                    JpegWork* chroma_dest;\n','').replace('                    s32* luma_base;\n','')
   if kind=='union':s=s.replace('    s32 stride;','    s32 stride;\n    union { JpegWork* chroma; s32* luma; } destination;').replace('chroma_dest','destination.chroma').replace('luma_base','destination.luma')
   else:
    s=s.replace('    s32 stride;','    s32 stride;\n    void* destination;').replace('chroma_dest->','((JpegWork*) destination)->').replace('luma_base[pixel_index * 64]','((s32*) destination)[pixel_index * 64]');s=re.sub(r'\bchroma_dest\b','destination',s);s=re.sub(r'\bluma_base\b','destination',s)
   s=src[:a]+s+src[b:];p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

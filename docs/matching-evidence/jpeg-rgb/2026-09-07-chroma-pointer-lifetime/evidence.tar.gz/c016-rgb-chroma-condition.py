from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-chroma-condition');root.mkdir(exist_ok=True);rows=[]
idx='''                    chroma_index = (chroma_x & 2) * 4;
                    chroma_index = (chroma_x & 1) + chroma_index;
                    chroma_index += dst_row;
'''
ptr='''                    chroma_dest =
                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);
'''
try:
 for shape in ['baseline','structural']:
  src=base if shape=='baseline' else Path('docs/matching-evidence/jpeg-rgb/2026-09-07-direct-row-call/structural-candidate.c.txt').read_text()
  for mode in ['index','both','direct-pointer']:
   n=shape+'-'+mode;s=src
   moved='                s32 chroma_index;\n' if mode in ['index','both'] else ''
   if mode in ['both','direct-pointer']:moved+='                JpegWork* chroma_dest;\n'
   s=s.replace('                s32 src_row;','                s32 src_row;\n'+moved)
   if mode in ['index','both']:s=s.replace('                    s32 chroma_index;\n','')
   if mode in ['both','direct-pointer']:s=s.replace('                    JpegWork* chroma_dest;\n','')
   s=s.replace(idx,'')
   cond='chroma_index = (chroma_x & 2) * 4, chroma_index = (chroma_x & 1) + chroma_index, chroma_index += dst_row, '
   if mode=='both':cond+='chroma_dest = (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4), ';s=s.replace(ptr,'')
   if mode=='direct-pointer':cond='chroma_dest = (JpegWork*) (HSD_804D2648_BUF + ((chroma_x & 1) + (chroma_x & 2) * 4 + dst_row) * 4), ';s=s.replace(ptr,'').replace('                    s32 chroma_index;\n','')
   s=s.replace('for (chroma_x = 0; chroma_x < 4; chroma_x++)','for (chroma_x = 0; '+cond+'chroma_x < 4; chroma_x++)')
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

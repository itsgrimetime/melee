from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-pointer-storage-scope');root.mkdir(exist_ok=True);rows=[]
try:
 for shape in ['baseline','structural']:
  for scope in ['tile-y','tile-x']:
   n=shape+'-'+scope;s=Path('/tmp/c016-rgb-pointer-storage/'+shape+'-void.c').read_text().replace('    void* destination;\n','')
   if scope=='tile-y':s=s.replace('        u16* src;','        u16* src;\n        void* destination;')
   else:s=s.replace('            s32 chroma_y;','            s32 chroma_y;\n            void* destination;')
   p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);v={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes')};rows.append(v);print(v,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

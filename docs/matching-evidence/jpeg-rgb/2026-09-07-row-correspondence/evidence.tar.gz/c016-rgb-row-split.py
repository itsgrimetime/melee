from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();src=Path('/tmp/c016-rgb-row-frame/corrected-no-row.c').read_text();root=Path('/tmp/c016-rgb-row-split');root.mkdir(exist_ok=True);rows=[]
old='static inline s32 rgb_row(s32 low, s32 high, s32 tile) { low += high; return tile + low; }'
variants={'out-return':('s32 rgb_row(s32* out, s32 low, s32 high, s32 tile)','*out = low + high; return tile + *out;',True),'out-update':('s32 rgb_row(s32* out, s32 low, s32 high, s32 tile)','*out = low + high; *out = tile + *out; return *out;',True),'local-two':('s32 rgb_row(s32 low, s32 high, s32 tile)','s32 sum = low + high; s32 result = tile + sum; return result;',False),'local-update':('s32 rgb_row(s32 low, s32 high, s32 tile)','s32 sum = low + high; sum = tile + sum; return sum;',False),'local-assign':('s32 rgb_row(s32 low, s32 high, s32 tile)','s32 sum; return (sum = low + high), tile + sum;',False)}
try:
 for n,(sig,body,out) in variants.items():
  s=src.replace(old,'static inline '+sig+' { '+body+' }')
  if out:s=s.replace('dst_row = rgb_row(', 'dst_row = rgb_row(&dst_row, ')
  p.write_text(s);(root/(n+'.c')).write_text(s);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

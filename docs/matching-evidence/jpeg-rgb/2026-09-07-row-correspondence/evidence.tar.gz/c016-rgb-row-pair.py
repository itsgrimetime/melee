from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-row-pair');root.mkdir(exist_ok=True);rows=[]
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b];old='''                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;
                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;
                src_row = (chroma_y & 1) * 32 + (chroma_y & 2) * stride;''';assert old in part
try:
 for order in ['dst-first','src-first']:
  for form in ['pointers','struct']:
   for low in ['raw','shared']:
    n=order+'-'+form+'-'+low;statements={'src': 'SRC = (y & 1) * 32 + (y & 2) * stride;','dst':'DST = (y & 1) * 4 + (y & 2) * 16; DST = tile + DST;'}
    body=' '.join(statements[k] for k in (['dst','src'] if order=='dst-first' else ['src','dst']))
    if low=='shared':body='s32 low = (y & 1) * 4; '+body.replace('(y & 1) * 32','low * 8').replace('(y & 1) * 4','low');body=body.replace('s32 low = low;','s32 low = (y & 1) * 4;')
    s=part.replace('(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)','((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row')
    if form=='pointers':helper='static inline void rgb_rows(s32 y, s32 tile, s32 stride, s32* dst, s32* src) { '+body.replace('DST','*dst').replace('SRC','*src')+' }\n';s=s.replace(old,'                rgb_rows(chroma_y, tile_y * 16 + tile_x * 2, stride, &dst_row, &src_row);')
    else:
     helper='typedef struct { s32 dst; s32 src; } RgbRows;\nstatic inline RgbRows rgb_rows(s32 y, s32 tile, s32 stride) { RgbRows rows; '+body.replace('DST','rows.dst').replace('SRC','rows.src')+' return rows; }\n';s=s.replace('                s32 dst_row;\n                s32 src_row;','                s32 dst_row;\n                s32 src_row;\n                RgbRows rows;');s=s.replace(old,'                rows = rgb_rows(chroma_y, tile_y * 16 + tile_x * 2, stride);\n                dst_row = rows.dst;\n                src_row = rows.src;')
    full=base[:a]+helper+s+base[b:];p.write_text(full);(root/(n+'.c')).write_text(full);r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(n+'.json')).write_text(r.stdout);(root/(n+'.log')).write_text(r.stderr);x=json.loads(r.stdout);row={'name':n,'score':x.get('fuzzy_match_percent'),'frame':x.get('classification',{}).get('stack_frame_sizes'),'structural':x.get('structural')};rows.append(row);print(row,flush=True);(root/'results.json').write_text(json.dumps(rows,indent=2))
finally:p.write_text(base)

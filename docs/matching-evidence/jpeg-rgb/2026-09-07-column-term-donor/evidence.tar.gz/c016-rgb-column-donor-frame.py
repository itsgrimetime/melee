from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();seed=Path('/tmp/c016-rgb-direct-index/row-low-high-expression.c').read_text();out=Path('/tmp/c016-rgb-column-donor-frame');out.mkdir(exist_ok=True)
old='(dst_row + (chroma_x & 1) + (chroma_x & 2) * 4)';load='                    pixel = src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row];'
try:
 for part in ['low','high']:
  for order in itertools.permutations(['row','low','high']):
   
   if order[0]!='row':continue
   s=seed;term='(chroma_x & 1)' if part=='low' else '(chroma_x & 2) * 4';terms={'row':'dst_row','low':'(chroma_x & 1)','high':'(chroma_x & 2) * 4'};terms[part]='column_part'
   s=s.replace('                for (chroma_x = 0; chroma_x < 4; chroma_x++) {','                for (chroma_x = 0; chroma_x < 4; chroma_x++) {\n                    s32 column_part;',1);s=s.replace(load,load+'\n                    column_part = '+term+';',1);s=s.replace(old,'('+' + '.join(terms[k] for k in order)+')')
   s=s.replace('s32 row_offset = (pixel_index & 2) * stride;', '').replace('src[column_offset + row_offset]', 'src[column_offset + (pixel_index & 2) * stride]');name=part+'-'+'-'.join(order);(out/(name+'.c')).write_text(s);p.write_text(s)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(out/(name+'.json')).write_text(r.stdout);x=json.loads(r.stdout);print(name,x['fuzzy_match_percent'],x['classification'].get('stack_frame_sizes'),flush=True)
finally:p.write_text(base)

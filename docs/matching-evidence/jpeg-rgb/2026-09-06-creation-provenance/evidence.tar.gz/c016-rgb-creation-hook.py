"""Reuse standalone read-only PCode creation capture in the retail emulator."""
def intervene(ctx):
    import runpy
    runpy.run_path('/Users/mike/code/mwcc-decomp/tools/gdb/allocator_snapshot.py')
    ctx.gdb.execute('mwcc-auto-capture ' + ctx.out_dir + '/creation ' + ctx.fn + ' ninji')
    ctx.cont()

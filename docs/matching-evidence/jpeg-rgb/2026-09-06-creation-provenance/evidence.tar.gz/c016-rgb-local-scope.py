from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-local-scope');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
candidate=Path('/tmp/c016-rgb-combine-rule/LHR-left.c').read_text()
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a)
ca=candidate.index('void hsd_803B3408(');cb=candidate.index('static void fn_803B376C',ca);part=candidate[ca:cb]
vs={}
decls={'index':'s32 chroma_index;','dest':'JpegWork* chroma_dest;'}
anchors={'function':'    s32 chroma_x;','tile':'            s32 chroma_y;','row':'                s32 dst_row;'}
for selection in ('index','dest','both'):
 for scope,anchor in anchors.items():
  t=part; selected=list(decls.values()) if selection=='both' else [decls[selection]]
  for decl in selected:
   assert t.count('                    '+decl+'\n')==1;t=t.replace('                    '+decl+'\n','')
  indent=anchor[:len(anchor)-len(anchor.lstrip())]
  t=t.replace(anchor,'\n'.join(indent+d for d in selected)+'\n'+anchor,1)
  vs[selection+'-'+scope]=t
vs['swap-inner']=part.replace('                    s32 chroma_index;\n                    JpegWork* chroma_dest;','                    JpegWork* chroma_dest;\n                    s32 chroma_index;')
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['classification'].get('structural_truth_gate')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

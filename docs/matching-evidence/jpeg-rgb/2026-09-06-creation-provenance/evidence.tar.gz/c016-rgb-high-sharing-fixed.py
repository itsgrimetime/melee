from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-high-sharing-fixed');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
assert part.count(expr)==2
vs={}

correct=part.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
for typ in ('s32','u32','int'):
 for shape in ('high','both'):
  names=[('column_low','chroma_x & 1')] if shape=='low' else [('column_high','(chroma_x & 2) * 4')] if shape=='high' else [('column_low','chroma_x & 1'),('column_high','(chroma_x & 2) * 4')]
  t=correct
  for name,value in names:t=t.replace(value if name=='column_high' else '('+value+')',name)
  decl=''.join('                    '+typ+' '+name+' = '+value+';\n' for name,value in names)
  t=t.replace('                    JpegWork* chroma_dest;','                    JpegWork* chroma_dest;\n'+decl)
  vs[typ+'-'+shape]=t
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['classification'].get('structural_truth_gate')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

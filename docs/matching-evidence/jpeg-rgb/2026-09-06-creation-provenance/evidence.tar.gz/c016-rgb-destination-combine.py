from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-destination-combine');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
candidate=Path('/tmp/c016-rgb-combine-rule/LHR-left.c').read_text()
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a)
ca=candidate.index('void hsd_803B3408(');cb=candidate.index('static void fn_803B376C',ca);part=candidate[ca:cb]
old='''                    chroma_index = (chroma_x & 2) * 4;
                    chroma_index = (chroma_x & 1) + chroma_index;
                    chroma_index += dst_row;
'''
assert part.count(old)==1
vs={}
terms={'L':'(chroma_x & 1)','H':'((chroma_x & 2) * 4)','R':'dst_row'}
for order in itertools.permutations('LHR'):
 x,y,z=[terms[t] for t in order]
 for assoc in ('left','right'):
  val='('+x+' + '+y+') + '+z if assoc=='left' else x+' + ('+y+' + '+z+')'
  vs[''.join(order)+'-'+assoc]=part.replace(old,'                    chroma_index = '+val+';\n')
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['classification'].get('structural_truth_gate')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

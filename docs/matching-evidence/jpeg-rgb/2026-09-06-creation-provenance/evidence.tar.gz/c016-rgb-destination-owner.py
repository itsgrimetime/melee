from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-destination-owner');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
assert part.count(expr)==2
vs={}

import re
correct=part.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
for base_name,body in [('base',part),('group',correct)]:
 for shape in ('struct','union','array','uncached'):
  t=body
  if shape=='uncached':
   init='                    chroma_dest =\n                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);\n'
   assert init in t;t=t.replace(init,'').replace('                    JpegWork* chroma_dest;\n','').replace('chroma_dest->','((JpegWork*) (HSD_804D2648_BUF + chroma_index * 4))->')
  else:
   name='destination.ptr' if shape in ('struct','union') else 'destination[0]'
   decl=shape+' { JpegWork* ptr; } destination;' if shape in ('struct','union') else 'JpegWork* destination[1];'
   t=t.replace('JpegWork* chroma_dest;',decl)
   t=re.sub(r'\bchroma_dest\b',name,t)
  vs[base_name+'-'+shape]=t
first='                    pixel = src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row];\n'
idx='                    chroma_index = (chroma_x & 2) * 4;\n                    chroma_index = (chroma_x & 1) + chroma_index;\n                    chroma_index += dst_row;\n'
assert first in correct and idx in correct
for n,move in [('low-high-before',idx.split('                    chroma_index +=')[0]),('index-before',idx)]:
 t=correct.replace(move,'').replace(first,move+first,1);vs['group-'+n]=t
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['classification'].get('structural_truth_gate')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

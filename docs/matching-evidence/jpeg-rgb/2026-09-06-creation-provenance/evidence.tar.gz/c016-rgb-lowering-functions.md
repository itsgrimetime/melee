# Selected functions from mwcceppc.exe

## `FUN_004a0ba0` at `004a0ba0`

- Bytes: 976
- Callers: `00434500` (`FUN_00434500`), `004351c0` (`FUN_004351c0`), `00435e00` (`FUN_00435e00`), `00435f60` (`FUN_00435f60`), `00436390` (`FUN_00436390`), `0047ce80` (`FUN_0047ce80`), `00485360` (`FUN_00485360`), `00487090` (`FUN_00487090`), `004871a0` (`FUN_004871a0`), `00487bd0` (`FUN_00487bd0`), `00487ce0` (`FUN_00487ce0`), `00487de0` (`FUN_00487de0`), `00487f00` (`FUN_00487f00`), `004880b0` (`FUN_004880b0`), `0049fe50` (`FUN_0049fe50`), `004a1860` (`FUN_004a1860`), `004a4cb0` (`FUN_004a4cb0`), `004a5840` (`FUN_004a5840`), `004a5fe0` (`FUN_004a5fe0`), `004a6df0` (`FUN_004a6df0`), `004a7020` (`FUN_004a7020`), `004b1300` (`FUN_004b1300`), `004b1b20` (`FUN_004b1b20`), `004b1d30` (`FUN_004b1d30`), `004b3670` (`FUN_004b3670`), `004b37b0` (`FUN_004b37b0`), `004b3b00` (`FUN_004b3b00`), `004b3e30` (`FUN_004b3e30`), `004b5860` (`FUN_004b5860`), `004b5970` (`FUN_004b5970`), `004b5a00` (`FUN_004b5a00`), `004b5ae0` (`FUN_004b5ae0`), `004ba200` (`FUN_004ba200`), `004bad00` (`FUN_004bad00`), `004bb200` (`FUN_004bb200`), `00518ab0` (`FUN_00518ab0`), `00519260` (`FUN_00519260`), `00519890` (`FUN_00519890`)
- Callees: `00445780` (`FUN_00445780`), `0048f180` (`FUN_0048f180`), `0049cf70` (`FUN_0049cf70`), `004a0680` (`FUN_004a0680`), `004a0fc0` (`FUN_004a0fc0`), `004a1dd0` (`FUN_004a1dd0`), `004a2060` (`FUN_004a2060`), `004a25d0` (`FUN_004a25d0`)
- Referenced strings:
  - `0055e9f8` `Operands.c`

```text
004a0ba0  53  PUSH EBX
004a0ba1  56  PUSH ESI
004a0ba2  57  PUSH EDI
004a0ba3  55  PUSH EBP
004a0ba4  83ec10  SUB ESP,0x10
004a0ba7  8b742428  MOV ESI,dword ptr [ESP + 0x28]
004a0bab  8b5c242c  MOV EBX,dword ptr [ESP + 0x2c]
004a0baf  8b7c2424  MOV EDI,dword ptr [ESP + 0x24]
004a0bb3  8a0e  MOV CL,byte ptr [ESI]
004a0bb5  80f901  CMP CL,0x1
004a0bb8  7405  JZ 0x004a0bbf
004a0bba  80f903  CMP CL,0x3
004a0bbd  7506  JNZ 0x004a0bc5
004a0bbf  837e0208  CMP dword ptr [ESI + 0x2],0x8
004a0bc3  7414  JZ 0x004a0bd9
004a0bc5  803d4442580000  CMP byte ptr [0x00584244],0x0
004a0bcc  7422  JZ 0x004a0bf0
004a0bce  80f902  CMP CL,0x2
004a0bd1  751d  JNZ 0x004a0bf0
004a0bd3  837e0204  CMP dword ptr [ESI + 0x2],0x4
004a0bd7  7417  JZ 0x004a0bf0
004a0bd9  89d8  MOV EAX,EBX
004a0bdb  6a00  PUSH 0x0
004a0bdd  50  PUSH EAX
004a0bde  56  PUSH ESI
004a0bdf  57  PUSH EDI
004a0be0  e89bfaffff  CALL 0x004a0680
004a0be5  83c410  ADD ESP,0x10
004a0be8  83c410  ADD ESP,0x10
004a0beb  5d  POP EBP
004a0bec  5f  POP EDI
004a0bed  5e  POP ESI
004a0bee  5b  POP EBX
004a0bef  c3  RET
004a0bf0  57  PUSH EDI
004a0bf1  e8ca030000  CALL 0x004a0fc0
004a0bf6  0fb607  MOVZX EAX,byte ptr [EDI]
004a0bf9  59  POP ECX
004a0bfa  3d0a000000  CMP EAX,0xa
004a0bff  0f878f030000  JA 0x004a0f94
004a0c05  ff2485a8ea5500  JMP dword ptr [EAX*0x4 + 0x55eaa8]
004a0c0c  83c410  ADD ESP,0x10
004a0c0f  5d  POP EBP
004a0c10  5f  POP EDI
004a0c11  5e  POP ESI
004a0c12  5b  POP EBX
004a0c13  c3  RET
004a0c14  83c410  ADD ESP,0x10
004a0c17  5d  POP EBP
004a0c18  5f  POP EDI
004a0c19  5e  POP ESI
004a0c1a  5b  POP EBX
004a0c1b  c3  RET
004a0c20  6685db  TEST BX,BX
004a0c23  740b  JZ 0x004a0c30
004a0c25  89d8  MOV EAX,EBX
004a0c27  eb14  JMP 0x004a0c3d
004a0c30  66a16e845800  MOV AX,[0x0058846e]
004a0c36  66ff056e845800  INC word ptr [0x0058846e]
004a0c3d  8944240c  MOV dword ptr [ESP + 0xc],EAX
004a0c41  668b5f08  MOV BX,word ptr [EDI + 0x8]
004a0c45  668b5702  MOV DX,word ptr [EDI + 0x2]
004a0c49  8b7712  MOV ESI,dword ptr [EDI + 0x12]
004a0c4c  53  PUSH EBX
004a0c4d  56  PUSH ESI
004a0c4e  52  PUSH EDX
004a0c4f  50  PUSH EAX
004a0c50  e80b140000  CALL 0x004a2060
004a0c55  83c410  ADD ESP,0x10
004a0c58  e948030000  JMP 0x004a0fa5
004a0c60  6685db  TEST BX,BX
004a0c63  750e  JNZ 0x004a0c73
004a0c65  668b1d6e845800  MOV BX,word ptr [0x0058846e]
004a0c6c  66ff056e845800  INC word ptr [0x0058846e]
004a0c73  895c240c  MOV dword ptr [ESP + 0xc],EBX
004a0c77  0fbf4706  MOVSX EAX,word ptr [EDI + 0x6]
004a0c7b  0fbf4f02  MOVSX ECX,word ptr [EDI + 0x2]
004a0c7f  50  PUSH EAX
004a0c80  0fbfc3  MOVSX EAX,BX
004a0c83  51  PUSH ECX
004a0c84  50  PUSH EAX
004a0c85  6a3c  PUSH 0x3c
004a0c87  e844190000  CALL 0x004a25d0
004a0c8c  83c410  ADD ESP,0x10
004a0c8f  e911030000  JMP 0x004a0fa5
004a0c94  6685db  TEST BX,BX
004a0c97  7407  JZ 0x004a0ca0
004a0c99  89dd  MOV EBP,EBX
004a0c9b  eb11  JMP 0x004a0cae
004a0ca0  668b2d6e845800  MOV BP,word ptr [0x0058846e]
004a0ca7  66ff056e845800  INC word ptr [0x0058846e]
004a0cae  896c240c  MOV dword ptr [ESP + 0xc],EBP
004a0cb2  8b5f0e  MOV EBX,dword ptr [EDI + 0xe]
004a0cb5  0fbfc3  MOVSX EAX,BX
004a0cb8  89442404  MOV dword ptr [ESP + 0x4],EAX
004a0cbc  3b5c2404  CMP EBX,dword ptr [ESP + 0x4]
004a0cc0  751e  JNZ 0x004a0ce0
004a0cc2  0fbfc5  MOVSX EAX,BP
004a0cc5  53  PUSH EBX
004a0cc6  50  PUSH EAX
004a0cc7  6889000000  PUSH 0x89
004a0ccc  e8ff180000  CALL 0x004a25d0
004a0cd1  83c40c  ADD ESP,0xc
004a0cd4  e9cc020000  JMP 0x004a0fa5
004a0ce0  803de142580001  CMP byte ptr [0x005842e1],0x1
004a0ce7  89e9  MOV ECX,EBP
004a0ce9  7e13  JLE 0x004a0cfe
004a0ceb  6685db  TEST BX,BX
004a0cee  740e  JZ 0x004a0cfe
004a0cf0  668b0d6e845800  MOV CX,word ptr [0x0058846e]
004a0cf7  66ff056e845800  INC word ptr [0x0058846e]
004a0cfe  89de  MOV ESI,EBX
004a0d00  89da  MOV EDX,EBX
004a0d02  c1fe0f  SAR ESI,0xf
004a0d05  c1fa10  SAR EDX,0x10
004a0d08  81e601000000  AND ESI,0x1
004a0d0e  01d6  ADD ESI,EDX
004a0d10  0fbfc6  MOVSX EAX,SI
004a0d13  0fbff1  MOVSX ESI,CX
004a0d16  50  PUSH EAX
004a0d17  6a00  PUSH 0x0
004a0d19  56  PUSH ESI
004a0d1a  688a000000  PUSH 0x8a
004a0d1f  e8ac180000  CALL 0x004a25d0
004a0d24  83c410  ADD ESP,0x10
004a0d27  6685db  TEST BX,BX
004a0d2a  0f8475020000  JZ 0x004a0fa5
004a0d30  0fbfc5  MOVSX EAX,BP
004a0d33  ff742404  PUSH dword ptr [ESP + 0x4]
004a0d37  6a00  PUSH 0x0
004a0d39  56  PUSH ESI
004a0d3a  50  PUSH EAX
004a0d3b  6a3f  PUSH 0x3f
004a0d3d  e88e180000  CALL 0x004a25d0
004a0d42  83c414  ADD ESP,0x14
004a0d45  e95b020000  JMP 0x004a0fa5
004a0d50  6685db  TEST BX,BX
004a0d53  740b  JZ 0x004a0d60
004a0d55  89dd  MOV EBP,EBX
004a0d57  eb15  JMP 0x004a0d6e
004a0d60  668b2d6e845800  MOV BP,word ptr [0x0058846e]
004a0d67  66ff056e845800  INC word ptr [0x0058846e]
004a0d6e  896c240c  MOV dword ptr [ESP + 0xc],EBP
004a0d72  8a06  MOV AL,byte ptr [ESI]
004a0d74  3c01  CMP AL,0x1
004a0d76  bb22000000  MOV EBX,0x22
004a0d7b  7404  JZ 0x004a0d81
004a0d7d  3c03  CMP AL,0x3
004a0d7f  753f  JNZ 0x004a0dc0
004a0d81  8b4602  MOV EAX,dword ptr [ESI + 0x2]
004a0d84  8b4e02  MOV ECX,dword ptr [ESI + 0x2]
004a0d87  2d01000000  SUB EAX,0x1
004a0d8c  7409  JZ 0x004a0d97
004a0d8e  2d01000000  SUB EAX,0x1
004a0d93  740b  JZ 0x004a0da0
004a0d95  eb5b  JMP 0x004a0df2
004a0d97  bb15000000  MOV EBX,0x15
004a0d9c  eb54  JMP 0x004a0df2
004a0da0  56  PUSH ESI
004a0da1  e8dae3feff  CALL 0x0048f180
004a0da6  84c0  TEST AL,AL
004a0da8  59  POP ECX
004a0da9  7407  JZ 0x004a0db2
004a0dab  bb19000000  MOV EBX,0x19
004a0db0  eb40  JMP 0x004a0df2
004a0db2  bb1d000000  MOV EBX,0x1d
004a0db7  eb39  JMP 0x004a0df2
004a0dc0  3c0b  CMP AL,0xb
004a0dc2  742e  JZ 0x004a0df2
004a0dc4  3c0a  CMP AL,0xa
004a0dc6  7506  JNZ 0x004a0dce
004a0dc8  837e0204  CMP dword ptr [ESI + 0x2],0x4
004a0dcc  7424  JZ 0x004a0df2
004a0dce  803d4442580000  CMP byte ptr [0x00584244],0x0
004a0dd5  740a  JZ 0x004a0de1
004a0dd7  3c02  CMP AL,0x2
004a0dd9  7506  JNZ 0x004a0de1
004a0ddb  837e0204  CMP dword ptr [ESI + 0x2],0x4
004a0ddf  7411  JZ 0x004a0df2
004a0de1  6824020000  PUSH 0x224
004a0de6  68f8e95500  PUSH 0x55e9f8
004a0deb  e89049faff  CALL 0x00445780
004a0df0  59  POP ECX
004a0df1  59  POP ECX
004a0df2  0fbf4708  MOVSX EAX,word ptr [EDI + 0x8]
004a0df6  8b7712  MOV ESI,dword ptr [EDI + 0x12]
004a0df9  50  PUSH EAX
004a0dfa  668b4702  MOV AX,word ptr [EDI + 0x2]
004a0dfe  56  PUSH ESI
004a0dff  50  PUSH EAX
004a0e00  55  PUSH EBP
004a0e01  53  PUSH EBX
004a0e02  e8c90f0000  CALL 0x004a1dd0
004a0e07  8b470a  MOV EAX,dword ptr [EDI + 0xa]
004a0e0a  83c414  ADD ESP,0x14
004a0e0d  50  PUSH EAX
004a0e0e  e85dc1ffff  CALL 0x0049cf70
004a0e13  59  POP ECX
004a0e14  e98c010000  JMP 0x004a0fa5
004a0e20  6685db  TEST BX,BX
004a0e23  740b  JZ 0x004a0e30
004a0e25  89dd  MOV EBP,EBX
004a0e27  eb15  JMP 0x004a0e3e
004a0e30  668b2d6e845800  MOV BP,word ptr [0x0058846e]
004a0e37  66ff056e845800  INC word ptr [0x0058846e]
004a0e3e  896c240c  MOV dword ptr [ESP + 0xc],EBP
004a0e42  8a06  MOV AL,byte ptr [ESI]
004a0e44  3c01  CMP AL,0x1
004a0e46  bb24000000  MOV EBX,0x24
004a0e4b  7404  JZ 0x004a0e51
004a0e4d  3c03  CMP AL,0x3
004a0e4f  753f  JNZ 0x004a0e90
004a0e51  8b4602  MOV EAX,dword ptr [ESI + 0x2]
004a0e54  8b5602  MOV EDX,dword ptr [ESI + 0x2]
004a0e57  2d01000000  SUB EAX,0x1
004a0e5c  7409  JZ 0x004a0e67
004a0e5e  2d01000000  SUB EAX,0x1
004a0e63  740b  JZ 0x004a0e70
004a0e65  eb5b  JMP 0x004a0ec2
004a0e67  bb17000000  MOV EBX,0x17
004a0e6c  eb54  JMP 0x004a0ec2
004a0e70  56  PUSH ESI
004a0e71  e80ae3feff  CALL 0x0048f180
004a0e76  84c0  TEST AL,AL
004a0e78  59  POP ECX
004a0e79  7407  JZ 0x004a0e82
004a0e7b  bb1b000000  MOV EBX,0x1b
004a0e80  eb40  JMP 0x004a0ec2
004a0e82  bb1f000000  MOV EBX,0x1f
004a0e87  eb39  JMP 0x004a0ec2
004a0e90  3c0b  CMP AL,0xb
004a0e92  742e  JZ 0x004a0ec2
004a0e94  3c0a  CMP AL,0xa
004a0e96  7506  JNZ 0x004a0e9e
004a0e98  837e0204  CMP dword ptr [ESI + 0x2],0x4
004a0e9c  7424  JZ 0x004a0ec2
004a0e9e  803d4442580000  CMP byte ptr [0x00584244],0x0
004a0ea5  740a  JZ 0x004a0eb1
004a0ea7  3c02  CMP AL,0x2
004a0ea9  7506  JNZ 0x004a0eb1
004a0eab  837e0204  CMP dword ptr [ESI + 0x2],0x4
004a0eaf  7411  JZ 0x004a0ec2
004a0eb1  683a020000  PUSH 0x23a
004a0eb6  68f8e95500  PUSH 0x55e9f8
004a0ebb  e8c048faff  CALL 0x00445780
004a0ec0  59  POP ECX
004a0ec1  59  POP ECX
004a0ec2  0fbf4706  MOVSX EAX,word ptr [EDI + 0x6]
004a0ec6  0fbf4f02  MOVSX ECX,word ptr [EDI + 0x2]
004a0eca  50  PUSH EAX
004a0ecb  0fbfc5  MOVSX EAX,BP
004a0ece  51  PUSH ECX
004a0ecf  50  PUSH EAX
004a0ed0  53  PUSH EBX
004a0ed1  e8fa160000  CALL 0x004a25d0
004a0ed6  8b470a  MOV EAX,dword ptr [EDI + 0xa]
004a0ed9  83c410  ADD ESP,0x10
004a0edc  50  PUSH EAX
004a0edd  e88ec0ffff  CALL 0x0049cf70
004a0ee2  e9bd000000  JMP 0x004a0fa4
004a0ee7  31ed  XOR EBP,EBP
004a0ee9  31f6  XOR ESI,ESI
004a0eeb  6685db  TEST BX,BX
004a0eee  7404  JZ 0x004a0ef4
004a0ef0  89d8  MOV EAX,EBX
004a0ef2  eb0d  JMP 0x004a0f01
004a0ef4  66a16e845800  MOV AX,[0x0058846e]
004a0efa  66ff056e845800  INC word ptr [0x0058846e]
004a0f01  0fbfd8  MOVSX EBX,AX
004a0f04  8944240c  MOV dword ptr [ESP + 0xc],EAX
004a0f08  53  PUSH EBX
004a0f09  6882000000  PUSH 0x82
004a0f0e  e8bd160000  CALL 0x004a25d0
004a0f13  0fbf4706  MOVSX EAX,word ptr [EDI + 0x6]
004a0f17  59  POP ECX
004a0f18  59  POP ECX
004a0f19  2d13000000  SUB EAX,0x13
004a0f1e  3d05000000  CMP EAX,0x5
004a0f23  772b  JA 0x004a0f50
004a0f25  ff248590ea5500  JMP dword ptr [EAX*0x4 + 0x55ea90]
004a0f2c  be01000000  MOV ESI,0x1
004a0f31  bd02000000  MOV EBP,0x2
004a0f36  eb29  JMP 0x004a0f61
004a0f38  be01000000  MOV ESI,0x1
004a0f3d  31ed  XOR EBP,EBP
004a0f3f  eb20  JMP 0x004a0f61
004a0f41  be01000000  MOV ESI,0x1
004a0f46  bd01000000  MOV EBP,0x1
004a0f4b  eb14  JMP 0x004a0f61
004a0f50  6859020000  PUSH 0x259
004a0f55  68f8e95500  PUSH 0x55e9f8
004a0f5a  e82148faff  CALL 0x00445780
004a0f5f  59  POP ECX
004a0f60  59  POP ECX
004a0f61  668b5702  MOV DX,word ptr [EDI + 0x2]
004a0f65  c1e202  SHL EDX,0x2
004a0f68  01ea  ADD EDX,EBP
004a0f6a  0fbfc2  MOVSX EAX,DX
004a0f6d  6a1f  PUSH 0x1f
004a0f6f  6a1f  PUSH 0x1f
004a0f71  40  INC EAX
004a0f72  50  PUSH EAX
004a0f73  53  PUSH EBX
004a0f74  53  PUSH EBX
004a0f75  6a67  PUSH 0x67
004a0f77  e854160000  CALL 0x004a25d0
004a0f7c  83c418  ADD ESP,0x18
004a0f7f  6685f6  TEST SI,SI
004a0f82  7421  JZ 0x004a0fa5
004a0f84  6a01  PUSH 0x1
004a0f86  53  PUSH EBX
004a0f87  53  PUSH EBX
004a0f88  6a5a  PUSH 0x5a
004a0f8a  e841160000  CALL 0x004a25d0
004a0f8f  83c410  ADD ESP,0x10
004a0f92  eb11  JMP 0x004a0fa5
004a0f94  6864020000  PUSH 0x264
004a0f99  68f8e95500  PUSH 0x55e9f8
004a0f9e  e8dd47faff  CALL 0x00445780
004a0fa3  59  POP ECX
004a0fa4  59  POP ECX
004a0fa5  c60700  MOV byte ptr [EDI],0x0
004a0fa8  8b44240c  MOV EAX,dword ptr [ESP + 0xc]
004a0fac  66894702  MOV word ptr [EDI + 0x2],AX
004a0fb0  83c410  ADD ESP,0x10
004a0fb3  5d  POP EBP
004a0fb4  5f  POP EDI
004a0fb5  5e  POP ESI
004a0fb6  5b  POP EBX
004a0fb7  c3  RET
```

```c

void __cdecl FUN_004a0ba0(char *param_1,char *param_2,uint param_3)

{
  bool bVar1;
  bool bVar2;
  char cVar3;
  short sVar4;
  uint local_14;
  
  cVar3 = *param_2;
  if ((((cVar3 != '\x01') && (cVar3 != '\x03')) || (*(int *)(param_2 + 2) != 8)) &&
     (((DAT_00584244 == '\0' || (cVar3 != '\x02')) || (*(int *)(param_2 + 2) == 4)))) {
    FUN_004a0fc0(param_1);
    sVar4 = (short)param_3;
    switch(*param_1) {
    case '\0':
      return;
    case '\x01':
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      FUN_004a2060(param_3,*(short *)(param_1 + 2),*(int *)(param_1 + 0x12),*(short *)(param_1 + 8))
      ;
      local_14 = param_3;
      break;
    case '\x02':
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      FUN_004a25d0(0x3c);
      local_14 = param_3;
      break;
    case '\x03':
      return;
    case '\x04':
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      sVar4 = (short)*(int *)(param_1 + 0xe);
      local_14 = param_3;
      if (*(int *)(param_1 + 0xe) == (int)sVar4) {
        FUN_004a25d0(0x89);
      }
      else {
        if (('\x01' < DAT_005842e1) && (sVar4 != 0)) {
          DAT_0058846e = DAT_0058846e + 1;
        }
        FUN_004a25d0(0x8a);
        if (sVar4 != 0) {
          FUN_004a25d0(0x3f);
        }
      }
      break;
    default:
      FUN_00445780();
      break;
    case '\a':
      bVar2 = false;
      bVar1 = false;
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      FUN_004a25d0(0x82);
      switch(*(undefined2 *)(param_1 + 6)) {
      case 0x15:
        bVar2 = true;
      case 0x14:
        bVar1 = bVar2;
        break;
      case 0x16:
        bVar2 = true;
      case 0x13:
        bVar1 = bVar2;
        break;
      case 0x18:
        bVar2 = true;
      case 0x17:
        bVar1 = bVar2;
        break;
      default:
        FUN_00445780();
      }
      FUN_004a25d0(0x67);
      local_14 = param_3;
      if (bVar1) {
        FUN_004a25d0(0x5a);
      }
      break;
    case '\t':
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      cVar3 = *param_2;
      sVar4 = 0x22;
      if ((cVar3 == '\x01') || (cVar3 == '\x03')) {
        if (*(int *)(param_2 + 2) == 1) {
          sVar4 = 0x15;
        }
        else if (*(int *)(param_2 + 2) == 2) {
          cVar3 = FUN_0048f180(param_2);
          if (cVar3 == '\0') {
            sVar4 = 0x1d;
          }
          else {
            sVar4 = 0x19;
          }
        }
      }
      else if (((cVar3 != '\v') && ((cVar3 != '\n' || (*(int *)(param_2 + 2) != 4)))) &&
              ((DAT_00584244 == '\0' || ((cVar3 != '\x02' || (*(int *)(param_2 + 2) != 4)))))) {
        FUN_00445780();
      }
      FUN_004a1dd0(sVar4,(short)param_3,
                   CONCAT22(*(short *)(param_1 + 8) >> 0xf,*(undefined2 *)(param_1 + 2)),
                   *(int *)(param_1 + 0x12),(int)*(short *)(param_1 + 8));
      FUN_0049cf70(*(uint *)(param_1 + 10));
      local_14 = param_3;
      break;
    case '\n':
      if (sVar4 == 0) {
        param_3 = (uint)DAT_0058846e;
        DAT_0058846e = DAT_0058846e + 1;
      }
      cVar3 = *param_2;
      sVar4 = 0x24;
      if ((cVar3 == '\x01') || (cVar3 == '\x03')) {
        if (*(int *)(param_2 + 2) == 1) {
          sVar4 = 0x17;
        }
        else if (*(int *)(param_2 + 2) == 2) {
          cVar3 = FUN_0048f180(param_2);
          if (cVar3 == '\0') {
            sVar4 = 0x1f;
          }
          else {
            sVar4 = 0x1b;
          }
        }
      }
      else if (((cVar3 != '\v') && ((cVar3 != '\n' || (*(int *)(param_2 + 2) != 4)))) &&
              ((DAT_00584244 == '\0' || ((cVar3 != '\x02' || (*(int *)(param_2 + 2) != 4)))))) {
        FUN_00445780();
      }
      FUN_004a25d0(sVar4);
      FUN_0049cf70(*(uint *)(param_1 + 10));
      local_14 = param_3;
    }
    *param_1 = '\0';
    *(short *)(param_1 + 2) = (short)local_14;
    return;
  }
  FUN_004a0680(param_1,param_2,param_3,0);
  return;
}


```

## `FUN_004a1130` at `004a1130`

- Bytes: 1780
- Callers: none
- Callees: `00445780` (`FUN_00445780`), `004a0fc0` (`FUN_004a0fc0`), `004a2060` (`FUN_004a2060`), `004a25d0` (`FUN_004a25d0`)
- Referenced strings:
  - `0055e9f8` `Operands.c`

```text
004a1130  53  PUSH EBX
004a1131  56  PUSH ESI
004a1132  57  PUSH EDI
004a1133  55  PUSH EBP
004a1134  83ec08  SUB ESP,0x8
004a1137  8b7c241c  MOV EDI,dword ptr [ESP + 0x1c]
004a113b  8b5c2428  MOV EBX,dword ptr [ESP + 0x28]
004a113f  8b742420  MOV ESI,dword ptr [ESP + 0x20]
004a1143  8a07  MOV AL,byte ptr [EDI]
004a1145  3c08  CMP AL,0x8
004a1147  7404  JZ 0x004a114d
004a1149  3c0b  CMP AL,0xb
004a114b  7507  JNZ 0x004a1154
004a114d  57  PUSH EDI
004a114e  e86dfeffff  CALL 0x004a0fc0
004a1153  59  POP ECX
004a1154  8a06  MOV AL,byte ptr [ESI]
004a1156  3c08  CMP AL,0x8
004a1158  7404  JZ 0x004a115e
004a115a  3c0b  CMP AL,0xb
004a115c  7507  JNZ 0x004a1165
004a115e  56  PUSH ESI
004a115f  e85cfeffff  CALL 0x004a0fc0
004a1164  59  POP ECX
004a1165  0fb60f  MOVZX ECX,byte ptr [EDI]
004a1168  0fb606  MOVZX EAX,byte ptr [ESI]
004a116b  6bc90b  IMUL ECX,ECX,0xb
004a116e  01c1  ADD ECX,EAX
004a1170  83f930  CMP ECX,0x30
004a1173  0f87c7060000  JA 0x004a1840
004a1179  ff248d04eb5500  JMP dword ptr [ECX*0x4 + 0x55eb04]
004a1180  c60302  MOV byte ptr [EBX],0x2
004a1183  668b4702  MOV AX,word ptr [EDI + 0x2]
004a1187  66894302  MOV word ptr [EBX + 0x2],AX
004a118b  668b4602  MOV AX,word ptr [ESI + 0x2]
004a118f  66894306  MOV word ptr [EBX + 0x6],AX
004a1193  e9b9060000  JMP 0x004a1851
004a1198  668b4f08  MOV CX,word ptr [EDI + 0x8]
004a119c  0fbf6e08  MOVSX EBP,word ptr [ESI + 0x8]
004a11a0  0fbfc1  MOVSX EAX,CX
004a11a3  01c5  ADD EBP,EAX
004a11a5  0fbfc5  MOVSX EAX,BP
004a11a8  39c5  CMP EBP,EAX
004a11aa  7524  JNZ 0x004a11d0
004a11ac  837f1200  CMP dword ptr [EDI + 0x12],0x0
004a11b0  7406  JZ 0x004a11b8
004a11b2  837e1200  CMP dword ptr [ESI + 0x12],0x0
004a11b6  7518  JNZ 0x004a11d0
004a11b8  66014e08  ADD word ptr [ESI + 0x8],CX
004a11bc  837e1200  CMP dword ptr [ESI + 0x12],0x0
004a11c0  755b  JNZ 0x004a121d
004a11c2  8b4712  MOV EAX,dword ptr [EDI + 0x12]
004a11c5  894612  MOV dword ptr [ESI + 0x12],EAX
004a11c8  eb53  JMP 0x004a121d
004a11d0  31d2  XOR EDX,EDX
004a11d2  6639542424  CMP word ptr [ESP + 0x24],DX
004a11d7  740b  JZ 0x004a11e4
004a11d9  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a11dd  663b4602  CMP AX,word ptr [ESI + 0x2]
004a11e1  7401  JZ 0x004a11e4
004a11e3  42  INC EDX
004a11e4  85d2  TEST EDX,EDX
004a11e6  7408  JZ 0x004a11f0
004a11e8  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a11ec  eb0f  JMP 0x004a11fd
004a11f0  66a16e845800  MOV AX,[0x0058846e]
004a11f6  66ff056e845800  INC word ptr [0x0058846e]
004a11fd  0fbfe8  MOVSX EBP,AX
004a1200  8b4712  MOV EAX,dword ptr [EDI + 0x12]
004a1203  668b4f08  MOV CX,word ptr [EDI + 0x8]
004a1207  668b5702  MOV DX,word ptr [EDI + 0x2]
004a120b  51  PUSH ECX
004a120c  50  PUSH EAX
004a120d  89e8  MOV EAX,EBP
004a120f  52  PUSH EDX
004a1210  50  PUSH EAX
004a1211  e84a0e0000  CALL 0x004a2060
004a1216  83c410  ADD ESP,0x10
004a1219  66896f02  MOV word ptr [EDI + 0x2],BP
004a121d  89f8  MOV EAX,EDI
004a121f  89f7  MOV EDI,ESI
004a1221  89c6  MOV ESI,EAX
004a1223  66a12a845800  MOV AX,[0x0058842a]
004a1229  668b4f02  MOV CX,word ptr [EDI + 0x2]
004a122d  6639c1  CMP CX,AX
004a1230  755e  JNZ 0x004a1290
004a1232  31ed  XOR EBP,EBP
004a1234  c60302  MOV byte ptr [EBX],0x2
004a1237  66396c2424  CMP word ptr [ESP + 0x24],BP
004a123c  740b  JZ 0x004a1249
004a123e  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a1242  663b4602  CMP AX,word ptr [ESI + 0x2]
004a1246  7401  JZ 0x004a1249
004a1248  45  INC EBP
004a1249  85ed  TEST EBP,EBP
004a124b  7406  JZ 0x004a1253
004a124d  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a1251  eb0d  JMP 0x004a1260
004a1253  66a16e845800  MOV AX,[0x0058846e]
004a1259  66ff056e845800  INC word ptr [0x0058846e]
004a1260  66894302  MOV word ptr [EBX + 0x2],AX
004a1264  668b4602  MOV AX,word ptr [ESI + 0x2]
004a1268  66894306  MOV word ptr [EBX + 0x6],AX
004a126c  8b4712  MOV EAX,dword ptr [EDI + 0x12]
004a126f  668b5708  MOV DX,word ptr [EDI + 0x8]
004a1273  668b7702  MOV SI,word ptr [EDI + 0x2]
004a1277  52  PUSH EDX
004a1278  50  PUSH EAX
004a1279  668b4302  MOV AX,word ptr [EBX + 0x2]
004a127d  56  PUSH ESI
004a127e  50  PUSH EAX
004a127f  e8dc0d0000  CALL 0x004a2060
004a1284  83c410  ADD ESP,0x10
004a1287  e9c5050000  JMP 0x004a1851
004a1290  66a12a845800  MOV AX,[0x0058842a]
004a1296  668b4e02  MOV CX,word ptr [ESI + 0x2]
004a129a  6639c1  CMP CX,AX
004a129d  7561  JNZ 0x004a1300
004a129f  31ed  XOR EBP,EBP
004a12a1  c60302  MOV byte ptr [EBX],0x2
004a12a4  66396c2424  CMP word ptr [ESP + 0x24],BP
004a12a9  740b  JZ 0x004a12b6
004a12ab  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a12af  663b4702  CMP AX,word ptr [EDI + 0x2]
004a12b3  7401  JZ 0x004a12b6
004a12b5  45  INC EBP
004a12b6  85ed  TEST EBP,EBP
004a12b8  7406  JZ 0x004a12c0
004a12ba  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a12be  eb0d  JMP 0x004a12cd
004a12c0  66a16e845800  MOV AX,[0x0058846e]
004a12c6  66ff056e845800  INC word ptr [0x0058846e]
004a12cd  66894302  MOV word ptr [EBX + 0x2],AX
004a12d1  668b4702  MOV AX,word ptr [EDI + 0x2]
004a12d5  66894306  MOV word ptr [EBX + 0x6],AX
004a12d9  8b4712  MOV EAX,dword ptr [EDI + 0x12]
004a12dc  668b5708  MOV DX,word ptr [EDI + 0x8]
004a12e0  668b7e02  MOV DI,word ptr [ESI + 0x2]
004a12e4  52  PUSH EDX
004a12e5  50  PUSH EAX
004a12e6  668b4302  MOV AX,word ptr [EBX + 0x2]
004a12ea  57  PUSH EDI
004a12eb  50  PUSH EAX
004a12ec  e86f0d0000  CALL 0x004a2060
004a12f1  83c410  ADD ESP,0x10
004a12f4  e958050000  JMP 0x004a1851
004a1300  837f1200  CMP dword ptr [EDI + 0x12],0x0
004a1304  745a  JZ 0x004a1360
004a1306  31d2  XOR EDX,EDX
004a1308  c60302  MOV byte ptr [EBX],0x2
004a130b  6639542424  CMP word ptr [ESP + 0x24],DX
004a1310  740b  JZ 0x004a131d
004a1312  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a1316  663b4602  CMP AX,word ptr [ESI + 0x2]
004a131a  7401  JZ 0x004a131d
004a131c  42  INC EDX
004a131d  85d2  TEST EDX,EDX
004a131f  7406  JZ 0x004a1327
004a1321  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a1325  eb0d  JMP 0x004a1334
004a1327  66a16e845800  MOV AX,[0x0058846e]
004a132d  66ff056e845800  INC word ptr [0x0058846e]
004a1334  66894302  MOV word ptr [EBX + 0x2],AX
004a1338  668b4602  MOV AX,word ptr [ESI + 0x2]
004a133c  66894306  MOV word ptr [EBX + 0x6],AX
004a1340  8b4712  MOV EAX,dword ptr [EDI + 0x12]
004a1343  668b6f08  MOV BP,word ptr [EDI + 0x8]
004a1347  668b4f02  MOV CX,word ptr [EDI + 0x2]
004a134b  55  PUSH EBP
004a134c  50  PUSH EAX
004a134d  668b4302  MOV AX,word ptr [EBX + 0x2]
004a1351  51  PUSH ECX
004a1352  50  PUSH EAX
004a1353  e8080d0000  CALL 0x004a2060
004a1358  83c410  ADD ESP,0x10
004a135b  e9f1040000  JMP 0x004a1851
004a1360  c60301  MOV byte ptr [EBX],0x1
004a1363  66837c242400  CMP word ptr [ESP + 0x24],0x0
004a1369  7406  JZ 0x004a1371
004a136b  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a136f  eb0d  JMP 0x004a137e
004a1371  66a16e845800  MOV AX,[0x0058846e]
004a1377  66ff056e845800  INC word ptr [0x0058846e]
004a137e  66894302  MOV word ptr [EBX + 0x2],AX
004a1382  668b4708  MOV AX,word ptr [EDI + 0x8]
004a1386  66894308  MOV word ptr [EBX + 0x8],AX
004a138a  8b4712  MOV EAX,dword ptr [EDI + 0x12]
004a138d  894312  MOV dword ptr [EBX + 0x12],EAX
004a1390  0fbf4602  MOVSX EAX,word ptr [ESI + 0x2]
004a1394  0fbf5702  MOVSX EDX,word ptr [EDI + 0x2]
004a1398  50  PUSH EAX
004a1399  0fbf4302  MOVSX EAX,word ptr [EBX + 0x2]
004a139d  52  PUSH EDX
004a139e  50  PUSH EAX
004a139f  6a3c  PUSH 0x3c
004a13a1  e82a120000  CALL 0x004a25d0
004a13a6  83c410  ADD ESP,0x10
004a13a9  e9a3040000  JMP 0x004a1851
004a13b0  89f8  MOV EAX,EDI
004a13b2  89f7  MOV EDI,ESI
004a13b4  89c6  MOV ESI,EAX
004a13b6  c60302  MOV byte ptr [EBX],0x2
004a13b9  31ed  XOR EBP,EBP
004a13bb  668b4702  MOV AX,word ptr [EDI + 0x2]
004a13bf  66894302  MOV word ptr [EBX + 0x2],AX
004a13c3  66396c2424  CMP word ptr [ESP + 0x24],BP
004a13c8  740b  JZ 0x004a13d5
004a13ca  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a13ce  663b4702  CMP AX,word ptr [EDI + 0x2]
004a13d2  7401  JZ 0x004a13d5
004a13d4  45  INC EBP
004a13d5  85ed  TEST EBP,EBP
004a13d7  7407  JZ 0x004a13e0
004a13d9  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a13dd  eb0e  JMP 0x004a13ed
004a13e0  66a16e845800  MOV AX,[0x0058846e]
004a13e6  66ff056e845800  INC word ptr [0x0058846e]
004a13ed  66894306  MOV word ptr [EBX + 0x6],AX
004a13f1  0fbf4602  MOVSX EAX,word ptr [ESI + 0x2]
004a13f5  0fbf7706  MOVSX ESI,word ptr [EDI + 0x6]
004a13f9  50  PUSH EAX
004a13fa  0fbf4306  MOVSX EAX,word ptr [EBX + 0x6]
004a13fe  56  PUSH ESI
004a13ff  50  PUSH EAX
004a1400  6a3c  PUSH 0x3c
004a1402  e8c9110000  CALL 0x004a25d0
004a1407  83c410  ADD ESP,0x10
004a140a  e942040000  JMP 0x004a1851
004a1410  89f8  MOV EAX,EDI
004a1412  89f7  MOV EDI,ESI
004a1414  89c6  MOV ESI,EAX
004a1416  837e1200  CMP dword ptr [ESI + 0x12],0x0
004a141a  0f8480000000  JZ 0x004a14a0
004a1420  31d2  XOR EDX,EDX
004a1422  c60302  MOV byte ptr [EBX],0x2
004a1425  6639542424  CMP word ptr [ESP + 0x24],DX
004a142a  740b  JZ 0x004a1437
004a142c  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a1430  663b4602  CMP AX,word ptr [ESI + 0x2]
004a1434  7401  JZ 0x004a1437
004a1436  42  INC EDX
004a1437  85d2  TEST EDX,EDX
004a1439  7406  JZ 0x004a1441
004a143b  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a143f  eb0d  JMP 0x004a144e
004a1441  66a16e845800  MOV AX,[0x0058846e]
004a1447  66ff056e845800  INC word ptr [0x0058846e]
004a144e  66894302  MOV word ptr [EBX + 0x2],AX
004a1452  66a16e845800  MOV AX,[0x0058846e]
004a1458  66894306  MOV word ptr [EBX + 0x6],AX
004a145c  66ff056e845800  INC word ptr [0x0058846e]
004a1463  0fbf4706  MOVSX EAX,word ptr [EDI + 0x6]
004a1467  0fbf6f02  MOVSX EBP,word ptr [EDI + 0x2]
004a146b  50  PUSH EAX
004a146c  0fbf4302  MOVSX EAX,word ptr [EBX + 0x2]
004a1470  55  PUSH EBP
004a1471  50  PUSH EAX
004a1472  6a3c  PUSH 0x3c
004a1474  e857110000  CALL 0x004a25d0
004a1479  8b4612  MOV EAX,dword ptr [ESI + 0x12]
004a147c  83c410  ADD ESP,0x10
004a147f  668b7e08  MOV DI,word ptr [ESI + 0x8]
004a1483  668b4e02  MOV CX,word ptr [ESI + 0x2]
004a1487  57  PUSH EDI
004a1488  50  PUSH EAX
004a1489  668b4306  MOV AX,word ptr [EBX + 0x6]
004a148d  51  PUSH ECX
004a148e  50  PUSH EAX
004a148f  e8cc0b0000  CALL 0x004a2060
004a1494  83c410  ADD ESP,0x10
004a1497  e9b5030000  JMP 0x004a1851
004a14a0  c60301  MOV byte ptr [EBX],0x1
004a14a3  31ed  XOR EBP,EBP
004a14a5  668b4608  MOV AX,word ptr [ESI + 0x8]
004a14a9  66894308  MOV word ptr [EBX + 0x8],AX
004a14ad  8b4612  MOV EAX,dword ptr [ESI + 0x12]
004a14b0  894312  MOV dword ptr [EBX + 0x12],EAX
004a14b3  66396c2424  CMP word ptr [ESP + 0x24],BP
004a14b8  740b  JZ 0x004a14c5
004a14ba  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a14be  663b4602  CMP AX,word ptr [ESI + 0x2]
004a14c2  7401  JZ 0x004a14c5
004a14c4  45  INC EBP
004a14c5  85ed  TEST EBP,EBP
004a14c7  7407  JZ 0x004a14d0
004a14c9  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a14cd  eb0e  JMP 0x004a14dd
004a14d0  66a16e845800  MOV AX,[0x0058846e]
004a14d6  66ff056e845800  INC word ptr [0x0058846e]
004a14dd  66894302  MOV word ptr [EBX + 0x2],AX
004a14e1  0fbf4706  MOVSX EAX,word ptr [EDI + 0x6]
004a14e5  0fbf5702  MOVSX EDX,word ptr [EDI + 0x2]
004a14e9  50  PUSH EAX
004a14ea  0fbf4302  MOVSX EAX,word ptr [EBX + 0x2]
004a14ee  52  PUSH EDX
004a14ef  50  PUSH EAX
004a14f0  6a3c  PUSH 0x3c
004a14f2  e8d9100000  CALL 0x004a25d0
004a14f7  0fbf4602  MOVSX EAX,word ptr [ESI + 0x2]
004a14fb  83c410  ADD ESP,0x10
004a14fe  50  PUSH EAX
004a14ff  0fbf4302  MOVSX EAX,word ptr [EBX + 0x2]
004a1503  50  PUSH EAX
004a1504  50  PUSH EAX
004a1505  6a3c  PUSH 0x3c
004a1507  e8c4100000  CALL 0x004a25d0
004a150c  83c410  ADD ESP,0x10
004a150f  e93d030000  JMP 0x004a1851
004a1514  c60302  MOV byte ptr [EBX],0x2
004a1517  31c9  XOR ECX,ECX
004a1519  668b4702  MOV AX,word ptr [EDI + 0x2]
004a151d  66894302  MOV word ptr [EBX + 0x2],AX
004a1521  66394c2424  CMP word ptr [ESP + 0x24],CX
004a1526  740b  JZ 0x004a1533
004a1528  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a152c  663b4706  CMP AX,word ptr [EDI + 0x6]
004a1530  7401  JZ 0x004a1533
004a1532  41  INC ECX
004a1533  85c9  TEST ECX,ECX
004a1535  7409  JZ 0x004a1540
004a1537  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a153b  eb10  JMP 0x004a154d
004a1540  66a16e845800  MOV AX,[0x0058846e]
004a1546  66ff056e845800  INC word ptr [0x0058846e]
004a154d  66894306  MOV word ptr [EBX + 0x6],AX
004a1551  0fbf4606  MOVSX EAX,word ptr [ESI + 0x6]
004a1555  0fbf6e02  MOVSX EBP,word ptr [ESI + 0x2]
004a1559  50  PUSH EAX
004a155a  0fbf4306  MOVSX EAX,word ptr [EBX + 0x6]
004a155e  55  PUSH EBP
004a155f  50  PUSH EAX
004a1560  6a3c  PUSH 0x3c
004a1562  e869100000  CALL 0x004a25d0
004a1567  0fbf4706  MOVSX EAX,word ptr [EDI + 0x6]
004a156b  83c410  ADD ESP,0x10
004a156e  50  PUSH EAX
004a156f  0fbf4306  MOVSX EAX,word ptr [EBX + 0x6]
004a1573  50  PUSH EAX
004a1574  50  PUSH EAX
004a1575  6a3c  PUSH 0x3c
004a1577  e854100000  CALL 0x004a25d0
004a157c  83c410  ADD ESP,0x10
004a157f  e9cd020000  JMP 0x004a1851
004a1584  89f8  MOV EAX,EDI
004a1586  89f7  MOV EDI,ESI
004a1588  89c6  MOV ESI,EAX
004a158a  8b4612  MOV EAX,dword ptr [ESI + 0x12]
004a158d  85c0  TEST EAX,EAX
004a158f  0f85db000000  JNZ 0x004a1670
004a1595  c60301  MOV byte ptr [EBX],0x1
004a1598  668b4602  MOV AX,word ptr [ESI + 0x2]
004a159c  66894302  MOV word ptr [EBX + 0x2],AX
004a15a0  668b4608  MOV AX,word ptr [ESI + 0x8]
004a15a4  66894308  MOV word ptr [EBX + 0x8],AX
004a15a8  8b4612  MOV EAX,dword ptr [ESI + 0x12]
004a15ab  894312  MOV dword ptr [EBX + 0x12],EAX
004a15ae  0fbf5308  MOVSX EDX,word ptr [EBX + 0x8]
004a15b2  8b4f0e  MOV ECX,dword ptr [EDI + 0xe]
004a15b5  01ca  ADD EDX,ECX
004a15b7  0fbfc2  MOVSX EAX,DX
004a15ba  39c2  CMP EDX,EAX
004a15bc  7509  JNZ 0x004a15c7
004a15be  66014b08  ADD word ptr [EBX + 0x8],CX
004a15c2  e98a020000  JMP 0x004a1851
004a15c7  66837c242400  CMP word ptr [ESP + 0x24],0x0
004a15cd  7406  JZ 0x004a15d5
004a15cf  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a15d3  eb0d  JMP 0x004a15e2
004a15d5  66a16e845800  MOV AX,[0x0058846e]
004a15db  66ff056e845800  INC word ptr [0x0058846e]
004a15e2  66894302  MOV word ptr [EBX + 0x2],AX
004a15e6  8b6f0e  MOV EBP,dword ptr [EDI + 0xe]
004a15e9  89ea  MOV EDX,EBP
004a15eb  89e8  MOV EAX,EBP
004a15ed  c1fa0f  SAR EDX,0xf
004a15f0  c1f810  SAR EAX,0x10
004a15f3  81e201000000  AND EDX,0x1
004a15f9  01c2  ADD EDX,EAX
004a15fb  6685d2  TEST DX,DX
004a15fe  7520  JNZ 0x004a1620
004a1600  0fbfc5  MOVSX EAX,BP
004a1603  0fbf7e02  MOVSX EDI,word ptr [ESI + 0x2]
004a1607  50  PUSH EAX
004a1608  0fbf4302  MOVSX EAX,word ptr [EBX + 0x2]
004a160c  6a00  PUSH 0x0
004a160e  57  PUSH EDI
004a160f  50  PUSH EAX
004a1610  6a3f  PUSH 0x3f
004a1612  e8b90f0000  CALL 0x004a25d0
004a1617  83c414  ADD ESP,0x14
004a161a  e932020000  JMP 0x004a1851
004a1620  0fbfc2  MOVSX EAX,DX
004a1623  0fbf7602  MOVSX ESI,word ptr [ESI + 0x2]
004a1627  50  PUSH EAX
004a1628  0fbf4302  MOVSX EAX,word ptr [EBX + 0x2]
004a162c  6a00  PUSH 0x0
004a162e  56  PUSH ESI
004a162f  50  PUSH EAX
004a1630  6a42  PUSH 0x42
004a1632  e8990f0000  CALL 0x004a25d0
004a1637  8b6f0e  MOV EBP,dword ptr [EDI + 0xe]
004a163a  83c414  ADD ESP,0x14
004a163d  0fbffd  MOVSX EDI,BP
004a1640  0fbf4b08  MOVSX ECX,word ptr [EBX + 0x8]
004a1644  01f9  ADD ECX,EDI
004a1646  0fbfc1  MOVSX EAX,CX
004a1649  39c1  CMP ECX,EAX
004a164b  7509  JNZ 0x004a1656
004a164d  66016b08  ADD word ptr [EBX + 0x8],BP
004a1651  e9fb010000  JMP 0x004a1851
004a1656  0fbf4302  MOVSX EAX,word ptr [EBX + 0x2]
004a165a  57  PUSH EDI
004a165b  6a00  PUSH 0x0
004a165d  50  PUSH EAX
004a165e  50  PUSH EAX
004a165f  6a3f  PUSH 0x3f
004a1661  e86a0f0000  CALL 0x004a25d0
004a1666  83c414  ADD ESP,0x14
004a1669  e9e3010000  JMP 0x004a1851
004a1670  80780201  CMP byte ptr [EAX + 0x2],0x1
004a1674  7522  JNZ 0x004a1698
004a1676  c60301  MOV byte ptr [EBX],0x1
004a1679  8b4612  MOV EAX,dword ptr [ESI + 0x12]
004a167c  894312  MOV dword ptr [EBX + 0x12],EAX
004a167f  668b4602  MOV AX,word ptr [ESI + 0x2]
004a1683  66894302  MOV word ptr [EBX + 0x2],AX
004a1687  668b4608  MOV AX,word ptr [ESI + 0x8]
004a168b  6603470e  ADD AX,word ptr [EDI + 0xe]
004a168f  66894308  MOV word ptr [EBX + 0x8],AX
004a1693  e9b9010000  JMP 0x004a1851
004a1698  66837c242400  CMP word ptr [ESP + 0x24],0x0
004a169e  7406  JZ 0x004a16a6
004a16a0  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a16a4  eb0d  JMP 0x004a16b3
004a16a6  66a16e845800  MOV AX,[0x0058846e]
004a16ac  66ff056e845800  INC word ptr [0x0058846e]
004a16b3  66894302  MOV word ptr [EBX + 0x2],AX
004a16b7  8b4612  MOV EAX,dword ptr [ESI + 0x12]
004a16ba  668b4e08  MOV CX,word ptr [ESI + 0x8]
004a16be  668b5602  MOV DX,word ptr [ESI + 0x2]
004a16c2  51  PUSH ECX
004a16c3  50  PUSH EAX
004a16c4  668b4302  MOV AX,word ptr [EBX + 0x2]
004a16c8  52  PUSH EDX
004a16c9  50  PUSH EAX
004a16ca  e891090000  CALL 0x004a2060
004a16cf  c60600  MOV byte ptr [ESI],0x0
004a16d2  83c410  ADD ESP,0x10
004a16d5  668b4302  MOV AX,word ptr [EBX + 0x2]
004a16d9  66894602  MOV word ptr [ESI + 0x2],AX
004a16dd  89f8  MOV EAX,EDI
004a16df  89f7  MOV EDI,ESI
004a16e1  89c6  MOV ESI,EAX
004a16e3  89f8  MOV EAX,EDI
004a16e5  89f7  MOV EDI,ESI
004a16e7  89c6  MOV ESI,EAX
004a16e9  66837f0e00  CMP word ptr [EDI + 0xe],0x0
004a16ee  7404  JZ 0x004a16f4
004a16f0  b001  MOV AL,0x1
004a16f2  eb02  JMP 0x004a16f6
004a16f4  30c0  XOR AL,AL
004a16f6  8803  MOV byte ptr [EBX],AL
004a16f8  668b470e  MOV AX,word ptr [EDI + 0xe]
004a16fc  66894308  MOV word ptr [EBX + 0x8],AX
004a1700  c7431200000000  MOV dword ptr [EBX + 0x12],0x0
004a1707  8b570e  MOV EDX,dword ptr [EDI + 0xe]
004a170a  0fbfc2  MOVSX EAX,DX
004a170d  39c2  CMP EDX,EAX
004a170f  750f  JNZ 0x004a1720
004a1711  668b4602  MOV AX,word ptr [ESI + 0x2]
004a1715  66894302  MOV word ptr [EBX + 0x2],AX
004a1719  e933010000  JMP 0x004a1851
004a1720  66837c242400  CMP word ptr [ESP + 0x24],0x0
004a1726  7408  JZ 0x004a1730
004a1728  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a172c  eb0f  JMP 0x004a173d
004a1730  66a16e845800  MOV AX,[0x0058846e]
004a1736  66ff056e845800  INC word ptr [0x0058846e]
004a173d  66894302  MOV word ptr [EBX + 0x2],AX
004a1741  8b4f0e  MOV ECX,dword ptr [EDI + 0xe]
004a1744  89cd  MOV EBP,ECX
004a1746  c1f910  SAR ECX,0x10
004a1749  c1fd0f  SAR EBP,0xf
004a174c  81e501000000  AND EBP,0x1
004a1752  01cd  ADD EBP,ECX
004a1754  0fbfc5  MOVSX EAX,BP
004a1757  0fbf7e02  MOVSX EDI,word ptr [ESI + 0x2]
004a175b  50  PUSH EAX
004a175c  0fbf4302  MOVSX EAX,word ptr [EBX + 0x2]
004a1760  6a00  PUSH 0x0
004a1762  57  PUSH EDI
004a1763  50  PUSH EAX
004a1764  6a42  PUSH 0x42
004a1766  e8650e0000  CALL 0x004a25d0
004a176b  83c414  ADD ESP,0x14
004a176e  e9de000000  JMP 0x004a1851
004a1773  89f8  MOV EAX,EDI
004a1775  89f7  MOV EDI,ESI
004a1777  89c6  MOV ESI,EAX
004a1779  c60302  MOV byte ptr [EBX],0x2
004a177c  31d2  XOR EDX,EDX
004a177e  668b4602  MOV AX,word ptr [ESI + 0x2]
004a1782  66894302  MOV word ptr [EBX + 0x2],AX
004a1786  6639542424  CMP word ptr [ESP + 0x24],DX
004a178b  740b  JZ 0x004a1798
004a178d  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a1791  663b4602  CMP AX,word ptr [ESI + 0x2]
004a1795  7401  JZ 0x004a1798
004a1797  42  INC EDX
004a1798  85d2  TEST EDX,EDX
004a179a  7406  JZ 0x004a17a2
004a179c  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004a17a0  eb0d  JMP 0x004a17af
004a17a2  66a16e845800  MOV AX,[0x0058846e]
004a17a8  66ff056e845800  INC word ptr [0x0058846e]
004a17af  66894306  MOV word ptr [EBX + 0x6],AX
004a17b3  8b4f0e  MOV ECX,dword ptr [EDI + 0xe]
004a17b6  89cd  MOV EBP,ECX
004a17b8  89c8  MOV EAX,ECX
004a17ba  c1fd0f  SAR EBP,0xf
004a17bd  c1f810  SAR EAX,0x10
004a17c0  81e501000000  AND EBP,0x1
004a17c6  01c5  ADD EBP,EAX
004a17c8  6685ed  TEST BP,BP
004a17cb  7523  JNZ 0x004a17f0
004a17cd  0fbfc1  MOVSX EAX,CX
004a17d0  0fbf7606  MOVSX ESI,word ptr [ESI + 0x6]
004a17d4  50  PUSH EAX
004a17d5  0fbf4306  MOVSX EAX,word ptr [EBX + 0x6]
004a17d9  6a00  PUSH 0x0
004a17db  56  PUSH ESI
004a17dc  50  PUSH EAX
004a17dd  6a3f  PUSH 0x3f
004a17df  e8ec0d0000  CALL 0x004a25d0
004a17e4  83c414  ADD ESP,0x14
004a17e7  eb68  JMP 0x004a1851
004a17f0  0fbfc5  MOVSX EAX,BP
004a17f3  0fbf5606  MOVSX EDX,word ptr [ESI + 0x6]
004a17f7  50  PUSH EAX
004a17f8  0fbf4306  MOVSX EAX,word ptr [EBX + 0x6]
004a17fc  6a00  PUSH 0x0
004a17fe  52  PUSH EDX
004a17ff  50  PUSH EAX
004a1800  6a42  PUSH 0x42
004a1802  e8c90d0000  CALL 0x004a25d0
004a1807  8b7f0e  MOV EDI,dword ptr [EDI + 0xe]
004a180a  83c414  ADD ESP,0x14
004a180d  6685ff  TEST DI,DI
004a1810  743f  JZ 0x004a1851
004a1812  0fbfc7  MOVSX EAX,DI
004a1815  50  PUSH EAX
004a1816  0fbf4306  MOVSX EAX,word ptr [EBX + 0x6]
004a181a  6a00  PUSH 0x0
004a181c  50  PUSH EAX
004a181d  50  PUSH EAX
004a181e  6a3f  PUSH 0x3f
004a1820  e8ab0d0000  CALL 0x004a25d0
004a1825  83c414  ADD ESP,0x14
004a1828  eb27  JMP 0x004a1851
004a1830  c60304  MOV byte ptr [EBX],0x4
004a1833  8b470e  MOV EAX,dword ptr [EDI + 0xe]
004a1836  03460e  ADD EAX,dword ptr [ESI + 0xe]
004a1839  89430e  MOV dword ptr [EBX + 0xe],EAX
004a183c  eb13  JMP 0x004a1851
004a1840  686a010000  PUSH 0x16a
004a1845  68f8e95500  PUSH 0x55e9f8
004a184a  e8313ffaff  CALL 0x00445780
004a184f  59  POP ECX
004a1850  59  POP ECX
004a1851  83c408  ADD ESP,0x8
004a1854  5d  POP EBP
004a1855  5f  POP EDI
004a1856  5e  POP ESI
004a1857  5b  POP EBX
004a1858  c3  RET
```

```c

void __cdecl FUN_004a1130(byte *param_1,byte *param_2,short param_3,undefined1 *param_4)

{
  bool bVar1;
  short sVar2;
  byte *pbVar3;
  short sVar4;
  int iVar5;
  byte *pbVar6;
  
  if ((*param_1 == 8) || (*param_1 == 0xb)) {
    FUN_004a0fc0((char *)param_1);
  }
  if ((*param_2 == 8) || (*param_2 == 0xb)) {
    FUN_004a0fc0((char *)param_2);
  }
  sVar2 = DAT_0058846e;
  pbVar6 = param_2;
  pbVar3 = param_1;
  switch((uint)*param_1 * 0xb + (uint)*param_2) {
  case 0:
    *param_4 = 2;
    *(undefined2 *)(param_4 + 2) = *(undefined2 *)(param_1 + 2);
    *(undefined2 *)(param_4 + 6) = *(undefined2 *)(param_2 + 2);
    break;
  case 2:
    param_1 = param_2;
  case 0x16:
    *param_4 = 2;
    bVar1 = false;
    *(undefined2 *)(param_4 + 2) = *(undefined2 *)(param_1 + 2);
    sVar2 = DAT_0058846e;
    if ((param_3 != 0) && (param_3 != *(short *)(param_1 + 2))) {
      bVar1 = true;
    }
    if (!bVar1) {
      DAT_0058846e = DAT_0058846e + 1;
      param_3 = sVar2;
    }
    *(short *)(param_4 + 6) = param_3;
    FUN_004a25d0(0x3c);
    break;
  default:
    FUN_00445780();
    break;
  case 4:
    goto switchD_004a1179_caseD_4;
  case 0xc:
    iVar5 = (int)*(short *)(param_2 + 8) + (int)*(short *)(param_1 + 8);
    if ((iVar5 == (short)iVar5) &&
       ((*(int *)(param_1 + 0x12) == 0 || (*(int *)(param_2 + 0x12) == 0)))) {
      *(short *)(param_2 + 8) = *(short *)(param_2 + 8) + *(short *)(param_1 + 8);
      if (*(int *)(param_2 + 0x12) == 0) {
        *(undefined4 *)(param_2 + 0x12) = *(undefined4 *)(param_1 + 0x12);
      }
    }
    else {
      bVar1 = false;
      if ((param_3 != 0) && (param_3 != *(short *)(param_2 + 2))) {
        bVar1 = true;
      }
      sVar4 = param_3;
      if (!bVar1) {
        DAT_0058846e = DAT_0058846e + 1;
        sVar4 = sVar2;
      }
      FUN_004a2060((int)sVar4,*(short *)(param_1 + 2),*(int *)(param_1 + 0x12),
                   *(short *)(param_1 + 8));
      *(short *)(param_1 + 2) = sVar4;
    }
  case 1:
    pbVar6 = param_1;
    param_1 = param_2;
  case 0xb:
    if (*(short *)(param_1 + 2) == DAT_0058842a) {
      bVar1 = false;
      *param_4 = 2;
      sVar2 = DAT_0058846e;
      if ((param_3 != 0) && (param_3 != *(short *)(pbVar6 + 2))) {
        bVar1 = true;
      }
      if (!bVar1) {
        DAT_0058846e = DAT_0058846e + 1;
        param_3 = sVar2;
      }
      *(short *)(param_4 + 2) = param_3;
      *(undefined2 *)(param_4 + 6) = *(undefined2 *)(pbVar6 + 2);
      FUN_004a2060(CONCAT22((short)((uint)*(int *)(param_1 + 0x12) >> 0x10),
                            *(undefined2 *)(param_4 + 2)),*(short *)(param_1 + 2),
                   *(int *)(param_1 + 0x12),*(short *)(param_1 + 8));
    }
    else if (*(short *)(pbVar6 + 2) == DAT_0058842a) {
      bVar1 = false;
      *param_4 = 2;
      sVar2 = DAT_0058846e;
      if ((param_3 != 0) && (param_3 != *(short *)(param_1 + 2))) {
        bVar1 = true;
      }
      if (!bVar1) {
        DAT_0058846e = DAT_0058846e + 1;
        param_3 = sVar2;
      }
      *(short *)(param_4 + 2) = param_3;
      *(undefined2 *)(param_4 + 6) = *(undefined2 *)(param_1 + 2);
      FUN_004a2060(CONCAT22((short)((uint)*(int *)(param_1 + 0x12) >> 0x10),
                            *(undefined2 *)(param_4 + 2)),*(short *)(pbVar6 + 2),
                   *(int *)(param_1 + 0x12),*(short *)(param_1 + 8));
    }
    else if (*(int *)(param_1 + 0x12) == 0) {
      *param_4 = 1;
      sVar2 = DAT_0058846e;
      if (param_3 == 0) {
        DAT_0058846e = DAT_0058846e + 1;
        param_3 = sVar2;
      }
      *(short *)(param_4 + 2) = param_3;
      *(undefined2 *)(param_4 + 8) = *(undefined2 *)(param_1 + 8);
      *(undefined4 *)(param_4 + 0x12) = *(undefined4 *)(param_1 + 0x12);
      FUN_004a25d0(0x3c);
    }
    else {
      bVar1 = false;
      *param_4 = 2;
      sVar2 = DAT_0058846e;
      if ((param_3 != 0) && (param_3 != *(short *)(pbVar6 + 2))) {
        bVar1 = true;
      }
      if (!bVar1) {
        DAT_0058846e = DAT_0058846e + 1;
        param_3 = sVar2;
      }
      *(short *)(param_4 + 2) = param_3;
      *(undefined2 *)(param_4 + 6) = *(undefined2 *)(pbVar6 + 2);
      FUN_004a2060(CONCAT22((short)((uint)*(int *)(param_1 + 0x12) >> 0x10),
                            *(undefined2 *)(param_4 + 2)),*(short *)(param_1 + 2),
                   *(int *)(param_1 + 0x12),*(short *)(param_1 + 8));
    }
    break;
  case 0xd:
    param_2 = param_1;
  case 0x17:
    if (*(int *)(param_2 + 0x12) == 0) {
      *param_4 = 1;
      bVar1 = false;
      *(undefined2 *)(param_4 + 8) = *(undefined2 *)(param_2 + 8);
      *(undefined4 *)(param_4 + 0x12) = *(undefined4 *)(param_2 + 0x12);
      sVar2 = DAT_0058846e;
      if ((param_3 != 0) && (param_3 != *(short *)(param_2 + 2))) {
        bVar1 = true;
      }
      if (!bVar1) {
        DAT_0058846e = DAT_0058846e + 1;
        param_3 = sVar2;
      }
      *(short *)(param_4 + 2) = param_3;
      FUN_004a25d0(0x3c);
      FUN_004a25d0(0x3c);
    }
    else {
      bVar1 = false;
      *param_4 = 2;
      sVar2 = DAT_0058846e;
      if ((param_3 != 0) && (param_3 != *(short *)(param_2 + 2))) {
        bVar1 = true;
      }
      if (!bVar1) {
        DAT_0058846e = DAT_0058846e + 1;
        param_3 = sVar2;
      }
      *(short *)(param_4 + 2) = param_3;
      *(short *)(param_4 + 6) = DAT_0058846e;
      DAT_0058846e = DAT_0058846e + 1;
      FUN_004a25d0(0x3c);
      FUN_004a2060(CONCAT22((short)((uint)*(int *)(param_2 + 0x12) >> 0x10),
                            *(undefined2 *)(param_4 + 6)),*(short *)(param_2 + 2),
                   *(int *)(param_2 + 0x12),*(short *)(param_2 + 8));
    }
    break;
  case 0xf:
    pbVar6 = param_1;
    pbVar3 = param_2;
  case 0x2d:
    param_2 = pbVar3;
    if (*(int *)(pbVar6 + 0x12) == 0) {
      *param_4 = 1;
      *(undefined2 *)(param_4 + 2) = *(undefined2 *)(pbVar6 + 2);
      *(undefined2 *)(param_4 + 8) = *(undefined2 *)(pbVar6 + 8);
      *(undefined4 *)(param_4 + 0x12) = *(undefined4 *)(pbVar6 + 0x12);
      sVar2 = DAT_0058846e;
      iVar5 = (int)*(short *)(param_4 + 8) + *(int *)(param_2 + 0xe);
      if (iVar5 == (short)iVar5) {
        *(short *)(param_4 + 8) = *(short *)(param_4 + 8) + (short)*(int *)(param_2 + 0xe);
      }
      else {
        if (param_3 == 0) {
          DAT_0058846e = DAT_0058846e + 1;
          param_3 = sVar2;
        }
        *(short *)(param_4 + 2) = param_3;
        if ((ushort)(((ushort)(*(int *)(param_2 + 0xe) >> 0xf) & 1) +
                    (short)((uint)*(int *)(param_2 + 0xe) >> 0x10)) == 0) {
          FUN_004a25d0(0x3f);
        }
        else {
          FUN_004a25d0(0x42);
          iVar5 = (int)*(short *)(param_4 + 8) + (int)(short)*(undefined4 *)(param_2 + 0xe);
          if (iVar5 == (short)iVar5) {
            *(short *)(param_4 + 8) =
                 *(short *)(param_4 + 8) + (short)*(undefined4 *)(param_2 + 0xe);
          }
          else {
            FUN_004a25d0(0x3f);
          }
        }
      }
    }
    else {
      if (*(char *)(*(int *)(pbVar6 + 0x12) + 2) != '\x01') {
        sVar4 = param_3;
        if (param_3 == 0) {
          DAT_0058846e = DAT_0058846e + 1;
          sVar4 = sVar2;
        }
        *(short *)(param_4 + 2) = sVar4;
        FUN_004a2060(CONCAT22((short)((uint)*(int *)(pbVar6 + 0x12) >> 0x10),
                              *(undefined2 *)(param_4 + 2)),*(short *)(pbVar6 + 2),
                     *(int *)(pbVar6 + 0x12),*(short *)(pbVar6 + 8));
        *pbVar6 = 0;
        *(undefined2 *)(pbVar6 + 2) = *(undefined2 *)(param_4 + 2);
        param_1 = pbVar6;
switchD_004a1179_caseD_4:
        pbVar6 = param_1;
        param_1 = param_2;
        goto switchD_004a1179_caseD_2c;
      }
      *param_4 = 1;
      *(undefined4 *)(param_4 + 0x12) = *(undefined4 *)(pbVar6 + 0x12);
      *(undefined2 *)(param_4 + 2) = *(undefined2 *)(pbVar6 + 2);
      *(short *)(param_4 + 8) = *(short *)(pbVar6 + 8) + *(short *)(param_2 + 0xe);
    }
    break;
  case 0x18:
    *param_4 = 2;
    bVar1 = false;
    *(undefined2 *)(param_4 + 2) = *(undefined2 *)(param_1 + 2);
    sVar2 = DAT_0058846e;
    if ((param_3 != 0) && (param_3 != *(short *)(param_1 + 6))) {
      bVar1 = true;
    }
    if (!bVar1) {
      DAT_0058846e = DAT_0058846e + 1;
      param_3 = sVar2;
    }
    *(short *)(param_4 + 6) = param_3;
    FUN_004a25d0(0x3c);
    FUN_004a25d0(0x3c);
    break;
  case 0x1a:
    pbVar6 = param_1;
    param_1 = param_2;
  case 0x2e:
    *param_4 = 2;
    bVar1 = false;
    *(undefined2 *)(param_4 + 2) = *(undefined2 *)(pbVar6 + 2);
    sVar2 = DAT_0058846e;
    if ((param_3 != 0) && (param_3 != *(short *)(pbVar6 + 2))) {
      bVar1 = true;
    }
    if (!bVar1) {
      DAT_0058846e = DAT_0058846e + 1;
      param_3 = sVar2;
    }
    *(short *)(param_4 + 6) = param_3;
    if ((ushort)(((ushort)(*(int *)(param_1 + 0xe) >> 0xf) & 1) +
                (short)((uint)*(int *)(param_1 + 0xe) >> 0x10)) == 0) {
      FUN_004a25d0(0x3f);
    }
    else {
      FUN_004a25d0(0x42);
      if ((short)*(undefined4 *)(param_1 + 0xe) != 0) {
        FUN_004a25d0(0x3f);
      }
    }
    break;
  case 0x2c:
switchD_004a1179_caseD_2c:
    *param_4 = *(short *)(param_1 + 0xe) != 0;
    *(undefined2 *)(param_4 + 8) = *(undefined2 *)(param_1 + 0xe);
    *(undefined4 *)(param_4 + 0x12) = 0;
    sVar2 = DAT_0058846e;
    if (*(int *)(param_1 + 0xe) == (int)(short)*(int *)(param_1 + 0xe)) {
      *(undefined2 *)(param_4 + 2) = *(undefined2 *)(pbVar6 + 2);
    }
    else {
      if (param_3 == 0) {
        DAT_0058846e = DAT_0058846e + 1;
        param_3 = sVar2;
      }
      *(short *)(param_4 + 2) = param_3;
      FUN_004a25d0(0x42);
    }
    break;
  case 0x30:
    *param_4 = 4;
    *(int *)(param_4 + 0xe) = *(int *)(param_1 + 0xe) + *(int *)(param_2 + 0xe);
  }
  return;
}


```


from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-index-reuse');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
assert part.count(expr)==2
vs={}

correct=part.replace(expr,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
first='                    pixel = src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row];\n'
idx='                    chroma_index = (chroma_x & 2) * 4;\n                    chroma_index = (chroma_x & 1) + chroma_index;\n'
for early in ('low','high'):
 for reused in (False,True):
  term='(chroma_x & 1)' if early=='low' else '(chroma_x & 2) * 4'
  other='(chroma_x & 2) * 4' if early=='low' else '(chroma_x & 1)'
  t=correct.replace(idx,'                    chroma_index += '+other+';\n')
  t=t.replace(first,'                    chroma_index = '+term+';\n'+first,1)
  if reused:
   t=t.replace('pixel = src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]', 'pixel = src[(chroma_index * 2 + (chroma_x & 2) * 4) + src_row]' if early=='low' else 'pixel = src[((chroma_x & 1) * 2 + chroma_index) + src_row]',1)
  vs[early+'-'+str(reused)]=t
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['classification'].get('structural_truth_gate')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

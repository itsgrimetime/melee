from pathlib import Path
import json,hashlib,tarfile,subprocess
out=Path('docs/matching-evidence/jpeg-rgb/2026-09-06-creation-provenance');out.mkdir(parents=True,exist_ok=True)
families=['combine-rule','low-sharing','high-sharing-fixed','destination-owner','pixel-type','index-reuse','destination-combine','local-scope']
inputs=[];candidates=[]
for family in families:
 p=Path('/tmp/c016-rgb-'+family)
 for f in p.rglob('*'):
  if f.is_file():inputs.append((f,str(f.relative_to('/tmp'))))
 script=Path(str(p)+'.py');inputs.append((script,script.name))
 for r in json.loads((p/'results.json').read_text()):
  excluded=family=='low-sharing' and r['name'].split('-')[-1] in ('high','both')
  candidates.append({'source':p.name+'/'+r['name']+'.c','percent':r['score'],'frame':r['frame'],'valid_intended_transform':not excluded,'exclusion_reason':'High-term replacement missed uses; unused declaration is not intended high-sharing evidence.' if excluded else None})
for name in ['creation','creation2','creation3','combine-capture','corrected-capture','corrected-stages']:
 p=Path('/tmp/c016-rgb-'+name)
 for f in p.rglob('*'):
  if f.is_file():inputs.append((f,str(f.relative_to('/tmp'))))
for name in ['creation-hook.py','creation-focused-hook.py','combine-capture-hook.py','corrected-capture.py','stages-hook.py','corrected-stages.py','lowering-functions.md','lowering-export.log','creation-pattern.json','creation-issue1515.txt','creation-doctor.log','creation-restored.json','creation-restored.log','creation-build.log','creation-tu-report.json','creation-checksums.json']:
 f=Path('/tmp/c016-rgb-'+name);assert f.is_file(),f;inputs.append((f,f.name))
toolroot=Path('/Users/mike/code/mwcc-decomp')
for name in ['tools/gdb/allocator_snapshot.py','tools/allocator_snapshot.py','tools/stack_frame_trace.py','tools/allocator_provenance.py','tools/explain_register.py','tools/vreg_map.py','tools/compare_pcode_stages.py','config/GC_1_2_5n/virtual_register_sites.json','config/GC_1_2_5/virtual_register_sites.json','src/backend/Operands.c']:
 f=toolroot/name;assert f.is_file(),f;inputs.append((f,'tool-inputs/mwcc-decomp/'+name))
inputs.append((Path('/tmp/c016-rgb-archive-creation.py'),'archive-creation.py'))
manifest={'function':'hsd_803B3408','scratch':None,'module':'sysdolphin/baselib','source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'source_sha256':hashlib.sha256(Path('src/sysdolphin/baselib/hsd_3B34.c').read_bytes()).hexdigest(),'retained_source_improvement':False,'retained_percent':98.7788,'retained_frame':152,'useful_candidate':'c016-rgb-combine-rule/LHR-left.c','useful_candidate_percent':98.04147,'useful_candidate_fact':'Exact target instructions +0xbc through +0xc8; full residual remains.','mwcc_decomp_head':subprocess.check_output(['git','-C',str(toolroot),'rev-parse','HEAD'],text=True).strip(),'capture_scope':'Read-only selected-function diagnostics, no full traced compiler run. Ordinary checkdiff and restored DOL verification are separate.','compiler_sha256':'ccf4b465cec73b5aae9c5c5543dcf8cda8a62aba246f89e2e0b200d742f2e55c','candidates':candidates,'members':[]}
with tarfile.open(out/'evidence.tar.gz','w:gz') as tar:
 for path,name in sorted(inputs,key=lambda x:x[1]):
  data=path.read_bytes();manifest['members'].append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()});info=tar.gettarinfo(str(path),arcname=name);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  with path.open('rb') as stream:tar.addfile(info,stream)
manifest['archive_sha256']=hashlib.sha256((out/'evidence.tar.gz').read_bytes()).hexdigest()
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(out/'evidence.tar.gz') as tar:
 assert len(tar.getmembers())==len(manifest['members'])
 for m in manifest['members']:
  data=tar.extractfile(m['path']).read();assert len(data)==m['bytes'];assert hashlib.sha256(data).hexdigest()==m['sha256']
print('Verified',len(inputs),'members,',sum(m['bytes'] for m in manifest['members']),'uncompressed bytes;',len(candidates),'candidates,',sum(c['valid_intended_transform'] for c in candidates),'valid intended transforms')

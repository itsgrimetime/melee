"""Read-only initial-lowering capture using the existing standalone reader.

Disable unrelated allocator/stack/optimizer probes. Stop after the selected
function's initial PCode boundary; this is not a complete compiler run.
"""
def intervene(ctx):
    import runpy, json
    from pathlib import Path
    m = runpy.run_path('/Users/mike/code/mwcc-decomp/tools/gdb/allocator_snapshot.py')
    out = Path(ctx.out_dir) / 'creation'
    out.mkdir(parents=True, exist_ok=True)
    session = m['CaptureSession'](out, target_name=ctx.fn, target='ninji')
    keep = [session.codegen_breakpoint, session.pcode_builder_return_breakpoint,
            *session.pcode_wrapper_breakpoints]
    for bp in ctx.gdb.breakpoints():
        bp.enabled = bp in keep
    original_begin = session.begin_function
    def begin(ptr):
        original_begin(ptr)
        obj = ctx.cad.MwccObject.load(ptr, load_linkname=False)
        session.function_identity['name'] = obj.name
        session.function_identity['name_decoder'] = 'cadmic exact-1.2.5n descriptor'
        session.capture_current = obj.name == ctx.fn
        with (out / 'functions.jsonl').open('a') as f:
            f.write(json.dumps(session.function_identity)+'\n')
    session.begin_function = begin
    class Initial(ctx.gdb.Breakpoint):
        def stop(self):
            if not session.capture_current:
                return False
            session.write_creation_trace('initial-only')
            try:
                session.write_pcode_stage('initial', int(ctx.gdb.parse_and_eval('$pc')))
            except Exception as e:
                (out / 'snapshot-error.txt').write_text(repr(e)+'\n')
            (out / 'capture-complete.json').write_text(json.dumps({
                'function':session.function_identity,
                'events':len(session.creation_events),
                'pending_events':len(session.pending_creations),
                'compiler':session.compiler,'target_sha256':session.target_sha256,
                'scope':'initial lowering only; no full compile or allocator capture'
            },indent=2)+'\n')
            return True
    Initial('*'+hex(m['INITIAL_PCODE_ADDRESS']), internal=True)
    class Combine(ctx.gdb.Breakpoint):
        def stop(self):
            if not session.capture_current:
                return False
            sp = ctx.reg('esp')
            def operand(ptr):
                return {'ptr':hex(ptr),'kind':ctx.read(ptr,1)[0],
                        'reg':int.from_bytes(ctx.read(ptr+2,2),'little',signed=True),
                        'secondary':int.from_bytes(ctx.read(ptr+6,2),'little',signed=True),
                        'raw':ctx.read(ptr,22).hex()}
            row={'caller_return':hex(ctx.u32(sp)),
                 'item':hex(ctx.u32(0x00587130)),
                 'left':operand(ctx.u32(sp+4)),
                 'right':operand(ctx.u32(sp+8)),
                 'requested':ctx.u32(sp+12),
                 'created_events':len(session.creation_events)}
            with (out/'combine-entries.jsonl').open('a') as f:
                f.write(json.dumps(row)+'\n')
            return False
    Combine('*0x004a1130',internal=True)
    ctx.cont()

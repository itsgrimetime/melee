from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');original=p.read_text()
try:
    p.write_text(Path('/tmp/c016-rgb-combine-rule/LHR-left.c').read_text())
    r=subprocess.run(['melee-agent','debug','retro','dump',str(p),'-f','hsd_803B3408','--phases','frontend','--gdb-py','/tmp/c016-rgb-stages-hook.py','--timeout','240','-O','/tmp/c016-rgb-corrected-stages'],capture_output=True,text=True)
    Path('/tmp/c016-rgb-corrected-stages.log').write_text(r.stdout+r.stderr)
    print('exit',r.returncode)
finally:p.write_text(original)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-destination-types');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
pix='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
init='''                    chroma_dest =
                        (JpegWork*) (HSD_804D2648_BUF + chroma_index * 4);''';assert init in part
rows=[]
try:
 for shape in ['baseline','corrected-pixel']:
  for kind in ['word-pointer','byte-pointer','chroma-record']:
   s=part;helper=''
   if kind=='word-pointer':
    s=s.replace('JpegWork* chroma_dest;','s32* chroma_dest;').replace(init,'                    chroma_dest = (s32*) HSD_804D2648_BUF + chroma_index;').replace('chroma_dest->data.x518[0]','chroma_dest[0x518 / sizeof(s32)]').replace('chroma_dest->data.x618[0]','chroma_dest[0x618 / sizeof(s32)]')
   elif kind=='byte-pointer':
    s=s.replace('JpegWork* chroma_dest;','u8* chroma_dest;').replace(init,'                    chroma_dest = HSD_804D2648_BUF + chroma_index * 4;').replace('chroma_dest->data.x518[0]','*(s32*) (chroma_dest + 0x518)').replace('chroma_dest->data.x618[0]','*(s32*) (chroma_dest + 0x618)')
   else:
    helper='typedef struct JpegChromaWork { u8 prefix[0x518]; s32 cb[64]; s32 cr[64]; } JpegChromaWork;\n'
    s=s.replace('JpegWork* chroma_dest;','JpegChromaWork* chroma_dest;').replace('(JpegWork*) (HSD_804D2648_BUF + chroma_index * 4)','(JpegChromaWork*) (HSD_804D2648_BUF + chroma_index * 4)').replace('chroma_dest->data.x518[0]','chroma_dest->cb[0]').replace('chroma_dest->data.x618[0]','chroma_dest->cr[0]')
   if shape=='corrected-pixel':s=s.replace(pix,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
   label=shape+'-'+kind;full=base[:a]+helper+s+base[b:];p.write_text(full);(out/(label+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   assert r.returncode in [0,1],(label,r.stderr)
   d=json.loads(r.stdout);rr={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(rr);print(rr,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

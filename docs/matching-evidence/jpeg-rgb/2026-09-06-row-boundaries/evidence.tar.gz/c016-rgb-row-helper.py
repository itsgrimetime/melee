from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-row-helper');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
pix='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
row='''                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;
                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;'''
locals='''                        s32 row_offset = (pixel_index & 2) * stride;

                        {
                            s32 column_offset = (pixel_index & 1) * 0x20;
                            pixel = src[column_offset + row_offset];
                        }''';assert row in part and locals in part
rows=[]
try:
 for shape in ['baseline','corrected-pixel']:
  for kind in ['no-helper','sum-helper','full-helper']:
   for offsets in ['locals','expressions']:
    if kind=='no-helper' and offsets=='locals':continue
    s=part;helper=''
    if kind=='sum-helper':
     helper='static inline s32 jpeg_chroma_row(s32 row) { return (row & 1) * 4 + (row & 2) * 16; }\n';s=s.replace('(chroma_y & 1) * 4 + (chroma_y & 2) * 16','jpeg_chroma_row(chroma_y)')
    if kind=='full-helper':
     helper='static inline s32 jpeg_chroma_row(s32 tile_y, s32 tile_x, s32 y) { s32 row = (y & 1) * 4 + (y & 2) * 16; return (tile_y * 16 + tile_x * 2) + row; }\n';s=s.replace(row,'                dst_row = jpeg_chroma_row(tile_y, tile_x, chroma_y);')
    if offsets=='expressions':s=s.replace(locals,'                        pixel = src[(pixel_index & 1) * 0x20 + (pixel_index & 2) * stride];')
    if shape=='corrected-pixel':s=s.replace(pix,'src[((chroma_x & 1) * 2 + (chroma_x & 2) * 4) + src_row]')
    label=shape+'-'+kind+'-'+offsets;full=base[:a]+helper+s+base[b:];p.write_text(full);(out/(label+'.c')).write_text(full)
    r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
    assert r.returncode in [0,1],(label,r.stderr)
    d=json.loads(r.stdout);rr={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(rr);print(rr,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

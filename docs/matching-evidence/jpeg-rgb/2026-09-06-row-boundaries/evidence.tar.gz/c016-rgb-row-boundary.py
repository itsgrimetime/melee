from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();out=Path('/tmp/c016-rgb-row-boundary');out.mkdir(exist_ok=True);(out/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b];expr='(chroma_y & 1) * 4 + (chroma_y & 2) * 16';assert part.count(expr)==1
rows=[]
try:
 for kind in ['cast','local']:
  for typ in ['u8','s8','u16','s16']:
   s=part.replace(expr,'('+typ+') ('+expr+')') if kind=='cast' else part.replace('s32 dst_row;',typ+' dst_row;')
   label=kind+'-'+typ;full=base[:a]+s+base[b:];p.write_text(full);(out/(label+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],capture_output=True,text=True,timeout=120);(out/(label+'.json')).write_text(r.stdout);(out/(label+'.log')).write_text(r.stderr)
   assert r.returncode in [0,1],(label,r.stderr)
   d=json.loads(r.stdout);row={'name':label,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural']};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(out/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-array-address');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
assert part.count(expr)==2
vs={}

for size,index in [(1,'(chroma_x & 2) * 4'),(2,'(chroma_x & 2) * 2'),(4,'chroma_x & 2'),(8,'chroma_x >> 1')]:
 for order in (False,True):
  offset='src_row + (chroma_x & 1) * 2' if not order else '(chroma_x & 1) * 2 + src_row'
  new='((u16 (*)['+str(size)+']) src)['+index+']['+offset+']'
  vs['array'+str(size)+'-'+str(order)]=part.replace(expr,new)
for shape,new in [('pointer-chain','*((src + src_row) + (chroma_x & 2) * 4 + (chroma_x & 1) * 2)'),('pointer-high-first','*((src + (chroma_x & 2) * 4) + src_row + (chroma_x & 1) * 2)')]:
 vs[shape]=part.replace(expr,new)
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['classification'].get('structural_truth_gate')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-helper-probes');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
assert part.count(expr)==2
vs={}
for typ in ('s32','u32','int'):
 for rev in (False,True):
  parms=f'{typ} row, {typ} column' if not rev else f'{typ} column, {typ} row'
  call='src_row, (chroma_x & 2) * 4' if not rev else '(chroma_x & 2) * 4, src_row'
  helper=f'static inline {typ} jpeg_row_column({parms}) {{ return column + row; }}\n'
  vs[f'row-column-{typ}-{rev}']=helper+part.replace(expr,'src[(chroma_x & 1) * 2 + jpeg_row_column('+call+')]')
for shape,params,body,args in [
 ('index','u16* src, s32 index','return src[index];','src, (chroma_x & 1) * 2 + (((chroma_x & 2) * 4) + src_row)'),
 ('row-high-low','u16* src, s32 row, s32 high, s32 low','return src[low + (high + row)];','src, src_row, (chroma_x & 2) * 4, (chroma_x & 1) * 2'),
 ('x-row','u16* src, s32 x, s32 row','return src[(x & 1) * 2 + ((x & 2) * 4 + row)];','src, chroma_x, src_row'),
 ('row-index-locals','u16* src, s32 x, s32 row','s32 high = (x & 2) * 4; s32 index = high + row; return src[(x & 1) * 2 + index];','src, chroma_x, src_row'),
 ('pointer-result','u16* src, s32 x, s32 row','return src + ((x & 1) * 2 + ((x & 2) * 4 + row));','src, chroma_x, src_row')]:
 ret='u16*' if shape=='pointer-result' else 'u16'
 helper=f'static inline {ret} jpeg_pixel({params}) {{ {body} }}\n'
 call=('*' if ret=='u16*' else '')+'jpeg_pixel('+args+')'
 vs[shape]=helper+part.replace(expr,call)
for op in ('|','^'):
 vs['disjoint-column-'+str(ord(op))]=part.replace(expr,'src[src_row + (((chroma_x & 1) * 2) '+op+' ((chroma_x & 2) * 4))]')
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['classification'].get('structural_truth_gate')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

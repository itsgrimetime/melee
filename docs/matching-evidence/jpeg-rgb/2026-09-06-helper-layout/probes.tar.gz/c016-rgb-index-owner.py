from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-index-owner');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
assert part.count(expr)==2
vs={}

for owner in ('struct','array','scalar'):
 decl={'struct':'struct { s32 index; } location;','array':'s32 location[1];','scalar':'s32 location;'}[owner]
 name={'struct':'location.index','array':'location[0]','scalar':'location'}[owner]
 for use in ('embedded-both','embedded-first','separate','compound'):
  t=part.replace('                    JpegWork* chroma_dest;','                    JpegWork* chroma_dest;\n                    '+decl)
  assignment=name+' = (chroma_x & 2) * 4 + src_row'
  if use.startswith('embedded'):
   new='src[(chroma_x & 1) * 2 + ('+assignment+')]'
   t=t.replace(expr,new,1 if use=='embedded-first' else 2)
   if use=='embedded-first':t=t.replace(expr,'src[(chroma_x & 1) * 2 + '+name+']')
  else:
   pre='                    '+assignment+';\n'
   if use=='compound':pre='                    '+name+' = (chroma_x & 2) * 4;\n                    '+name+' += src_row;\n'
   t=t.replace('                    pixel = '+expr+';',pre+'                    pixel = src[(chroma_x & 1) * 2 + '+name+'];',1)
   t=t.replace(expr,'src[(chroma_x & 1) * 2 + '+name+']')
  vs[owner+'-'+use]=t
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['classification'].get('structural_truth_gate')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-rgb-loop-setup');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3408(');b=base.index('static void fn_803B376C',a);part=base[a:b]
expr='src[(chroma_x & 1) * 2 +\n                                (((chroma_x & 2) * 4) + src_row)]'
assert part.count(expr)==2
vs={}

for typ in ('u8','u16','s8','s16','register s32'):
 vs['counter-'+typ.replace(' ','-')]=part.replace('    s32 pixel_index;','    '+typ+' pixel_index;')
for name,cond in [('lt4','pixel_index < 4'),('le3','pixel_index <= 3')]:
 vs[name]=part.replace('pixel_index != 4',cond)
row='                dst_row = (chroma_y & 1) * 4 + (chroma_y & 2) * 16;\n                dst_row = (tile_y * 16 + tile_x * 2) + dst_row;'
for name,new in [('single-row','                dst_row = (tile_y * 16 + tile_x * 2) + ((chroma_y & 1) * 4 + (chroma_y & 2) * 16);'),('row-base-first','                dst_row = tile_y * 16 + tile_x * 2;\n                dst_row += (chroma_y & 1) * 4 + (chroma_y & 2) * 16;')]:
 assert row in part;vs[name]=part.replace(row,new)
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3408','--no-tty','--format','json'],text=True,capture_output=True,timeout=120);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['classification'].get('structural_truth_gate')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

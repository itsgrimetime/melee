from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc5-ac-helper');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];start=part.index('    for (index = 1;');ac=part[start:part.rfind('}')]
vs={}
for shape in ('pointer-first','pointer-last','global'):
 params=['JpegWork* work','u16* ac_code','u8* ac_length'];args=['state.work','ac_code','ac_length'];owner=''
 if shape=='pointer-last':params=params[1:]+params[:1];args=args[1:]+args[:1]
 if shape=='global':params=params[1:];args=args[1:];owner='    JpegWork* work = (JpegWork*) &hsd_804D2648;\n'
 helper='static inline void jpeg_encode_ac('+', '.join(params)+')\n{\n'+owner+'    s32 index;\n    s32 run = 0;\n    s32 length;\n\n'+ac.replace('state.work','work')+'}\n\n'
 s=part[:start]+'    jpeg_encode_ac('+', '.join(args)+');\n}\n\n';s=s.replace('    s32 run;\n','').replace('    s32 index;\n','').replace('    run = 0;\n','')
 for depth in (None,4):
  text=helper+s
  if depth:text='#pragma push\n#pragma inline_depth(4)\n'+text+'#pragma pop\n\n'
  vs[shape+('-depth4' if depth else '-default')]=base[:a]+text+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

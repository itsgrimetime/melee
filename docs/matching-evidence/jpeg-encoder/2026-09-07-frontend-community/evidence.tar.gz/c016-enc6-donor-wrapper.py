from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc6-donor-wrapper');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];vs={}
for shape in ('flat','aggregate'):
 for depth in (0,4):
  for redundant in (False,True):
   s=part
   if shape=='flat':
    s=s.replace('    struct {\n        JpegWork* work;\n    } state;\n','').replace('state.work','work')
   else:
    s=s.replace('    state.work = (JpegWork*) &hsd_804D2648;', '    state.work = work;')
   if redundant:
    if shape=='aggregate':s=s.replace('    state.work = work;', '    work = (JpegWork*) &hsd_804D2648;\n    state.work = work;')
   elif shape=='flat':s=s.replace('    work = (JpegWork*) &hsd_804D2648;\n','')
   s=s.replace('void hsd_803B3CD8(s32 component)', 'static inline void hsd_803B3CD8_inline(s32 component, JpegWork* work)')
   s+='void hsd_803B3CD8(s32 component)\n{\n    hsd_803B3CD8_inline(component, (JpegWork*) &hsd_804D2648);\n}\n\n'
   if depth:s='#pragma inline_depth(4)\n'+s+'#pragma inline_depth(3)\n'
   vs[f'{shape}-depth{depth}-redundant{int(redundant)}']=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

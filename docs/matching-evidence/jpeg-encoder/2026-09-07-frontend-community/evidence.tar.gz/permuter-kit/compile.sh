#!/usr/bin/env bash
# Patched by melee-agent debug permute fix-compile
set -e
INPUT_ABS="$(realpath "$1")"
OUTPUT_ABS="$(realpath "$3")"
cd /Users/mike/.codex/worktrees/c016/melee
STAGE="nonmatchings/.permuter_stage_$$.c"
mkdir -p nonmatchings
cp "$INPUT_ABS" "$STAGE"
trap 'rm -f "$STAGE"' EXIT
INPUT="$STAGE"
OUTPUT="$OUTPUT_ABS"
WIBO=""
if [[ -n "${MWCC_DEBUG_WIBO:-}" && -f "$MWCC_DEBUG_WIBO" && -x "$MWCC_DEBUG_WIBO" ]]; then
  WIBO="$MWCC_DEBUG_WIBO"
elif [[ -n "${MELEE_ROOT:-}" && -f "$MELEE_ROOT/tools/mwcc_debug/bin/wibo" && -x "$MELEE_ROOT/tools/mwcc_debug/bin/wibo" ]]; then
  WIBO="$MELEE_ROOT/tools/mwcc_debug/bin/wibo"
elif [[ -f "tools/mwcc_debug/bin/wibo" && -x "tools/mwcc_debug/bin/wibo" ]]; then
  WIBO="tools/mwcc_debug/bin/wibo"
elif [[ -f "/Users/mike/code/melee/tools/mwcc_debug/bin/wibo" && -x "/Users/mike/code/melee/tools/mwcc_debug/bin/wibo" ]]; then
  WIBO="/Users/mike/code/melee/tools/mwcc_debug/bin/wibo"
else
  echo "error: patched wibo executable not found; set MWCC_DEBUG_WIBO or build tools/mwcc_debug/bin/wibo" >&2
  exit 2
fi
"$WIBO" build/compilers/GC/1.2.5n/mwcceppc.exe -Cpp_exceptions off -proc gekko -fp hard -fp_contract on -O4,p -enum int -nodefaults -inline auto -c -i src -i src/MSL -i src/Runtime -i extern/dolphin/include -i src/melee -i src/melee/ft/chara -i src/sysdolphin -DBUILD_VERSION=0 -DVERSION_GALE01 "$INPUT" -o "$OUTPUT"

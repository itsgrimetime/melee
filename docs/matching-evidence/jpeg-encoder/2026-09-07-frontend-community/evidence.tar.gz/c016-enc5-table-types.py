from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc5-table-types');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];vs={}
for names in (['dc_code'],['dc_length'],['dc_code','dc_length']):
 for typ in ('void*','const','array'):
  s=part
  for name in names:
   item='u16' if name.endswith('code') else 'u8';decl=f'    {item}* {name};';assert decl in s
   if typ=='const':s=s.replace(decl,f'    const {item}* {name};')
   else:
    selectedtype='void*' if typ=='void*' else item+' (*)[12]'
    newdecl=f'    void* {name};' if typ=='void*' else f'    {item} (*{name})[12];'
    s=s.replace(decl,newdecl)
    s=re.sub(r'('+name+r' = )([^;]+);',lambda m:m[1]+'('+selectedtype+') ('+m[2]+');',s)
    s=s.replace(name+'[length]',f'(({item}*) {name})[length]' if typ=='void*' else f'(*{name})[length]')
  vs['-'.join(names)+'-'+typ.replace('*','ptr')]=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,os
paths=[Path('tools/workflow/mwcc-inspect.sh'),Path('tools/workflow/mwcc-inspect-supervisor.sh')]
backups={p:p.read_bytes() for p in paths}
try:
 wrapper=paths[0];source=wrapper.read_text();needle='cd "${REMOTE_REPO}"\nREMOTE_PRIVATE_COMMAND'
 assert source.count(needle)==1
 source=source.replace(needle,'cd "${REMOTE_REPO}"\nsafe_mkdir_parents "${REMOTE_REPO}" "build/GALE01/include"\nREMOTE_PRIVATE_COMMAND')
 wrapper.write_text(source)
 Path('/tmp/c016-enc6-inspector-wrapper.sh').write_text(source)
 env=dict(os.environ);env['MWCC_INSPECT_REMOTE_REF']='5d8814c18093525f573011ff5e37e97020d3c655'
 r=subprocess.run(['tools/workflow/mwcc-inspect.sh','--invocation-id','c016-encoder-20260906-frontend-dir','--deadline-seconds','180','--output','/tmp/c016-enc6-inspector.txt','src/sysdolphin/baselib/hsd_3B34.c'],env=env,capture_output=True,text=True)
 Path('/tmp/c016-enc6-inspector.log').write_text(r.stdout+r.stderr);print('exit',r.returncode);print(r.stdout[-2500:]);print(r.stderr[-2500:])
finally:
 for p,b in backups.items():p.write_bytes(b)

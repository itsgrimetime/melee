from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc2-copies');root.mkdir(exist_ok=True)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b]
calls=list(re.finditer(r'hsd_803B3CD8_write_bits\(([^;]*?)\);',part));assert len(calls)==7,len(calls)
rows=[]
try:
 for i,m in enumerate(calls):
  args=[x.strip() for x in m.group(1).split(',')];assert len(args)==3
  for j,label,typ in [(0,'value','s32'),(1,'length','s32'),(2,'work','JpegWork*')]:
   name=f'call{i}-{label}';args2=args.copy();args2[j]='(call_'+label+' = '+args[j]+')'
   newcall='hsd_803B3CD8_write_bits('+', '.join(args2)+');'
   s=part[:m.start()]+newcall+part[m.end():]
   s=s.replace('    s32 index;','    s32 index;\n    '+typ+' call_'+label+';')
   full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
   r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90)
   (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
   d=json.loads(r.stdout);asm=d['current_asm'];asm=asm.splitlines() if isinstance(asm,str) else asm
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'head':asm[:25]}
   rows.append(row);print(json.dumps({k:v for k,v in row.items() if k!='head'}),flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

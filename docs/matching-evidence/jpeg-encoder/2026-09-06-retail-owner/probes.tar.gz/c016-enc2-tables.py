from pathlib import Path
import json,subprocess,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc2-tables');root.mkdir(exist_ok=True)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];vs={}
for label,names in [('dc-code',['dc_code']),('dc-length',['dc_length']),('dc-pair',['dc_code','dc_length']),('dc-pair-reverse',['dc_length','dc_code']),('all-tables',['dc_code','dc_length','ac_code','ac_length'])]:
 s=part;fields=[]
 for name in names:
  typ='u16*' if name.endswith('code') else 'u8*';decl='    '+typ+' '+name+';\n';assert decl in s;s=s.replace(decl,'');fields.append(typ+' '+name+';')
 for name in names:s=re.sub(r'\b'+name+r'\b','selected.'+name,s)
 s=s.replace('    JpegEncodeTables* tables;','    JpegEncodeTables* tables;\n    struct { '+' '.join(fields)+' } selected;');vs[label]=s
# Separate selector helpers preserve the same four conditional address expressions.
for label,sel in [('dc-code-helper',['dc_code']),('dc-length-helper',['dc_length']),('dc-both-helper',['dc_code','dc_length'])]:
 s=part;helpers=''
 for name in sel:
  typ,yes,no=('u16*','lbl_80431678','lbl_8043169C') if name=='dc_code' else ('u8*','lbl_80431690','lbl_804316B4')
  helpers+='static inline '+typ+' select_'+name+'(s32 component) { return component == 0 ? '+yes+' : '+no+'; }\n'
  s=s.replace(name+' = component == 0 ? '+yes+' : '+no+';',name+' = select_'+name+'(component);')
 vs[label]=helpers+s
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);asm=d['current_asm'];asm=asm.splitlines() if isinstance(asm,str) else asm;i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
  row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import json,subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc2-init');root.mkdir(exist_ok=True)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b]
init='    state.work = (JpegWork*) &hsd_804D2648;\n';assert part.count(init)==1
anchors=[('tables','    tables = (JpegEncodeTables*) lbl_80430C40;\n'),('dc-code','    dc_code = component == 0 ? lbl_80431678 : lbl_8043169C;\n'),('dc-length','    dc_length = component == 0 ? lbl_80431690 : lbl_804316B4;\n'),('ac-code','    ac_code = component == 0 ? tables->ac_code_luma : tables->ac_code_chroma;\n'),('ac-length','        component == 0 ? tables->ac_length_luma : tables->ac_length_chroma;\n')]
rows=[]
try:
 for name,anchor in anchors:
  assert anchor in part
  s=part.replace(init,'').replace(anchor,anchor+init);full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  d=json.loads(r.stdout);asm=d['current_asm'];asm=asm.splitlines() if isinstance(asm,str) else asm;i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
  row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]};rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

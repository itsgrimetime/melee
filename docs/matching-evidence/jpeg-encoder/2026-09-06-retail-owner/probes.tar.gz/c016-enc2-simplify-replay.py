import json
from pathlib import Path
raw=json.load(open('/tmp/c016-enc2-retail-cost/allocator-cost-0.json'))
nodes={n['virtual_register']:n for n in raw['nodes']}
trace=json.load(open('/tmp/c016-enc2-retail/backend-trace.v1.json'))['functions'][0]['regalloc']['classes'][0]
expected=[d['ig_id'] for d in trace['color_decisions']]
def replay(omit=()):
 edges={v:[u for u in n['neighbors'] if (v,u) not in omit and (u,v) not in omit] for v,n in nodes.items()}
 degree={v:len(ns) for v,ns in edges.items()};active={v for v,n in nodes.items() if v>=32 and not n['flags']&4};removed=[];passes=[]
 while active:
  progress=[]
  for v in sorted(active):
   if degree[v]<29:
    at=degree[v];active.remove(v)
    for u in edges[v]:degree[u]-=1
    removed.append(v);progress.append([v,at])
  passes.append(progress)
  if not progress:return {'stuck':sorted(active),'passes':passes,'select':list(reversed(removed))}
 return {'stuck':[],'passes':passes,'select':list(reversed(removed))}
r=replay();assert not r['stuck'];assert r['select']==expected,(r['select'][:25],expected[:25])
print('Baseline replay exactly reproduces all',len(expected),'select positions; scans',len(r['passes']))
rows=[]
for omit in [(),((57,107),),((57,109),),((57,111),),((57,113),),((57,107),(57,109)),((57,111),(57,113)),((57,107),(57,109),(57,111)),tuple((57,x) for x in [107,109,111,113])]:
 s=replay(omit);row={'removed_edges':omit,'stuck':s['stuck'],'first_selects':s['select'][:25],'root57_select':s['select'].index(57),'root57_removal':next({'scan':i,'degree':d} for i,p in enumerate(s['passes']) for v,d in p if v==57)};rows.append(row);print(row)
Path('/tmp/c016-enc2-simplify-replay.json').write_text(json.dumps({'baseline_all_selects_verified':True,'baseline':r,'edge_perturbations_diagnostic_only':rows},indent=2)+'\n')

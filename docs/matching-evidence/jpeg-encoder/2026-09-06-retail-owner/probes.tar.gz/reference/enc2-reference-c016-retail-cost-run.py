from pathlib import Path
import subprocess
src=Path('src/melee/mn/mnitemsw.c');original=src.read_text()
try:
 for name,path in [('baseline','/tmp/c016-pr3358-best.c'),('compact','/tmp/c016-original-flag-use/joints-16.c')]:
  src.write_text(Path(path).read_text())
  cmd=['melee-agent','debug','retro','dump',str(src),'-f','mnItemSw_8023453C','--phases','frontend','--gdb-py','/tmp/c016-retail-cost-hook.py','--timeout','240','-O','/tmp/c016-retail-cost-'+name]
  print('Starting '+name,flush=True)
  r=subprocess.run(cmd,capture_output=True,text=True)
  Path('/tmp/c016-retail-cost-'+name+'.log').write_text(r.stdout+r.stderr)
  print(name+' exit '+str(r.returncode)+' '+(r.stdout+r.stderr)[-1000:],flush=True)
finally:src.write_text(original)

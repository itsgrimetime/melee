# Selected functions from mwcceppc.exe

## `FUN_004cdef0` at `004cdef0`

- Bytes: 661
- Callers: `004351c0` (`FUN_004351c0`), `004e67c0` (`FUN_004e67c0`)
- Callees: `00441e20` (`FUN_00441e20`), `00445780` (`FUN_00445780`), `0047cd70` (`FUN_0047cd70`), `004a9c80` (`FUN_004a9c80`), `004c1560` (`FUN_004c1560`), `004c1590` (`FUN_004c1590`), `004c15c0` (`FUN_004c15c0`), `004c1ae0` (`FUN_004c1ae0`), `004c1b00` (`FUN_004c1b00`), `004c1b20` (`FUN_004c1b20`), `004c2560` (`FUN_004c2560`), `004c4bd0` (`FUN_004c4bd0`), `004ce1a0` (`FUN_004ce1a0`), `004ce2d0` (`FUN_004ce2d0`), `004ce400` (`FUN_004ce400`), `004ce5f0` (`FUN_004ce5f0`), `004ce710` (`FUN_004ce710`), `004ce850` (`FUN_004ce850`), `00530a00` (`FUN_00530a00`), `00531800` (`FUN_00531800`)
- Referenced strings:
  - `00563064` `AFTER CHECKING FOR ALTIVEC FRAME`
  - `0056308c` `Coloring.c`

```text
004cdef0  53  PUSH EBX
004cdef1  55  PUSH EBP
004cdef2  8b5c240c  MOV EBX,dword ptr [ESP + 0xc]
004cdef6  e86536ffff  CALL 0x004c1560
004cdefb  66a19a845800  MOV AX,[0x0058849a]
004cdf01  66a3881b5800  MOV [0x00581b88],AX
004cdf07  66833d9a84580020  CMP word ptr [0x0058849a],0x20
004cdf0f  7e1f  JLE 0x004cdf30
004cdf11  e8ca3bffff  CALL 0x004c1ae0
004cdf16  85c0  TEST EAX,EAX
004cdf18  7516  JNZ 0x004cdf30
004cdf1a  6860305600  PUSH 0x563060
004cdf1f  6a66  PUSH 0x66
004cdf21  e84aeefaff  CALL 0x0047cd70
004cdf26  59  POP ECX
004cdf27  59  POP ECX
004cdf28  5d  POP EBP
004cdf29  5b  POP EBX
004cdf2a  c3  RET
004cdf30  bd01000000  MOV EBP,0x1
004cdf35  eb70  JMP 0x004cdfa7
004cdf37  0fbf059a845800  MOVSX EAX,word ptr [0x0058849a]
004cdf3e  50  PUSH EAX
004cdf3f  6a09  PUSH 0x9
004cdf41  53  PUSH EBX
004cdf42  e8b92a0600  CALL 0x00530a00
004cdf47  83c40c  ADD ESP,0xc
004cdf4a  e8a1060000  CALL 0x004ce5f0
004cdf4f  0fbf059a845800  MOVSX EAX,word ptr [0x0058849a]
004cdf56  31ed  XOR EBP,EBP
004cdf58  50  PUSH EAX
004cdf59  e8823bffff  CALL 0x004c1ae0
004cdf5e  50  PUSH EAX
004cdf5f  6a09  PUSH 0x9
004cdf61  e89a040000  CALL 0x004ce400
004cdf66  83c40c  ADD ESP,0xc
004cdf69  50  PUSH EAX
004cdf6a  6a09  PUSH 0x9
004cdf6c  e85f030000  CALL 0x004ce2d0
004cdf71  85c0  TEST EAX,EAX
004cdf73  59  POP ECX
004cdf74  59  POP ECX
004cdf75  7505  JNZ 0x004cdf7c
004cdf77  bd01000000  MOV EBP,0x1
004cdf7c  85ed  TEST EBP,EBP
004cdf7e  7411  JZ 0x004cdf91
004cdf80  0fbf059a845800  MOVSX EAX,word ptr [0x0058849a]
004cdf87  50  PUSH EAX
004cdf88  6a09  PUSH 0x9
004cdf8a  e871380600  CALL 0x00531800
004cdf8f  eb0f  JMP 0x004cdfa0
004cdf91  0fbf059a845800  MOVSX EAX,word ptr [0x0058849a]
004cdf98  50  PUSH EAX
004cdf99  6a09  PUSH 0x9
004cdf9b  e800020000  CALL 0x004ce1a0
004cdfa0  59  POP ECX
004cdfa1  59  POP ECX
004cdfa2  e8793ef7ff  CALL 0x00441e20
004cdfa7  85ed  TEST EBP,EBP
004cdfa9  740a  JZ 0x004cdfb5
004cdfab  66833d9a84580020  CMP word ptr [0x0058849a],0x20
004cdfb3  7f82  JG 0x004cdf37
004cdfb5  e8c6bcfdff  CALL 0x004a9c80
004cdfba  803d2642580000  CMP byte ptr [0x00584226],0x0
004cdfc1  7422  JZ 0x004cdfe5
004cdfc3  803df984580000  CMP byte ptr [0x005884f9],0x0
004cdfca  7419  JZ 0x004cdfe5
004cdfcc  6864305600  PUSH 0x563064
004cdfd1  53  PUSH EBX
004cdfd2  e88945ffff  CALL 0x004c2560
004cdfd7  050a000000  ADD EAX,0xa
004cdfdc  59  POP ECX
004cdfdd  50  PUSH EAX
004cdfde  e8ed6bffff  CALL 0x004c4bd0
004cdfe3  59  POP ECX
004cdfe4  59  POP ECX
004cdfe5  e8d635ffff  CALL 0x004c15c0
004cdfea  66a16e845800  MOV AX,[0x0058846e]
004cdff0  66a3881b5800  MOV [0x00581b88],AX
004cdff6  66833d6e84580020  CMP word ptr [0x0058846e],0x20
004cdffe  7e20  JLE 0x004ce020
004ce000  e81b3bffff  CALL 0x004c1b20
004ce005  85c0  TEST EAX,EAX
004ce007  7f17  JG 0x004ce020
004ce009  6888305600  PUSH 0x563088
004ce00e  6a66  PUSH 0x66
004ce010  e85bedfaff  CALL 0x0047cd70
004ce015  59  POP ECX
004ce016  59  POP ECX
004ce017  5d  POP EBP
004ce018  5b  POP EBX
004ce019  c3  RET
004ce020  bd01000000  MOV EBP,0x1
004ce025  eb70  JMP 0x004ce097
004ce027  0fbf056e845800  MOVSX EAX,word ptr [0x0058846e]
004ce02e  50  PUSH EAX
004ce02f  6a00  PUSH 0x0
004ce031  53  PUSH EBX
004ce032  e8c9290600  CALL 0x00530a00
004ce037  83c40c  ADD ESP,0xc
004ce03a  e811080000  CALL 0x004ce850
004ce03f  0fbf056e845800  MOVSX EAX,word ptr [0x0058846e]
004ce046  31ed  XOR EBP,EBP
004ce048  50  PUSH EAX
004ce049  e8d23affff  CALL 0x004c1b20
004ce04e  50  PUSH EAX
004ce04f  6a00  PUSH 0x0
004ce051  e8aa030000  CALL 0x004ce400
004ce056  83c40c  ADD ESP,0xc
004ce059  50  PUSH EAX
004ce05a  6a00  PUSH 0x0
004ce05c  e86f020000  CALL 0x004ce2d0
004ce061  85c0  TEST EAX,EAX
004ce063  59  POP ECX
004ce064  59  POP ECX
004ce065  7505  JNZ 0x004ce06c
004ce067  bd01000000  MOV EBP,0x1
004ce06c  85ed  TEST EBP,EBP
004ce06e  7411  JZ 0x004ce081
004ce070  0fbf056e845800  MOVSX EAX,word ptr [0x0058846e]
004ce077  50  PUSH EAX
004ce078  6a00  PUSH 0x0
004ce07a  e881370600  CALL 0x00531800
004ce07f  eb0f  JMP 0x004ce090
004ce081  0fbf056e845800  MOVSX EAX,word ptr [0x0058846e]
004ce088  50  PUSH EAX
004ce089  6a00  PUSH 0x0
004ce08b  e810010000  CALL 0x004ce1a0
004ce090  59  POP ECX
004ce091  59  POP ECX
004ce092  e8893df7ff  CALL 0x00441e20
004ce097  85ed  TEST EBP,EBP
004ce099  740a  JZ 0x004ce0a5
004ce09b  66833d6e84580020  CMP word ptr [0x0058846e],0x20
004ce0a3  7f82  JG 0x004ce027
004ce0a5  e8e634ffff  CALL 0x004c1590
004ce0aa  66a16c845800  MOV AX,[0x0058846c]
004ce0b0  66a3881b5800  MOV [0x00581b88],AX
004ce0b6  803d4442580000  CMP byte ptr [0x00584244],0x0
004ce0bd  741b  JZ 0x004ce0da
004ce0bf  66833d6c84580020  CMP word ptr [0x0058846c],0x20
004ce0c7  7e11  JLE 0x004ce0da
004ce0c9  68ec010000  PUSH 0x1ec
004ce0ce  688c305600  PUSH 0x56308c
004ce0d3  e8a876f7ff  CALL 0x00445780
004ce0d8  59  POP ECX
004ce0d9  59  POP ECX
004ce0da  66833d6c84580020  CMP word ptr [0x0058846c],0x20
004ce0e2  7e1c  JLE 0x004ce100
004ce0e4  e8173affff  CALL 0x004c1b00
004ce0e9  85c0  TEST EAX,EAX
004ce0eb  7f13  JG 0x004ce100
004ce0ed  6898305600  PUSH 0x563098
004ce0f2  6a66  PUSH 0x66
004ce0f4  e877ecfaff  CALL 0x0047cd70
004ce0f9  59  POP ECX
004ce0fa  59  POP ECX
004ce0fb  5d  POP EBP
004ce0fc  5b  POP EBX
004ce0fd  c3  RET
004ce100  bd01000000  MOV EBP,0x1
004ce105  eb70  JMP 0x004ce177
004ce107  0fbf056c845800  MOVSX EAX,word ptr [0x0058846c]
004ce10e  50  PUSH EAX
004ce10f  6a01  PUSH 0x1
004ce111  53  PUSH EBX
004ce112  e8e9280600  CALL 0x00530a00
004ce117  83c40c  ADD ESP,0xc
004ce11a  e8f1050000  CALL 0x004ce710
004ce11f  0fbf056c845800  MOVSX EAX,word ptr [0x0058846c]
004ce126  31ed  XOR EBP,EBP
004ce128  50  PUSH EAX
004ce129  e8d239ffff  CALL 0x004c1b00
004ce12e  50  PUSH EAX
004ce12f  6a01  PUSH 0x1
004ce131  e8ca020000  CALL 0x004ce400
004ce136  83c40c  ADD ESP,0xc
004ce139  50  PUSH EAX
004ce13a  6a01  PUSH 0x1
004ce13c  e88f010000  CALL 0x004ce2d0
004ce141  85c0  TEST EAX,EAX
004ce143  59  POP ECX
004ce144  59  POP ECX
004ce145  7505  JNZ 0x004ce14c
004ce147  bd01000000  MOV EBP,0x1
004ce14c  85ed  TEST EBP,EBP
004ce14e  7411  JZ 0x004ce161
004ce150  0fbf056c845800  MOVSX EAX,word ptr [0x0058846c]
004ce157  50  PUSH EAX
004ce158  6a01  PUSH 0x1
004ce15a  e8a1360600  CALL 0x00531800
004ce15f  eb0f  JMP 0x004ce170
004ce161  0fbf056c845800  MOVSX EAX,word ptr [0x0058846c]
004ce168  50  PUSH EAX
004ce169  6a01  PUSH 0x1
004ce16b  e830000000  CALL 0x004ce1a0
004ce170  59  POP ECX
004ce171  59  POP ECX
004ce172  e8a93cf7ff  CALL 0x00441e20
004ce177  85ed  TEST EBP,EBP
004ce179  740a  JZ 0x004ce185
004ce17b  66833d6c84580020  CMP word ptr [0x0058846c],0x20
004ce183  7f82  JG 0x004ce107
004ce185  c7054876580000000000  MOV dword ptr [0x00587648],0x0
004ce18f  5d  POP EBP
004ce190  5b  POP EBX
004ce191  c3  RET
```

```c

void __cdecl FUN_004cdef0(int param_1)

{
  int iVar1;
  uint uVar2;
  int *piVar3;
  bool bVar4;
  
  FUN_004c1560();
  DAT_00581b88 = DAT_0058849a;
  if ((0x20 < DAT_0058849a) && (iVar1 = FUN_004c1ae0(), iVar1 == 0)) {
    FUN_0047cd70(0x66);
    return;
  }
  bVar4 = true;
  while ((bVar4 && (0x20 < DAT_0058849a))) {
    FUN_00530a00(param_1,9,(int)DAT_0058849a);
    FUN_004ce5f0();
    uVar2 = (uint)DAT_0058849a;
    iVar1 = FUN_004c1ae0();
    piVar3 = FUN_004ce400(9,iVar1,uVar2);
    iVar1 = FUN_004ce2d0(9,piVar3);
    bVar4 = iVar1 == 0;
    if (bVar4) {
      FUN_00531800(9,(int)DAT_0058849a);
    }
    else {
      FUN_004ce1a0(9,(int)DAT_0058849a);
    }
    FUN_00441e20();
  }
  FUN_004a9c80();
  if ((DAT_00584224._2_1_ != '\0') && (DAT_005884f9 != '\0')) {
    FUN_004c2560(param_1);
    FUN_004c4bd0();
  }
  FUN_004c15c0();
  DAT_00581b88 = DAT_0058846e;
  if ((0x20 < DAT_0058846e) && (iVar1 = FUN_004c1b20(), iVar1 < 1)) {
    FUN_0047cd70(0x66);
    return;
  }
  bVar4 = true;
  while ((bVar4 && (0x20 < DAT_0058846e))) {
    FUN_00530a00(param_1,0,(int)DAT_0058846e);
    FUN_004ce850();
    uVar2 = (uint)DAT_0058846e;
    iVar1 = FUN_004c1b20();
    piVar3 = FUN_004ce400(0,iVar1,uVar2);
    iVar1 = FUN_004ce2d0(0,piVar3);
    bVar4 = iVar1 == 0;
    if (bVar4) {
      FUN_00531800(0,(int)DAT_0058846e);
    }
    else {
      FUN_004ce1a0(0,(int)DAT_0058846e);
    }
    FUN_00441e20();
  }
  FUN_004c1590();
  DAT_00581b88 = DAT_0058846c;
  if ((DAT_00584244 != '\0') && (0x20 < DAT_0058846c)) {
    FUN_00445780();
  }
  if ((0x20 < DAT_0058846c) && (iVar1 = FUN_004c1b00(), iVar1 < 1)) {
    FUN_0047cd70(0x66);
    return;
  }
  bVar4 = true;
  while ((bVar4 && (0x20 < DAT_0058846c))) {
    FUN_00530a00(param_1,1,(int)DAT_0058846c);
    FUN_004ce710();
    uVar2 = (uint)DAT_0058846c;
    iVar1 = FUN_004c1b00();
    piVar3 = FUN_004ce400(1,iVar1,uVar2);
    iVar1 = FUN_004ce2d0(1,piVar3);
    bVar4 = iVar1 == 0;
    if (bVar4) {
      FUN_00531800(1,(int)DAT_0058846c);
    }
    else {
      FUN_004ce1a0(1,(int)DAT_0058846c);
    }
    FUN_00441e20();
  }
  DAT_00587648 = 0;
  return;
}


```

## `FUN_004ce400` at `004ce400`

- Bytes: 477
- Callers: `004cdef0` (`FUN_004cdef0`)
- Callees: `00532790` (`FUN_00532790`)

```text
004ce400  53  PUSH EBX
004ce401  56  PUSH ESI
004ce402  57  PUSH EDI
004ce403  55  PUSH EBP
004ce404  83ec10  SUB ESP,0x10
004ce407  31ed  XOR EBP,EBP
004ce409  8d842000000000  LEA EAX,[EAX]
004ce410  c7042420000000  MOV dword ptr [ESP],0x20
004ce417  31db  XOR EBX,EBX
004ce419  837c242c20  CMP dword ptr [ESP + 0x2c],0x20
004ce41e  c744240400000000  MOV dword ptr [ESP + 0x4],0x0
004ce426  7668  JBE 0x004ce490
004ce428  8b0424  MOV EAX,dword ptr [ESP]
004ce42b  8b353c7e5800  MOV ESI,dword ptr [0x00587e3c]
004ce431  8b3c86  MOV EDI,dword ptr [ESI + EAX*0x4]
004ce434  0fb64f12  MOVZX ECX,byte ptr [EDI + 0x12]
004ce438  89f8  MOV EAX,EDI
004ce43a  81e106000000  AND ECX,0x6
004ce440  7542  JNZ 0x004ce484
004ce442  0fbf500e  MOVSX EDX,word ptr [EAX + 0xe]
004ce446  3b542428  CMP EDX,dword ptr [ESP + 0x28]
004ce44a  7d34  JGE 0x004ce480
004ce44c  31c9  XOR ECX,ECX
004ce44e  eb13  JMP 0x004ce463
004ce450  0fbf7c4816  MOVSX EDI,word ptr [EAX + ECX*0x2 + 0x16]
004ce455  8b353c7e5800  MOV ESI,dword ptr [0x00587e3c]
004ce45b  8b14be  MOV EDX,dword ptr [ESI + EDI*0x4]
004ce45e  66ff4a0e  DEC word ptr [EDX + 0xe]
004ce462  41  INC ECX
004ce463  0fbf7814  MOVSX EDI,word ptr [EAX + 0x14]
004ce467  39f9  CMP ECX,EDI
004ce469  72e5  JC 0x004ce450
004ce46b  80481202  OR byte ptr [EAX + 0x12],0x2
004ce46f  8928  MOV dword ptr [EAX],EBP
004ce471  c744240401000000  MOV dword ptr [ESP + 0x4],0x1
004ce479  89c5  MOV EBP,EAX
004ce47b  eb07  JMP 0x004ce484
004ce480  8918  MOV dword ptr [EAX],EBX
004ce482  89c3  MOV EBX,EAX
004ce484  ff0424  INC dword ptr [ESP]
004ce487  8b0424  MOV EAX,dword ptr [ESP]
004ce48a  3b44242c  CMP EAX,dword ptr [ESP + 0x2c]
004ce48e  7298  JC 0x004ce428
004ce490  837c240400  CMP dword ptr [ESP + 0x4],0x0
004ce495  0f8575ffffff  JNZ 0x004ce410
004ce49b  85db  TEST EBX,EBX
004ce49d  0f842e010000  JZ 0x004ce5d1
004ce4a3  8b442424  MOV EAX,dword ptr [ESP + 0x24]
004ce4a7  50  PUSH EAX
004ce4a8  e8e3420600  CALL 0x00532790
004ce4ad  59  POP ECX
004ce4ae  e91e010000  JMP 0x004ce5d1
004ce4b3  66a1881b5800  MOV AX,[0x00581b88]
004ce4b9  668b530c  MOV DX,word ptr [EBX + 0xc]
004ce4bd  d9ee  FLDZ
004ce4bf  d9ee  FLDZ
004ce4c1  6639c2  CMP DX,AX
004ce4c4  89de  MOV ESI,EBX
004ce4c6  7c08  JL 0x004ce4d0
004ce4c8  d9059c305600  FLD float ptr [0x0056309c]
004ce4ce  eb11  JMP 0x004ce4e1
004ce4d0  0fbf430e  MOVSX EAX,word ptr [EBX + 0xe]
004ce4d4  89442408  MOV dword ptr [ESP + 0x8],EAX
004ce4d8  db442408  FILD dword ptr [ESP + 0x8]
004ce4dc  db4308  FILD dword ptr [EBX + 0x8]
004ce4df  def1  FDIVRP
004ce4e1  ddda  FSTP ST2
004ce4e3  d9c1  FLD ST1
004ce4e5  8b03  MOV EAX,dword ptr [EBX]
004ce4e7  ddda  FSTP ST2
004ce4e9  85c0  TEST EAX,EAX
004ce4eb  89c2  MOV EDX,EAX
004ce4ed  7443  JZ 0x004ce532
004ce4ef  90  NOP
004ce4f0  66a1881b5800  MOV AX,[0x00581b88]
004ce4f6  668b4a0c  MOV CX,word ptr [EDX + 0xc]
004ce4fa  6639c1  CMP CX,AX
004ce4fd  7c08  JL 0x004ce507
004ce4ff  d905a0305600  FLD float ptr [0x005630a0]
004ce505  eb11  JMP 0x004ce518
004ce507  0fbf420e  MOVSX EAX,word ptr [EDX + 0xe]
004ce50b  89442408  MOV dword ptr [ESP + 0x8],EAX
004ce50f  db442408  FILD dword ptr [ESP + 0x8]
004ce513  db4208  FILD dword ptr [EDX + 0x8]
004ce516  def1  FDIVRP
004ce518  ddd9  FSTP ST1
004ce51a  d8d1  FCOM
004ce51c  dfe0  FNSTSW AX
004ce51e  80e405  AND AH,0x5
004ce521  80fc01  CMP AH,0x1
004ce524  7506  JNZ 0x004ce52c
004ce526  d9c0  FLD ST0
004ce528  ddda  FSTP ST2
004ce52a  89d6  MOV ESI,EDX
004ce52c  8b12  MOV EDX,dword ptr [EDX]
004ce52e  85d2  TEST EDX,EDX
004ce530  75be  JNZ 0x004ce4f0
004ce532  31c9  XOR ECX,ECX
004ce534  eb13  JMP 0x004ce549
004ce536  0fbf7c4e16  MOVSX EDI,word ptr [ESI + ECX*0x2 + 0x16]
004ce53b  8b1d3c7e5800  MOV EBX,dword ptr [0x00587e3c]
004ce541  8b04bb  MOV EAX,dword ptr [EBX + EDI*0x4]
004ce544  66ff480e  DEC word ptr [EAX + 0xe]
004ce548  41  INC ECX
004ce549  0fbf4614  MOVSX EAX,word ptr [ESI + 0x14]
004ce54d  39c1  CMP ECX,EAX
004ce54f  72e5  JC 0x004ce536
004ce551  804e1202  OR byte ptr [ESI + 0x12],0x2
004ce555  892e  MOV dword ptr [ESI],EBP
004ce557  89f5  MOV EBP,ESI
004ce559  8d842000000000  LEA EAX,[EAX]
004ce560  b920000000  MOV ECX,0x20
004ce565  31db  XOR EBX,EBX
004ce567  31d2  XOR EDX,EDX
004ce569  394c242c  CMP dword ptr [ESP + 0x2c],ECX
004ce56d  765c  JBE 0x004ce5cb
004ce56f  90  NOP
004ce570  a13c7e5800  MOV EAX,[0x00587e3c]
004ce575  8b3c88  MOV EDI,dword ptr [EAX + ECX*0x4]
004ce578  0fb64712  MOVZX EAX,byte ptr [EDI + 0x12]
004ce57c  89fe  MOV ESI,EDI
004ce57e  2506000000  AND EAX,0x6
004ce583  753f  JNZ 0x004ce5c4
004ce585  0fbf460e  MOVSX EAX,word ptr [ESI + 0xe]
004ce589  3b442428  CMP EAX,dword ptr [ESP + 0x28]
004ce58d  7d31  JGE 0x004ce5c0
004ce58f  31c0  XOR EAX,EAX
004ce591  eb13  JMP 0x004ce5a6
004ce593  0fbf7c4616  MOVSX EDI,word ptr [ESI + EAX*0x2 + 0x16]
004ce598  8b153c7e5800  MOV EDX,dword ptr [0x00587e3c]
004ce59e  8b14ba  MOV EDX,dword ptr [EDX + EDI*0x4]
004ce5a1  66ff4a0e  DEC word ptr [EDX + 0xe]
004ce5a5  40  INC EAX
004ce5a6  0fbf5614  MOVSX EDX,word ptr [ESI + 0x14]
004ce5aa  39d0  CMP EAX,EDX
004ce5ac  72e5  JC 0x004ce593
004ce5ae  ba01000000  MOV EDX,0x1
004ce5b3  804e1202  OR byte ptr [ESI + 0x12],0x2
004ce5b7  892e  MOV dword ptr [ESI],EBP
004ce5b9  89f5  MOV EBP,ESI
004ce5bb  eb07  JMP 0x004ce5c4
004ce5c0  891e  MOV dword ptr [ESI],EBX
004ce5c2  89f3  MOV EBX,ESI
004ce5c4  41  INC ECX
004ce5c5  3b4c242c  CMP ECX,dword ptr [ESP + 0x2c]
004ce5c9  72a5  JC 0x004ce570
004ce5cb  85d2  TEST EDX,EDX
004ce5cd  7591  JNZ 0x004ce560
004ce5cf  ded9  FCOMPP
004ce5d1  85db  TEST EBX,EBX
004ce5d3  0f85dafeffff  JNZ 0x004ce4b3
004ce5d9  89e8  MOV EAX,EBP
004ce5db  83c410  ADD ESP,0x10
004ce5de  5d  POP EBP
004ce5df  5f  POP EDI
004ce5e0  5e  POP ESI
004ce5e1  5b  POP EBX
004ce5e2  c3  RET
```

```c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int * __cdecl FUN_004ce400(uint param_1,int param_2,uint param_3)

{
  short *psVar1;
  int *piVar2;
  float fVar3;
  float fVar4;
  bool bVar5;
  uint uVar6;
  uint uVar7;
  int *piVar8;
  int *piVar9;
  int *piVar10;
  uint local_20;
  
  piVar9 = (int *)0x0;
  do {
    local_20 = 0x20;
    piVar8 = (int *)0x0;
    bVar5 = false;
    if (0x20 < param_3) {
      do {
        piVar2 = *(int **)(DAT_00587e3c + local_20 * 4);
        if ((*(byte *)((int)piVar2 + 0x12) & 6) == 0) {
          if (*(short *)((int)piVar2 + 0xe) < param_2) {
            for (uVar7 = 0; uVar7 < (uint)(int)(short)piVar2[5]; uVar7 = uVar7 + 1) {
              psVar1 = (short *)(*(int *)(DAT_00587e3c +
                                         *(short *)((int)piVar2 + uVar7 * 2 + 0x16) * 4) + 0xe);
              *psVar1 = *psVar1 + -1;
            }
            *(byte *)((int)piVar2 + 0x12) = *(byte *)((int)piVar2 + 0x12) | 2;
            *piVar2 = (int)piVar9;
            bVar5 = true;
            piVar9 = piVar2;
          }
          else {
            *piVar2 = (int)piVar8;
            piVar8 = piVar2;
          }
        }
        local_20 = local_20 + 1;
      } while (local_20 < param_3);
    }
  } while (bVar5);
  if (piVar8 != (int *)0x0) {
    FUN_00532790(param_1);
  }
  while (piVar8 != (int *)0x0) {
    fVar3 = _DAT_0056309c;
    if ((short)piVar8[3] < DAT_00581b88) {
      fVar3 = (float)piVar8[2] / (float)(int)*(short *)((int)piVar8 + 0xe);
    }
    piVar10 = piVar8;
    for (piVar2 = (int *)*piVar8; piVar2 != (int *)0x0; piVar2 = (int *)*piVar2) {
      fVar4 = _DAT_005630a0;
      if ((short)piVar2[3] < DAT_00581b88) {
        fVar4 = (float)piVar2[2] / (float)(int)*(short *)((int)piVar2 + 0xe);
      }
      if ((byte)(fVar4 < fVar3 | (byte)((ushort)((ushort)(NAN(fVar4) || NAN(fVar3)) << 10) >> 8)) ==
          1) {
        piVar10 = piVar2;
        fVar3 = fVar4;
      }
    }
    for (uVar7 = 0; uVar7 < (uint)(int)(short)piVar10[5]; uVar7 = uVar7 + 1) {
      psVar1 = (short *)(*(int *)(DAT_00587e3c + *(short *)((int)piVar10 + uVar7 * 2 + 0x16) * 4) +
                        0xe);
      *psVar1 = *psVar1 + -1;
    }
    *(byte *)((int)piVar10 + 0x12) = *(byte *)((int)piVar10 + 0x12) | 2;
    *piVar10 = (int)piVar9;
    do {
      uVar7 = 0x20;
      piVar8 = (int *)0x0;
      bVar5 = false;
      if (0x20 < param_3) {
        do {
          piVar9 = *(int **)(DAT_00587e3c + uVar7 * 4);
          if ((*(byte *)((int)piVar9 + 0x12) & 6) == 0) {
            if (*(short *)((int)piVar9 + 0xe) < param_2) {
              for (uVar6 = 0; uVar6 < (uint)(int)(short)piVar9[5]; uVar6 = uVar6 + 1) {
                psVar1 = (short *)(*(int *)(DAT_00587e3c +
                                           *(short *)((int)piVar9 + uVar6 * 2 + 0x16) * 4) + 0xe);
                *psVar1 = *psVar1 + -1;
              }
              bVar5 = true;
              *(byte *)((int)piVar9 + 0x12) = *(byte *)((int)piVar9 + 0x12) | 2;
              *piVar9 = (int)piVar10;
              piVar10 = piVar9;
            }
            else {
              *piVar9 = (int)piVar8;
              piVar8 = piVar9;
            }
          }
          uVar7 = uVar7 + 1;
        } while (uVar7 < param_3);
      }
      piVar9 = piVar10;
    } while (bVar5);
  }
  return piVar9;
}


```


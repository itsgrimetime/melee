from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');root=Path('/tmp/c016-enc18-run-payload');root.mkdir(exist_ok=True);vs={}
src=Path('/tmp/c016-enc17-flat-boundary/caller-ac_value-run-value.c').read_text();a=src.index('static inline void hsd_803B3CD8_write_bits');b=src.index('static inline void jpeg_encode_component',a);writer=src[a:b]
for shape in ['local-bit-first','local-value-first','run-bit-first','run-for-comma']:
 h=writer.replace('hsd_803B3CD8_write_bits(s32 value','jpeg_write_run_payload(s32 run')
 if shape.startswith('local'):
  h=h.replace('    s32 bit;','    s32 bit;\n    s32 value;')
  init='    bit = length - 1;\n    value = run + 1;\n' if shape=='local-bit-first' else '    value = run + 1;\n    bit = length - 1;\n'
  h=h.replace('    for (bit = length - 1; bit >= 0; bit--) {',init+'    for (; bit >= 0; bit--) {')
 else:
  h=h.replace('if (value &','if (run &')
  replacement='    bit = length - 1;\n    run++;\n    for (; bit >= 0; bit--) {' if shape=='run-bit-first' else '    for (bit = length - 1, run++; bit >= 0; bit--) {'
  h=h.replace('    for (bit = length - 1; bit >= 0; bit--) {',replacement)
 full=src[:b]+h+src[b:]
 old='hsd_803B3CD8_write_bits((*run_out) + 1, length, &work);';new='jpeg_write_run_payload((*run_out), length, &work);';assert full.count(old)==1;vs[shape]=full.replace(old,new)
base=p.read_text();(root/'baseline.c').write_text(base);rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

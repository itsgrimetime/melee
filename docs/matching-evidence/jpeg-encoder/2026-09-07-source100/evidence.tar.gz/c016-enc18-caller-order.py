from pathlib import Path
import subprocess,json,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc18-caller-order');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
src=Path('/tmp/c016-enc18-run-cross/caller-index-run-bit-first-original.c').read_text();a=src.index('void hsd_803B3CD8(s32 component)');b=src.index('#pragma pop',a);part=src[a:b];old='    s32 ac_value;\n    s32 run;\n    s32 value;\n    s32 index;\n';assert old in part
preferred=('value','run','index','ac_value');orders=[preferred]+[o for o in itertools.permutations(['ac_value','run','value','index']) if o not in [preferred,('ac_value','run','value','index')]];rows=[]
try:
 for order in orders:
  name='-'.join(order);full=src[:a]+part.replace(old,''.join('    s32 '+v+';\n' for v in order))+src[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
  if row['score']==100:print('SOURCE100 candidate saved',root/(name+'.c'),flush=True);break
finally:p.write_text(base)

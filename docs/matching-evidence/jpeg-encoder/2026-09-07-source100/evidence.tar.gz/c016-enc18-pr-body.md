Match `hsd_803B3CD8` (JPEG coefficient encoding) at 100%. Reconstruct the component encoder with explicit inline helpers for bit length, bit output, and run payloads. Caller-owned temporaries and a scoped auto-inlining setting preserve the original register allocation, 104-byte frame, and call boundary. No stack padding is needed.

The six previously matched functions in this TU remain at 100%. RGB conversion (`hsd_803B3408`) remains unmatched, so the TU remains Linkable.

This builds on @fjooord’s merged #3358 and follows the index-before-field-offset technique in @sadkellz’s #3378.

Validation: encoder instruction comparison is identical; all seven matched functions report 100%; full GALE01 build passes.

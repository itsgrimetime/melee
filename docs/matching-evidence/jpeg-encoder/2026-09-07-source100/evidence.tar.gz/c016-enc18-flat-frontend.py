from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();candidate=Path('/tmp/c016-enc17-flat-boundary/caller-ac_value-run-value.c').read_text()
try:
 p.write_text(candidate)
 with open('/tmp/c016-enc18-flat-frontend.log','w') as log:
  r=subprocess.run(['melee-agent','debug','retro','dump',str(p),'-f','hsd_803B3CD8','--phases','frontend','--timeout','180','-O','/tmp/c016-enc18-flat-frontend'],stdout=log,stderr=subprocess.STDOUT)
 print('retail exit',r.returncode,flush=True)
finally:p.write_text(base)

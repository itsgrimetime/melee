from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc18-work-decl');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base);vs={}
for outer in ['inline-index','caller-index']:
 src=Path('/tmp/c016-enc17-flat-boundary/caller-ac_value-run-value.c' if outer=='inline-index' else '/tmp/c016-enc17-caller-length/index.c').read_text();a=src.index('static inline void jpeg_encode_component');b=src.index('void hsd_803B3CD8(s32 component)',a);fn=src[a:b]
 for place in ['after-top-locals','after-indexed','after-coefficient']:
  main=fn.replace('    JpegWork* work;\n','');decls=''
  if place in ['after-indexed','after-coefficient']:
   main=main.replace('        JpegWork* indexed;\n','');decls+='    JpegWork* indexed;\n'
  if place=='after-coefficient':
   main=main.replace('        s32 coefficient =','        coefficient =');decls+='    s32 coefficient;\n'
  main=main.replace('    work = (JpegWork*) &hsd_804D2648;',decls+'    JpegWork* work;\n\n    work = (JpegWork*) &hsd_804D2648;',1)
  vs[outer+'-'+place]=src[:a]+main+src[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

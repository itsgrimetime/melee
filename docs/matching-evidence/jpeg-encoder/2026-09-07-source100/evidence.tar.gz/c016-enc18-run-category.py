from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc18-run-category');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
src=Path('/tmp/c016-enc18-caller-order/value-run-index-ac_value.c').read_text();a=src.index('static inline s32 hsd_803B3CD8_bit_length');b=src.index('static inline void hsd_803B3CD8_write_byte',a);original=src[a:b];vs={}
for shape in ['reuse-increment','value-before-bit','value-after-bit','bit-first-reuse','for-comma-reuse']:
 h=original.replace('hsd_803B3CD8_bit_length','jpeg_run_bit_length')
 if shape.startswith('value-'):
  h=h.replace('jpeg_run_bit_length(s32 value)','jpeg_run_bit_length(s32 run)')
  h=h.replace('    s32 bit;','    s32 value;\n    s32 bit;' if shape=='value-before-bit' else '    s32 bit;\n    s32 value;')
  h=h.replace('    for (bit = 0x1F;', '    value = run + 1;\n    for (bit = 0x1F;')
 elif shape=='reuse-increment':h=h.replace('    for (bit = 0x1F;', '    value++;\n    for (bit = 0x1F;')
 elif shape=='bit-first-reuse':h=h.replace('    for (bit = 0x1F;', '    bit = 0x1F;\n    value++;\n    for (;')
 else:h=h.replace('for (bit = 0x1F;', 'for (bit = 0x1F, value++;')
 full=src[:b]+h+src[b:];old='hsd_803B3CD8_bit_length((*run_out) + 1)';assert full.count(old)==1;vs[shape]=full.replace(old,'jpeg_run_bit_length((*run_out))')
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
  if row['score']==100:print('SOURCE100 candidate saved',root/(name+'.c'),flush=True);break
finally:p.write_text(base)

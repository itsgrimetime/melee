from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc3-owner');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];decl='    struct {\n        JpegWork* work;\n    } state;';init='    state.work = (JpegWork*) &hsd_804D2648;\n';vs={}
for name,newdecl in [('flat-initializer','    JpegWork* work = (JpegWork*) &hsd_804D2648;'),('const-flat-initializer','    JpegWork* const work = (JpegWork*) &hsd_804D2648;')]:
 vs[name]=part.replace(decl,newdecl).replace(init,'').replace('state.work','work')
for name,newdecl in [('aggregate-initializer','    struct { JpegWork* work; } state = { (JpegWork*) &hsd_804D2648 };'),('const-aggregate-initializer','    const struct { JpegWork* work; } state = { (JpegWork*) &hsd_804D2648 };'),('const-member-initializer','    struct { JpegWork* const work; } state = { (JpegWork*) &hsd_804D2648 };')]:
 vs[name]=part.replace(decl,newdecl).replace(init,'')
for name,helper,call in [
 ('return-pointer-helper','static inline JpegWork* jpeg_work(void) { return (JpegWork*) &hsd_804D2648; }\n','jpeg_work()'),
 ('identity-pointer-helper','static inline JpegWork* jpeg_work(JpegWork* work) { return work; }\n','jpeg_work((JpegWork*) &hsd_804D2648)'),
 ('return-void-pointer-helper','static inline void* jpeg_work(void) { return &hsd_804D2648; }\n','jpeg_work()')]:
 vs[name]=helper+part.replace('(JpegWork*) &hsd_804D2648',call)
helper='static inline void jpeg_get_work(JpegWork** out) { *out = (JpegWork*) &hsd_804D2648; }\n'
vs['out-pointer-helper']=helper+part.replace(init,'    jpeg_get_work(&state.work);\n')
helper='typedef struct JpegWorkRef { JpegWork* work; } JpegWorkRef;\nstatic inline JpegWorkRef jpeg_work(void) { JpegWorkRef ref; ref.work = (JpegWork*) &hsd_804D2648; return ref; }\n'
vs['return-aggregate-helper']=helper+part.replace(decl,'    JpegWorkRef state;').replace(init,'    state = jpeg_work();\n')
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];asm=asm.splitlines() if isinstance(asm,str) else asm;i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc3-owner-qualifiers');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];decl='    struct {\n        JpegWork* work;\n    } state;';init='    state.work = (JpegWork*) &hsd_804D2648;\n';vs={}

for qualifier in ('register ', 'register const ', ''):
 for typ in ('JpegWork*', 'void*', 'u8*'):
  if qualifier=='register const ' and typ!='JpegWork*':continue
  d='    '+qualifier+typ+' work;'
  s=part.replace(decl,d).replace(init,'    work = ('+typ+') &hsd_804D2648;\n')
  s=s.replace('state.work', 'work' if typ=='JpegWork*' else '((JpegWork*) work)')
  if qualifier=='register const ':s=s.replace('register const JpegWork*','register JpegWork* const').replace('    register JpegWork* const work;','    register JpegWork* const work = (JpegWork*) &hsd_804D2648;').replace('    work = (JpegWork*) &hsd_804D2648;\n','')
  vs[(qualifier.strip() or 'plain').replace(' ','-')+'-'+typ.replace('*','ptr')]=s
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];asm=asm.splitlines() if isinstance(asm,str) else asm;i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

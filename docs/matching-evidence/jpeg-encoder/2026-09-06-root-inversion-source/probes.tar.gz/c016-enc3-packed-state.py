from pathlib import Path
src=Path('/tmp/c016-enc3-owner.py').read_text()
header=src[:src.index('for name,newdecl')].replace('/tmp/c016-enc3-owner','/tmp/c016-enc3-packed-state')
gen='''
import re
for group,fields in [('counters',[('s32','value'),('s32','length'),('s32','run'),('s32','index')]),('tables',[('JpegEncodeTables*','tables'),('u16*','dc_code'),('u8*','dc_length'),('u16*','ac_code'),('u8*','ac_length')])]:
 for pos in range(len(fields)+1):
  s=part.replace(decl+'\\n','')
  for typ,name in fields:
   s=s.replace('    '+typ+' '+name+';\\n','')
   s=re.sub(r'(?<![.\\w])'+name+r'\\b','state.'+name,s)
  members=fields.copy();members.insert(pos,('JpegWork*','work'))
  d='    struct {\\n'+''.join('        '+typ+' '+name+';\\n' for typ,name in members)+'    } state;\\n'
  s=s.replace('{\\n','{\\n'+d,1)
  vs[group+'-work'+str(pos)]=s
'''
Path('/tmp/c016-enc3-packed-state-run.py').write_text(header+gen+src[src.index('rows=[]'):])

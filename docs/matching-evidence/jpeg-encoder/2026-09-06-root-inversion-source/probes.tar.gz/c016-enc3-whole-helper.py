from pathlib import Path
src=Path('/tmp/c016-enc3-owner.py').read_text()
header=src[:src.index('for name,newdecl')].replace('/tmp/c016-enc3-owner','/tmp/c016-enc3-whole-helper')
gen='''
for shape in ('pointer','struct','tables','all-tables'):
 for reverse in (False,True):
  s=part.replace('void hsd_803B3CD8(s32 component)','static inline void jpeg_encode_impl(PARAMS)')
  s=s.replace(init,'')
  params=['s32 component'];args=['component']
  if shape=='struct':
   typedef='typedef struct JpegEncoderRef { JpegWork* work; } JpegEncoderRef;\\n'
   s=s.replace(decl,'');params+=['JpegEncoderRef state'];args+=['state']
   wrapper=decl+'\\n'+init
  else:
   typedef='';s=s.replace(decl,'').replace('state.work','work');params+=['JpegWork* work'];args+=['(JpegWork*) &hsd_804D2648'];wrapper=''
  if shape in ('tables','all-tables'):
   s=s.replace('    JpegEncodeTables* tables;\\n','').replace('    tables = (JpegEncodeTables*) lbl_80430C40;\\n','')
   params+=['JpegEncodeTables* tables'];args+=['(JpegEncodeTables*) lbl_80430C40']
  if shape=='all-tables':
   for typ,name,val in [('u16*','dc_code','component == 0 ? lbl_80431678 : lbl_8043169C'),('u8*','dc_length','component == 0 ? lbl_80431690 : lbl_804316B4')]:
    s=s.replace('    '+typ+' '+name+';\\n','').replace('    '+name+' = '+val+';\\n','')
    params+=[typ+' '+name];args+=[val]
  if reverse:params.reverse();args.reverse()
  if shape=='struct':wrapper='    JpegEncoderRef state;\\n'+init
  s=typedef+s.replace('PARAMS',', '.join(params))+'\\nvoid hsd_803B3CD8(s32 component) {\\n'+wrapper+'    jpeg_encode_impl('+', '.join(args)+');\\n}\\n\\n'
  vs[shape+('-reversed' if reverse else '')]=s
'''
Path('/tmp/c016-enc3-whole-helper-run.py').write_text(header+gen+src[src.index('rows=[]'):])

from pathlib import Path
src=Path('/tmp/c016-enc3-owner.py').read_text()
header=src[:src.index('for name,newdecl')].replace('/tmp/c016-enc3-owner','/tmp/c016-enc3-declarations')
gen='''
for flat in (False, True):
 for anchor in ['    JpegEncodeTables* tables;', '    u16* dc_code;', '    u8* dc_length;', '    u16* ac_code;', '    u8* ac_length;', '    s32 value;', '    s32 length;', '    s32 run;', '    s32 index;', '    PAD_STACK(16);']:
  s=part.replace(decl+'\\n','')
  d='    JpegWork* work;' if flat else decl
  s=s.replace(anchor,d+'\\n'+anchor)
  if flat:s=s.replace('state.work','work')
  vs[('flat-' if flat else 'struct-')+anchor.strip().replace('*','ptr').replace(' ','-').replace(';','').replace('(','').replace(')','')]=s
'''
Path('/tmp/c016-enc3-declarations-run.py').write_text(header+gen+src[src.index('rows=[]'):])

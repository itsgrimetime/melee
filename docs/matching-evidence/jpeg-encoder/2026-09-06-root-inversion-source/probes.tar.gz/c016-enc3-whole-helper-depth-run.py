from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc3-whole-helper-depth');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];decl='    struct {\n        JpegWork* work;\n    } state;';init='    state.work = (JpegWork*) &hsd_804D2648;\n';vs={}

for shape in ('pointer','struct','tables','all-tables'):
 for reverse in (False,True):
  s=part.replace('void hsd_803B3CD8(s32 component)','static inline void jpeg_encode_impl(PARAMS)')
  s=s.replace(init,'')
  params=['s32 component'];args=['component']
  if shape=='struct':
   typedef='typedef struct JpegEncoderRef { JpegWork* work; } JpegEncoderRef;\n'
   s=s.replace(decl,'');params+=['JpegEncoderRef state'];args+=['state']
   wrapper=decl+'\n'+init
  else:
   typedef='';s=s.replace(decl,'').replace('state.work','work');params+=['JpegWork* work'];args+=['(JpegWork*) &hsd_804D2648'];wrapper=''
  if shape in ('tables','all-tables'):
   s=s.replace('    JpegEncodeTables* tables;\n','').replace('    tables = (JpegEncodeTables*) lbl_80430C40;\n','')
   params+=['JpegEncodeTables* tables'];args+=['(JpegEncodeTables*) lbl_80430C40']
  if shape=='all-tables':
   for typ,name,val in [('u16*','dc_code','component == 0 ? lbl_80431678 : lbl_8043169C'),('u8*','dc_length','component == 0 ? lbl_80431690 : lbl_804316B4')]:
    s=s.replace('    '+typ+' '+name+';\n','').replace('    '+name+' = '+val+';\n','')
    params+=[typ+' '+name];args+=[val]
  if reverse:params.reverse();args.reverse()
  if shape=='struct':wrapper='    JpegEncoderRef state;\n'+init
  s=typedef+s.replace('PARAMS',', '.join(params))+'\nvoid hsd_803B3CD8(s32 component) {\n'+wrapper+'    jpeg_encode_impl('+', '.join(args)+');\n}\n\n'
  vs[shape+('-reversed' if reverse else '')]=s
vs={name+'-depth'+str(depth): '#pragma push\n#pragma inline_depth('+str(depth)+')\n'+body+'#pragma pop\n' for name,body in vs.items() for depth in (4,8)}
rows=[]
try:
 for name,s in vs.items():
  full=base[:a]+s+base[b:];p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];asm=asm.splitlines() if isinstance(asm,str) else asm;i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import json,tarfile,hashlib
root=Path('docs/matching-evidence/jpeg-encoder/2026-09-07-state-pointer');root.mkdir(parents=True,exist_ok=True);files={};rows=[]
for name in ['rebased-owner','state-pointer','sequenced-owners','huffman-helper','context-order','bit-helpers','huffman-widths']:
 d=Path('/tmp/c016-enc11-'+name);rows.extend({'family':name,**r} for r in json.loads((d/'results.json').read_text()))
 for p in d.rglob('*'):
  if p.is_file():files[str(p.relative_to('/tmp'))]=p
 p=Path('/tmp/c016-enc11-'+name+'.py');files[p.name]=p
for p in Path('/tmp/c016-enc11-state-pointer-retail').rglob('*'):
 if p.is_file():files[str(p.relative_to('/tmp'))]=p
for name in ['c016-enc11-state-pointer-retail.py','c016-enc11-state-pointer-retail.log','c016-enc11-compare-allocator.py','c016-enc11-state-pointer-comparison.json','c016-enc11-public-scratch.txt','c016-enc11-public-fork.txt','c016-enc11-final.json','c016-enc11-final.log','c016-enc11-build.log','c016-enc11-archive.py']:
 p=Path('/tmp')/name;files[name]=p
files['baseline-retail/backend-trace.v1.json']=Path('/tmp/c016-enc4-retail/backend-trace.v1.json')
x=json.loads(Path('/tmp/c016-enc11-final.json').read_text());assert x['fuzzy_match_percent']==99.70266
summary={'function':'hsd_803B3CD8','retained_percent':x['fuzzy_match_percent'],'retained_source_sha256':hashlib.sha256(Path('src/sysdolphin/baselib/hsd_3B34.c').read_bytes()).hexdigest(),'attempts':len(rows),'valid_attempts':sum(r['score'] is not None for r in rows),'retained_source_changes':False,'retail_comparison':json.loads(Path('/tmp/c016-enc11-state-pointer-comparison.json').read_text()),'public_family':{'method':'Read-only browser Family tab, followed by sync fetch of both members','members':[{'slug':'mbSPH','owner':'itsgrimetime','score':190,'max_score':63900},{'slug':'yajTB','owner':'itsgrimetime','score':190,'max_score':63900}],'better_family_member':False},'tool_issue':1533,'validation':{'ordinary_compile':'99.70266%, frame104, 38 register-only differences','ninja':'exit0','source100':False},'excluded':'Raw Cloudflare challenge responses and empty failed CLI suggestions are deliberately excluded.'}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');archive=root/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
manifest={'summary':summary,'runs':rows,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as t:
 for n,digest in manifest['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==digest
print(len(rows),'attempts;',len(files),'verified members;',archive.stat().st_size,'bytes')

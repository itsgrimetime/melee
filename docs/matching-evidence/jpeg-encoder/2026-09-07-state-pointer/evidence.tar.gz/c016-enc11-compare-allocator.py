from pathlib import Path
import json
before=json.load(open('/tmp/c016-enc4-retail/backend-trace.v1.json'))['functions'][0]['regalloc']['classes'][0]
after=json.load(open('/tmp/c016-enc11-state-pointer-retail/backend-trace.v1.json'))['functions'][0]['regalloc']['classes'][0]
r={'field_equality':{k:before[k]==after.get(k) for k in before},'before_counts':{k:len(before[k]) for k in ('nodes','edges','color_decisions')},'after_counts':{k:len(after[k]) for k in ('nodes','edges','color_decisions')},'scope':'Recorded retail GPR class at colorgraph return plus recorded decisions/orders; not a comparison of all earlier compiler passes.'}
assert all(r['field_equality'].values());Path('/tmp/c016-enc11-state-pointer-comparison.json').write_text(json.dumps(r,indent=2)+'\n');print(r['before_counts'])

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc11-huffman-widths');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
src=Path('/tmp/c016-enc11-huffman-helper/all-length-first-work-last.c').read_text();a=src.index('static inline void jpeg_write_huffman');b=src.index('void hsd_803B3CD8(s32 component)',a);h=src[a:b];vs={}
for name,vtype,ltype in [('code-u16','u16','s32'),('length-u8','s32','u8'),('compact','u16','u8'),('code-uint','unsigned int','s32'),('code-u32','u32','s32')]:
 new=h.replace('s32 value = codes[symbol];',vtype+' value = codes[symbol];').replace('s32 length = lengths[symbol];',ltype+' length = lengths[symbol];');vs[name]=src[:a]+new+src[b:]
# Signed table view followed by unsigned-short conversion retains all original code bits.
new=h.replace('u16* codes','s16* codes').replace('s32 value = codes[symbol];','u16 value = (u16) codes[symbol];')
s=src[:a]+new+src[b:];s=s.replace('jpeg_write_huffman(length, dc_code,','jpeg_write_huffman(length, (s16*) dc_code,').replace('jpeg_write_huffman(length, ac_code,','jpeg_write_huffman(length, (s16*) ac_code,').replace('jpeg_write_huffman(0, ac_code,','jpeg_write_huffman(0, (s16*) ac_code,');vs['signed-code-view']=s
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

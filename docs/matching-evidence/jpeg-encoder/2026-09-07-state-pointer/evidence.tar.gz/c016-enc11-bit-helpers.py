from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc11-bit-helpers');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline s32 hsd_803B3CD8_bit_length');b=base.index('static inline void hsd_803B3CD8_write_byte',a);c=base.index('static inline void hsd_803B3CD8_write_bits',b);d=base.index('void hsd_803B3CD8(s32 component)',c);vs={}
for shape in ('mask','test-mask','test-bool'):
 if shape=='mask':helper='static inline s32 jpeg_bit_mask(s32 bit) { return 1 << bit; }\n\n';old='value & (1 << bit)';new='value & jpeg_bit_mask(bit)'
 else:
  helper='static inline s32 jpeg_test_bit(s32 value, s32 bit) { return '+('value & (1 << bit)' if shape=='test-mask' else '(value & (1 << bit)) != 0')+'; }\n\n';old='value & (1 << bit)';new='jpeg_test_bit(value, bit)'
 for scope in ('length','writer','both'):
  left=base[a:b];right=base[c:d]
  if scope in ('length','both'):assert old in left;left=left.replace(old,new)
  if scope in ('writer','both'):assert old in right;right=right.replace(old,new)
  vs[shape+'-'+scope]=base[:a]+helper+left+base[b:c]+right+base[d:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

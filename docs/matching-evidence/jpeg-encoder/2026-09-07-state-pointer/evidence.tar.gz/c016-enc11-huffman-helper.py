from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc11-huffman-helper');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline void hsd_803B3CD8_write_bits');b=base.index('void hsd_803B3CD8(s32 component)',a);end=base.index('static const s32 lbl_804DEB88',b);writer=base[a:b];body=writer[writer.index('{')+1:writer.rfind('}')];fn=base[b:end];vs={}
for order in ('length-first','value-first'):
 for workorder in ('last','first'):
  for scope in ('all','dc-only'):
   decls=['s32 value = codes[symbol];','s32 length = lengths[symbol];']
   if order=='length-first':decls.reverse()
   params=['s32 symbol','u16* codes','u8* lengths'];params=(['JpegWork* work']+params) if workorder=='first' else (params+['JpegWork* work'])
   helper='static inline void jpeg_write_huffman('+', '.join(params)+')\n{\n    '+'\n    '.join(decls)+body+'}\n\n'
   s=fn
   for code,length,index in [('dc_code','dc_length','length')]+([('ac_code','ac_length','length'),('ac_code','ac_length','0')] if scope=='all' else []):
    pat=r'hsd_803B3CD8_write_bits\('+re.escape(code+'['+index+']')+r',\s*'+re.escape(length+'['+index+']')+r',\s*state.work\)'
    args=[index,code,length];args=(['state.work']+args) if workorder=='first' else (args+['state.work'])
    s,n=re.subn(pat,'jpeg_write_huffman('+', '.join(args)+')',s);assert n==(2 if code=='ac_code' and index=='length' else 1)
   vs[f'{scope}-{order}-work-{workorder}']=base[:b]+helper+s+base[end:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

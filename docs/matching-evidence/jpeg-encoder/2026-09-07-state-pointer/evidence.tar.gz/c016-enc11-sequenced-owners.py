from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc11-sequenced-owners');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];vs={}
for owner in ('member','flat'):
 s=part
 if owner=='flat':s=s.replace('    struct {\n        JpegWork* work;\n    } state;','    JpegWork* work;').replace('state.work','work')
 ref='state.work' if owner=='member' else 'work';assignment=f'    {ref} = (JpegWork*) &hsd_804D2648;'
 for form in ('comma-self','comma-direct','statement-self','embedded-first-call'):
  if form=='comma-self':new=f'    {ref} = ({ref} = (JpegWork*) &hsd_804D2648, {ref});'
  elif form=='comma-direct':new=f'    ({ref} = (JpegWork*) &hsd_804D2648, {ref} = {ref});'
  elif form=='statement-self':new=assignment+f'\n    {ref} = {ref};'
  else:new=assignment
  t=s.replace(assignment,new)
  if form=='embedded-first-call':t=t.replace('dc_code[length], dc_length[length], '+ref+')','dc_code[length], dc_length[length], ('+ref+' = '+ref+'))')
  vs[owner+'-'+form]=base[:a]+t+base[b:]
# Sequenced initializers for loop temporaries: comma provides a real sequence point.
for helper in ('bit-length','write-bits'):
 start=base.index('static inline s32 hsd_803B3CD8_bit_length') if helper=='bit-length' else base.index('static inline void hsd_803B3CD8_write_bits')
 end=base.index('static inline void hsd_803B3CD8_write_byte',start) if helper=='bit-length' else a
 h=base[start:end]
 init='0x1F' if helper=='bit-length' else 'length - 1'
 h=h.replace('bit = '+init+';', 'bit = (bit = '+init+', bit);')
 vs[helper+'-comma-loop']=base[:start]+h+base[end:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

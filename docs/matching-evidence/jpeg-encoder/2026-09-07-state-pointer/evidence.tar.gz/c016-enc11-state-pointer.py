from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc11-state-pointer');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline s32 hsd_803B3CD8_bit_length');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];vs={}
for mode in ('both','bits-only'):
 for const in (False,True):
  s=part;typ=('const ' if const else '')+'JpegEncoderState*';s=s.replace('    struct {\n        JpegWork* work;\n    } state;','    JpegEncoderState state;')
  s=s.replace('s32 length,\n                                           JpegWork* work)','s32 length,\n                                           '+typ+' work)')
  if mode=='both':
   s=s.replace('hsd_803B3CD8_write_byte(u8 byte, JpegWork* work)','hsd_803B3CD8_write_byte(u8 byte, '+typ+' work)').replace('&work->jmp_buf','&work->work->jmp_buf')
  else:
   s=s.replace('hsd_803B3CD8_write_byte(hsd_804D79B0[0], work)','hsd_803B3CD8_write_byte(hsd_804D79B0[0], work->work)').replace('hsd_803B3CD8_write_byte(0, work)','hsd_803B3CD8_write_byte(0, work->work)')
  s=s.replace(', state.work)',', &state)').replace(',\n                                    state.work)',',\n                                    &state)')
  vs[mode+('-const' if const else '')]=base[:a]+'typedef struct JpegEncoderState { JpegWork* work; } JpegEncoderState;\n\n'+s+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

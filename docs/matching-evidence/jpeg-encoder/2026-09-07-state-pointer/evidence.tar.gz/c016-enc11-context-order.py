from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc11-context-order');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline s32 hsd_803B3CD8_bit_length');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];vs={}
for family,mapping in [('state-names',{'state':'encoder','work':'buffer'}),('descriptive-locals',{'state':'encoder','work':'buffer','value':'bits_value','length':'bit_count','run':'zero_run','index':'coefficient_index','bit':'bit_index','indexed':'indexed_work','coefficient':'coefficient_value','ac_value':'ac_coefficient','tables':'huffman_tables','dc_code':'dc_codes','ac_code':'ac_codes','dc_length':'dc_sizes','ac_length':'ac_sizes'}),('helper-names',{'hsd_803B3CD8_bit_length':'jpeg_bit_length','hsd_803B3CD8_write_bits':'jpeg_write_bits','hsd_803B3CD8_write_byte':'jpeg_write_byte'})]:
 pat=r'\b('+ '|'.join(mapping)+r')\b';s=re.sub(pat,lambda m:mapping[m.group()],part);vs[family]=base[:a]+s+base[b:]
i=base.index('static inline void hsd_803B3CD8_write_byte',a);j=base.index('static inline void hsd_803B3CD8_write_bits',i);k=base.index('void hsd_803B3CD8(s32 component)',j)
length=base[a:i];byte=base[i:j];bits=base[j:k]
vs['length-after-byte']=base[:a]+byte+length+bits+base[k:]
vs['length-after-bits']=base[:a]+byte+bits+length+base[k:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

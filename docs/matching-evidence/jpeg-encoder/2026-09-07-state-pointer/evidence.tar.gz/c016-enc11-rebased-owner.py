from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc11-rebased-owner');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];vs={}
for field,offset in [('coef',0x718),('prev_dc',0x818)]:
 for owner in ('member','flat'):
  for access in ('recovered-parent','direct-field'):
   s=part;old='    struct {\n        JpegWork* work;\n    } state;';new='    struct {\n        s32* buffer;\n    } state;' if owner=='member' else '    s32* buffer;';s=s.replace(old,new);ref='state.buffer' if owner=='member' else 'buffer'
   s=s.replace('    state.work = (JpegWork*) &hsd_804D2648;','    '+ref+' = ((JpegWork*) &hsd_804D2648)->data.'+field+';')
   if access=='direct-field':s=s.replace('state.work->data.'+field,ref)
   # Address-to-integer roundtrip is supported by the 32-bit target; avoid out-of-array pointer arithmetic.
   s=s.replace('state.work','((JpegWork*) ((u32) '+ref+' - '+hex(offset)+'))')
   vs[f'{field}-{owner}-{access}']=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

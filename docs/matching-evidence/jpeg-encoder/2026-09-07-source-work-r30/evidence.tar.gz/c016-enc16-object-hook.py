"""Bounded read-only preallocation object-list diagnostic; no compiler writes."""
def intervene(ctx):
 import json
 gdb=ctx.gdb;entries=ctx.table['entries'];state={'active':False,'matched':False,'snapshots':[],'errors':[]};breakpoints=[]
 lists={'initial':0x5882ac,'post_initial':0x58806c,'local':0x587fb8,'trailing':0x5876a0}
 def u32(a):return ctx.u32(a)
 def s16(a):return int.from_bytes(ctx.read(a,2),'little',signed=True)
 def bounded(a):return 0x600000<=a<0x4000000
 def name(a):
  h=u32(a+0xa)
  if not 0x400000<=h<0x4000000:return None
  return bytes(ctx.read(h+0xa,160)).split(b'\0',1)[0].decode('utf-8','replace')
 def snapshot(stage):
  out={'stage':stage,'pc':int(gdb.parse_and_eval('$pc')),'lists':{},'gpr_next':s16(0x58846e),'gpr_coalesce_first':s16(0x5882da),'gpr_coalesce_last':s16(0x5882e2)}
  for label,va in lists.items():
   rows=[];ptr=u32(va);seen=set()
   while ptr:
    if not bounded(ptr) or ptr in seen or len(rows)>=512:raise ValueError('invalid/cyclic/oversized list '+label)
    seen.add(ptr);obj=u32(ptr+4)
    if not bounded(obj):raise ValueError('invalid object '+hex(obj))
    raw=bytes(ctx.read(obj,0x36));kind=raw[2];info=u32(obj+(0x26 if kind==1 else 0x2e)) if kind in [0,1,2] else 0
    row={'list_node':hex(ptr),'object':hex(obj),'name':name(obj),'kind':kind,'raw_object':raw.hex(),'info_address':hex(info)}
    if info:
     if not bounded(info):raise ValueError('invalid info '+hex(info))
     iraw=bytes(ctx.read(info,0x2c));row.update({'raw_info':iraw.hex(),'register_slot_24':s16(info+0x24),'register_slot_26':s16(info+0x26),'is_fpr':iraw[0x28],'is_vector':iraw[0x2a],'excluded_22':iraw[0x22],'candidate_23':iraw[0x23]})
    rows.append(row);ptr=u32(ptr)
   out['lists'][label]=rows
  state['snapshots'].append(out)
 class Start(gdb.Breakpoint):
  def stop(self):
   try:
    obj=u32(int(gdb.parse_and_eval('$esp'))+8);state['active']=ctx.cad.MwccObject.load(obj,load_linkname=False).name==ctx.fn
    if state['active']:state['matched']=True
   except Exception as exc:state['errors'].append({'stage':'start','error':str(exc)});state['active']=False
   return False
 class Preallocate(gdb.Breakpoint):
  def stop(self):
   if not state['active']:return False
   try:
    snapshot('preallocate_entry');ret=u32(int(gdb.parse_and_eval('$esp')))
    if not 0x400000<=ret<0x600000:raise ValueError('invalid return pc')
    fired={'done':False}
    class Returned(gdb.Breakpoint):
     def stop(self):
      if fired['done']:return False
      fired['done']=True
      try:snapshot('preallocate_return')
      except Exception as exc:state['errors'].append({'stage':'return','error':str(exc)})
      return False
    breakpoints.append(Returned('*'+hex(ret)))
   except Exception as exc:state['errors'].append({'stage':'entry','error':str(exc)})
   return False
 class End(gdb.Breakpoint):
  def stop(self):state['active']=False;return False
 breakpoints.extend([Start('*'+hex(entries['codegen_start']['va'])),Preallocate('*0x437230'),End('*'+hex(entries['codegen_end']['va']))])
 try:ctx.cont()
 finally:
  state.update({'schema':'c016-object-preallocation-diagnostic-v1','function':ctx.fn,'read_only':True,'scope':'Raw before/after object-list reads. Field layout from high-level compiler reconstruction, not yet independently proven by this probe. No linkname helper calls or compiler data mutations.','compiler_sha256':'ccf4b465cec73b5aae9c5c5543dcf8cda8a62aba246f89e2e0b200d742f2e55c'})
  with open(ctx.out_dir+'/preallocation-objects.json','w') as f:json.dump(state,f,indent=2)

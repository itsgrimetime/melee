from pathlib import Path
import json,re,difflib,collections
x=json.load(open('/tmp/c016-enc17-flat-boundary/caller-ac_value-run-value.json'))
def norm(s):
 s=re.sub(r'^.*?\t','',s);s=re.sub(r'\br\d+\b','rN',s);return re.sub(r'<[^>]+>','LABEL',s)
c=[norm(s) for s in x['current_asm']];t=[norm(s) for s in x['target_asm']];changes=[]
for tag,a,b,d,e in difflib.SequenceMatcher(None,t,c,autojunk=False).get_opcodes():
 if tag!='equal':changes.append({'tag':tag,'target':x['target_asm'][a:b],'current':x['current_asm'][d:e]})
trace=json.load(open('/tmp/c016-enc17-flat-retail/backend-trace.v1.json'))['functions'][0]['regalloc']['classes'][0]
work=next(m for m in trace['coalesce']['mappings'] if m['alias']==105);assert work['root']==98 and work['root_phys']==30
assert [(d['ig_id'],d['assigned_phys']) for d in trace['color_decisions'][:2]]==[(101,31),(98,30)]
obj=json.load(open('/tmp/c016-enc17-objects-flat/preallocation-objects.json'));assert obj['matched'] and not obj['errors'];after=obj['snapshots'][-1]
objects=[r for ls in after['lists'].values() for r in ls];names={r['register_slot_24']:r['name'] for r in objects if r.get('register_slot_24')}
assert names[98]=='@173' and after['gpr_coalesce_first']==36
assigned=[r['register_slot_24'] for r in objects if r.get('register_slot_24',0)>=32 and not r.get('is_fpr') and not r.get('is_vector')];assert sorted(assigned)==list(range(32,104))
result={'source_candidate':'caller-ac_value-run-value.c','ordinary_match':x['fuzzy_match_percent'],'ordinary_frame':x['classification']['stack_frame_sizes'],'ordinary_register_diff':x['classification']['register_allocation_guidance']['register_only_count'],'ordinary_alignment_scope':'Registers and branch labels normalized; full ordinary JSON retained. This is not byte equality.','normalized_alignment_changes':changes,'retail':{'nodes':len(trace['nodes']),'edges':len(trace['edges']),'color_decisions':len(trace['color_decisions']),'leading':[(d['ig_id'],d['assigned_phys']) for d in trace['color_decisions'][:10]],'work_merge':work},'preallocation':{'first':36,'assigned_slots':[32,103],'work_object':'@173','work_slot':98,'named_caller':{r['name']:r.get('register_slot_24') for r in objects if not r['name'].startswith('@')},'first_selected_object':names[101]},'scope':'Work r30 is achieved by ordinary C and corroborated by read-only retail traces; overall candidate is worse than99.70266. Semantic object role uses the source and global-address merge/ordinary uses, not a fabricated normal-trace source attribution. No physical override.'}
Path('/tmp/c016-enc17-source-r30-summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc17-inline-flat');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base);vs={}
a=base.index('static inline s32 hsd_803B3CD8_bit_length');f=base.index('void hsd_803B3CD8(s32 component)',a);b=base.index('static const s32 lbl_804DEB88',f);helpers=base[a:f];fn=base[f:b]
fn=fn.replace('void hsd_803B3CD8(s32 component)','static inline void jpeg_encode_component(s32 component)').replace('    struct {\n        JpegWork* work;\n    } state;','    JpegWork* work;').replace('state.work','work')
wrapper='void hsd_803B3CD8(s32 component)\n{\n    jpeg_encode_component(component);\n}\n\n'
for style in ['value','pointer','const-pointer']:
 h=helpers;main=fn
 if style!='value':
  # Pass the address of the local pointer through both output layers.
  h=h.replace('u8 byte, JpegWork* work','u8 byte, JpegWork*'+(' const' if style=='const-pointer' else '')+'* work').replace('JpegWork* work)\n{\n    s32 bit;','JpegWork*'+(' const' if style=='const-pointer' else '')+'* work)\n{\n    s32 bit;')
  h=h.replace('&work->jmp_buf','&(*work)->jmp_buf')
  main=main.replace(', work);',', &work);').replace('                                    work);','                                    &work);')
 for result in ['local','direct']:
  hh=h
  if result=='direct':hh=hh.replace('            s32 result = bit + 1;\n\n            return result;','            return bit + 1;')
  vs[style+'-'+result]=base[:a]+'#pragma push\n#pragma inline_depth(8)\n'+hh+main+wrapper+'#pragma pop\n\n'+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

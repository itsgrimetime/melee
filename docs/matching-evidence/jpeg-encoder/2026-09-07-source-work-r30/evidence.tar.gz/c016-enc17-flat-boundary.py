from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc17-flat-boundary');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
src=Path('/tmp/c016-enc17-inline-flat/pointer-direct.c').read_text();a=src.index('static inline void jpeg_encode_component');b=src.index('void hsd_803B3CD8(s32 component)',a);e=src.index('#pragma pop',b);fn=src[a:b];vs={}
for variables in [['ac_value'],['ac_value','run'],['ac_value','value'],['ac_value','run','value']]:
 main=fn
 for v in variables:
  if v=='ac_value':main=main.replace('        s32 ac_value = coefficient;','        (*ac_value_out) = coefficient;')
  else:main=main.replace('    s32 '+v+';\n','')
  main=re.sub(r'\b'+v+r'\b','(*'+v+'_out)',main)
 main=main.replace('jpeg_encode_component(s32 component)','jpeg_encode_component(s32 component, '+', '.join('s32* '+v+'_out' for v in variables)+')')
 wrapper='void hsd_803B3CD8(s32 component)\n{\n'+''.join('    s32 '+v+';\n' for v in variables)+'    jpeg_encode_component(component, '+', '.join('&'+v for v in variables)+');\n}\n\n'
 vs['caller-'+'-'.join(variables)]=src[:a]+main+wrapper+src[e:]
for order in ['work-first','work-last']:
 params='JpegWork* work, s32 component' if order=='work-first' else 's32 component, JpegWork* work';args='(JpegWork*) &hsd_804D2648, component' if order=='work-first' else 'component, (JpegWork*) &hsd_804D2648'
 main=fn.replace('    JpegWork* work;\n','').replace('jpeg_encode_component(s32 component)','jpeg_encode_component('+params+')')
 wrapper='void hsd_803B3CD8(s32 component)\n{\n    jpeg_encode_component('+args+');\n}\n\n';vs['reassigned-parameter-'+order]=src[:a]+main+wrapper+src[e:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

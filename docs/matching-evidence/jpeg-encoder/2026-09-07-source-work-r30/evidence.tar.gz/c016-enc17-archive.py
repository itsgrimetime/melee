from pathlib import Path
import json,hashlib,tarfile
root=Path('docs/matching-evidence/jpeg-encoder/2026-09-07-source-work-r30');root.mkdir(parents=True,exist_ok=True);files={};rows=[]
for p in Path('/tmp').glob('c016-enc17-*'):
 for q in ([p] if p.is_file() else p.rglob('*')):
  if q.is_file():files[str(q.relative_to('/tmp'))]=q
for family in ['inline-flat','flat-boundary','caller-length']:
 rows.extend({'family':family,**r} for r in json.loads(Path('/tmp/c016-enc17-'+family+'/results.json').read_text()))
files['c016-enc16-object-hook.py']=Path('/tmp/c016-enc16-object-hook.py')
x=json.loads(Path('/tmp/c016-enc17-final.json').read_text());assert x['fuzzy_match_percent']==99.70266
summary={'function':'hsd_803B3CD8','retained_percent':99.70266,'source100':False,'source_changes_retained':False,'source_sha256':hashlib.sha256(Path('src/sysdolphin/baselib/hsd_3B34.c').read_bytes()).hexdigest(),'valid_compiles':sum(r.get('score') is not None for r in rows),'compile_attempts':len(rows),'lead':{'candidate':'c016-enc17-flat-boundary/caller-ac_value-run-value.c','ordinary_score':99.02973,'ordinary_frame':104,'ordinary_work_register':30,'ordinary_register_differences':95,'additional_difference':'run+1 calculation reordered before bit-count decrement','retail_work_merge':'105->98/r30','retail_work_select_position':1,'preallocation_object':'@173','preallocation_first':36,'source100':False},'validation':{'frame':104,'instructions':639,'register_only_differences':38,'full_build':'exit0','matched_neighbors':6}}
assert len(rows)==16 and summary['valid_compiles']==16
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');archive=root/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
manifest={'summary':summary,'runs':rows,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as t:
 for n,d in manifest['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==d
print(len(files),'verified members;',archive.stat().st_size,'bytes;',len(rows),'compiles')

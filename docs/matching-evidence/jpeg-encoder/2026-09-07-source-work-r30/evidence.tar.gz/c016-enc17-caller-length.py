from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc17-caller-length');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
src=Path('/tmp/c016-enc17-flat-boundary/caller-ac_value-run-value.c').read_text();a=src.index('static inline void jpeg_encode_component');b=src.index('void hsd_803B3CD8(s32 component)',a);e=src.index('#pragma pop',b);fn=src[a:b];vs={};previous=['ac_value','run','value']
for extra in [['length'],['index'],['length','index'],['length','index','ac_code','ac_length']]:
 main=fn;types={'length':'s32','index':'s32','ac_code':'u16*','ac_length':'u8*'}
 for v in extra:
  decl='    '+types[v]+' '+v+';\n';assert decl in main;main=main.replace(decl,'');main=re.sub(r'\b'+v+r'\b','(*'+v+'_out)',main)
 marker=main.index('\n{');main=main[:marker-1]+', '+', '.join(types[v]+'* '+v+'_out' for v in extra)+')'+main[marker:]
 wrapper='void hsd_803B3CD8(s32 component)\n{\n'+''.join('    s32 '+v+';\n' for v in previous)+''.join('    '+types[v]+' '+v+';\n' for v in extra)+'    jpeg_encode_component(component, '+', '.join('&'+v for v in previous+extra)+');\n}\n\n'
 vs['-'.join(extra)]=src[:a]+main+wrapper+src[e:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

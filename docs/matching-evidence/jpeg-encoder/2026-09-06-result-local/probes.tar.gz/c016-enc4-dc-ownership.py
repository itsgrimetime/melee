from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc4-dc-ownership');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b]
init='    state.work = (JpegWork*) &hsd_804D2648;\n';glob='((JpegWork*) &hsd_804D2648)';vs={}
anchor='    hsd_803B3CD8_write_bits(dc_code[length], dc_length[length], state.work);'
pos=part.index(anchor)
s=part[:pos].replace(init,'').replace('state.work',glob)+init+part[pos:]
vs['global-dc-prefix']=base[:a]+s+base[b:]
read='    value = state.work->data.coef[0] - state.work->data.prev_dc[component];'
write='    state.work->data.prev_dc[component] = state.work->data.coef[0];'
for scope in ('read','write','both'):
 helper='';s=part
 if scope in ('read','both'):
  helper+='static inline s32 jpeg_read_dc(s32 component)\n{\n    JpegWork* work = (JpegWork*) &hsd_804D2648;\n    return work->data.coef[0] - work->data.prev_dc[component];\n}\n\n'
  s=s.replace(read,'    value = jpeg_read_dc(component);')
 if scope in ('write','both'):
  helper+='static inline void jpeg_save_dc(s32 component)\n{\n    JpegWork* work = (JpegWork*) &hsd_804D2648;\n    work->data.prev_dc[component] = work->data.coef[0];\n}\n\n'
  s=s.replace(write,'    jpeg_save_dc(component);')
 if scope=='both':s=s.replace(init,'').replace(anchor,init+anchor)
 vs['helper-dc-'+scope]=base[:a]+helper+s+base[b:]
a0=base.index('static inline s32 hsd_803B3CD8_bit_length');b0=base.index('static inline void hsd_803B3CD8_write_byte',a0);old=base[a0:b0]
new=old.replace('    s32 bit;','    s32 bit;\n    s32 result;').replace('            return bit + 1;','            result = bit + 1;\n            goto done;').replace('    return 0;','    result = 0;\ndone:\n    return result;')
vs['late-zero-result']=base.replace(old,new)
vs['late-zero-result-no-pad']=vs['late-zero-result'].replace('    PAD_STACK(16);\n','')
new2=old.replace('static inline s32','static inline void').replace('(s32 value)','(s32 value, s32* result)').replace('            return bit + 1;','            *result = bit + 1;\n            return;').replace('    return 0;','    *result = 0;')
s=base.replace(old,new2)
for expr in ('abs(value)','run + 1','abs(ac_value)'):s=s.replace('length = hsd_803B3CD8_bit_length('+expr+');','hsd_803B3CD8_bit_length('+expr+', &length);')
vs['output-length']=s;vs['output-length-no-pad']=s.replace('    PAD_STACK(16);\n','')
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

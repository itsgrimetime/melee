Improve `hsd_803B3CD8` from 99.51487% to 99.70266% by applying the zigzag index before the coefficient array offset. Assigning the indexed work pointer inside the member access produces the target `slwi; add; lwz` sequence.

A local result in the bit-length helper also replaces `PAD_STACK(16)`, preserving the generated instructions and the target 104-byte frame. The remaining differences are register allocation.

The six already-matched functions in `hsd_3B34.c` remain at 100%. The TU remains unlinked while coefficient encoding and RGB conversion have residual differences.

This builds on @fjooord’s merged #3358 and follows the index-before-field-offset technique in @sadkellz’s #3378.

Validation: full GALE01 build and original DOL checksum verification. The padding removal preserves every encoder instruction and relocation from the preceding revision.

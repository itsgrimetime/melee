from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc4-loop-ownership');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline s32 hsd_803B3CD8_bit_length');b=base.index('static inline void hsd_803B3CD8_write_byte',a);old_length=base[a:b]
c=base.index('static inline void hsd_803B3CD8_write_bits');e=base.index('void hsd_803B3CD8(s32 component)',c);old_bits=base[c:e]
lengths={
'result-break':old_length.replace('    s32 bit;','    s32 bit;\n    s32 result = 0;').replace('            return bit + 1;','            result = bit + 1;\n            break;').replace('    return 0;','    return result;'),
'return-counter':old_length.replace('            return bit + 1;','            break;').replace('    return 0;','    return bit + 1;'),
'result-goto':old_length.replace('    s32 bit;','    s32 bit;\n    s32 result = 0;').replace('            return bit + 1;','            result = bit + 1;\n            goto done;').replace('    return 0;','done:\n    return result;'),
}
bits={
'reuse-length':old_bits.replace('    s32 bit;\n\n','').replace('for (bit = length - 1; bit >= 0; bit--)','for (length--; length >= 0; length--)').replace('1 << bit','1 << length'),
'while-length':old_bits.replace('    s32 bit;\n\n','').replace('for (bit = length - 1; bit >= 0; bit--)','while (--length >= 0)').replace('1 << bit','1 << length'),
'counter-initializer':old_bits.replace('    s32 bit;','    s32 bit = length - 1;').replace('for (bit = length - 1; bit >= 0; bit--)','for (; bit >= 0; bit--)'),
}
vs={**{k:base.replace(old_length,v) for k,v in lengths.items()},**{k:base.replace(old_bits,v) for k,v in bits.items()}}
for k in ('result-break','return-counter'):vs[k+'-reuse-length']=base.replace(old_length,lengths[k]).replace(old_bits,bits['reuse-length'])
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

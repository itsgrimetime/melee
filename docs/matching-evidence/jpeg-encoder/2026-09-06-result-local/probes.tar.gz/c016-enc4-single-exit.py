from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc4-single-exit');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline s32 hsd_803B3CD8_bit_length');b=base.index('static inline void hsd_803B3CD8_write_byte',a);old=base[a:b]
variants={
'negative-counter-fallback':'''    s32 bit;
    s32 result;
    for (bit = 0x1F; bit >= 0; bit--) {
        if (value & (1 << bit)) {
            result = bit + 1;
            break;
        }
    }
    if (bit < 0) {
        result = 0;
    }
    return result;''',
'loop-else-zero':'''    s32 bit;
    s32 result;
    for (bit = 0x1F; bit >= 0; bit--) {
        if (value & (1 << bit)) {
            result = bit + 1;
            break;
        } else {
            result = 0;
        }
    }
    return result;''',
'do-break-result':'''    s32 bit;
    s32 result;
    bit = 0x1F;
    do {
        if (value & (1 << bit)) {
            result = bit + 1;
            break;
        }
        bit--;
    } while (bit >= 0);
    if (bit < 0) {
        result = 0;
    }
    return result;''',
'goto-reuse-value':'''    s32 bit;
    for (bit = 0x1F; bit >= 0; bit--) {
        if (value & (1 << bit)) {
            value = bit + 1;
            goto done;
        }
    }
    value = 0;
done:
    return value;''',
}
rows=[]
try:
 for name,body in variants.items():
  full=base.replace(old,'static inline s32 hsd_803B3CD8_bit_length(s32 value)\n{\n'+body+'\n}\n\n').replace('    PAD_STACK(16);\n','')
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

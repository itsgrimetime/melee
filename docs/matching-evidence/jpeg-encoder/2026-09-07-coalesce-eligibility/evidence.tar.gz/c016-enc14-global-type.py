from pathlib import Path
import subprocess,json
paths=[Path('src/sysdolphin/baselib')/n for n in ('hsd_3B34.c','hsd_3A94.h','hsd_3B33.c','hsd_4D11.c')];original={p:p.read_text() for p in paths};p,h,other,definition=paths;base=original[p];root=Path('/tmp/c016-enc14-global-type');root.mkdir(exist_ok=True)
for q,s in original.items():(root/('baseline-'+q.name)).write_text(s)
a=base.index('typedef union JpegWork');b=base.index('typedef struct JpegByteBuffer',a);union=base[a:b];start=base.index('void hsd_803B3CD8(s32 component)');end=base.index('static const s32 lbl_804DEB88',start);fn=base[start:end];vs={}
for mode in ('byte-array','typed-union','typed-direct-global','typed-flat-pointer'):
 src=dict(original)
 if mode=='byte-array':
  src[h]=src[h].replace('extern __jmp_buf hsd_804D2648;','extern u8 hsd_804D2648[0x828];');jump='(__jmp_buf*) &hsd_804D2648'
 else:
  src[h]=src[h].replace('typedef struct CardFileData',union+'typedef struct CardFileData',1).replace('extern __jmp_buf hsd_804D2648;','extern JpegWork hsd_804D2648;');src[p]=src[p].replace(union,'');jump='&hsd_804D2648.jmp_buf'
  src[definition]=src[definition].replace('#include <Runtime/platform.h>','#include "hsd_3A94.h"').replace('/// @todo Declared as `__jmp_buf` (0xF8 bytes) by users, but the object is\n/// 0x828 bytes: a JpegWork whose first member is the jmp_buf (see hsd_3B34.c).\n','').replace('u8 hsd_804D2648[0x828];','JpegWork hsd_804D2648;')
 # Explicitly update only jump-buffer uses; byte-address and encoder work casts retain their shape.
 src[p]=src[p].replace('state.jmp_buf = &hsd_804D2648;','state.jmp_buf = '+jump+';').replace('    jmp_buf = &hsd_804D2648;','    jmp_buf = '+jump+';').replace('hsd_803B4D64_inline(arg0, arg1, &hsd_804D2648);','hsd_803B4D64_inline(arg0, arg1, '+jump+');')
 src[other]=src[other].replace('longjmp(&hsd_804D2648, true);','longjmp('+jump+', true);')
 if mode=='typed-direct-global':
  main=fn.replace('    struct {\n        JpegWork* work;\n    } state;\n','').replace('    state.work = (JpegWork*) &hsd_804D2648;\n','').replace('state.work->data.','hsd_804D2648.data.').replace('state.work','(&hsd_804D2648)');src[p]=src[p].replace(fn,main)
 elif mode=='typed-flat-pointer':
  main=fn.replace('    struct {\n        JpegWork* work;\n    } state;','    JpegWork* work;').replace('state.work','work').replace('(JpegWork*) &hsd_804D2648','&hsd_804D2648');src[p]=src[p].replace(fn,main)
 vs[mode]=src
rows=[]
try:
 for name,src in vs.items():
  d=root/name;d.mkdir(exist_ok=True)
  for q,s in src.items():q.write_text(s);(d/q.name).write_text(s)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=180)
  (d/'result.json').write_text(r.stdout);(d/'compile.log').write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   report=json.load(open('build/GALE01/report.json'));units=[u for u in report['units'] if any(n in u.get('name','') for n in ('hsd_3B34','hsd_3B33','hsd_4D11'))];(d/'units.json').write_text(json.dumps(units,indent=2)+'\n')
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:
 for q,s in original.items():q.write_text(s)

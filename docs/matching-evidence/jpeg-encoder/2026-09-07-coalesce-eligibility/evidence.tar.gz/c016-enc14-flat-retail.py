from pathlib import Path
import subprocess
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();candidate=Path('/tmp/c016-enc14-entry-assignment/flat-tables-rhs.c').read_text()
try:
 p.write_text(candidate)
 with open('/tmp/c016-enc14-flat-retail.log','w') as log:
  r=subprocess.run(['melee-agent','debug','retro','backend',str(p),'-f','hsd_803B3CD8','-O','/tmp/c016-enc14-flat-retail'],stdout=log,stderr=subprocess.STDOUT)
 print('retail exit',r.returncode,flush=True)
finally:p.write_text(base)

import json,itertools
from pathlib import Path
raw=json.load(open('/tmp/c016-enc2-retail-cost/allocator-cost-0.json'));nodes={n['virtual_register']:n for n in raw['nodes']}
expected=[d['ig_id'] for d in json.load(open('/tmp/c016-enc4-retail/backend-trace.v1.json'))['functions'][0]['regalloc']['classes'][0]['color_decisions']]
def replay(newid,omitted):
 def rename(x): return newid if x==57 else 57 if x==newid else x
 edges={rename(v):[rename(u) for u in n['neighbors'] if (v,u) not in omitted and (u,v) not in omitted] for v,n in nodes.items()}
 degree={v:len(ns) for v,ns in edges.items()};active={rename(v) for v,n in nodes.items() if v>=32 and not n['flags']&4};removed=[];passes=[]
 while active:
  current=[]
  for v in sorted(active):
   if degree[v]<29:
    at=degree[v];active.remove(v)
    for u in edges[v]:degree[u]-=1
    removed.append(v);current.append((rename(v),at))
  passes.append(current)
  if not current:return None
 return {'select_original_roles':[rename(v) for v in reversed(removed)],'passes_original_roles':passes}
assert replay(57,())['select_original_roles']==expected
rows=[]
for count in range(5):
 for stale in itertools.combinations((107,109,111,113),count):
  for newid in range(57,104):
   r=replay(newid,tuple((57,v) for v in stale))
   if r is None:rows.append({'root_id':newid,'removed_stale_neighbors':stale,'jam':True});continue
   selected=r['select_original_roles'];desired=expected.copy();desired[:2]=desired[1::-1]
   rows.append({'root_id':newid,'removed_stale_neighbors':stale,'work_select':selected.index(57),'run_payload_select':selected.index(216),'desired_leading_pair':selected[:2]==[216,57],'entire_select_order_only_pair_swap':selected==desired})
result={'diagnostic_only':True,'scope':'Offline permutations/edge deletions of the captured graph; no compiler intervention or claim of realizable source. Roles are mapped back to baseline IDs before comparisons.','baseline_full_select_replay':True,'cases':rows}
Path('/tmp/c016-enc14-edge-rank-model.json').write_text(json.dumps(result,indent=2)+'\n')
for count in range(5):
 good=[r for r in rows if len(r['removed_stale_neighbors'])==count and r.get('desired_leading_pair')]
 print('Removed',count,'edges; desired-leading-pair cases',len(good),'root ids',sorted(set(r['root_id'] for r in good)), 'exact pair-only order',sum(r['entire_select_order_only_pair_swap'] for r in good))

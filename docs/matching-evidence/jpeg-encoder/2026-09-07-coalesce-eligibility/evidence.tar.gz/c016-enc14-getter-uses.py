from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc14-getter-uses');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);fn=base[a:b];vs={}
for shape in ('return-global','local-pointer','local-member'):
 body='    return (JpegWork*) &hsd_804D2648;'
 if shape=='local-pointer':body='    JpegWork* work = (JpegWork*) &hsd_804D2648;\n    return work;'
 if shape=='local-member':body='    struct { JpegWork* work; } ref;\n    ref.work = (JpegWork*) &hsd_804D2648;\n    return ref.work;'
 helper='static inline JpegWork* jpeg_get_work(void)\n{\n'+body+'\n}\n\n'
 for entry in (False,True):
  main=fn.replace('    struct {\n        JpegWork* work;\n    } state;\n','').replace('    state.work = (JpegWork*) &hsd_804D2648;\n','    jpeg_get_work();\n' if entry else '').replace('state.work','jpeg_get_work()')
  vs[shape+('-entry' if entry else '-uses-only')]=base[:a]+helper+main+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();rows=[]
try:
 for name,source in [('base',base),('flat',Path('/tmp/c016-enc14-entry-assignment/flat-tables-rhs.c').read_text())]:
  p.write_text(source);directory='/tmp/c016-enc14-window-'+name
  with open(directory+'.log','w') as log:
   r=subprocess.run(['melee-agent','debug','retro','dump',str(p),'-f','hsd_803B3CD8','--phases','frontend','--gdb-py','/tmp/c016-enc14-coalesce-window-hook.py','-O',directory,'--timeout','180'],stdout=log,stderr=subprocess.STDOUT)
  row={'name':name,'exit_code':r.returncode}
  f=Path(directory)/'allocator-cost-0.json'
  if f.exists():row['window']=json.loads(f.read_text())['coalesce_window_at_colorgraph_entry']
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);Path('/tmp/c016-enc14-window-results.json').write_text(json.dumps(rows,indent=2)+'\n')

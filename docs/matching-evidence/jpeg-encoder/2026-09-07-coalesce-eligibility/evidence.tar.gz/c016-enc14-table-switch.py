from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc14-table-switch');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);fn=base[a:b]
selects={'dc_code':('lbl_80431678','lbl_8043169C'),'dc_length':('lbl_80431690','lbl_804316B4'),'ac_code':('tables->ac_code_luma','tables->ac_code_chroma'),'ac_length':('tables->ac_length_luma','tables->ac_length_chroma')};vs={}
for group in (('dc_code',),('dc_length',),('dc_code','dc_length'),('ac_code','ac_length'),tuple(selects)):
 for shape in ('switch','nested-conditional'):
  main=fn
  for name in group:
   yes,no=selects[name];old='    '+name+' = component == 0 ? '+yes+' : '+no+';'
   if name=='ac_length':old='    ac_length =\n        component == 0 ? '+yes+' : '+no+';'
   assert old in main
   if shape=='switch':new='    switch (component) {\n    case 0:\n        '+name+' = '+yes+';\n        break;\n    default:\n        '+name+' = '+no+';\n        break;\n    }'
   else:new='    '+name+' = component == 0 ? '+yes+' : (component == 1 ? '+no+' : '+no+');'
   main=main.replace(old,new)
  vs[shape+'-'+'-'.join(group)]=base[:a]+main+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

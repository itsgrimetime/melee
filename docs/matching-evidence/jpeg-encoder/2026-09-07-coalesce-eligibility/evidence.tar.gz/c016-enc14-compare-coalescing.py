from pathlib import Path
import json,hashlib
paths={'base':Path('/tmp/c016-enc4-retail/backend-trace.v1.json'),'flat':Path('/tmp/c016-enc14-flat-retail/backend-trace.v1.json')}
result={'scope':'Recorded retail allocator states and separately observed bounds at colorgraph entry after coalescing. Does not compare earlier PCode passes or supply unavailable source-object attribution.','rows':{}}
for name,path in paths.items():
 c=json.loads(path.read_text())['functions'][0]['regalloc']['classes'][0];owner=57 if name=='base' else 40;nodes={n['ig_id']:n for n in c['nodes']}
 window=json.load(open('/tmp/c016-enc14-window-'+name+'/allocator-cost-0.json'))['coalesce_window_at_colorgraph_entry'];pair={owner,103};edge=any({e['a'],e['b']}==pair for e in c['edges'])
 row={'trace_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'counts':{k:len(c[k]) for k in ('nodes','edges','color_decisions')},'pointer_role_id':owner,'pointer_role_basis':'physical-register uses in the ordinary assembly plus comparison of allocator graph; trace source-object attribution itself is unavailable','first_decisions':[(d['ig_id'],d['assigned_phys']) for d in c['color_decisions'][:5]],'coalesce_mappings':c['coalesce']['mappings'],'owner_address_interference_edge':edge,'window':window,'owner_inside_observed_window':window['gpr_first']<=owner<=window['gpr_last'],'address_inside_observed_window':window['gpr_first']<=103<=window['gpr_last'],'nodes':{str(v):{k:nodes[v][k] for k in ('assigned_phys','degree','flags','coalesce','select_order')} for v in (owner,103)}}
 result['rows'][name]=row
 assert not edge;assert window['gpr_first']==41 and window['gpr_last']==317
assert result['rows']['base']['nodes']['103']['coalesce']['root_ig_id']==57
assert result['rows']['flat']['nodes']['103']['coalesce']['root_ig_id']==103
Path('/tmp/c016-enc14-coalescing-comparison.json').write_text(json.dumps(result,indent=2)+'\n')
print('Observed both windows41..317, no owner/address edge in either graph; baseline103->57, flat103 independent and40 outside window.')

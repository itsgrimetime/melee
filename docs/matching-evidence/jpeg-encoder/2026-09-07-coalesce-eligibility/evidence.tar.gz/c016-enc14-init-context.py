from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc14-init-context');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);fn=base[a:b];start=fn.index('    state.work =');end=fn.index('    value =',start);setup=fn[start:end]
fields=[('u16*','dc_code'),('u8*','dc_length'),('u16*','ac_code'),('u8*','ac_length')];vs={}
for mode in ('out-context','return-context','out-tables-return-work','out-separate'):
 for pos in ('first','last'):
  members=[('JpegWork*','work')]+fields if pos=='first' else fields+[('JpegWork*','work')]
  typedef='typedef struct JpegEncoderContext {\n'+''.join('    '+ty+' '+n+';\n' for ty,n in members)+'} JpegEncoderContext;\n\n'
  main=fn;init=setup
  if mode in ('out-context','return-context'):
   main=main.replace('    struct {\n        JpegWork* work;\n    } state;','    JpegEncoderContext state;').replace('    JpegEncodeTables* tables;\n','')
   for ty,n in fields:
    main=main.replace('    '+ty+' '+n+';\n','');main=re.sub(r'\b'+n+r'\b','state.'+n,main)
    init=re.sub(r'\b'+n+r'\b',('out->' if mode=='out-context' else 'state.')+n,init)
   # Find the rewritten setup region in main.
   ms=main.index('    state.work =');me=main.index('    value =',ms)
   if mode=='out-context':
    init=init.replace('state.work','out->work');helper='static inline void jpeg_init_context(JpegEncoderContext* out, s32 component)\n{\n    JpegEncodeTables* tables;\n\n'+init+'}\n\n';call='    jpeg_init_context(&state, component);\n\n'
   else:
    helper='static inline JpegEncoderContext jpeg_init_context(s32 component)\n{\n    JpegEncoderContext state;\n    JpegEncodeTables* tables;\n\n'+init+'    return state;\n}\n\n';call='    state = jpeg_init_context(component);\n\n'
   main=main[:ms]+call+main[me:]
  else:
   ordered=fields if pos=='first' else list(reversed(fields))
   params=['s32 component']+[ty+'* out_'+n for ty,n in ordered];args=['component']+['&'+n for _,n in ordered]
   for ty,n in fields:init=re.sub(r'\b'+n+r'\b','(*out_'+n+')',init)
   if mode=='out-tables-return-work':
    local='    struct { JpegWork* work; } state;\n    JpegEncodeTables* tables;\n';rettype='JpegWork*';tail='    return state.work;\n';call='    state.work = jpeg_init_context('+', '.join(args)+');\n\n'
   else:
    params.insert(1,'JpegWork** out_work');args.insert(1,'&state.work');local='    JpegEncodeTables* tables;\n';init=init.replace('state.work','(*out_work)');rettype='void';tail='';call='    jpeg_init_context('+', '.join(args)+');\n\n'
   helper='static inline '+rettype+' jpeg_init_context('+', '.join(params)+')\n{\n'+local+'\n'+init+tail+'}\n\n';main=main.replace(setup,call).replace('    JpegEncodeTables* tables;\n','');typedef=''
  vs[mode+'-work-'+pos]=base[:a]+typedef+helper+main+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc14-entry-assignment');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);fn=base[a:b];vs={}
for owner in ('member','flat'):
 main=fn
 if owner=='flat':main=main.replace('    struct {\n        JpegWork* work;\n    } state;','    JpegWork* work;').replace('state.work','work')
 ref='state.work' if owner=='member' else 'work';init=ref+' = (JpegWork*) &hsd_804D2648';main=main.replace('    '+init+';\n','')
 for position in ('tables-rhs','dc-condition','dc-branches','both-start-assignments'):
  candidate=main
  if position=='tables-rhs':candidate=candidate.replace('tables = (JpegEncodeTables*) lbl_80430C40;','tables = ('+init+', (JpegEncodeTables*) lbl_80430C40);')
  elif position=='dc-condition':candidate=candidate.replace('dc_code = component == 0 ?','dc_code = ('+init+', component == 0) ?')
  elif position=='dc-branches':candidate=candidate.replace('dc_code = component == 0 ? lbl_80431678 : lbl_8043169C;','dc_code = component == 0 ? ('+init+', lbl_80431678) : ('+init+', lbl_8043169C);')
  else:candidate=candidate.replace('tables = (JpegEncodeTables*) lbl_80430C40;',init+', tables = (JpegEncodeTables*) lbl_80430C40;')
  vs[owner+'-'+position]=base[:a]+candidate+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

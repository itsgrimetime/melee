from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path('docs/matching-evidence/jpeg-encoder/2026-09-07-coalesce-eligibility');root.mkdir(parents=True,exist_ok=True)
files={};rows=[]
for p in Path('/tmp').glob('c016-enc14-*'):
 for q in ([p] if p.is_file() else p.rglob('*')):
  if q.is_file():files[str(q.relative_to('/tmp'))]=q
for family in ['init-context','global-type','table-switch','entry-assignment','getter-uses','word-carrier']:
 rows.extend({'family':family,**r} for r in json.loads(Path('/tmp/c016-enc14-'+family+'/results.json').read_text()))
p=Path('/tmp/c016-enc4-retail/backend-trace.v1.json');files['baseline-retail/backend-trace.v1.json']=p
ref=Path('/Users/mike/code/mwcc-decomp')
for name in ['src/backend/SpillCode.c','src/backend/CodeGen.c','src/backend/Registers.c','docs/HOST_TOOLCHAIN.md','LICENSE']:
 p=ref/name
 if p.exists():files['compiler-reconstruction/'+name]=p
prov={'repo':str(ref),'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ref,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=ref,text=True),'scope':'High-level equivalent reconstruction; binary match unmeasured. Actual bounds measured separately in retail compiler.', 'melee_compiler_sha256':'ccf4b465cec73b5aae9c5c5543dcf8cda8a62aba246f89e2e0b200d742f2e55c'}
x=json.loads(Path('/tmp/c016-enc14-final.json').read_text());assert x['fuzzy_match_percent']==99.70266
summary={'function':'hsd_803B3CD8','retained_percent':99.70266,'source100':False,'source_changes_retained':False,'source_sha256':hashlib.sha256(Path('src/sysdolphin/baselib/hsd_3B34.c').read_bytes()).hexdigest(),'valid_compiles':sum(r.get('score') is not None for r in rows),'compile_attempts':len(rows),'finding':'Observed coalescing bounds 41..317 exclude flat work owner 40, include aggregate work owner 57 and address temporary 103. Read-only bounds at colorgraph entry, not full coalescer branch tracing.','tool_issue':1535,'offline_model_cases':752,'offline_model_scope':'Graph edits only, no evidence of source realizability','validation':{'frame':104,'instructions':639,'register_only_differences':38,'full_build':'exit0'},'compiler_reference':prov}
assert len(rows)==40 and summary['valid_compiles']==40
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
archive=root/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
manifest={'summary':summary,'runs':rows,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as t:
 for n,d in manifest['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==d
print(len(files),'verified members;',archive.stat().st_size,'bytes; attempts',len(rows))

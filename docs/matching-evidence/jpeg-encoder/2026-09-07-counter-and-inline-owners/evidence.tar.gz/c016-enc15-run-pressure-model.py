import json
from pathlib import Path
raw=json.load(open('/tmp/c016-enc2-retail-cost/allocator-cost-0.json'));nodes={n['virtual_register']:n for n in raw['nodes']}
expected=[d['ig_id'] for d in json.load(open('/tmp/c016-enc4-retail/backend-trace.v1.json'))['functions'][0]['regalloc']['classes'][0]['color_decisions']]
def replay(extra):
 edges={v:set(n['neighbors']) for v,n in nodes.items()}
 for a,b in extra:edges[a].add(b);edges[b].add(a)
 degree={v:len(ns) for v,ns in edges.items()};active={v for v,n in nodes.items() if v>=32 and not n['flags']&4};removed=[];passes=[];at=[]
 while active:
  current=[]
  for v in sorted(active):
   if degree[v]<29:
    if v in [57,216]:at.append({'node':v,'scan':len(passes)+1,'degree':degree[v],'remaining_neighbors':[u for u in sorted(edges[v]) if u in active or u<32 or nodes[u]['flags']&4]})
    active.remove(v)
    for u in edges[v]:degree[u]-=1
    removed.append(v);current.append(v)
  passes.append(current)
  if not current:return {'jam':True}
 return {'order':list(reversed(removed)), 'at':at}
assert replay([])['order']==expected
rows=[]
for u in nodes:
 if u==216 or u in nodes[216]['neighbors']:continue
 r=replay([(216,u)]);order=r.get('order',[])
 desired=expected.copy();desired[:2]=desired[1::-1]
 rows.append({'added_edge':[216,u],'other_flags':nodes[u]['flags'],'desired_pair':order[:2]==[216,57],'exact_pair_only':order==desired,'work_select':order.index(57) if 57 in order else None,'run_select':order.index(216) if 216 in order else None,'jam':r.get('jam',False)})
res={'scope':'Offline added graph-edge hypotheses only, not source evidence or compiler perturbation. Baseline replay exact.', 'baseline_at':replay([])['at'],'single_edge_cases':rows}
Path('/tmp/c016-enc15-run-pressure-model.json').write_text(json.dumps(res,indent=2)+'\n')
print('Baseline:',res['baseline_at']);print('Desired pair cases',[r for r in rows if r['desired_pair']]);print('Tested',len(rows),'single new edges')

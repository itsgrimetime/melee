import json,itertools
from pathlib import Path
raw=json.load(open('/tmp/c016-enc2-retail-cost/allocator-cost-0.json'));nodes={n['virtual_register']:n for n in raw['nodes']}
expected=[d['ig_id'] for d in json.load(open('/tmp/c016-enc4-retail/backend-trace.v1.json'))['functions'][0]['regalloc']['classes'][0]['color_decisions']]
def replay(removed_edges):
 edges={v:set(n['neighbors']) for v,n in nodes.items()}
 for a,b in removed_edges:edges[a].discard(b);edges[b].discard(a)
 degree={v:len(ns) for v,ns in edges.items()};active={v for v,n in nodes.items() if v>=32 and not n['flags']&4};removed=[]
 while active:
  done=False
  for v in sorted(active):
   if degree[v]<29:
    active.remove(v)
    for u in edges[v]:degree[u]-=1
    removed.append(v);done=True
  if not done:return None
 return list(reversed(removed))
assert replay([])==expected
rows=[]
# Removing physical-call clobber edges is not source-plausible; still record all cases as graph-only.
for v in nodes[57]['neighbors']:
 order=replay([(57,v)]);desired=expected.copy();desired[:2]=desired[1::-1]
 rows.append({'removed_edge':[57,v],'other_flags':nodes[v]['flags'],'desired_pair':order[:2]==[216,57] if order else False,'exact_pair_only':order==desired,'work_select':order.index(57) if order else None,'run_select':order.index(216) if order else None})
res={'scope':'Offline edge removals only. Not source evidence, no compiler mutation. Baseline replay exact.', 'cases':rows}
Path('/tmp/c016-enc15-work-edge-model.json').write_text(json.dumps(res,indent=2)+'\n')
print('Cases',len(rows));print('Desired pair',[r for r in rows if r['desired_pair']]);print('Other changed selections',[r for r in rows if r['work_select']!=0])

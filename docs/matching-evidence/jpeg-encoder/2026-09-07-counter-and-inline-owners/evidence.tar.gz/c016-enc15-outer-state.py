from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc15-outer-state');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline s32 hsd_803B3CD8_bit_length');b=base.index('static const s32 lbl_804DEB88',a);vs={}
for qualifier in ['', '-const']:
 old=Path('/tmp/c016-enc11-state-pointer/both'+qualifier+'.c').read_text();s=old.index('typedef struct JpegEncoderState');e=old.index('static const s32 lbl_804DEB88',s);region=old[s:e];f=region.index('void hsd_803B3CD8(s32 component)');helpers=region[:f];fn=region[f:]
 for owner in ['local','pointer-argument','value-argument','pointer-initialize-helper']:
  main=fn.replace('void hsd_803B3CD8(s32 component)','static inline void jpeg_encode_component(s32 component)')
  wrapper='void hsd_803B3CD8(s32 component)\n{\n    jpeg_encode_component(component);\n}\n\n'
  if owner!='local':
   main=main.replace('    JpegEncoderState state;\n','')
   if owner=='value-argument':
    main=main.replace('jpeg_encode_component(s32 component)','jpeg_encode_component(s32 component, JpegEncoderState state)')
    main=main.replace('    state.work = (JpegWork*) &hsd_804D2648;\n','')
    wrapper='void hsd_803B3CD8(s32 component)\n{\n    JpegEncoderState state;\n    state.work = (JpegWork*) &hsd_804D2648;\n    jpeg_encode_component(component, state);\n}\n\n'
   else:
    main=main.replace('jpeg_encode_component(s32 component)','jpeg_encode_component(s32 component, JpegEncoderState* state)')
    main=main.replace('state.work','state->work').replace('&state','state')
    init='    state.work = (JpegWork*) &hsd_804D2648;\n'
    if owner=='pointer-argument':main=main.replace('    state->work = (JpegWork*) &hsd_804D2648;\n','')
    else:init=''
    wrapper='void hsd_803B3CD8(s32 component)\n{\n    JpegEncoderState state;\n'+init+'    jpeg_encode_component(component, &state);\n}\n\n'
  vs[owner+qualifier]=base[:a]+'#pragma push\n#pragma inline_depth(8)\n'+helpers+main+wrapper+'#pragma pop\n\n'+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

from pathlib import Path
import json,hashlib,tarfile
root=Path('docs/matching-evidence/jpeg-encoder/2026-09-07-counter-and-inline-owners');root.mkdir(parents=True,exist_ok=True);files={};rows=[]
for p in Path('/tmp').glob('c016-enc15-*'):
 for q in ([p] if p.is_file() else p.rglob('*')):
  if q.is_file():files[str(q.relative_to('/tmp'))]=q
for family in ['counter-types','scalar-owners','pointer-views','outer-state','outer-homes']:
 rows.extend({'family':family,**r} for r in json.loads(Path('/tmp/c016-enc15-'+family+'/results.json').read_text()))
for n in ['c016-enc2-retail-cost/allocator-cost-0.json','c016-enc4-retail/backend-trace.v1.json','c016-enc10-outer-depth/helper-local.c','c016-enc10-outer-depth/helper-local.json','c016-enc11-state-pointer/both.c','c016-enc11-state-pointer/both-const.c']:
 files['prior-inputs/'+n]=Path('/tmp')/n
x=json.loads(Path('/tmp/c016-enc15-final.json').read_text());assert x['fuzzy_match_percent']==99.70266
summary={'function':'hsd_803B3CD8','retained_percent':99.70266,'source100':False,'source_changes_retained':False,'source_sha256':hashlib.sha256(Path('src/sysdolphin/baselib/hsd_3B34.c').read_bytes()).hexdigest(),'valid_compiles':sum(r.get('score') is not None for r in rows),'compile_attempts':len(rows),'offline_graph_cases':528,'offline_scope':'Single added run-payload edge or deleted work edge. No compiler mutation and no source ceiling conclusion.','validation':{'frame':104,'instructions':639,'register_only_differences':38,'full_build':'exit0','matched_neighbors':6},'pr3377_head':'5d8814c18093525f573011ff5e37e97020d3c655','finding':'Outer shared-state helper removes duplicate work copies but loses coefficient mr. Caller-owned AC value restores the copy; no source score gain.'}
assert len(rows)==46 and summary['valid_compiles']==46
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');archive=root/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
manifest={'summary':summary,'runs':rows,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as t:
 for n,d in manifest['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==d
print(len(files),'verified archive members;',archive.stat().st_size,'bytes; attempts',len(rows))

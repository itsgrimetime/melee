from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc15-outer-homes');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
outer=Path('/tmp/c016-enc15-outer-state/local.c').read_text();a=outer.index('static inline void jpeg_encode_component');b=outer.index('void hsd_803B3CD8(s32 component)',a);e=outer.index('#pragma pop',b);body=outer[a:b];vs={}
for variable in ['none','ac_value','coefficient','run','length','index']:
 main=body;wrapper=outer[b:e]
 if variable!='none':
  main=main.replace('jpeg_encode_component(s32 component)','jpeg_encode_component(s32 component, s32* '+variable+'_out)')
  if variable=='coefficient':main=main.replace('        s32 coefficient =','        (*coefficient_out) =')
  elif variable=='ac_value':main=main.replace('        s32 ac_value = coefficient;','        (*ac_value_out) = coefficient;')
  else:main=main.replace('    s32 '+variable+';\n','')
  main=re.sub(r'\b'+variable+r'\b','(*'+variable+'_out)',main)
  # Both original coefficient declarations precede an initialized AC-value declaration.
  # Promote AC declaration to the top of the loop if coefficient assignment is now a statement.
  if variable=='coefficient':
   main=main.replace('        JpegWork* indexed;','        JpegWork* indexed;\n        s32 ac_value;').replace('        s32 ac_value =','        ac_value =')
  wrapper='void hsd_803B3CD8(s32 component)\n{\n    s32 '+variable+';\n    jpeg_encode_component(component, &'+variable+');\n}\n\n'
 full=outer[:a]+main+wrapper+outer[e:]
 full=full.replace('            s32 result = bit + 1;\n\n            return result;','            return bit + 1;')
 vs[variable+'-direct-result']=full
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

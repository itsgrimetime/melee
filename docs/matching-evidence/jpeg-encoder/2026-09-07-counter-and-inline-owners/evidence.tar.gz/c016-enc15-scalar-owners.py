from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc15-scalar-owners');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);fn=base[a:b];vs={}
for variable in ['run','length','index','value']:
 for style in ['member','array']:
  main=fn.replace('    s32 '+variable+';', '    struct { s32 '+variable+(';' if style=='member' else '[1];')+' } '+variable+'_state;')
  # Rewrite usages, excluding the replacement declaration.
  lines=main.splitlines(True)
  main=''.join(line if variable+'_state;' in line else re.sub(r'\b'+variable+r'\b',variable+'_state.'+variable+('' if style=='member' else '[0]'),line) for line in lines)
  vs[variable+'-'+style]=base[:a]+main+base[b:]
# Split categories by semantic phase; no control-flow or arithmetic changes.
for split in ['ac','all']:
 main=fn
 start=main.index('    for (index = 1;')
 tail=main[start:]
 if split=='ac':
  tail=tail.replace('        JpegWork* indexed;', '        s32 ac_length_bits;\n        JpegWork* indexed;')
  loopend=tail.index('    if (run != 0)')
  tail=re.sub(r'\blength\b','ac_length_bits',tail[:loopend])+tail[loopend:]
 else:
  tail=tail.replace('        JpegWork* indexed;', '        s32 run_length;\n        s32 coefficient_length;\n        JpegWork* indexed;')
  acstart=tail.index('            length = hsd_803B3CD8_bit_length(abs(ac_value));')
  acend=tail.index('            run = 0;',acstart)
  tail=re.sub(r'\blength\b','run_length',tail[:acstart])+re.sub(r'\blength\b','coefficient_length',tail[acstart:acend])+tail[acend:]
 vs['split-length-'+split]=base[:a]+main[:start]+tail+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc10-work-layout');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('typedef union JpegWork {');b=base.index('} JpegWork;',a)+len('} JpegWork;');old=base[a:b]
fields='''        s32 x118[0x100];
        s32 x518[0x40];
        s32 x618[0x40];
        s32 coef[0x40];
        s32 prev_dc[3];''';vs={}
flat='typedef struct JpegWork {\n    __jmp_buf jmp_buf;\n    u8 pad_f8[0x20];\n'+fields+'\n} JpegWork;'
s=base[:a]+flat+base[b:];s=s.replace('->data.','->');vs['flat-sequential']=s
nested='typedef struct JpegWork {\n    __jmp_buf jmp_buf;\n    struct {\n        u8 pad_f8[0x20];\n'+fields+'\n    } data;\n} JpegWork;';vs['sequential-data']=base[:a]+nested+base[b:]
wrapped='typedef struct JpegWork {\n    struct {\n        __jmp_buf jmp_buf;\n        u8 pad_f8[0x20];\n'+fields+'\n    } data;\n} JpegWork;';s=base[:a]+wrapped+base[b:];s=s.replace('&work->jmp_buf','&work->data.jmp_buf');vs['wrapped-sequential']=s
# Non-overlapping explicit jmp member inside union data view while retaining public union.
s=old.replace('u8 x0[0x118];','__jmp_buf context;\n        u8 pad_f8[0x20];');vs['union-explicit-context']=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

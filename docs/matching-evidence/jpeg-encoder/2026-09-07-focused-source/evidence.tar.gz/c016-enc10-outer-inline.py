from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc10-outer-inline');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base);vs={}
for byteform in ('helper','expanded'):
 src=base if byteform=='helper' else Path('/tmp/c016-enc10-inline-boundary/byte-expanded-False.c').read_text()
 a=src.index('void hsd_803B3CD8(s32 component)');b=src.index('static const s32 lbl_804DEB88',a);fn=src[a:b]
 for owner in ('local','parameter-first','parameter-last'):
  if owner=='local':
   helper=fn.replace('void hsd_803B3CD8(s32 component)','static inline void jpeg_encode_block(s32 component)',1)
   wrapper='void hsd_803B3CD8(s32 component)\n{\n    jpeg_encode_block(component);\n}\n\n'
  else:
   params='JpegWork* work, s32 component' if owner=='parameter-first' else 's32 component, JpegWork* work'
   helper=fn.replace('void hsd_803B3CD8(s32 component)','static inline void jpeg_encode_block('+params+')',1)
   helper=helper.replace('    struct {\n        JpegWork* work;\n    } state;\n','').replace('    state.work = (JpegWork*) &hsd_804D2648;\n','').replace('state.work','work')
   args='(JpegWork*) &hsd_804D2648, component' if owner=='parameter-first' else 'component, (JpegWork*) &hsd_804D2648'
   wrapper='void hsd_803B3CD8(s32 component)\n{\n    jpeg_encode_block('+args+');\n}\n\n'
  vs[byteform+'-'+owner]=src[:a]+helper+wrapper+src[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

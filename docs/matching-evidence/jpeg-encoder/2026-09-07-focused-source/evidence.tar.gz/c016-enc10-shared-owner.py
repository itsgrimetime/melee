from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc10-shared-owner');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b]
calls=list(re.finditer(r'hsd_803B3CD8_write_bits\(([^;]*?)\);',part));assert len(calls)==7
vs={}
for group,ids in [('dc',[0,1]),('ac',[2,3,4,5]),('all',list(range(7)))]:
 for kind in ('flat','member'):
  owner='writer_work' if kind=='flat' else 'writer.work'
  decl='    JpegWork* writer_work;' if kind=='flat' else '    struct { JpegWork* work; } writer;'
  for initform in ('embedded','separate'):
   s=part
   for i in reversed(ids):
    m=calls[i];args=[v.strip() for v in m.group(1).split(',')]
    args[2]='('+owner+' = state.work)' if i==ids[0] and initform=='embedded' else owner
    repl='hsd_803B3CD8_write_bits('+', '.join(args)+');'
    if i==ids[0] and initform=='separate':repl=owner+' = state.work;\n'+('            ' if group=='ac' else '    ')+repl
    s=s[:m.start()]+repl+s[m.end():]
   s=s.replace('    s32 index;','    s32 index;\n'+decl)
   vs[f'{group}-{kind}-{initform}']=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

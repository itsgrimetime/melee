from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc10-table-branches');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];vs={}
fields={'dc_code':('lbl_80431678','lbl_8043169C'),'dc_length':('lbl_80431690','lbl_804316B4'),'ac_code':('tables->ac_code_luma','tables->ac_code_chroma'),'ac_length':('tables->ac_length_luma','tables->ac_length_chroma')}
for names in [('dc_code',),('dc_length',),('ac_code',),('ac_length',),('dc_code','dc_length'),tuple(fields)]:
 for form in ('if','default-override'):
  s=part
  for name in names:
   yes,no=fields[name];pattern=r'    '+name+r'\s*=\s*component == 0 \? '+re.escape(yes)+r' : '+re.escape(no)+r';'
   if form=='if':new=f'    if (component == 0) {{\n        {name} = {yes};\n    }} else {{\n        {name} = {no};\n    }}'
   else:new=f'    {name} = {no};\n    if (component == 0) {{\n        {name} = {yes};\n    }}'
   s,count=re.subn(pattern,new,s);assert count==1
  vs[form+'-'+'-'.join(names)]=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

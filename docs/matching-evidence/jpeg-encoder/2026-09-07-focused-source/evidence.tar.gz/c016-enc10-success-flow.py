from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc10-success-flow');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base);vs={}
for which in ('bits','both'):
 s=Path('/tmp/c016-enc10-writer-returns/'+('bits-return-success' if which=='bits' else 'both-return-success')+'.c').read_text()
 a=s.index('void hsd_803B3CD8(s32 component)');b=s.index('static const s32 lbl_804DEB88',a);fn=s[a:b]
 fn,n=re.subn(r'hsd_803B3CD8_write_bits\(([^;]*?)\);',r'if (!hsd_803B3CD8_write_bits(\1)) { return; }',fn);assert n==7
 s=s[:a]+fn+s[b:]
 if which=='both':
  a=s.index('static inline int hsd_803B3CD8_write_bits');b=s.index('void hsd_803B3CD8(s32 component)',a);h=s[a:b]
  h,n=re.subn(r'hsd_803B3CD8_write_byte\(([^;]*?)\);',r'if (!hsd_803B3CD8_write_byte(\1)) { return 0; }',h);assert n==2
  s=s[:a]+h+s[b:]
 vs[which+'-checked']=s
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

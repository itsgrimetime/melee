from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc10-writer-returns');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline void hsd_803B3CD8_write_byte');b=base.index('static inline void hsd_803B3CD8_write_bits',a);c=base.index('void hsd_803B3CD8(s32 component)',b);byte=base[a:b];bits=base[b:c];vs={}
for name,typ,result in [('success','int','1'),('length','s32','length'),('remaining','s32','bit'),('value','s32','value')]:
 changed=bits.replace('static inline void','static inline '+typ,1);idx=changed.rfind('}');changed=changed[:idx]+'    return '+result+';\n'+changed[idx:]
 vs['bits-return-'+name]=base[:b]+changed+base[c:]
for name,typ,result in [('success','int','1'),('byte','u8','byte'),('destination','u8*','hsd_804D79A0')]:
 changed=byte.replace('static inline void','static inline '+typ,1);idx=changed.rfind('}');changed=changed[:idx]+'    return '+result+';\n'+changed[idx:]
 vs['byte-return-'+name]=base[:a]+changed+base[b:]
# One coherent successful-output convention for both nested helpers.
s=vs['byte-return-success'];old=bits;new=vs['bits-return-success'][b:c+len(vs['bits-return-success'])-len(base)];assert new.endswith('\n\n');vs['both-return-success']=s.replace(old,new)
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

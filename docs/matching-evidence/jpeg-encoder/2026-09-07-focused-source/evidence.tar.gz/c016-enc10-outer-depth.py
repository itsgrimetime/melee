from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc10-outer-depth');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base);rows=[]
try:
 for name in ('helper-local','helper-parameter-first','helper-parameter-last','expanded-local','expanded-parameter-first','expanded-parameter-last'):
  src=Path('/tmp/c016-enc10-outer-inline/'+name+'.c').read_text();a=src.index('static inline s32 hsd_803B3CD8_bit_length');b=src.index('static const s32 lbl_804DEB88',a)
  full=src[:a]+'#pragma push\n#pragma inline_depth(8)\n'+src[a:b]+'#pragma pop\n'+src[b:]
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'calls':sorted(set(l.split('\t')[-1] for l in d['current_asm'] if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

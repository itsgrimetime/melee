from pathlib import Path
import json,tarfile,hashlib
root=Path('docs/matching-evidence/jpeg-encoder/2026-09-07-focused-source');root.mkdir(parents=True,exist_ok=True)
files={};rows=[]
for d in sorted(Path('/tmp').glob('c016-enc10-*')):
 if d.is_dir() and (d/'results.json').exists():
  rows.extend({'family':d.name,**r} for r in json.loads((d/'results.json').read_text()))
  for p in d.rglob('*'):
   if p.is_file():files[str(p.relative_to('/tmp'))]=p
for p in Path('/tmp').glob('c016-enc10-*'):
 if p.is_file() and p.suffix in ('.py','.json','.log','.diff'):files[p.name]=p
x=json.loads(Path('/tmp/c016-enc10-final.json').read_text());assert x['fuzzy_match_percent']==99.70266
summary={'function':'hsd_803B3CD8','scratch':'https://decomp.me/scratch/mbSPH','focus':'User explicitly requests this function until source100; no function switching.','retained_percent':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'register_only_count':x['classification']['register_allocation_guidance']['register_only_count'],'source_sha256':hashlib.sha256(Path('src/sysdolphin/baselib/hsd_3B34.c').read_bytes()).hexdigest(),'ordinary_compile_attempts':len(rows),'valid_candidates':sum(r['score'] is not None for r in rows),'retained_changes':False,'permuter':{'base_score':190,'last_iteration':11547,'compile_errors':1569,'better_candidate_directories':0,'exit':'Interrupted normally after bounded run; Exiting; exit0','command':'python /Users/mike/code/decomp-permuter/permuter.py nonmatchings/hsd_803B3CD8 --better-only --stop-on-zero -j 4','triage':'No candidate sources found; no winners existed to transfer.'},'validation':{'checkdiff':'Retained baseline restored and verified','ninja':'exit0','source100':False}}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
archive=root/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
manifest={'summary':summary,'runs':rows,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as t:
 for n,digest in manifest['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==digest
print(len(rows),'attempts;',summary['valid_candidates'],'valid;',len(files),'verified members;',archive.stat().st_size,'bytes')

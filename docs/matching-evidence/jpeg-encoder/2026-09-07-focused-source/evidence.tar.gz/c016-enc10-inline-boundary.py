from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc10-inline-boundary');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline void hsd_803B3CD8_write_bits');b=base.index('void hsd_803B3CD8(s32 component)',a);part=base[a:b];vs={}
# Expand the byte helper with distinct block scopes, evaluating byte once.
for bindwork in (False,True):
 s=part
 for expr in ('hsd_804D79B0[0]','0'):
  old='hsd_803B3CD8_write_byte('+expr+', work);'
  new='''{
                u8 byte = EXPR;
                WORK_DECL
                u8* dst = hsd_804D79A0;
                if (dst < &hsd_804D79A4[hsd_804D79A8]) {
                    hsd_804D79A0 = dst + 1;
                    *dst = byte;
                } else {
                    longjmp(&WORK->jmp_buf, 1);
                }
            }'''.replace('EXPR',expr).replace('WORK_DECL','JpegWork* byte_work = work;' if bindwork else '').replace('WORK','byte_work' if bindwork else 'work')
  assert s.count(old)==1;s=s.replace(old,new)
 vs['byte-expanded-'+str(bindwork)]=base[:a]+s+base[b:]
# Expand bit writer at every call, preserving single evaluation and parameter types.
fnend=base.index('static const s32 lbl_804DEB88',b)
body=part[part.index('{')+1:part.rfind('}')]
for scalarwork in ('flat','member','direct'):
 for byteexpanded in (False,True):
  src=vs['byte-expanded-False'] if byteexpanded else base
  ab=src.index('static inline void hsd_803B3CD8_write_bits');bb=src.index('void hsd_803B3CD8(s32 component)',ab);ee=src.index('static const s32 lbl_804DEB88',bb)
  writer=src[ab:bb];wb=writer[writer.index('{')+1:writer.rfind('}')];fn=src[bb:ee]
  calls=list(re.finditer(r'hsd_803B3CD8_write_bits\(([^;]*?)\);',fn));assert len(calls)==7
  for m in reversed(calls):
   value,length,work=[x.strip() for x in m.group(1).split(',')]
   inner=wb
   for var in ('value','length','bit'):inner=re.sub(r'\b'+var+r'\b','emit_'+var,inner)
   owner='emit_work' if scalarwork=='flat' else 'emit_state.work' if scalarwork=='member' else work
   inner=re.sub(r'\bwork\b',owner,inner)
   declaration='JpegWork* emit_work = '+work+';' if scalarwork=='flat' else 'struct { JpegWork* work; } emit_state;\n' if scalarwork=='member' else ''
   if scalarwork=='member':inner=inner.replace('    s32 emit_bit;','    s32 emit_bit;\n    emit_state.work = '+work+';')
   replacement='{\n    s32 emit_value = '+value+';\n    s32 emit_length = '+length+';\n    '+declaration+inner+'\n}'
   fn=fn[:m.start()]+replacement+fn[m.end():]
  vs['bits-expanded-'+scalarwork+'-bytes-'+str(byteexpanded)]=src[:bb]+fn+src[ee:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

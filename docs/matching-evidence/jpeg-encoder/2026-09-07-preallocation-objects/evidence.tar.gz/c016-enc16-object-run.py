from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();rows=[]
try:
 for name,source in [('base',base),('outer',Path('/tmp/c016-enc15-outer-homes/ac_value-direct-result.c').read_text())]:
  p.write_text(source);d='/tmp/c016-enc16-objects-'+name
  with open(d+'.log','w') as log:
   r=subprocess.run(['melee-agent','debug','retro','dump',str(p),'-f','hsd_803B3CD8','--phases','frontend','--gdb-py','/tmp/c016-enc16-object-hook.py','-O',d,'--timeout','180'],stdout=log,stderr=subprocess.STDOUT)
  row={'name':name,'exit_code':r.returncode};rows.append(row);print(row,flush=True)
finally:p.write_text(base);Path('/tmp/c016-enc16-object-results.json').write_text(json.dumps(rows,indent=2)+'\n')

from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc16-caller-tables');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
outer=Path('/tmp/c016-enc15-outer-homes/none-direct-result.c').read_text();a=outer.index('static inline void jpeg_encode_component');b=outer.index('void hsd_803B3CD8(s32 component)',a);e=outer.index('#pragma pop',b);body=outer[a:b];vs={}
specs=[['ac_code'],['ac_length'],['ac_code','ac_length'],['ac_value','ac_code'],['ac_value','ac_length'],['ac_value','ac_code','ac_length'],['ac_value','ac_code','ac_length','run'],['ac_value','ac_code','ac_length','run','index']]
types={'ac_code':'u16*','ac_length':'u8*','ac_value':'s32','run':'s32','index':'s32'}
for variables in specs:
 main=body
 for v in variables:
  if v=='ac_value':main=main.replace('        s32 ac_value = coefficient;','        (*ac_value_out) = coefficient;')
  else:
   declaration='    '+types[v]+' '+v+';\n';assert declaration in main;main=main.replace(declaration,'')
  main=re.sub(r'\b'+v+r'\b','(*'+v+'_out)',main)
 params=', '.join(types[v]+'* '+v+'_out' for v in variables)
 main=main.replace('jpeg_encode_component(s32 component)','jpeg_encode_component(s32 component, '+params+')')
 wrapper='void hsd_803B3CD8(s32 component)\n{\n'+''.join('    '+types[v]+' '+v+';\n' for v in variables)+'    jpeg_encode_component(component, '+', '.join('&'+v for v in variables)+');\n}\n\n'
 vs['-'.join(variables)]=outer[:a]+main+wrapper+outer[e:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

from pathlib import Path
import json,networkx as nx,signal
from collections import Counter
base=json.load(open('/tmp/c016-enc4-retail/backend-trace.v1.json'))['functions'][0]['regalloc']['classes'][0]
other=json.load(open('/tmp/c016-enc16-outer-retail/backend-trace.v1.json'))['functions'][0]['regalloc']['classes'][0]
def graph(c,roles):
 g=nx.Graph()
 for n in c['nodes']:
  v=n['ig_id'];flags=sum(x.get('raw',0) for x in n['flags'])
  color=('physical-'+str(v)) if v<32 else ('coalesced' if flags&4 else 'virtual')
  if v in roles:color+=':'+roles[v]
  g.add_node(v,color=color)
 for e in c['edges']:g.add_edge(e['a'],e['b'])
 return g
rows=[]
def timeout(*_):raise TimeoutError('bounded 20 second graph isomorphism check')
signal.signal(signal.SIGALRM,timeout)
for label,roles_a,roles_b in [('fixed-physical',{},{}),('fixed-physical-and-work',{57:'work'},{50:'work'}),('fixed-physical-work-ac-tables',{57:'work',58:'ac_length',59:'ac_code'},{50:'work',51:'ac_length',52:'ac_code'})]:
 a=graph(base,roles_a);b=graph(other,roles_b)
 ha=nx.weisfeiler_lehman_graph_hash(a,node_attr='color',iterations=8);hb=nx.weisfeiler_lehman_graph_hash(b,node_attr='color',iterations=8)
 da=Counter(dict(a.degree()).values());db=Counter(dict(b.degree()).values())
 row={'degree_histogram_equal':da==db,'degree_histogram_differences':[{'degree':v,'baseline_count':da[v],'outer_count':db[v]} for v in sorted(set(da)|set(db)) if da[v]!=db[v]],'label':label,'a_nodes':len(a),'b_nodes':len(b),'a_edges':a.number_of_edges(),'b_edges':b.number_of_edges(),'wl8_a':ha,'wl8_b':hb}
 if ha!=hb:row.update({'isomorphic':False,'proof':'Different color-preserving WL hashes; no permutation preserves these node colors and edges.'})
 else:
  try:
   signal.alarm(20);matcher=nx.algorithms.isomorphism.GraphMatcher(a,b,node_match=lambda x,y:x['color']==y['color']);same=matcher.is_isomorphic();row.update({'isomorphic':same,'proof':'Bounded exact GraphMatcher completed.'})
   if same:row['mapping']=matcher.mapping
  except TimeoutError:row.update({'isomorphic':None,'proof':'Timed out; not a negative result.'})
  finally:signal.alarm(0)
 rows.append(row);print({k:v for k,v in row.items() if k!='mapping'},flush=True)
Path('/tmp/c016-enc16-graph-isomorphism.json').write_text(json.dumps({'scope':'Comparison of recorded undirected interference graphs with fixed physical identities and coalesced status. Does not compare earlier PCode or imply source realizability. Named work/table role pins are based on observed SSA slots and ordinary assembly uses.','cases':rows},indent=2)+'\n')

from pathlib import Path
import json
rows=[]
for variant,first,nextreg,workname,workid in [('base',41,102,'@319',57),('outer',34,104,'@344',50)]:
 x=json.load(open('/tmp/c016-enc16-objects-'+variant+'/preallocation-objects.json'));assert x['matched'] and not x['errors']
 assert [s['stage'] for s in x['snapshots']]==['preallocate_entry','preallocate_return']
 before,after=x['snapshots'];assert before['gpr_next']==32 and after['gpr_next']==nextreg and after['gpr_coalesce_first']==first
 objs=[r for items in after['lists'].values() for r in items];assigned=[r for r in objs if r.get('register_slot_24',0)>=32 and not r.get('is_fpr') and not r.get('is_vector')]
 assert sorted(r['register_slot_24'] for r in assigned)==list(range(32,nextreg))
 work=next(r for r in assigned if r['name']==workname);ac=next(r for r in assigned if r['name']=='ac_value');assert work['register_slot_24']==workid and ac['register_slot_24']==33
 rows.append({'variant':variant,'assigned_gpr_objects':len(assigned),'observed_contiguous_slots':[32,nextreg-1],'preallocation_return_coalesce_first':first,'work_optimizer_object':workname,'work_slot':workid,'ac_value_slot':33,'ac_value_below_coalesce_first':33<first,'named_objects':[{k:r.get(k) for k in ['name','register_slot_24','candidate_23','excluded_22']} for r in objs if not r['name'].startswith('@')],'warning':'Entry coalesce bounds are not current-function bounds; use the return snapshot. Raw field layouts and function-address selection are diagnostic, not production matching proof.'})
Path('/tmp/c016-enc16-object-summary.json').write_text(json.dumps({'scope':'Bounded read-only object-list observations validated for contiguous GPR slots, target function, and error-free snapshots. Source work name in baseline agrees with earlier IRO scalarization capture; outer semantic role also uses ordinary assembly and retail merge mapping.','variants':rows},indent=2)+'\n')
print([(r['variant'],r['assigned_gpr_objects'],r['work_slot'],r['preallocation_return_coalesce_first']) for r in rows])

from pathlib import Path
import subprocess,json,re,itertools
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc16-prefix-arguments');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
source=Path('/tmp/c016-enc16-component-prefix/state-state-out-local.c').read_text();vs={};paramtypes={'value':'s32 value','length':'s32 length','work':'JpegEncoderState* work'}
for order in itertools.permutations(['value','length','work']):
 if order==('value','length','work'):continue
 full,n=re.subn(r'static inline void hsd_803B3CD8_write_bits\(.*?\)\n\{','static inline void hsd_803B3CD8_write_bits('+', '.join(paramtypes[v] for v in order)+')\n{',source,count=1,flags=re.S);assert n==1
 def rewrite(m):
  args=m[2].split(',');assert len(args)==3
  mapping=dict(zip(['value','length','work'],args));return m[1]+'hsd_803B3CD8_write_bits('+', '.join(mapping[v].strip() for v in order)+');'
 full,n=re.subn(r'(?m)^(\s*)hsd_803B3CD8_write_bits\((.*?)\);',rewrite,full,flags=re.S);assert n==7
 vs['-'.join(order)]=full
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

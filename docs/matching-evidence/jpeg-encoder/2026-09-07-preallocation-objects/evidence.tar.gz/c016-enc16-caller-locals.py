from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc16-caller-locals');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
outer=Path('/tmp/c016-enc16-caller-tables/ac_value-ac_code-ac_length-run-index.c').read_text();a=outer.index('static inline void jpeg_encode_component');b=outer.index('void hsd_803B3CD8(s32 component)',a);e=outer.index('#pragma pop',b);body=outer[a:b];vs={}
types={'ac_code':'u16*','ac_length':'u8*','ac_value':'s32','run':'s32','index':'s32','length':'s32','value':'s32','coefficient':'s32','indexed':'JpegWork*','tables':'JpegEncodeTables*','dc_code':'u16*','dc_length':'u8*'}
previous=['ac_value','ac_code','ac_length','run','index']
specs=[['length'],['value'],['length','value'],['length','value','coefficient'],['length','value','coefficient','indexed'],['length','value','coefficient','indexed','tables'],['length','value','coefficient','indexed','tables','dc_code','dc_length']]
for additional in specs:
 main=body
 for v in additional:
  if v=='coefficient':main=main.replace('        s32 coefficient =','        (*coefficient_out) =')
  else:
   declaration=('        ' if v=='indexed' else '    ')+types[v]+' '+v+';\n';assert declaration in main;main=main.replace(declaration,'')
  # Only references in the function body are replaced; names with _out suffix remain intact.
  main=re.sub(r'\b'+v+r'\b','(*'+v+'_out)',main)
 params=', '.join(types[v]+'* '+v+'_out' for v in additional)
 marker=main.index('\n{');main=main[:marker-1]+', '+params+')'+main[marker:]
 variables=previous+additional
 for order in ['as-added','original'] if len(additional)>=6 else ['as-added']:
  ordered=variables if order=='as-added' else [v for v in ['tables','dc_code','dc_length','ac_code','ac_length','value','length','run','index','indexed','coefficient','ac_value'] if v in variables]
  wrapper='void hsd_803B3CD8(s32 component)\n{\n'+''.join('    '+types[v]+' '+v+';\n' for v in ordered)+'    jpeg_encode_component(component, '+', '.join('&'+v for v in variables)+');\n}\n\n'
  vs['-'.join(additional)+'-'+order]=outer[:a]+main+wrapper+outer[e:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

from pathlib import Path
import json,hashlib,tarfile,subprocess
root=Path('docs/matching-evidence/jpeg-encoder/2026-09-07-preallocation-objects');root.mkdir(parents=True,exist_ok=True);files={};rows=[]
for p in Path('/tmp').glob('c016-enc16-*'):
 for q in ([p] if p.is_file() else p.rglob('*')):
  if q.is_file():files[str(q.relative_to('/tmp'))]=q
for family in ['caller-tables','caller-locals','component-prefix','prefix-arguments','embedded-base-use']:
 rows.extend({'family':family,**r} for r in json.loads(Path('/tmp/c016-enc16-'+family+'/results.json').read_text()))
for n in ['c016-enc4-retail/backend-trace.v1.json','c016-enc15-outer-homes/ac_value-direct-result.c','c016-enc15-outer-homes/ac_value-direct-result.json','c016-enc15-outer-homes/none-direct-result.c','c016-enc11-state-pointer/both.c','c016-enc5-frontend/iro-04-iro-buildflowgraph-1.txt','c016-enc5-frontend/iro-05-iro-scalarizeclassdatamembers.txt']:
 files['prior-inputs/'+n]=Path('/tmp')/n
ref=Path('/Users/mike/code/mwcc-decomp')
for n in ['include/mwcc/backend_types.h','src/backend/CodeGen.c','src/backend/Registers.c']:
 files['compiler-reference/'+n]=ref/n
x=json.loads(Path('/tmp/c016-enc16-final.json').read_text());assert x['fuzzy_match_percent']==99.70266
summary={'function':'hsd_803B3CD8','retained_percent':99.70266,'source100':False,'source_changes_retained':False,'source_sha256':hashlib.sha256(Path('src/sysdolphin/baselib/hsd_3B34.c').read_bytes()).hexdigest(),'valid_compiles':sum(r.get('score') is not None for r in rows),'compile_attempts':len(rows),'findings':['Read-only preallocation capture binds baseline @319 to57, first41; alternate @344 to50, first34. ac_value33 is below first in both.','Baseline and alternate 320-node/2655-edge graphs have different degree histograms; they are not just register-ID permutations.'],'validation':{'frame':104,'instructions':639,'register_only_differences':38,'full_build':'exit0','matched_neighbors':6},'compiler_reference_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ref,text=True).strip(),'compiler_reference_scope':'High-level reconstruction, binary match unmeasured; raw field values observed independently.','tool_issue_note':1535}
assert len(rows)==35 and summary['valid_compiles']==35
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');archive=root/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for n,p in sorted(files.items()):t.add(p,arcname=n)
manifest={'summary':summary,'runs':rows,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as t:
 for n,d in manifest['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==d
print(len(files),'verified members;',archive.stat().st_size,'bytes;',len(rows),'compiles')

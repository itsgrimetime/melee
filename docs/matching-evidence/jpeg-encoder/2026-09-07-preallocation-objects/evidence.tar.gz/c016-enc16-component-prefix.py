from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc16-component-prefix');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base);vs={}
a=base.index('static inline s32 hsd_803B3CD8_bit_length');end=base.index('static const s32 lbl_804DEB88',a)
for helperstyle in ['work','state']:
 source=base if helperstyle=='work' else Path('/tmp/c016-enc11-state-pointer/both.c').read_text()
 start=source.index('static inline s32 hsd_803B3CD8_bit_length');f=source.index('void hsd_803B3CD8(s32 component)',start);e=source.index('static const s32 lbl_804DEB88',f);fn=source[f:e];helpers=source[start:f]
 # Define state uniformly before the helper family.
 fn=fn.replace('    struct {\n        JpegWork* work;\n    } state;','    JpegEncoderState state;')
 init=fn.index('    state.work =');loop=fn.index('    for (index = 1;',init);prefix=fn[init:loop]
 for ownership in ['state-out','work-return']:
  if helperstyle=='state' and ownership=='work-return':continue
  params=['s32 component','u16** ac_code_out','u8** ac_length_out','s32* run_out'];args=['component','&ac_code','&ac_length','&run']
  local='    JpegEncodeTables* tables;\n    u16* dc_code;\n    u8* dc_length;\n    s32 value;\n    s32 length;\n'
  body=prefix
  for v in ['ac_code','ac_length','run']:body=re.sub(r'\b'+v+r'\b','(*'+v+'_out)',body)
  if ownership=='state-out':
   params.insert(1,'JpegEncoderState* state');args.insert(1,'&state');body=body.replace('state.work','state->work').replace('&state','state');ret='void';tail='';call='    jpeg_begin_component('+', '.join(args)+');\n'
  else:
   local+='    JpegWork* work;\n';body=body.replace('state.work','work');ret='JpegWork*';tail='    return work;\n';call='    state.work = jpeg_begin_component('+', '.join(args)+');\n'
  main=fn[:init]+call+fn[loop:]
  for decl in ['    JpegEncodeTables* tables;\n','    u16* dc_code;\n','    u8* dc_length;\n','    s32 value;\n']:main=main.replace(decl,'')
  helper='static inline '+ret+' jpeg_begin_component('+', '.join(params)+')\n{\n'+local+'\n'+body+tail+'}\n\n'
  for result in ['local','direct']:
   region=helpers+helper+main
   if result=='direct':region=region.replace('            s32 result = bit + 1;\n\n            return result;','            return bit + 1;')
   full=base[:a]+'typedef struct JpegEncoderState { JpegWork* work; } JpegEncoderState;\n\n#pragma push\n#pragma inline_depth(8)\n'+region+'#pragma pop\n\n'+base[end:]
   vs[helperstyle+'-'+ownership+'-'+result]=full
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=150)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

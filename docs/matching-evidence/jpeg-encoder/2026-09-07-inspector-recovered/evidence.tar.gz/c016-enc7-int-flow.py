from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc7-int-flow');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);part=base[a:b];vs={}
helper_start=base.index('static inline s32 hsd_803B3CD8_bit_length')
for form in ('function-locals','helper-types','whole-flow'):
 s=part;prefix=base[:a]
 if form in ('function-locals','whole-flow'):
  s=s.replace('s32','int').replace('void hsd_803B3CD8(int component)','void hsd_803B3CD8(s32 component)').replace('(int*) state.work','(s32*) state.work')
 if form in ('helper-types','whole-flow'):
  prefix=base[:helper_start]+base[helper_start:a].replace('s32','int')
 vs[form]=prefix+s+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

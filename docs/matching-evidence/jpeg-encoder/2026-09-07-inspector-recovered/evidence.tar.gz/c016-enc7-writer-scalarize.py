from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc7-writer-scalarize');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline void hsd_803B3CD8_write_bits');b=base.index('void hsd_803B3CD8(s32 component)',a);part=base[a:b];vs={}
import itertools
for count in (1,2,3):
 for selected in itertools.combinations(('value','length','bit'),count):
  brace=part.index('{');body=part[brace+1:]
  if 'bit' in selected:body=body.replace('    s32 bit;\n','')
  for name in selected:body=re.sub(r'\b'+name+r'\b','writer.'+name,body)
  members=''.join('        s32 '+name+';\n' for name in selected)
  init=''.join('    writer.'+name+' = '+name+';\n' for name in selected if name!='bit')
  s=part[:brace+1]+'\n    struct {\n'+members+'    } writer;\n'+init+body
  vs['-'.join(selected)]=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],text=True,capture_output=True,timeout=90);(root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   d=json.loads(r.stdout);asm=d['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':d['fuzzy_match_percent'],'frame':d['classification']['stack_frame_sizes'],'structural':d['structural'],'regdiff':d['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

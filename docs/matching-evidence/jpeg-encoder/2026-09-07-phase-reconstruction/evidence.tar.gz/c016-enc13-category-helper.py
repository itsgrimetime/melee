from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc13-category-helper');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('static inline s32 hsd_803B3CD8_bit_length');b=base.index('static inline void hsd_803B3CD8_write_byte',a);bit=base[a:b];vs={}
for shape in ('nested','direct-local','direct-parameter','out-magnitude'):
 for sites in ('both','dc','ac'):
  if shape=='nested':helper='static inline s32 jpeg_category(s32 value)\n{\n    return hsd_803B3CD8_bit_length(abs(value));\n}\n\n'
  elif shape=='direct-local':helper=bit.replace('hsd_803B3CD8_bit_length','jpeg_category').replace('    s32 bit;','    s32 bit;\n    s32 magnitude = abs(value);').replace('if (value &','if (magnitude &')
  elif shape=='direct-parameter':helper=bit.replace('hsd_803B3CD8_bit_length','jpeg_category').replace('    s32 bit;','    s32 bit;\n\n    value = abs(value);')
  else:helper='static inline s32 jpeg_category(s32* value)\n{\n    return hsd_803B3CD8_bit_length(abs(*value));\n}\n\n'
  full=base[:b]+helper+base[b:]
  if sites in ('both','dc'):full=full.replace('hsd_803B3CD8_bit_length(abs(value))','jpeg_category('+('&' if shape=='out-magnitude' else '')+'value)',1 if False else 0) if False else full
  # Only replace calls in encoder body, keeping helper intact.
  f=full.index('void hsd_803B3CD8(s32 component)');e=full.index('static const s32 lbl_804DEB88',f);main=full[f:e]
  for value in (('value','ac_value') if sites=='both' else ('value',) if sites=='dc' else ('ac_value',)):
   main=main.replace('hsd_803B3CD8_bit_length(abs('+value+'))','jpeg_category('+('&' if shape=='out-magnitude' else '')+value+')')
  full=full[:f]+main+full[e:];e=full.index('static const s32 lbl_804DEB88',a)
  full=full[:a]+'#pragma push\n#pragma inline_depth(8)\n'+full[a:e]+'#pragma pop\n'+full[e:]
  vs[shape+'-'+sites]=full
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

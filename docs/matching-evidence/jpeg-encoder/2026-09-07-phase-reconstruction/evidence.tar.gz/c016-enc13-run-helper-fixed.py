from pathlib import Path
import subprocess,json,re
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc13-run-helper-fixed');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);fn=base[a:b]
start=fn.index('            length = hsd_803B3CD8_bit_length(run + 1);');end=fn.index('            length = hsd_803B3CD8_bit_length(abs(ac_value));',start);runbody=fn[start:end]
vs={}
for shape in ('count-param','run-param','count-local','run-pointer','state-count'):
 for outlength in (True,):
  params=['u16* code','u8* sizes','JpegWork* work'];args=['ac_code','ac_length','state.work'];locals='';body=runbody.replace('ac_code','code').replace('ac_length','sizes').replace('state.work','work')
  if shape=='count-param':params.insert(0,'s32 count');args.insert(0,'run + 1');body=body.replace('run + 1','count')
  if shape=='run-param':params.insert(0,'s32 run');args.insert(0,'run')
  if shape=='count-local':params.insert(0,'s32 run');args.insert(0,'run');locals+='    s32 count = run + 1;\n';body=body.replace('run + 1','count')
  if shape=='run-pointer':params.insert(0,'s32* run');args.insert(0,'&run');body=body.replace('run + 1','*run + 1')
  if shape=='state-count':params.insert(0,'s32 run');args.insert(0,'run');locals+='    struct { s32 count; } count_state;\n';body='    count_state.count = run + 1;\n'+body.replace('run + 1','count_state.count')
  if outlength:params.append('s32* length');args.append('&length');body=re.sub(r'\blength\b','(*length)',body)
  else:locals='    s32 length;\n'+locals
  helper='static inline void jpeg_encode_run('+', '.join(params)+')\n{\n'+locals+'\n'+body+'}\n\n'
  main=fn.replace(runbody,'            jpeg_encode_run('+', '.join(args)+');\n')
  full=base[:a]+helper+main+base[b:];h=full.index('static inline s32 hsd_803B3CD8_bit_length');e=full.index('static const s32 lbl_804DEB88',h)
  full=full[:h]+'#pragma push\n#pragma inline_depth(8)\n'+full[h:e]+'#pragma pop\n'+full[e:]
  vs[shape+('-out-length' if outlength else '-local-length')]=full
# Retain zero-run semantics outside the nonzero case, reuse it once it is dead.
for mode in ():
 main=fn
 if mode=='separate': main=main.replace(runbody,runbody.replace('            length =','            run++;\n            length =',1).replace('run + 1','run'))
 else:main=main.replace(runbody,runbody.replace('bit_length(run + 1)','bit_length(++run)').replace('write_bits(run + 1,','write_bits(run,'))
 vs['reuse-run-'+mode]=base[:a]+main+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1],'calls':sorted(set(l.split('\t')[-1] for l in asm if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc13-reuse-embedded');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base);vs={}
for name,ty in [('dc_code','u16*'),('dc_length','u8*'),('component','s32')]:
 s=Path('/tmp/c016-enc13-owner-reuse/'+name+'-copy.c').read_text();init='    '+name+' = ('+ty+') state.work;\n';assert init in s;s=s.replace(init,'')
 for site in ('for-init','lookup'):
  t=s
  if site=='for-init':t=t.replace('for (index = 1; index < 64; index++)','for ('+name+' = ('+ty+') state.work, index = 1; index < 64; index++)')
  else:t=t.replace('(s32*) ((JpegWork*) '+name+') + lbl_80431638[index]','(s32*) ((JpegWork*) ('+name+' = ('+ty+') state.work)) + lbl_80431638[index]')
  assert t!=s;vs[name+'-'+site]=t
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

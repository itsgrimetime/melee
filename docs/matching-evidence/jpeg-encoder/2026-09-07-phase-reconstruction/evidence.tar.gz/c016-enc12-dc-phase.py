from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc12-dc-phase');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);fn=base[a:b]
dcstart=fn.index('    value = state.work->data.coef[0]');dcend=fn.index('    for (index = 1;',dcstart);dc=fn[dcstart:dcend]
select='    dc_code = component == 0 ? lbl_80431678 : lbl_8043169C;\n    dc_length = component == 0 ? lbl_80431690 : lbl_804316B4;\n';vs={}
for owner in ('global','pointer','state-pointer'):
 for tables in ('caller','callee'):
  for runmode in ('caller','output'):
   params=['s32 component'];args=['component'];locals='    s32 value;\n    s32 length;\n';body=dc
   main=fn.replace('    s32 value;\n','')
   if owner=='global':
    locals+='    struct { JpegWork* work; } dc_state;\n';init='    dc_state.work = (JpegWork*) &hsd_804D2648;\n';body=body.replace('state.work','dc_state.work')
   elif owner=='pointer':
    params+=['JpegWork* work'];args+=['state.work'];init='';body=body.replace('state.work','work')
   else:
    params+=['const JpegEncoderState* state'];args+=['&state'];init='';body=body.replace('state.work','state->work');main=main.replace('    struct {\n        JpegWork* work;\n    } state;','    JpegEncoderState state;')
   if tables=='caller':params+=['u16* dc_code','u8* dc_length'];args+=['dc_code','dc_length']
   else:
    locals+='    u16* dc_code;\n    u8* dc_length;\n';init+=select;main=main.replace('    u16* dc_code;\n','').replace('    u8* dc_length;\n','').replace(select,'')
   if runmode=='output':params+=['s32* run'];args+=['&run'];body=body.replace('    run = 0;','    *run = 0;');runinit=''
   else:body=body.replace('    run = 0;\n','');runinit='    run = 0;\n'
   call=runinit+'    jpeg_encode_dc('+', '.join(args)+');\n'
   main=main.replace(dc,call)
   helper='static inline void jpeg_encode_dc('+', '.join(params)+')\n{\n'+locals+'\n'+init+body+'}\n\n'
   typedef='typedef struct JpegEncoderState { JpegWork* work; } JpegEncoderState;\n\n' if owner=='state-pointer' else ''
   full=base[:a]+typedef+helper+main+base[b:]
   h=full.index('static inline s32 hsd_803B3CD8_bit_length');e=full.index('static const s32 lbl_804DEB88',h)
   full=full[:h]+'#pragma push\n#pragma inline_depth(8)\n'+full[h:e]+'#pragma pop\n'+full[e:]
   vs[f'{owner}-tables-{tables}-run-{runmode}']=full
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'calls':sorted(set(l.split('\t')[-1] for l in x['current_asm'] if 'R_PPC_REL24' in l))}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base)

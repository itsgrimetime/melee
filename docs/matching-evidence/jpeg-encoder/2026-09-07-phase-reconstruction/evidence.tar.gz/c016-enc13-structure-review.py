from pathlib import Path
import json,subprocess,hashlib
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc13-structure-scored');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
rows=[];seen=set()
try:
 for v in json.load(open('/tmp/c016-enc13-structure.json'))['variants']:
  name=v['label'];full=Path(v['path']).read_text();digest=hashlib.sha256(full.encode()).hexdigest()
  if name in ('block-scope-0','declaration-use-distance-0'):
   rows.append({'name':name,'score':None,'review':'rejected-invalid-C-struct-member-treated-as-local'});continue
  if digest in seen:rows.append({'name':name,'score':None,'review':'duplicate-generated-source'});continue
  seen.add(digest);p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count')}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);print(row,flush=True)
finally:p.write_text(base);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n')

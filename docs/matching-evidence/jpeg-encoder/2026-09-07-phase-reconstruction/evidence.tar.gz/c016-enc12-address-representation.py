from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');base=p.read_text();root=Path('/tmp/c016-enc12-address-representation');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);fn=base[a:b];decl='    struct {\n        JpegWork* work;\n    } state;';init='    state.work = (JpegWork*) &hsd_804D2648;\n';vs={}
for fieldorder in ('pointer-first','integer-first'):
 fields='JpegWork* work; u32 address;' if fieldorder=='pointer-first' else 'u32 address; JpegWork* work;'
 for direction in ('write-integer','read-integer'):
  s=fn.replace(decl,'    union { '+fields+' } state;')
  if direction=='write-integer':s=s.replace(init,'    state.address = (u32) &hsd_804D2648;\n')
  else:
   s=s.replace(init,'    state.work = (JpegWork*) &hsd_804D2648;\n',1)
   k=s.index('    tables =');s=s[:k]+s[k:].replace('state.work','((JpegWork*) state.address)')
  vs['union-'+fieldorder+'-'+direction]=base[:a]+s+base[b:]
for shape in ('scalar','aggregate'):
 if shape=='scalar':s=fn.replace(decl,'    static JpegWork* const work = (JpegWork*) &hsd_804D2648;').replace(init,'').replace('state.work','work')
 else:s=fn.replace(decl,'    static const struct { JpegWork* work; } state = { (JpegWork*) &hsd_804D2648 };').replace(init,'')
 vs['static-const-'+shape]=base[:a]+s+base[b:]
rows=[]
try:
 for name,full in vs.items():
  p.write_text(full);(root/(name+'.c')).write_text(full)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'entry':x['current_asm'][:22]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print({k:v for k,v in row.items() if k!='entry'},flush=True)
finally:p.write_text(base)

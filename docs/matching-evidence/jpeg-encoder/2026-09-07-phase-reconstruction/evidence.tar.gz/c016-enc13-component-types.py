from pathlib import Path
import subprocess,json
p=Path('src/sysdolphin/baselib/hsd_3B34.c');h=Path('src/sysdolphin/baselib/hsd_3B34.h');base=p.read_text();head=h.read_text();root=Path('/tmp/c016-enc13-component-types');root.mkdir(exist_ok=True);(root/'baseline.c').write_text(base);(root/'baseline.h').write_text(head)
a=base.index('void hsd_803B3CD8(s32 component)');b=base.index('static const s32 lbl_804DEB88',a);fn=base[a:b];vs={}
for name,ty in [('int','int'),('unsigned-int','unsigned int'),('u32','u32'),('enum','JpegComponent')]:
 newhead=head.replace('hsd_803B3CD8(s32)','hsd_803B3CD8('+ty+')')
 if name=='enum':newhead=newhead.replace('/* 3B3CD8 */','typedef enum JpegComponent { JPEG_LUMA, JPEG_CB, JPEG_CR } JpegComponent;\n\n/* 3B3CD8 */')
 for signedtest in ((False,True) if name in ('unsigned-int','u32') else (False,)):
  main=fn.replace('(s32 component)','('+ty+' component)')
  if signedtest:main=main.replace('component == 0','(s32) component == 0')
  vs[name+('-signed-test' if signedtest else '')]=(base[:a]+main+base[b:],newhead)
rows=[]
try:
 for name,(full,header) in vs.items():
  p.write_text(full);h.write_text(header);(root/(name+'.c')).write_text(full);(root/(name+'.h')).write_text(header)
  r=subprocess.run(['python','tools/checkdiff.py','hsd_803B3CD8','--no-tty','--format','json'],capture_output=True,text=True,timeout=90)
  (root/(name+'.json')).write_text(r.stdout);(root/(name+'.log')).write_text(r.stderr)
  try:
   x=json.loads(r.stdout);asm=x['current_asm'];i=next(i for i,l in enumerate(asm) if 'R_PPC_ADDR16_LO\thsd_804D2648' in l)
   row={'name':name,'score':x['fuzzy_match_percent'],'frame':x['classification']['stack_frame_sizes'],'structural':x['structural'],'regdiff':x['classification'].get('register_allocation_guidance',{}).get('register_only_count'),'work_load':asm[i-1]}
  except Exception:row={'name':name,'score':None,'exit':r.returncode}
  rows.append(row);(root/'results.json').write_text(json.dumps(rows,indent=2)+'\n');print(row,flush=True)
finally:p.write_text(base);h.write_text(head)

from pathlib import Path
import json,hashlib,tarfile
root=Path('docs/matching-evidence/jpeg-encoder/2026-09-07-phase-reconstruction');root.mkdir(parents=True,exist_ok=True);files={};rows=[]
families=['c016-enc12-dc-phase','c016-enc12-address-representation','c016-enc13-run-helper','c016-enc13-run-helper-fixed','c016-enc13-category-helper','c016-enc13-component-types','c016-enc13-owner-reuse','c016-enc13-reuse-embedded','c016-enc13-structure-scored']
for family in families:
 d=Path('/tmp')/family;rows.extend({'family':family,**r} for r in json.loads((d/'results.json').read_text()))
 for p in d.rglob('*'):
  if p.is_file():files[str(p.relative_to('/tmp'))]=p
 p=Path('/tmp')/(family+'.py')
 if p.exists():files[p.name]=p
for p in Path('/tmp/c016-enc13-structure').rglob('*'):
 if p.is_file():files[str(p.relative_to('/tmp'))]=p
for name in ['c016-enc13-structure-review.py','c016-enc13-structure.json','c016-enc12-pr2479.json','c016-enc12-pr2479.diff','c016-enc13-pr3377.json','c016-enc13-kar-tree.txt','c016-enc13-code-search.json','c016-enc13-final.json','c016-enc13-final.log','c016-enc13-build.log','c016-enc13-upstream-merge.log','c016-enc13-archive.py']:
 p=Path('/tmp')/name;files[name]=p
x=json.load(open('/tmp/c016-enc13-final.json'));assert x['fuzzy_match_percent']==99.70266
summary={'function':'hsd_803B3CD8','retained_percent':x['fuzzy_match_percent'],'retained_source_sha256':hashlib.sha256(Path('src/sysdolphin/baselib/hsd_3B34.c').read_bytes()).hexdigest(),'compile_attempts':sum('review' not in r for r in rows),'valid_compiles':sum(r.get('score') is not None for r in rows),'invalid_generator_compiles':sum(r.get('score') is None and 'review' not in r for r in rows),'review_rejections':sum(r.get('review','').startswith('rejected-') for r in rows),'duplicate_sources_skipped':sum(r.get('review','').startswith('duplicate-') for r in rows),'source_changes_retained':False,'source100':False,'validation':{'frame':104,'register_only_differences':38,'instruction_count':639,'full_build':'exit0','matched_neighbors':6},'tool_issue':1534,'upstream_merge':'4ae0cedc4c','upstream_head':'7f97c7afe0','pr3377_head':'5d8814c18093525f573011ff5e37e97020d3c655','research_scope':'PR2479 is a regressing standard-JPEG rewrite. Public code search and inspected KAR tree supplied no new encoder body; this is not an exhaustive donor verdict.'}
(root/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');archive=root/'evidence.tar.gz'
with tarfile.open(archive,'w:gz') as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name)
manifest={'summary':summary,'runs':rows,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':{n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in sorted(files.items())}}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive) as t:
 for n,digest in manifest['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==digest
print(summary);print(len(files),'verified members;',archive.stat().st_size,'bytes')
